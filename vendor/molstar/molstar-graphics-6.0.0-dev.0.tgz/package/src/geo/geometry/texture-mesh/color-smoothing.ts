/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { setColorType } from '../color-data.js';
import { setEmissiveType } from '../emissive-data.js';
import { setOverpaintType } from '../overpaint-data.js';
import { setSubstanceType } from '../substance-data.js';
import { setTransparencyType } from '../transparency-data.js';
import { ValueCell } from '@molstar/core/util';
import { createComputeRenderable, type ComputeRenderable } from '@molstar/graphics/gl/renderable';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { RenderState } from '@molstar/graphics/gl/render-state';
import { isNullTexture, type Texture } from '@molstar/graphics/gl/texture';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import {
  ValueSpec,
  AttributeSpec,
  UniformSpec,
  TextureSpec,
  type Values,
  DefineSpec,
} from '@molstar/graphics/gl/renderable/schema';
import { QuadSchema, QuadValues } from '@molstar/graphics/gl/compute/util';
import { Mat4, Vec2, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import { Box3D, type Sphere3D } from '@molstar/core/math/geometry';
import type { TextureMeshValues } from '@molstar/graphics/gl/renderable/texture-mesh';
import { TextureMesh } from './texture-mesh.js';
import { isTimingMode } from '@molstar/core/util/debug';
import { computeColorSmoothing, isComputeColorSmoothingSupported } from '@molstar/graphics/gl/compute/color-smoothing';
import type { StorageBuffer } from '@molstar/graphics/gl/compute';

export const ColorAccumulateSchema = {
  drawCount: ValueSpec('number'),
  instanceCount: ValueSpec('number'),
  stride: ValueSpec('number'),

  uGroupCount: UniformSpec('i', 'material'),

  aTransform: AttributeSpec('float32', 16, 1),
  aInstance: AttributeSpec('float32', 1, 1),
  aSample: AttributeSpec('float32', 1, 0),

  uGeoTexDim: UniformSpec('v2', 'material'),
  tPosition: TextureSpec('texture', 'rgba', 'float', 'nearest', 'material'),
  tGroup: TextureSpec('texture', 'rgba', 'float', 'nearest', 'material'),

  uColorTexDim: UniformSpec('v2', 'material'),
  tColor: TextureSpec('texture', 'rgba', 'ubyte', 'nearest', 'material'),
  dColorType: DefineSpec('string', ['group', 'groupInstance', 'vertex', 'vertexInstance']),

  uCurrentSlice: UniformSpec('f'),
  uCurrentX: UniformSpec('f'),
  uCurrentY: UniformSpec('f'),
  uBboxMin: UniformSpec('v3', 'material'),
  uBboxSize: UniformSpec('v3', 'material'),
  uResolution: UniformSpec('f', 'material'),
};
export const ColorAccumulateShaderCode = ShaderCode('color-smoothing-accumulate', {
  drawBuffers: 'required',
});
type ColorAccumulateValues = Values<typeof ColorAccumulateSchema>;
const ColorAccumulateName = 'color-accumulate';
const ColorCountName = 'color-count';

interface AccumulateInput {
  /** an upper bound for vertices in the vertex arena (`chunks`) */
  vertexCount: number;
  instanceCount: number;
  groupCount: number;
  transformBuffer: Float32Array;
  instanceBuffer: Float32Array;
  positionTexture: Texture;
  groupTexture: Texture;
  /** the page table and positions of a surface in the vertex arena (WebGPU), instead of the textures; smoothed with
   * compute kernels */
  chunks?: { table: StorageBuffer; positions: StorageBuffer };
  colorData: Texture;
  colorType: 'group' | 'groupInstance';
}

/** The vertices in pages of the vertex arena, see `TextureMesh.isoChunks` */
function getChunks(values: TextureMeshValues): AccumulateInput['chunks'] {
  const table = values.sIsoTable.ref.value;
  const positions = values.sIsoPositions.ref.value;
  return values.dIsoChunks.ref.value && table && positions ? { table, positions } : undefined;
}

function getSampleBuffer(sampleCount: number, stride: number) {
  const sampleBuffer = new Float32Array(sampleCount);
  for (let i = 0; i < sampleCount; ++i) {
    sampleBuffer[i] = i * stride;
  }
  return sampleBuffer;
}

function getAccumulateRenderable(
  ctx: GraphicsContext,
  input: AccumulateInput,
  box: Box3D,
  resolution: number,
  stride: number,
): ComputeRenderable<ColorAccumulateValues> {
  if (ctx.namedComputeRenderables[ColorAccumulateName]) {
    const extent = Vec3.sub(Vec3(), box.max, box.min);
    const v = ctx.namedComputeRenderables[ColorAccumulateName].values as ColorAccumulateValues;

    const sampleCount = Math.round(input.vertexCount / stride);
    if (sampleCount > v.drawCount.ref.value || stride !== v.stride.ref.value) {
      ValueCell.update(v.aSample, getSampleBuffer(sampleCount, stride));
    }

    ValueCell.updateIfChanged(v.drawCount, sampleCount);
    ValueCell.updateIfChanged(v.instanceCount, input.instanceCount);
    ValueCell.updateIfChanged(v.stride, stride);

    ValueCell.updateIfChanged(v.uGroupCount, input.groupCount);

    ValueCell.update(v.aTransform, input.transformBuffer);
    ValueCell.update(v.aInstance, input.instanceBuffer);

    ValueCell.update(
      v.uGeoTexDim,
      Vec2.set(v.uGeoTexDim.ref.value, input.positionTexture.getWidth(), input.positionTexture.getHeight()),
    );
    ValueCell.update(v.tPosition, input.positionTexture);
    ValueCell.update(v.tGroup, input.groupTexture);

    ValueCell.update(
      v.uColorTexDim,
      Vec2.set(v.uColorTexDim.ref.value, input.colorData.getWidth(), input.colorData.getHeight()),
    );
    ValueCell.update(v.tColor, input.colorData);
    ValueCell.updateIfChanged(v.dColorType, input.colorType);

    ValueCell.updateIfChanged(v.uCurrentSlice, 0);
    ValueCell.updateIfChanged(v.uCurrentX, 0);
    ValueCell.updateIfChanged(v.uCurrentY, 0);
    ValueCell.update(v.uBboxMin, box.min);
    ValueCell.update(v.uBboxSize, extent);
    ValueCell.updateIfChanged(v.uResolution, resolution);

    ctx.namedComputeRenderables[ColorAccumulateName].update();
  } else {
    ctx.namedComputeRenderables[ColorAccumulateName] = createAccumulateRenderable(ctx, input, box, resolution, stride);
  }
  return ctx.namedComputeRenderables[ColorAccumulateName];
}

function createAccumulateRenderable(
  ctx: GraphicsContext,
  input: AccumulateInput,
  box: Box3D,
  resolution: number,
  stride: number,
) {
  const extent = Vec3.sub(Vec3(), box.max, box.min);
  const sampleCount = Math.round(input.vertexCount / stride);

  const values: ColorAccumulateValues = {
    drawCount: ValueCell.create(sampleCount),
    instanceCount: ValueCell.create(input.instanceCount),
    stride: ValueCell.create(stride),

    uGroupCount: ValueCell.create(input.groupCount),

    aTransform: ValueCell.create(input.transformBuffer),
    aInstance: ValueCell.create(input.instanceBuffer),
    aSample: ValueCell.create(getSampleBuffer(sampleCount, stride)),

    uGeoTexDim: ValueCell.create(Vec2.create(input.positionTexture.getWidth(), input.positionTexture.getHeight())),
    tPosition: ValueCell.create(input.positionTexture),
    tGroup: ValueCell.create(input.groupTexture),

    uColorTexDim: ValueCell.create(Vec2.create(input.colorData.getWidth(), input.colorData.getHeight())),
    tColor: ValueCell.create(input.colorData),
    dColorType: ValueCell.create(input.colorType),

    uCurrentSlice: ValueCell.create(0),
    uCurrentX: ValueCell.create(0),
    uCurrentY: ValueCell.create(0),
    uBboxMin: ValueCell.create(box.min),
    uBboxSize: ValueCell.create(extent),
    uResolution: ValueCell.create(resolution),
  };

  const schema = { ...ColorAccumulateSchema };
  const renderItem = ctx.createComputeRenderItem('points', ColorAccumulateShaderCode, schema, values);

  return createComputeRenderable(renderItem, values);
}

//

export const ColorNormalizeSchema = {
  ...QuadSchema,

  tColor: TextureSpec('texture', 'rgba', 'float', 'nearest'),
  tCount: TextureSpec('texture', 'r', 'float', 'nearest'),
  uTexSize: UniformSpec('v2'),
};
export const ColorNormalizeShaderCode = ShaderCode('normalize');
type ColorNormalizeValues = Values<typeof ColorNormalizeSchema>;
const ColorNormalizeName = 'color-normalize';

function getNormalizeRenderable(
  ctx: GraphicsContext,
  color: Texture,
  count: Texture,
): ComputeRenderable<ColorNormalizeValues> {
  if (ctx.namedComputeRenderables[ColorNormalizeName]) {
    const v = ctx.namedComputeRenderables[ColorNormalizeName].values as ColorNormalizeValues;

    ValueCell.update(v.tColor, color);
    ValueCell.update(v.tCount, count);
    ValueCell.update(v.uTexSize, Vec2.set(v.uTexSize.ref.value, color.getWidth(), color.getHeight()));

    ctx.namedComputeRenderables[ColorNormalizeName].update();
  } else {
    ctx.namedComputeRenderables[ColorNormalizeName] = createColorNormalizeRenderable(ctx, color, count);
  }
  return ctx.namedComputeRenderables[ColorNormalizeName];
}

function createColorNormalizeRenderable(ctx: GraphicsContext, color: Texture, count: Texture) {
  const values: ColorNormalizeValues = {
    ...QuadValues,
    tColor: ValueCell.create(color),
    tCount: ValueCell.create(count),
    uTexSize: ValueCell.create(Vec2.create(color.getWidth(), color.getHeight())),
  };

  const schema = { ...ColorNormalizeSchema };
  const renderItem = ctx.createComputeRenderItem('triangles', ColorNormalizeShaderCode, schema, values);

  return createComputeRenderable(renderItem, values);
}

//

function getTexture2dSize(gridDim: Vec3) {
  const area = gridDim[0] * gridDim[1] * gridDim[2];
  const squareDim = Math.sqrt(area);
  const powerOfTwoSize = Math.pow(2, Math.ceil(Math.log(squareDim) / Math.log(2)));

  let texDimX = 0;
  let texDimY = gridDim[1];
  let texRows = 1;
  let texCols = gridDim[2];
  if (powerOfTwoSize < gridDim[0] * gridDim[2]) {
    texCols = Math.floor(powerOfTwoSize / gridDim[0]);
    texRows = Math.ceil(gridDim[2] / texCols);
    texDimX = texCols * gridDim[0];
    texDimY *= texRows;
  } else {
    texDimX = gridDim[0] * gridDim[2];
  }
  // console.log(texDimX, texDimY, texDimY < powerOfTwoSize ? powerOfTwoSize : powerOfTwoSize * 2);
  return {
    texDimX,
    texDimY,
    texRows,
    texCols,
    powerOfTwoSize: texDimY < powerOfTwoSize ? powerOfTwoSize : powerOfTwoSize * 2,
  };
}

interface ColorSmoothingInput extends AccumulateInput {
  boundingSphere: Sphere3D;
  invariantBoundingSphere: Sphere3D;
}

export type ColorSmoothingOptions = {
  resolution: number;
  stride: number;
};

/** Grid of the smoothing: the box expanded by `1 + resolution`, two extra cells per axis */
export function getGridDim(box: Box3D, resolution: number) {
  const pad = 1 + resolution;
  const expandedBox = Box3D.expand(Box3D(), box, Vec3.create(pad, pad, pad));
  const gridDim = Box3D.size(Vec3(), Box3D.scale(Box3D(), expandedBox, 1 / resolution));
  Vec3.ceil(gridDim, gridDim);
  return Vec3.add(gridDim, gridDim, Vec3.create(2, 2, 2));
}

/**
 * `resolution`, coarsened in steps of 10% until the 2d atlas of the grid (largest side by `getTextureSide`) fits
 * textures of `maxTextureSize` (larger grids would fail to allocate; WebGPU's limit is often half of WebGL's)
 */
export function getFittingResolution(
  box: Box3D,
  resolution: number,
  maxTextureSize: number,
  getTextureSide: (gridDim: Vec3) => number,
) {
  while (getTextureSide(getGridDim(box, resolution)) > maxTextureSize) resolution *= 1.1;
  return resolution;
}

export function calcTextureMeshColorSmoothing(
  input: ColorSmoothingInput,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  texture?: Texture,
) {
  // a texture of another context (e.g. before a backend switch) is not reused
  if (texture && !graphics.resources.ownsTexture(texture)) texture = undefined;
  const { chunks } = input;
  const useCompute = !!chunks && isComputeColorSmoothingSupported(graphics);
  if (!useCompute && !graphics.capabilities.multipleRenderTargets) throw new Error('need multiple render targets');

  if (isTimingMode) graphics.timer.group('calcTextureMeshColorSmoothing');
  const {
    resources,
    capabilities: { halfFloatRenderTarget, mixedAttachmentFormats },
  } = graphics;
  const { stride } = options;

  const isInstanceType = input.colorType.endsWith('Instance');
  const box = Box3D.fromSphere3D(Box3D(), isInstanceType ? input.boundingSphere : input.invariantBoundingSphere);
  const resolution = getFittingResolution(box, options.resolution, resources.limits.maxTextureSize, (gridDim) => {
    const { texDimX, texDimY } = getTexture2dSize(gridDim);
    return Math.max(texDimX, texDimY);
  });
  const pad = 1 + resolution;
  const expandedBox = Box3D.expand(Box3D(), box, Vec3.create(pad, pad, pad));

  if (!isInstanceType) {
    input.instanceCount = 1;
    input.instanceBuffer = new Float32Array([0]);
    input.transformBuffer = new Float32Array(Mat4.id);
  }

  const scaleFactor = 1 / resolution;
  const gridDim = getGridDim(box, resolution);
  const { min } = expandedBox;

  const [dx, dy, dz] = gridDim;
  const { texDimX: width, texDimY: height, texCols } = getTexture2dSize(gridDim);
  // console.log({ width, height, texCols, gridDim, resolution });
  const gridTransform = Vec4.create(min[0], min[1], min[2], scaleFactor);
  const type = isInstanceType ? 'volumeInstance' : 'volume';

  if (useCompute) {
    if (!texture || isNullTexture(texture)) {
      texture = resources.texture('image-uint8', 'rgba', 'ubyte', 'linear');
    }
    const bboxSize = Box3D.size(Vec3(), expandedBox);
    computeColorSmoothing(
      graphics.compute,
      { ...input, chunks, stride },
      { gridDim, texCols, width, height, bboxMin: min, bboxSize, resolution },
      texture,
    );
    if (isTimingMode) graphics.timer.groupEnd('calcTextureMeshColorSmoothing');
    return { texture, gridDim, gridTexDim: Vec2.create(width, height), gridTransform, type };
  }

  if (!graphics.namedFramebuffers[ColorAccumulateName]) {
    graphics.namedFramebuffers[ColorAccumulateName] = graphics.resources.framebuffer();
  }
  const framebuffer = graphics.namedFramebuffers[ColorAccumulateName];

  if (mixedAttachmentFormats) {
    if (!graphics.namedTextures[ColorAccumulateName]) {
      graphics.namedTextures[ColorAccumulateName] = halfFloatRenderTarget
        ? resources.texture('image-float16', 'rgba', 'fp16', 'nearest')
        : resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }

    if (!graphics.namedTextures[ColorCountName]) {
      graphics.namedTextures[ColorCountName] = resources.texture('image-float32', 'r', 'float', 'nearest');
    }
  } else {
    // webgl1 requires consistent bit plane counts
    // this is quite wasteful but good enough for medium size meshes

    if (!graphics.namedTextures[ColorAccumulateName]) {
      graphics.namedTextures[ColorAccumulateName] = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }

    if (!graphics.namedTextures[ColorCountName]) {
      graphics.namedTextures[ColorCountName] = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }
  }

  const accumulateTexture = graphics.namedTextures[ColorAccumulateName];
  const countTexture = graphics.namedTextures[ColorCountName];

  accumulateTexture.define(width, height);
  countTexture.define(width, height);

  accumulateTexture.attachFramebuffer(framebuffer, 0);
  countTexture.attachFramebuffer(framebuffer, 1);

  const accumulateRenderable = getAccumulateRenderable(graphics, input, expandedBox, resolution, stride);

  framebuffer.setDrawBuffers(2);
  graphics.beginRenderPass(framebuffer, { label: 'color accumulate' });

  const { uCurrentSlice, uCurrentX, uCurrentY } = accumulateRenderable.values;

  graphics.setRenderState(RenderState.Additive);
  graphics.setViewport(0, 0, width, height);
  graphics.setScissor(0, 0, width, height);
  graphics.clear({ color: [0, 0, 0, 0] });
  ValueCell.update(uCurrentY, 0);
  let currCol = 0;
  let currY = 0;
  let currX = 0;
  for (let i = 0; i < dz; ++i) {
    if (currCol >= texCols) {
      currCol -= texCols;
      currY += dy;
      currX = 0;
      ValueCell.update(uCurrentY, currY);
    }
    // console.log({ i, currX, currY });
    ValueCell.update(uCurrentX, currX);
    ValueCell.update(uCurrentSlice, i);
    // tiles at texel rows from the bottom (`uCurrentY`), rectangles have a top-left origin
    const tileY = height - currY - dy;
    graphics.setViewport(currX, tileY, dx, dy);
    graphics.setScissor(currX, tileY, dx, dy);
    accumulateRenderable.render();
    ++currCol;
    currX += dx;
  }

  accumulateTexture.detachFramebuffer(framebuffer, 0);
  countTexture.detachFramebuffer(framebuffer, 1);
  framebuffer.setDrawBuffers(1);

  // const accImage = new Float32Array(width * height * 4);
  // accumulateTexture.attachFramebuffer(framebuffer, 0);
  // webgl.readPixels(0, 0, width, height, accImage);
  // console.log(accImage);
  // printTextureImage({ array: accImage, width, height }, { scale: 1 });

  // const cntImage = new Float32Array(width * height * 4);
  // countTexture.attachFramebuffer(framebuffer, 0);
  // webgl.readPixels(0, 0, width, height, cntImage);
  // console.log(cntImage);
  // printTextureImage({ array: cntImage, width, height }, { scale: 1 });

  // normalize

  if (!texture || isNullTexture(texture)) {
    texture = resources.texture('image-uint8', 'rgba', 'ubyte', 'linear');
  }
  texture.define(width, height);

  const normalizeRenderable = getNormalizeRenderable(graphics, accumulateTexture, countTexture);

  graphics.setRenderState(RenderState.Additive);
  texture.attachFramebuffer(framebuffer, 0);
  graphics.beginRenderPass(framebuffer, { label: 'color normalize' });
  graphics.setViewport(0, 0, width, height);
  graphics.setScissor(0, 0, width, height);
  graphics.clear({ color: [0, 0, 0, 0] });
  normalizeRenderable.render();

  // const normImage = new Uint8Array(width * height * 4);
  // texture.attachFramebuffer(framebuffer, 0);
  // webgl.readPixels(0, 0, width, height, normImage);
  // console.log(normImage);
  // printTextureImage({ array: normImage, width, height }, { scale: 1 });

  if (isTimingMode) graphics.timer.groupEnd('calcTextureMeshColorSmoothing');

  // printTextureImage(readTexture(webgl, texture), { scale: 0.75, id: `${texture.id}` });

  return { texture, gridDim, gridTexDim: Vec2.create(width, height), gridTransform, type };
}

//

const ColorSmoothingColorName = 'color-smoothing-color';
const ColorSmoothingRgbaName = 'color-smoothing-rgba';
const ColorSmoothingAlphaName = 'color-smoothing-alpha';

function isSupportedColorType(x: string): x is 'group' | 'groupInstance' {
  return x === 'group' || x === 'groupInstance';
}

/**
 * Runs `run` again when the vertices of the texture mesh changed after it ran (extracted again, or more than its upper
 * bound, see `computeTextureMeshIsosurface`): smoothing samples the vertices, which were incomplete before
 */
function setReextractionHandler(values: TextureMeshValues, key: string, run: () => void) {
  TextureMesh.setReextractionHandler(values.meta.ref.value as TextureMesh['meta'], key, run);
}

export function applyTextureMeshColorSmoothing(
  values: TextureMeshValues,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  colorTexture?: Texture,
) {
  if (!isSupportedColorType(values.colorType.ref.value)) return;
  const type = values.colorType.ref.value;

  const run = () => {
    const tripled = { ...options, stride: options.stride * 3 }; // triple because TextureMesh is never indexed (no elements buffer)

    if (!graphics.namedTextures[ColorSmoothingColorName]) {
      graphics.namedTextures[ColorSmoothingColorName] = graphics.resources.texture(
        'image-uint8',
        'rgba',
        'ubyte',
        'nearest',
      );
    }
    const colorData = graphics.namedTextures[ColorSmoothingColorName];
    colorData.load(values.tColor.ref.value);

    const smoothingData = calcTextureMeshColorSmoothing(
      {
        vertexCount: values.uVertexCount.ref.value,
        instanceCount: values.uInstanceCount.ref.value,
        groupCount: values.uGroupCount.ref.value,
        transformBuffer: values.aTransform.ref.value,
        instanceBuffer: values.aInstance.ref.value,
        positionTexture: values.tPosition.ref.value,
        groupTexture: values.tGroup.ref.value,
        chunks: getChunks(values),
        colorData,
        colorType: type,
        boundingSphere: values.boundingSphere.ref.value,
        invariantBoundingSphere: values.invariantBoundingSphere.ref.value,
      },
      tripled,
      graphics,
      colorTexture,
    );

    // reused when run again
    colorTexture = smoothingData.texture;
    setColorType(values, smoothingData.type);
    ValueCell.update(values.tColorGrid, smoothingData.texture);
    ValueCell.update(values.uColorTexDim, smoothingData.gridTexDim);
    ValueCell.update(values.uColorGridDim, smoothingData.gridDim);
    ValueCell.update(values.uColorGridTransform, smoothingData.gridTransform);
  };
  run();
  // unless no longer smoothed
  setReextractionHandler(values, 'color', () => {
    if (values.colorType.ref.value.startsWith('volume')) run();
  });
}

function isSupportedOverpaintType(x: string): x is 'groupInstance' {
  return x === 'groupInstance';
}

export function applyTextureMeshOverpaintSmoothing(
  values: TextureMeshValues,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  colorTexture?: Texture,
) {
  if (!isSupportedOverpaintType(values.overpaintType.ref.value)) return;
  const type = values.overpaintType.ref.value;

  const run = () => {
    const tripled = { ...options, stride: options.stride * 3 }; // triple because TextureMesh is never indexed (no elements buffer)

    if (!graphics.namedTextures[ColorSmoothingRgbaName]) {
      graphics.namedTextures[ColorSmoothingRgbaName] = graphics.resources.texture(
        'image-uint8',
        'rgba',
        'ubyte',
        'nearest',
      );
    }
    const colorData = graphics.namedTextures[ColorSmoothingRgbaName];
    colorData.load(values.tOverpaint.ref.value);

    const smoothingData = calcTextureMeshColorSmoothing(
      {
        vertexCount: values.uVertexCount.ref.value,
        instanceCount: values.uInstanceCount.ref.value,
        groupCount: values.uGroupCount.ref.value,
        transformBuffer: values.aTransform.ref.value,
        instanceBuffer: values.aInstance.ref.value,
        positionTexture: values.tPosition.ref.value,
        groupTexture: values.tGroup.ref.value,
        chunks: getChunks(values),
        colorData,
        colorType: type,
        boundingSphere: values.boundingSphere.ref.value,
        invariantBoundingSphere: values.invariantBoundingSphere.ref.value,
      },
      tripled,
      graphics,
      colorTexture,
    );

    // reused when run again
    colorTexture = smoothingData.texture;
    setOverpaintType(values, smoothingData.type);
    ValueCell.update(values.tOverpaintGrid, smoothingData.texture);
    ValueCell.update(values.uOverpaintTexDim, smoothingData.gridTexDim);
    ValueCell.update(values.uOverpaintGridDim, smoothingData.gridDim);
    ValueCell.update(values.uOverpaintGridTransform, smoothingData.gridTransform);
  };
  run();
  // unless no longer smoothed
  setReextractionHandler(values, 'overpaint', () => {
    if (values.overpaintType.ref.value.startsWith('volume')) run();
  });
}

function isSupportedTransparencyType(x: string): x is 'groupInstance' {
  return x === 'groupInstance';
}

export function applyTextureMeshTransparencySmoothing(
  values: TextureMeshValues,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  colorTexture?: Texture,
) {
  if (!isSupportedTransparencyType(values.transparencyType.ref.value)) return;
  const type = values.transparencyType.ref.value;

  const run = () => {
    const tripled = { ...options, stride: options.stride * 3 }; // triple because TextureMesh is never indexed (no elements buffer)

    if (!graphics.namedTextures[ColorSmoothingAlphaName]) {
      graphics.namedTextures[ColorSmoothingAlphaName] = graphics.resources.texture(
        'image-uint8',
        'r',
        'ubyte',
        'nearest',
      );
    }
    const colorData = graphics.namedTextures[ColorSmoothingAlphaName];
    colorData.load(values.tTransparency.ref.value);

    const smoothingData = calcTextureMeshColorSmoothing(
      {
        vertexCount: values.uVertexCount.ref.value,
        instanceCount: values.uInstanceCount.ref.value,
        groupCount: values.uGroupCount.ref.value,
        transformBuffer: values.aTransform.ref.value,
        instanceBuffer: values.aInstance.ref.value,
        positionTexture: values.tPosition.ref.value,
        groupTexture: values.tGroup.ref.value,
        chunks: getChunks(values),
        colorData,
        colorType: type,
        boundingSphere: values.boundingSphere.ref.value,
        invariantBoundingSphere: values.invariantBoundingSphere.ref.value,
      },
      tripled,
      graphics,
      colorTexture,
    );

    // reused when run again
    colorTexture = smoothingData.texture;
    setTransparencyType(values, smoothingData.type);
    ValueCell.update(values.tTransparencyGrid, smoothingData.texture);
    ValueCell.update(values.uTransparencyTexDim, smoothingData.gridTexDim);
    ValueCell.update(values.uTransparencyGridDim, smoothingData.gridDim);
    ValueCell.update(values.uTransparencyGridTransform, smoothingData.gridTransform);
  };
  run();
  // unless no longer smoothed
  setReextractionHandler(values, 'transparency', () => {
    if (values.transparencyType.ref.value.startsWith('volume')) run();
  });
}

function isSupportedEmissiveType(x: string): x is 'groupInstance' {
  return x === 'groupInstance';
}

export function applyTextureMeshEmissiveSmoothing(
  values: TextureMeshValues,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  colorTexture?: Texture,
) {
  if (!isSupportedEmissiveType(values.emissiveType.ref.value)) return;
  const type = values.emissiveType.ref.value;

  const run = () => {
    const tripled = { ...options, stride: options.stride * 3 }; // triple because TextureMesh is never indexed (no elements buffer)

    if (!graphics.namedTextures[ColorSmoothingAlphaName]) {
      graphics.namedTextures[ColorSmoothingAlphaName] = graphics.resources.texture(
        'image-uint8',
        'r',
        'ubyte',
        'nearest',
      );
    }
    const colorData = graphics.namedTextures[ColorSmoothingAlphaName];
    colorData.load(values.tEmissive.ref.value);

    const smoothingData = calcTextureMeshColorSmoothing(
      {
        vertexCount: values.uVertexCount.ref.value,
        instanceCount: values.uInstanceCount.ref.value,
        groupCount: values.uGroupCount.ref.value,
        transformBuffer: values.aTransform.ref.value,
        instanceBuffer: values.aInstance.ref.value,
        positionTexture: values.tPosition.ref.value,
        groupTexture: values.tGroup.ref.value,
        chunks: getChunks(values),
        colorData,
        colorType: type,
        boundingSphere: values.boundingSphere.ref.value,
        invariantBoundingSphere: values.invariantBoundingSphere.ref.value,
      },
      tripled,
      graphics,
      colorTexture,
    );

    // reused when run again
    colorTexture = smoothingData.texture;
    setEmissiveType(values, smoothingData.type);
    ValueCell.update(values.tEmissiveGrid, smoothingData.texture);
    ValueCell.update(values.uEmissiveTexDim, smoothingData.gridTexDim);
    ValueCell.update(values.uEmissiveGridDim, smoothingData.gridDim);
    ValueCell.update(values.uEmissiveGridTransform, smoothingData.gridTransform);
  };
  run();
  // unless no longer smoothed
  setReextractionHandler(values, 'emissive', () => {
    if (values.emissiveType.ref.value.startsWith('volume')) run();
  });
}

function isSupportedSubstanceType(x: string): x is 'groupInstance' {
  return x === 'groupInstance';
}

export function applyTextureMeshSubstanceSmoothing(
  values: TextureMeshValues,
  options: ColorSmoothingOptions,
  graphics: GraphicsContext,
  colorTexture?: Texture,
) {
  if (!isSupportedSubstanceType(values.substanceType.ref.value)) return;
  const type = values.substanceType.ref.value;

  const run = () => {
    const tripled = { ...options, stride: options.stride * 3 }; // triple because TextureMesh is never indexed (no elements buffer)

    if (!graphics.namedTextures[ColorSmoothingRgbaName]) {
      graphics.namedTextures[ColorSmoothingRgbaName] = graphics.resources.texture(
        'image-uint8',
        'rgba',
        'ubyte',
        'nearest',
      );
    }
    const colorData = graphics.namedTextures[ColorSmoothingRgbaName];
    colorData.load(values.tSubstance.ref.value);

    const smoothingData = calcTextureMeshColorSmoothing(
      {
        vertexCount: values.uVertexCount.ref.value,
        instanceCount: values.uInstanceCount.ref.value,
        groupCount: values.uGroupCount.ref.value,
        transformBuffer: values.aTransform.ref.value,
        instanceBuffer: values.aInstance.ref.value,
        positionTexture: values.tPosition.ref.value,
        groupTexture: values.tGroup.ref.value,
        chunks: getChunks(values),
        colorData,
        colorType: type,
        boundingSphere: values.boundingSphere.ref.value,
        invariantBoundingSphere: values.invariantBoundingSphere.ref.value,
      },
      tripled,
      graphics,
      colorTexture,
    );

    // reused when run again
    colorTexture = smoothingData.texture;
    setSubstanceType(values, smoothingData.type);
    ValueCell.update(values.tSubstanceGrid, smoothingData.texture);
    ValueCell.update(values.uSubstanceTexDim, smoothingData.gridTexDim);
    ValueCell.update(values.uSubstanceGridDim, smoothingData.gridDim);
    ValueCell.update(values.uSubstanceGridTransform, smoothingData.gridTransform);
  };
  run();
  // unless no longer smoothed
  setReextractionHandler(values, 'substance', () => {
    if (values.substanceType.ref.value.startsWith('volume')) run();
  });
}
