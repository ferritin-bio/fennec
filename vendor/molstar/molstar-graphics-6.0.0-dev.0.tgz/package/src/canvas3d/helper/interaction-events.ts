/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import type { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { Representation } from '@molstar/graphics/repr/representation';
import { type InputObserver, ModifiersKeys, ButtonsType } from '@molstar/core/util/input/input-observer';
import { RxEventHelper } from '@molstar/core/util/rx-event-helper';
import { Vec2, Vec3 } from '@molstar/core/math/linear-algebra';
import type { Camera } from '../camera.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Bond } from '@molstar/model/model/structure';
import type { TrackballControls } from '../controls/trackball.js';
import { Ray3D } from '@molstar/core/math/geometry/primitives/ray3d';
import type { AsyncPickData, PickData } from '../passes/pick.js';

type Canvas3D = import('../canvas3d.js').Canvas3D;
type HoverEvent = import('../canvas3d.js').Canvas3D.HoverEvent;
type DragEvent = import('../canvas3d.js').Canvas3D.DragEvent;
type ClickEvent = import('../canvas3d.js').Canvas3D.ClickEvent;

const tmpPosA = Vec3();
const tmpPos = Vec3();
const tmpNorm = Vec3();

export const Canvas3dInteractionHelperParams = {
  maxFps: PD.Numeric(30, { min: 10, max: 60, step: 10 }),
  preferAtomPixelPadding: PD.Numeric(
    3,
    { min: 0, max: 20, step: 1 },
    { description: 'Number of extra pixels at which to prefer atoms over bonds.' },
  ),
  convertCoordsToRay: PD.Boolean(false, { description: 'Convert screen coordinates to ray for picking.' }),
};
export type Canvas3dInteractionHelperParams = typeof Canvas3dInteractionHelperParams;
export type Canvas3dInteractionHelperProps = PD.Values<Canvas3dInteractionHelperParams>;

export class Canvas3dInteractionHelper {
  private ev = RxEventHelper.create();

  readonly events = {
    hover: this.ev<HoverEvent>(),
    drag: this.ev<DragEvent>(),
    click: this.ev<ClickEvent>(),
  };

  private startX = -1;
  private startY = -1;
  private endX = -1;
  private endY = -1;

  private ray: Ray3D | undefined = void 0;

  private pickData: AsyncPickData | undefined = void 0;
  /** a click whose pick data is read asynchronously, see `synchronousIdentify` */
  private pendingClick:
    | {
        pickData: AsyncPickData;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        x: number;
        y: number;
      }
    | undefined = void 0;
  private position: Vec3 | undefined = void 0;

  private isInteracting = false;

  private prevLoci: Representation.Loci = Representation.Loci.Empty;
  private prevT = 0;

  private inside = false;

  private buttons: ButtonsType = ButtonsType.create(0);
  private button: ButtonsType.Flag = ButtonsType.create(0);
  private modifiers: ModifiersKeys = ModifiersKeys.None;

  readonly props: Canvas3dInteractionHelperProps;

  setProps(props: Partial<Canvas3dInteractionHelperProps>) {
    Object.assign(this.props, props);
  }

  private getTarget(): Vec2 | Ray3D {
    if (this.ray) {
      return this.ray;
    } else if (this.props.convertCoordsToRay) {
      return this.camera.getRay(Ray3D(), this.endX, this.endY);
    } else {
      return Vec2.create(this.endX, this.endY);
    }
  }

  private handleMove() {
    const xyChanged =
      this.startX !== this.endX || this.startY !== this.endY || (this.input.pointerLock && !this.controls.isMoving);
    if (xyChanged) {
      this.pickData = this.canvasAsyncIdentify(this.getTarget());
      this.startX = this.endX;
      this.startY = this.endY;
    }
  }

  private handleClick() {
    const target = this.getTarget();
    const { buttons, button, modifiers, endX: x, endY: y } = this;
    // without synchronous reads the click waits for the read
    const pickData = this.synchronousIdentify ? this.canvasIdentify(target) : 'pending';
    if (pickData === 'pending') {
      const pending = this.canvasAsyncIdentify(target);
      if (pending) {
        this.pendingClick = { pickData: pending, buttons, button, modifiers, x, y };
        return;
      }
    }
    this.emitClick(pickData === 'pending' ? undefined : pickData, buttons, button, modifiers, x, y);
  }

  private emitClick(
    pickData: PickData | undefined,
    buttons: ButtonsType,
    button: ButtonsType.Flag,
    modifiers: ModifiersKeys,
    x: number,
    y: number,
  ) {
    const loci = this.getLoci(pickData?.id, pickData?.position);
    this.events.click.next({
      current: loci,
      buttons,
      button,
      modifiers,
      page: Vec2.create(x, y),
      position: pickData?.position,
    });
    this.prevLoci = loci;
  }

  private tickPendingClick() {
    if (!this.pendingClick) return;
    const { pickData, buttons, button, modifiers, x, y } = this.pendingClick;
    const data = pickData.tryGet();
    if (data === 'pending') return;
    this.pendingClick = undefined;
    this.emitClick(data, buttons, button, modifiers, x, y);
  }

  private handleDrag() {
    const xyChanged =
      this.startX !== this.endX || this.startY !== this.endY || (this.input.pointerLock && !this.controls.isMoving);

    if (xyChanged && !this.outsideViewport(this.startX, this.startY, this.ray)) {
      this.events.drag.next({
        current: this.prevLoci,
        buttons: this.buttons,
        button: this.button,
        modifiers: this.modifiers,
        pageStart: Vec2.create(this.startX, this.startY),
        pageEnd: Vec2.create(this.endX, this.endY),
      });

      this.startX = this.endX;
      this.startY = this.endY;
    }
  }

  /**
   * Work the next tick does: a click's pick being read (also after leaving), a hover pick under way, a move or drag not
   * handled yet (it is throttled to `maxFps`).
   */
  get isPending() {
    if (this.pendingClick) return true;
    if (!this.inside) return false;
    return (
      this.pickData !== undefined || this.startX !== this.endX || this.startY !== this.endY || this.input.pointerLock
    );
  }

  tick(t: number) {
    this.tickPendingClick();
    if (!this.inside) return;

    if (this.pickData) {
      const pickData = this.pickData.tryGet();
      if (pickData !== 'pending') {
        this.position = pickData?.position;
        if (this.inside) {
          const loci = this.getLoci(pickData?.id, pickData?.position);
          this.events.hover.next({
            current: loci,
            buttons: this.buttons,
            button: this.button,
            modifiers: this.modifiers,
            page: Vec2.create(this.endX, this.endY),
            position: pickData?.position,
          });
          this.prevLoci = loci;
        }
        this.pickData = undefined;
      }
    }

    if (t - this.prevT > 1000 / this.props.maxFps) {
      this.prevT = t;
      if (this.isInteracting) {
        this.handleDrag();
      } else {
        this.handleMove();
      }
    }
  }

  private leave() {
    this.inside = false;
    if (!Representation.Loci.isEmpty(this.prevLoci)) {
      this.prevLoci = Representation.Loci.Empty;
      this.events.hover.next({
        current: this.prevLoci,
        buttons: this.buttons,
        button: this.button,
        modifiers: this.modifiers,
      });
    }
  }

  private move(
    x: number,
    y: number,
    buttons: ButtonsType,
    button: ButtonsType.Flag,
    modifiers: ModifiersKeys,
    ray?: Ray3D,
  ) {
    this.inside = true;
    this.buttons = buttons;
    this.button = button;
    this.modifiers = modifiers;
    this.ray = ray;
    this.endX = x;
    this.endY = y;
  }

  private click(
    x: number,
    y: number,
    buttons: ButtonsType,
    button: ButtonsType.Flag,
    modifiers: ModifiersKeys,
    ray?: Ray3D,
  ) {
    this.endX = x;
    this.endY = y;
    this.buttons = buttons;
    this.button = button;
    this.modifiers = modifiers;
    this.ray = ray;
    this.handleClick();
  }

  private drag(x: number, y: number, buttons: ButtonsType, button: ButtonsType.Flag, modifiers: ModifiersKeys) {
    this.endX = x;
    this.endY = y;
    this.buttons = buttons;
    this.button = button;
    this.modifiers = modifiers;
    this.handleDrag();
  }

  private modify(modifiers: ModifiersKeys) {
    if (ModifiersKeys.areEqual(modifiers, this.modifiers)) return;
    this.modifiers = modifiers;
    this.events.hover.next({
      current: this.prevLoci,
      buttons: this.buttons,
      button: this.button,
      modifiers: this.modifiers,
      page: Vec2.create(this.endX, this.endY),
      position: this.position,
    });
  }

  private outsideViewport(x: number, y: number, ray?: Ray3D) {
    if (ray) return false;

    const {
      input,
      camera: { viewport },
    } = this;
    x *= input.pixelRatio;
    y *= input.pixelRatio;
    return x > viewport.x + viewport.width || y > viewport.y + viewport.height || x < viewport.x || y < viewport.y;
  }

  private getLoci(pickingId: PickingId | undefined, position: Vec3 | undefined) {
    const { repr, loci } = this.lociGetter(pickingId);
    if (position && repr && Bond.isLoci(loci) && loci.bonds.length === 2) {
      const { aUnit, aIndex } = loci.bonds[0];
      aUnit.conformation.position(aUnit.elements[aIndex], tmpPosA);
      Vec3.sub(tmpNorm, this.camera.state.position, this.camera.state.target);
      Vec3.projectPointOnPlane(tmpPos, position, tmpNorm, tmpPosA);
      const pixelSize = this.camera.getPixelSize(tmpPos);
      let radius = repr.theme.size.size(loci.bonds[0]) * (repr.props.sizeFactor ?? 1);
      if (repr.props.lineSizeAttenuation === false) {
        // divide by two to get radius
        radius *= pixelSize / 2;
      }
      radius += this.props.preferAtomPixelPadding * pixelSize;
      if (Vec3.distance(tmpPos, tmpPosA) < radius) {
        return { repr, loci: Bond.toFirstStructureElementLoci(loci) };
      }
    }
    return { repr, loci };
  }

  resetTime(t: number) {
    this.prevT = t;
  }

  dispose() {
    this.ev.dispose();
  }

  /**
   * After the graphics context changed: `synchronousIdentify` of the new pick helpers, pending reads of the previous
   * ones (which resolve to nothing) are requested again
   */
  resetPicks(synchronousIdentify: boolean) {
    this.synchronousIdentify = synchronousIdentify;
    if (this.pickData) this.pickData = this.canvasAsyncIdentify(this.getTarget());
    if (this.pendingClick) {
      const { x, y } = this.pendingClick;
      const target = this.props.convertCoordsToRay ? this.camera.getRay(Ray3D(), x, y) : Vec2.create(x, y);
      const pickData = this.ray ? this.canvasAsyncIdentify(this.ray) : this.canvasAsyncIdentify(target);
      if (pickData) this.pendingClick.pickData = pickData;
    }
  }

  constructor(
    private canvasIdentify: Canvas3D['identify'],
    private canvasAsyncIdentify: Canvas3D['asyncIdentify'],
    private lociGetter: Canvas3D['getLoci'],
    private input: InputObserver,
    private camera: Camera,
    private controls: TrackballControls,
    props: Partial<Canvas3dInteractionHelperProps> = {},
    /** false if `canvasIdentify` can't read pick data synchronously, clicks then wait for `canvasAsyncIdentify` */
    private synchronousIdentify = true,
  ) {
    this.props = { ...PD.getDefaultValues(Canvas3dInteractionHelperParams), ...props };

    input.drag.subscribe(({ x, y, buttons, button, modifiers }) => {
      this.isInteracting = true;
      // console.log('drag');
      this.drag(x, y, buttons, button, modifiers);
    });

    input.move.subscribe(({ x, y, inside, buttons, button, modifiers, onElement, ray }) => {
      if (!inside || this.isInteracting) return;
      if (!onElement) {
        this.leave();
        return;
      }
      // console.log('move');
      this.move(x, y, buttons, button, modifiers, ray);
    });

    input.leave.subscribe(() => {
      // console.log('leave');
      this.leave();
    });

    input.click.subscribe(({ x, y, buttons, button, modifiers, ray }) => {
      if (this.outsideViewport(x, y, ray)) return;
      // console.log('click');
      this.click(x, y, buttons, button, modifiers, ray);
    });

    input.interactionEnd.subscribe(() => {
      // console.log('interactionEnd');
      this.isInteracting = false;
    });

    input.modifiers.subscribe((modifiers) => {
      // console.log('modifiers');
      this.modify(modifiers);
    });
  }
}
