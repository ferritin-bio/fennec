/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import {
  type GLRenderingContext,
  type COMPAT_instanced_arrays,
  type COMPAT_standard_derivatives,
  type COMPAT_vertex_array_object,
  getInstancedArrays,
  getStandardDerivatives,
  type COMPAT_element_index_uint,
  getElementIndexUint,
  type COMPAT_texture_float,
  getTextureFloat,
  type COMPAT_texture_float_linear,
  getTextureFloatLinear,
  type COMPAT_blend_minmax,
  getBlendMinMax,
  getFragDepth,
  type COMPAT_frag_depth,
  type COMPAT_color_buffer_float,
  type COMPAT_float_blend,
  getFloatBlend,
  getColorBufferFloat,
  type COMPAT_draw_buffers,
  getDrawBuffers,
  getShaderTextureLod,
  type COMPAT_shader_texture_lod,
  getDepthTexture,
  type COMPAT_depth_texture,
  type COMPAT_sRGB,
  getSRGB,
  getTextureHalfFloat,
  getTextureHalfFloatLinear,
  type COMPAT_texture_half_float,
  type COMPAT_texture_half_float_linear,
  type COMPAT_color_buffer_half_float,
  getColorBufferHalfFloat,
  getVertexArrayObject,
  getDisjointTimerQuery,
  type COMPAT_disjoint_timer_query,
  getNoNonInstancedActiveAttribs,
  type COMPAT_multi_draw,
  getMultiDraw,
  getDrawInstancedBaseVertexBaseInstance,
  getMultiDrawInstancedBaseVertexBaseInstance,
  type COMPAT_draw_instanced_base_vertex_base_instance,
  type COMPAT_multi_draw_instanced_base_vertex_base_instance,
  getDrawBuffersIndexed,
  type COMPAT_draw_buffers_indexed,
  getParallelShaderCompile,
  type COMPAT_parallel_shader_compile,
  getFboRenderMipmap,
  type COMPAT_fboRenderMipmap,
  type COMPAT_provoking_vertex,
  getProvokingVertex,
  type COMPAT_clip_cull_distance,
  getClipCullDistance,
  type COMPAT_conservative_depth,
  getConservativeDepth,
  type COMPAT_stencil_texturing,
  getStencilTexturing,
  type COMPAT_clip_control,
  getClipControl,
  getRenderSnorm,
  type COMPAT_render_snorm,
  getRenderSharedExponent,
  type COMPAT_render_shared_exponent,
  getTextureNorm16,
  type COMPAT_texture_norm16,
  getDepthClamp,
  type COMPAT_depth_clamp,
  type COMPAT_multiview2,
  getMultiview2,
} from './compat.js';
import { isDebugMode } from '@molstar/core/util/debug';

export type WebGLExtensions = {
  instancedArrays: COMPAT_instanced_arrays;
  elementIndexUint: COMPAT_element_index_uint;
  standardDerivatives: COMPAT_standard_derivatives;
  textureFloat: COMPAT_texture_float;
  blendMinMax: COMPAT_blend_minmax;

  textureFloatLinear: COMPAT_texture_float_linear | null;
  textureHalfFloat: COMPAT_texture_half_float | null;
  textureHalfFloatLinear: COMPAT_texture_half_float_linear | null;
  depthTexture: COMPAT_depth_texture | null;
  vertexArrayObject: COMPAT_vertex_array_object | null;
  fragDepth: COMPAT_frag_depth | null;
  colorBufferFloat: COMPAT_color_buffer_float | null;
  floatBlend: COMPAT_float_blend | null;
  colorBufferHalfFloat: COMPAT_color_buffer_half_float | null;
  drawBuffers: COMPAT_draw_buffers | null;
  drawBuffersIndexed: COMPAT_draw_buffers_indexed | null;
  shaderTextureLod: COMPAT_shader_texture_lod | null;
  sRGB: COMPAT_sRGB | null;
  disjointTimerQuery: COMPAT_disjoint_timer_query | null;
  multiDraw: COMPAT_multi_draw | null;
  drawInstancedBaseVertexBaseInstance: COMPAT_draw_instanced_base_vertex_base_instance | null;
  multiDrawInstancedBaseVertexBaseInstance: COMPAT_multi_draw_instanced_base_vertex_base_instance | null;
  parallelShaderCompile: COMPAT_parallel_shader_compile | null;
  fboRenderMipmap: COMPAT_fboRenderMipmap | null;
  provokingVertex: COMPAT_provoking_vertex | null;
  clipCullDistance: COMPAT_clip_cull_distance | null;
  conservativeDepth: COMPAT_conservative_depth | null;
  stencilTexturing: COMPAT_stencil_texturing | null;
  clipControl: COMPAT_clip_control | null;
  renderSnorm: COMPAT_render_snorm | null;
  renderSharedExponent: COMPAT_render_shared_exponent | null;
  textureNorm16: COMPAT_texture_norm16 | null;
  depthClamp: COMPAT_depth_clamp | null;
  multiview2: COMPAT_multiview2 | null;

  noNonInstancedActiveAttribs: boolean;
};

export function createExtensions(gl: GLRenderingContext): WebGLExtensions {
  const instancedArrays = getInstancedArrays(gl);
  if (instancedArrays === null) {
    throw new Error('Could not find support for "instanced_arrays"');
  }
  const elementIndexUint = getElementIndexUint(gl);
  if (elementIndexUint === null) {
    throw new Error('Could not find support for "element_index_uint"');
  }
  const standardDerivatives = getStandardDerivatives(gl);
  if (standardDerivatives === null) {
    throw new Error('Could not find support for "standard_derivatives"');
  }
  const textureFloat = getTextureFloat(gl);
  if (textureFloat === null) {
    throw new Error('Could not find support for "texture_float"');
  }
  const blendMinMax = getBlendMinMax(gl);
  if (blendMinMax === null) {
    throw new Error('Could not find support for "blend_minmax"');
  }

  const textureFloatLinear = getTextureFloatLinear(gl);
  if (isDebugMode && textureFloatLinear === null) {
    // TODO handle non-support downstream (no gpu gaussian calc, no gpu mc???)
    // - can't be a required extension because it is not supported by `headless-gl`
    console.log('Could not find support for "texture_float_linear"');
  }
  const textureHalfFloat = getTextureHalfFloat(gl);
  if (isDebugMode && textureHalfFloat === null) {
    console.log('Could not find support for "texture_half_float"');
  }
  const textureHalfFloatLinear = getTextureHalfFloatLinear(gl);
  if (isDebugMode && textureHalfFloatLinear === null) {
    // TODO handle non-support downstream (no gpu gaussian calc, no gpu mc???)
    // - can't be a required extension because it is not supported by `headless-gl`
    console.log('Could not find support for "texture_half_float_linear"');
  }
  const depthTexture = getDepthTexture(gl);
  if (isDebugMode && depthTexture === null) {
    console.log('Could not find support for "depth_texture"');
  }
  const vertexArrayObject = getVertexArrayObject(gl);
  if (isDebugMode && vertexArrayObject === null) {
    console.log('Could not find support for "vertex_array_object"');
  }
  const fragDepth = getFragDepth(gl);
  if (isDebugMode && fragDepth === null) {
    console.log('Could not find support for "frag_depth"');
  }
  const colorBufferFloat = getColorBufferFloat(gl);
  if (isDebugMode && colorBufferFloat === null) {
    console.log('Could not find support for "color_buffer_float"');
  }
  const floatBlend = getFloatBlend(gl);
  if (isDebugMode && floatBlend === null) {
    console.log('Could not find support for "float_blend"');
  }
  const colorBufferHalfFloat = getColorBufferHalfFloat(gl);
  if (isDebugMode && colorBufferHalfFloat === null) {
    console.log('Could not find support for "color_buffer_half_float"');
  }
  const drawBuffers = getDrawBuffers(gl);
  if (isDebugMode && drawBuffers === null) {
    console.log('Could not find support for "draw_buffers"');
  }
  const drawBuffersIndexed = getDrawBuffersIndexed(gl);
  if (isDebugMode && drawBuffersIndexed === null) {
    console.log('Could not find support for "draw_buffers_indexed"');
  }
  const shaderTextureLod = getShaderTextureLod(gl);
  if (isDebugMode && shaderTextureLod === null) {
    console.log('Could not find support for "shader_texture_lod"');
  }
  const sRGB = getSRGB(gl);
  if (isDebugMode && sRGB === null) {
    console.log('Could not find support for "sRGB"');
  }
  const disjointTimerQuery = getDisjointTimerQuery(gl);
  if (isDebugMode && disjointTimerQuery === null) {
    console.log('Could not find support for "disjoint_timer_query"');
  }
  const multiDraw = getMultiDraw(gl);
  if (isDebugMode && multiDraw === null) {
    console.log('Could not find support for "multi_draw"');
  }
  const drawInstancedBaseVertexBaseInstance = getDrawInstancedBaseVertexBaseInstance(gl);
  if (isDebugMode && drawInstancedBaseVertexBaseInstance === null) {
    console.log('Could not find support for "draw_instanced_base_vertex_base_instance"');
  }
  const multiDrawInstancedBaseVertexBaseInstance = getMultiDrawInstancedBaseVertexBaseInstance(gl);
  if (isDebugMode && multiDrawInstancedBaseVertexBaseInstance === null) {
    console.log('Could not find support for "multi_draw_instanced_base_vertex_base_instance"');
  }
  const parallelShaderCompile = getParallelShaderCompile(gl);
  if (isDebugMode && parallelShaderCompile === null) {
    console.log('Could not find support for "parallel_shader_compile"');
  }
  const fboRenderMipmap = getFboRenderMipmap(gl);
  if (isDebugMode && fboRenderMipmap === null) {
    console.log('Could not find support for "fbo_render_mipmap"');
  }
  const provokingVertex = getProvokingVertex(gl);
  if (isDebugMode && provokingVertex === null) {
    console.log('Could not find support for "provoking_vertex"');
  }
  const clipCullDistance = getClipCullDistance(gl);
  if (isDebugMode && clipCullDistance === null) {
    console.log('Could not find support for "clip_cull_distance"');
  }
  const conservativeDepth = getConservativeDepth(gl);
  if (isDebugMode && conservativeDepth === null) {
    console.log('Could not find support for "conservative_depth"');
  }
  const stencilTexturing = getStencilTexturing(gl);
  if (isDebugMode && stencilTexturing === null) {
    console.log('Could not find support for "stencil_texturing"');
  }
  const clipControl = getClipControl(gl);
  if (isDebugMode && clipControl === null) {
    console.log('Could not find support for "clip_control"');
  }
  const renderSnorm = getRenderSnorm(gl);
  if (isDebugMode && renderSnorm === null) {
    console.log('Could not find support for "render_snorm"');
  }
  const renderSharedExponent = getRenderSharedExponent(gl);
  if (isDebugMode && renderSharedExponent === null) {
    console.log('Could not find support for "render_shared_exponent"');
  }
  const textureNorm16 = getTextureNorm16(gl);
  if (isDebugMode && textureNorm16 === null) {
    console.log('Could not find support for "texture_norm16"');
  }
  const depthClamp = getDepthClamp(gl);
  if (isDebugMode && depthClamp === null) {
    console.log('Could not find support for "depth_clamp"');
  }
  const multiview2 = getMultiview2(gl);
  if (isDebugMode && multiview2 === null) {
    console.log('Could not find support for "multiview2"');
  }

  const noNonInstancedActiveAttribs = getNoNonInstancedActiveAttribs(gl);

  return {
    instancedArrays,
    standardDerivatives,
    elementIndexUint,
    textureFloat,
    blendMinMax,

    textureFloatLinear,
    textureHalfFloat,
    textureHalfFloatLinear,
    depthTexture,
    vertexArrayObject,
    fragDepth,
    colorBufferFloat,
    floatBlend,
    colorBufferHalfFloat,
    drawBuffers,
    drawBuffersIndexed,
    shaderTextureLod,
    sRGB,
    disjointTimerQuery,
    multiDraw,
    drawInstancedBaseVertexBaseInstance,
    multiDrawInstancedBaseVertexBaseInstance,
    parallelShaderCompile,
    fboRenderMipmap,
    provokingVertex,
    clipCullDistance,
    conservativeDepth,
    stencilTexturing,
    clipControl,
    renderSnorm,
    renderSharedExponent,
    textureNorm16,
    depthClamp,
    multiview2,

    noNonInstancedActiveAttribs,
  };
}
