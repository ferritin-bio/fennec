/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { isWebGLContext, type WebGLContext } from '../../context.js';
import type { AtlasIsosurfaceExtraction } from '../../../compute/marching-cubes/atlas.js';
import { type ComputeRenderable, createComputeRenderable } from '../../../renderable.js';
import { RenderState } from '../../../render-state.js';
import { type Values, TextureSpec, UniformSpec, DefineSpec } from '../../../renderable/schema.js';
import type { Texture } from '../../../texture.js';
import { ShaderCode } from '../../../shader-code.js';
import { ValueCell } from '@molstar/core/util';
import { type Vec3, type Vec2, type Mat4, Mat3 } from '@molstar/core/math/linear-algebra';
import { QuadSchema, QuadValues } from '../../../compute/util.js';
import { createHistogramPyramid, type HistogramPyramid } from '../histogram-pyramid/reduction.js';
import { getTriIndices } from './tables.js';
import { calcActiveVoxels, type ValueChannel } from './active-voxels.js';
import { isTimingMode } from '@molstar/core/util/debug';
import { setTexelViewport } from '../../render-pass-target.js';

export const IsosurfaceSchema = {
  ...QuadSchema,

  tTriIndices: TextureSpec('image-uint8', 'r', 'ubyte', 'nearest'),
  tActiveVoxelsPyramid: TextureSpec('texture', 'rgba', 'float', 'nearest', undefined, { sampleType: 'sint' }),
  tActiveVoxelsBase: TextureSpec('texture', 'rgba', 'float', 'nearest'),
  tVolumeData: TextureSpec('texture', 'rgba', 'ubyte', 'nearest'),
  dValueChannel: DefineSpec('string', ['red', 'alpha']),
  uIsoValue: UniformSpec('f'),

  uSize: UniformSpec('f'),
  uLevels: UniformSpec('f'),
  uCount: UniformSpec('f'),
  uInvert: UniformSpec('b'),

  uGridDim: UniformSpec('v3'),
  uGridTexDim: UniformSpec('v3'),
  uGridDataDim: UniformSpec('v3'),
  uGridTransform: UniformSpec('m4'),
  uGridTransformAdjoint: UniformSpec('m3'),
  uScale: UniformSpec('v2'),

  dPackedGroup: DefineSpec('boolean'),
  dAxisOrder: DefineSpec('string', ['012', '021', '102', '120', '201', '210']),
  dConstantGroup: DefineSpec('boolean'),
};
export const IsosurfaceShaderCode = ShaderCode('isosurface', { drawBuffers: 'required' });
type IsosurfaceValues = Values<typeof IsosurfaceSchema>;

const IsosurfaceName = 'isosurface';

function getIsosurfaceRenderable(
  ctx: WebGLContext,
  activeVoxelsPyramid: Texture,
  activeVoxelsBase: Texture,
  volumeData: Texture,
  valueChannel: ValueChannel,
  gridDim: Vec3,
  gridTexDim: Vec3,
  gridDataDim: Vec3,
  transform: Mat4,
  isoValue: number,
  levels: number,
  scale: Vec2,
  count: number,
  invert: boolean,
  packedGroup: boolean,
  axisOrder: Vec3,
  constantGroup: boolean,
): ComputeRenderable<IsosurfaceValues> {
  if (ctx.namedComputeRenderables[IsosurfaceName]) {
    const v = ctx.namedComputeRenderables[IsosurfaceName].values as IsosurfaceValues;

    ValueCell.update(v.tActiveVoxelsPyramid, activeVoxelsPyramid);
    ValueCell.update(v.tActiveVoxelsBase, activeVoxelsBase);
    ValueCell.update(v.tVolumeData, volumeData);
    ValueCell.update(v.dValueChannel, valueChannel);

    ValueCell.updateIfChanged(v.uIsoValue, isoValue);
    ValueCell.updateIfChanged(v.uSize, Math.pow(2, levels));
    ValueCell.updateIfChanged(v.uLevels, levels);
    ValueCell.updateIfChanged(v.uCount, count);
    ValueCell.updateIfChanged(v.uInvert, invert);

    ValueCell.update(v.uGridDim, gridDim);
    ValueCell.update(v.uGridTexDim, gridTexDim);
    ValueCell.update(v.uGridDataDim, gridDataDim);
    ValueCell.update(v.uGridTransform, transform);
    ValueCell.update(v.uGridTransformAdjoint, Mat3.adjointFromMat4(Mat3(), transform));
    ValueCell.update(v.uScale, scale);

    ValueCell.updateIfChanged(v.dPackedGroup, packedGroup);
    ValueCell.updateIfChanged(v.dAxisOrder, axisOrder.join(''));
    ValueCell.updateIfChanged(v.dConstantGroup, constantGroup);

    ctx.namedComputeRenderables[IsosurfaceName].update();
  } else {
    ctx.namedComputeRenderables[IsosurfaceName] = createIsosurfaceRenderable(
      ctx,
      activeVoxelsPyramid,
      activeVoxelsBase,
      volumeData,
      valueChannel,
      gridDim,
      gridTexDim,
      gridDataDim,
      transform,
      isoValue,
      levels,
      scale,
      count,
      invert,
      packedGroup,
      axisOrder,
      constantGroup,
    );
  }
  return ctx.namedComputeRenderables[IsosurfaceName];
}

function createIsosurfaceRenderable(
  ctx: WebGLContext,
  activeVoxelsPyramid: Texture,
  activeVoxelsBase: Texture,
  volumeData: Texture,
  valueChannel: ValueChannel,
  gridDim: Vec3,
  gridTexDim: Vec3,
  gridDataDim: Vec3,
  transform: Mat4,
  isoValue: number,
  levels: number,
  scale: Vec2,
  count: number,
  invert: boolean,
  packedGroup: boolean,
  axisOrder: Vec3,
  constantGroup: boolean,
) {
  // console.log('uSize', Math.pow(2, levels))
  const values: IsosurfaceValues = {
    ...QuadValues,
    tTriIndices: ValueCell.create(getTriIndices()),

    tActiveVoxelsPyramid: ValueCell.create(activeVoxelsPyramid),
    tActiveVoxelsBase: ValueCell.create(activeVoxelsBase),
    tVolumeData: ValueCell.create(volumeData),
    dValueChannel: ValueCell.create(valueChannel),

    uIsoValue: ValueCell.create(isoValue),
    uSize: ValueCell.create(Math.pow(2, levels)),
    uLevels: ValueCell.create(levels),
    uCount: ValueCell.create(count),
    uInvert: ValueCell.create(invert),

    uGridDim: ValueCell.create(gridDim),
    uGridTexDim: ValueCell.create(gridTexDim),
    uGridDataDim: ValueCell.create(gridDataDim),
    uGridTransform: ValueCell.create(transform),
    uGridTransformAdjoint: ValueCell.create(Mat3.adjointFromMat4(Mat3(), transform)),
    uScale: ValueCell.create(scale),

    dPackedGroup: ValueCell.create(packedGroup),
    dAxisOrder: ValueCell.create(axisOrder.join('')),
    dConstantGroup: ValueCell.create(constantGroup),
  };

  const schema = { ...IsosurfaceSchema };
  const renderItem = ctx.createComputeRenderItem('triangles', IsosurfaceShaderCode, schema, values);

  return createComputeRenderable(renderItem, values);
}

export function createIsosurfaceBuffers(
  ctx: WebGLContext,
  activeVoxelsBase: Texture,
  volumeData: Texture,
  valueChannel: ValueChannel,
  histogramPyramid: HistogramPyramid,
  gridDim: Vec3,
  gridTexDim: Vec3,
  gridDataDim: Vec3,
  transform: Mat4,
  isoValue: number,
  invert: boolean,
  packedGroup: boolean,
  axisOrder: Vec3,
  constantGroup: boolean,
  vertexTexture?: Texture,
  groupTexture?: Texture,
  normalTexture?: Texture,
) {
  if (!ctx.capabilities.multipleRenderTargets) throw new Error('need multiple render targets');

  if (isTimingMode) ctx.timer.group('createIsosurfaceBuffers');
  const { resources, capabilities } = ctx;
  const { pyramidTex, height, levels, scale, count } = histogramPyramid;
  const width = pyramidTex.getWidth();

  // console.log('width', width, 'height', height);
  // console.log('iso', 'gridDim', gridDim, 'scale', scale, 'gridTexDim', gridTexDim);
  // console.log('iso volumeData', volumeData);

  if (!ctx.namedFramebuffers[IsosurfaceName]) {
    ctx.namedFramebuffers[IsosurfaceName] = resources.framebuffer();
  }
  const framebuffer = ctx.namedFramebuffers[IsosurfaceName];

  if (capabilities.mixedAttachmentFormats) {
    if (!vertexTexture) {
      vertexTexture = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }

    if (!groupTexture) {
      groupTexture = resources.texture('image-uint8', 'rgba', 'ubyte', 'nearest');
    }

    if (!normalTexture) {
      normalTexture = capabilities.halfFloatRenderTarget
        ? resources.texture('image-float16', 'rgba', 'fp16', 'nearest')
        : resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }
  } else {
    // webgl1 requires consistent bit plane counts
    // this is quite wasteful but good enough for medium size meshes

    if (!vertexTexture) {
      vertexTexture = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }

    if (!groupTexture) {
      groupTexture = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }

    if (!normalTexture) {
      normalTexture = resources.texture('image-float32', 'rgba', 'float', 'nearest');
    }
  }

  vertexTexture.define(width, height);
  groupTexture.define(width, height);
  normalTexture.define(width, height);

  vertexTexture.attachFramebuffer(framebuffer, 0);
  groupTexture.attachFramebuffer(framebuffer, 1);
  normalTexture.attachFramebuffer(framebuffer, 2);

  const renderable = getIsosurfaceRenderable(
    ctx,
    pyramidTex,
    activeVoxelsBase,
    volumeData,
    valueChannel,
    gridDim,
    gridTexDim,
    gridDataDim,
    transform,
    isoValue,
    levels,
    scale,
    count,
    invert,
    packedGroup,
    axisOrder,
    constantGroup,
  );

  framebuffer.setDrawBuffers(3);

  ctx.beginRenderPass(framebuffer, { label: 'isosurface' });
  ctx.setRenderState(RenderState.Default);
  ctx.disableScissor();
  setTexelViewport(ctx, 0, 0, width, height);
  ctx.clear({ color: [0, 0, 0, 0] });
  renderable.render();

  if (isTimingMode) ctx.timer.groupEnd('createIsosurfaceBuffers');

  // printTextureImage(readTexture(ctx, vertexTexture, new Float32Array(width * height * 4)), { scale: 0.75, normalize: true });
  // printTextureImage(readTexture(ctx, groupTexture, new Uint8Array(width * height * 4)), { scale: 0.75, normalize: true });
  // printTextureImage(readTexture(ctx, normalTexture, new Float32Array(width * height * 4)), { scale: 0.75, normalize: true });

  return { vertexTexture, groupTexture, normalTexture, vertexCount: count };
}

//

/**
 * GPU isosurface extraction
 *
 * Algorithm from "High‐speed Marching Cubes using HistoPyramids"
 * by C Dyken, G Ziegler, C Theobalt, HP Seidel
 * https://doi.org/10.1111/j.1467-8659.2008.01182.x
 *
 * Implementation based on http://www.miaumiau.cat/2016/10/stream-compaction-in-webgl/
 */
export function extractIsosurface(
  ctx: WebGLContext,
  volumeData: Texture,
  valueChannel: ValueChannel,
  gridDim: Vec3,
  gridTexDim: Vec3,
  gridDataDim: Vec3,
  gridTexScale: Vec2,
  transform: Mat4,
  isoValue: number,
  invert: boolean,
  packedGroup: boolean,
  axisOrder: Vec3,
  constantGroup: boolean,
  vertexTexture?: Texture,
  groupTexture?: Texture,
  normalTexture?: Texture,
) {
  if (isTimingMode) ctx.timer.group('extractIsosurface');
  const activeVoxelsTex = calcActiveVoxels(ctx, volumeData, valueChannel, gridDim, gridTexDim, isoValue, gridTexScale);
  const compacted = createHistogramPyramid(ctx, activeVoxelsTex, gridTexScale, gridTexDim);
  const gv = createIsosurfaceBuffers(
    ctx,
    activeVoxelsTex,
    volumeData,
    valueChannel,
    compacted,
    gridDim,
    gridTexDim,
    gridDataDim,
    transform,
    isoValue,
    invert,
    packedGroup,
    axisOrder,
    constantGroup,
    vertexTexture,
    groupTexture,
    normalTexture,
  );
  if (isTimingMode) ctx.timer.groupEnd('extractIsosurface');

  return gv;
}

/** The fragment-shader marching cubes of WebGL, registered with each WebGL context */
export const WebGLAtlasIsosurfaceExtraction: AtlasIsosurfaceExtraction = {
  isSupported: (graphics) => isWebGLContext(graphics),
  extract: (graphics, input, textures) => {
    if (!isWebGLContext(graphics)) throw new Error('not a WebGL context');
    return extractIsosurface(
      graphics,
      input.texture,
      input.channel,
      input.gridDim,
      input.gridTexDim,
      input.gridDataDim,
      input.gridTexScale,
      input.transform,
      input.isoValue,
      input.invert,
      input.packedGroup,
      input.axisOrder,
      input.constantGroup,
      textures?.vertex,
      textures?.group,
      textures?.normal,
    );
  },
};
