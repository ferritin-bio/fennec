/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { type Renderable, type RenderableState, createRenderable } from '../renderable.js';
import type { GraphicsContext } from '../context.js';
import type { Transparency } from '../render-item.js';
import {
  GlobalUniformSchema,
  BaseSchema,
  AttributeSpec,
  type Values,
  InternalSchema,
  SizeSchema,
  type InternalValues,
  ElementsSpec,
  ValueSpec,
  DefineSpec,
  GlobalTextureSchema,
  UniformSpec,
  type GlobalDefineValues,
  type GlobalDefines,
  GlobalDefineSchema,
  InteriorSchema,
  AnimationSchema,
} from './schema.js';
import { CylindersShaderCode } from '../shader-code.js';
import { ValueCell } from '@molstar/core/util';

export const CylindersSchema = {
  ...BaseSchema,
  ...SizeSchema,
  aGroup: AttributeSpec('float32', 1, 0),
  aStart: AttributeSpec('float32', 3, 0),
  aEnd: AttributeSpec('float32', 3, 0),
  aMapping: AttributeSpec('float32', 3, 0),
  aScale: AttributeSpec('float32', 1, 0),
  aCap: AttributeSpec('float32', 1, 0),
  aColorMode: AttributeSpec('float32', 1, 0),
  elements: ElementsSpec('uint32'),

  padding: ValueSpec('number'),
  uDoubleSided: UniformSpec('b', 'material'),
  dIgnoreLight: DefineSpec('boolean'),
  dCelShaded: DefineSpec('boolean'),
  dXrayShaded: DefineSpec('string', ['off', 'on', 'inverted']),
  dTransparentBackfaces: DefineSpec('string', ['off', 'on', 'opaque']),
  dSolidInterior: DefineSpec('boolean'),
  uBumpFrequency: UniformSpec('f', 'material'),
  uBumpAmplitude: UniformSpec('f', 'material'),
  dDualColor: DefineSpec('boolean'),

  ...InteriorSchema,
  ...AnimationSchema,
};
export type CylindersSchema = typeof CylindersSchema;
export type CylindersValues = Values<CylindersSchema>;

/** The schema of the renderable: the object's with the global and internal ones (one object, shared by the items) */
export const CylindersRenderableSchema = {
  ...GlobalUniformSchema,
  ...GlobalTextureSchema,
  ...GlobalDefineSchema,
  ...InternalSchema,
  ...CylindersSchema,
};

export function CylindersRenderable(
  ctx: GraphicsContext,
  id: number,
  values: CylindersValues,
  state: RenderableState,
  materialId: number,
  transparency: Transparency,
  globals: GlobalDefines,
): Renderable<CylindersValues> {
  const schema = CylindersRenderableSchema;
  const renderValues: CylindersValues & InternalValues & GlobalDefineValues = {
    ...values,
    uObjectId: ValueCell.create(id),
    dLightCount: ValueCell.create(globals.dLightCount),
    dColorMarker: ValueCell.create(globals.dColorMarker),
  };
  const shaderCode = CylindersShaderCode;
  const renderItem = ctx.createGraphicsRenderItem(
    'triangles',
    shaderCode,
    schema,
    renderValues,
    materialId,
    transparency,
  );
  return createRenderable(renderItem, renderValues, state);
}
