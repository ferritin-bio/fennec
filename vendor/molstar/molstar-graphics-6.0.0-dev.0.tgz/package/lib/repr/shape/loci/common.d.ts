/**
 * Copyright (c) 2020-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export declare const MeasurementRepresentationCommonTextParams: {
    customText: PD.Text<string>;
    textColor: PD.Color;
    textSize: PD.Numeric;
};
export declare const LociLabelTextParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    fontFamily: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontFamily>;
    fontQuality: PD.Select<number>;
    fontStyle: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontStyle>;
    fontVariant: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontVariant>;
    fontWeight: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontWeight>;
    sizeFactor: PD.Numeric;
    borderColor: PD.Color;
    offsetX: PD.Numeric;
    offsetY: PD.Numeric;
    offsetZ: PD.Numeric;
    background: PD.BooleanParam;
    backgroundMargin: PD.Numeric;
    backgroundColor: PD.Color;
    backgroundOpacity: PD.Numeric;
    tether: PD.BooleanParam;
    tetherLength: PD.Numeric;
    tetherBaseWidth: PD.Numeric;
    attachment: PD.Select<"bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right">;
    customText: PD.Text<string>;
    textColor: PD.Color;
    textSize: PD.Numeric;
    borderWidth: PD.Numeric;
};
export type LociLabelTextParams = typeof LociLabelTextParams;
//# sourceMappingURL=common.d.ts.map