/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Loci } from '@molstar/model/model/loci';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Representation, type RepresentationParamsGetter, type RepresentationContext } from '../../representation.js';
import { Vec3, Mat4 } from '@molstar/core/math/linear-algebra';
export interface AngleData {
    triples: Loci.Bundle<3>[];
}
export declare const AngleParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpFrequency: PD.Numeric;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    fontFamily: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontFamily>;
    fontQuality: PD.Select<number>;
    fontStyle: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontStyle>;
    fontVariant: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontVariant>;
    fontWeight: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontWeight>;
    sizeFactor: PD.Numeric;
    borderColor: PD.Color;
    offsetX: PD.Numeric;
    offsetY: PD.Numeric;
    offsetZ: PD.Numeric;
    background: PD.BooleanParam;
    backgroundMargin: PD.Numeric;
    backgroundColor: PD.Color;
    backgroundOpacity: PD.Numeric;
    tether: PD.BooleanParam;
    tetherLength: PD.Numeric;
    tetherBaseWidth: PD.Numeric;
    attachment: PD.Select<"bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right">;
    customText: PD.Text<string>;
    textColor: PD.Color;
    textSize: PD.Numeric;
    borderWidth: PD.Numeric;
    color: PD.Color;
    arcScale: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    linesSize: PD.Numeric;
    dashLength: PD.Numeric;
    ignoreLight: PD.BooleanParam;
    sectorOpacity: PD.Numeric;
    visuals: PD.MultiSelect<"arc" | "sector" | "text" | "vectors">;
};
export type AngleParams = typeof AngleParams;
export type AngleProps = PD.Values<AngleParams>;
export type AngleRepresentation = Representation<AngleData, AngleParams>;
export declare function AngleRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<AngleData, AngleParams>): AngleRepresentation;
//# sourceMappingURL=angle.d.ts.map