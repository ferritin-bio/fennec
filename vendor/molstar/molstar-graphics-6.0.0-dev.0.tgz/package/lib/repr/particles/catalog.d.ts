/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParticleTargetRepresentationProvider } from './representation/target/representation.js';
export declare const BuiltInParticleRepresentations: {
    spacefill: import("./representation.js").ParticleRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        excludeFibers: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        excludeTargets: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
    }, "spacefill">;
    orientation: import("./representation.js").ParticleRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        axisLength: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        xColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        yColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        zColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"axes">;
    }, "orientation">;
    fibers: import("./representation.js").ParticleRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        useLineStrips: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tubeSizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linearSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"lines" | "tube-mesh">;
    }, "fibers">;
    target: ParticleTargetRepresentationProvider<"target">;
};
//# sourceMappingURL=catalog.d.ts.map