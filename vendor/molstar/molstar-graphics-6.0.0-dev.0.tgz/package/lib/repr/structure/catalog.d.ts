/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInStructureRepresentations: {
    cartoon: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        sizeAspectRatio: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        thicknessFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        aspectRatio: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        arrowFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        tubularHelices: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        roundCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        helixProfile: import("@molstar/core/util/param-definition").ParamDefinition.Select<"elliptical" | "rounded" | "square">;
        nucleicProfile: import("@molstar/core/util/param-definition").ParamDefinition.Select<"elliptical" | "rounded" | "square">;
        linearSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"direction-wedge" | "nucleotide-atomic-bond" | "nucleotide-atomic-element" | "nucleotide-atomic-ring-fill" | "nucleotide-block" | "nucleotide-ring" | "polymer-gap" | "polymer-trace">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colorMode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"default" | "interpolate">;
    }, "cartoon">;
    backbone: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeAspectRatio: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"polymer-backbone-cylinder" | "polymer-backbone-sphere" | "polymer-gap">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colorMode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"default" | "interpolate">;
    }, "backbone">;
    'ball-and-stick': import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        linkScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        aromaticScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticDashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stubCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colorMode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"default" | "interpolate">;
        includeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        excludeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        aromaticBonds: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        multipleBonds: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "offset" | "symmetric">;
        metalCoordination: import("@molstar/core/util/param-definition").ParamDefinition.Select<"dashed" | "solid">;
        adjustCylinderLength: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        stride: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeAspectRatio: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"element-sphere" | "inter-bond" | "intra-bond" | "structure-element-sphere" | "structure-intra-bond">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "ball-and-stick">;
    'blob-surface': import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        blobSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        blobMethod: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "grid"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            iterations: number;
        }>, "clustering">>;
        resolution: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        adjustResolution: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        blobShape: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "ellipsoid"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            degree: number;
            regularization: number;
        }>, "sphericalHarmonics">>;
        radiusOffset: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        smoothness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"blob-surface-mesh" | "blob-surface-wireframe" | "structure-blob-surface-mesh" | "structure-blob-surface-wireframe">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
    }, "blob-surface">;
    carbohydrate: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        linkScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        aromaticScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticDashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stubCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colorMode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"default" | "interpolate">;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        linkSizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        terminalLinkSizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"carbohydrate-link" | "carbohydrate-symbol" | "carbohydrate-terminal-link">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "carbohydrate">;
    ellipsoid: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        linkScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticDashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stubCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colorMode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"default" | "interpolate">;
        includeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        excludeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        aromaticBonds: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        multipleBonds: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "offset" | "symmetric">;
        metalCoordination: import("@molstar/core/util/param-definition").ParamDefinition.Select<"dashed" | "solid">;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        adjustCylinderLength: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeAspectRatio: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkCap: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"ellipsoid-mesh" | "inter-bond" | "intra-bond" | "structure-ellipsoid-mesh" | "structure-intra-bond">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "ellipsoid">;
    'gaussian-surface': import("./representation.js").StructureRepresentationProvider<{
        smoothColors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "auto"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "off"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            resolutionFactor: number;
            sampleStride: number;
        }>, "on">>;
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        resolution: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        radiusOffset: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        smoothness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        floodfill: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inside" | "off" | "outside">;
        tryUseGpu: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"gaussian-surface-mesh" | "gaussian-surface-wireframe" | "structure-gaussian-surface-mesh" | "structure-gaussian-surface-wireframe">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "gaussian-surface">;
    'gaussian-volume': import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        controlPoints: import("@molstar/core/util/param-definition").ParamDefinition.LineGraph;
        stepsPerCell: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        resolution: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        radiusOffset: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        smoothness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        jumpLength: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"gaussian-volume" | "units-gaussian-volume">;
    }, "gaussian-volume">;
    label: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        fontFamily: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/text/font-atlas.js").FontFamily>;
        fontQuality: import("@molstar/core/util/param-definition").ParamDefinition.Select<number>;
        fontStyle: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/text/font-atlas.js").FontStyle>;
        fontVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/text/font-atlas.js").FontVariant>;
        fontWeight: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/text/font-atlas.js").FontWeight>;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        borderColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        offsetX: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        offsetY: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        offsetZ: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        tether: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tetherLength: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        tetherBaseWidth: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        attachment: import("@molstar/core/util/param-definition").ParamDefinition.Select<"bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right">;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        background: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        backgroundMargin: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        backgroundColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        backgroundOpacity: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        borderWidth: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        level: import("@molstar/core/util/param-definition").ParamDefinition.Select<"chain" | "element" | "residue">;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        chainScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        residueScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        elementScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"label-text">;
    }, "label">;
    line: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        linkScale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linkSpacing: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        aromaticDashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        dashCount: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        includeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        excludeTypes: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
        aromaticBonds: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        metalCoordination: import("@molstar/core/util/param-definition").ParamDefinition.Select<"dashed" | "solid">;
        pointSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stride: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        crosses: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "lone">;
        crossSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        pointStyle: import("@molstar/core/util/param-definition").ParamDefinition.Select<"circle" | "fuzzy" | "square">;
        multipleBonds: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "offset" | "symmetric">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"element-cross" | "element-point" | "inter-bond" | "intra-bond" | "structure-element-cross" | "structure-element-point" | "structure-intra-bond">;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "line">;
    'molecular-surface': import("./representation.js").StructureRepresentationProvider<{
        smoothColors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "auto"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "off"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            resolutionFactor: number;
            sampleStride: number;
        }>, "on">>;
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        probeRadius: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        resolution: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            isEssential?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: number;
            min?: number;
            max?: number;
            step?: number;
            type: 'number';
            immediateUpdate?: boolean;
        };
        probePositions: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            isEssential?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: number;
            min?: number;
            max?: number;
            step?: number;
            type: 'number';
            immediateUpdate?: boolean;
        };
        floodfill: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inside" | "off" | "outside">;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"molecular-surface-mesh" | "molecular-surface-wireframe" | "structure-molecular-surface-mesh" | "structure-molecular-surface-wireframe">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "molecular-surface">;
    orientation: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"orientation-ellipsoid-mesh">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "orientation">;
    plane: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        interpolation: import("@molstar/core/util/param-definition").ParamDefinition.Select<"bspline" | "catmulrom" | "mitchell" | "nearest">;
        imageResolution: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        mode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"frame" | "plane">;
        offset: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        axis: import("@molstar/core/util/param-definition").ParamDefinition.Select<"a" | "b" | "c">;
        rotation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            axis: import("@molstar/core/math/linear-algebra").Vec3;
            angle: number;
        }>>;
        plane: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            point: import("@molstar/core/math/linear-algebra").Vec3;
            normal: import("@molstar/core/math/linear-algebra").Vec3;
        }>>;
        extent: import("@molstar/core/util/param-definition").ParamDefinition.Select<"frame" | "sphere">;
        margin: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        frame: import("@molstar/core/util/param-definition").ParamDefinition.Select<"boundingBox" | "principalAxes">;
        antialias: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        cutout: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        defaultColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"plane-image">;
    }, "plane">;
    point: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        pointStyle: import("@molstar/core/util/param-definition").ParamDefinition.Select<"circle" | "fuzzy" | "square">;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        pointSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stride: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"element-point" | "structure-element-point">;
    }, "point">;
    putty: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        radialSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        linearSegments: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"polymer-gap" | "polymer-tube">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "putty">;
    spacefill: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        ignoreHydrogens: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreHydrogensVariant: import("@molstar/core/util/param-definition").ParamDefinition.Select<"all" | "non-polar">;
        traceOnly: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        stride: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"element-sphere" | "structure-element-sphere">;
    }, "spacefill">;
    polyhedron: import("./representation.js").StructureRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        unitKinds: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"atomic" | "gaussians" | "spheres">;
        includeParent: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        minCoordination: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        maxCoordination: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"coordination-polyhedron-mesh">;
    }, "polyhedron">;
};
//# sourceMappingURL=catalog.d.ts.map