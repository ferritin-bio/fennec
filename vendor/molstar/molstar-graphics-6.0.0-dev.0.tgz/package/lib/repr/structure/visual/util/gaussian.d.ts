/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { Unit, Structure } from '@molstar/model/model/structure';
import { Task } from '@molstar/core/task';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ComputeContext } from '@molstar/graphics/gl/compute';
import type { Texture } from '@molstar/graphics/gl/texture';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { SizeTheme } from '@molstar/graphics/theme/size';
export declare const GaussianDensityParams: {
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    resolution: PD.Numeric;
    radiusOffset: PD.Numeric;
    smoothness: PD.Numeric;
    floodfill: PD.Select<"inside" | "off" | "outside">;
};
export declare const DefaultGaussianDensityProps: PD.Values<{
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    resolution: PD.Numeric;
    radiusOffset: PD.Numeric;
    smoothness: PD.Numeric;
    floodfill: PD.Select<"inside" | "off" | "outside">;
}>;
export type GaussianDensityProps = typeof DefaultGaussianDensityProps;
/**
 * Cells of a 3d density computed with kernels (WebGPU), by a device limit as the 2d atlas of WebGL
 * (`getTextureMaxCells`): the marching cubes keep a u32 count and offset per cell in storage buffers, so a cell
 * count beyond `maxStorageBufferSize / 4` fails to extract. That is 2²⁵ cells with the core limits (128 MiB storage
 * bindings, a 256 MiB rgba fp16 density), more with the adapter's (requested by default), where the GPU memory, not
 * reported by WebGPU, is the practical limit
 */
export declare function getComputeDensityMaxCells(compute: ComputeContext): number;
export declare function getTextureMaxCells(graphics: GraphicsContext, structure?: Structure): number;
export declare function computeUnitGaussianDensity(structure: Structure, unit: Unit, sizeTheme: SizeTheme<any>, props: GaussianDensityProps): Task<import("@molstar/core/math/geometry/gaussian-density").GaussianDensityData>;
export declare function computeUnitGaussianDensityTexture(structure: Structure, unit: Unit, sizeTheme: SizeTheme<any>, props: Omit<GaussianDensityProps, 'floodfill'>, graphics: GraphicsContext, texture?: Texture, growTexture?: boolean): import("../../../../geo/gaussian-density.js").GaussianDensityTextureData;
export declare function computeUnitGaussianDensityTexture2d(structure: Structure, unit: Unit, sizeTheme: SizeTheme<any>, powerOfTwo: boolean, props: GaussianDensityProps, graphics: GraphicsContext, texture?: Texture): import("../../../../geo/gaussian-density.js").GaussianDensityTextureData;
export declare function computeStructureGaussianDensity(structure: Structure, sizeTheme: SizeTheme<any>, props: GaussianDensityProps): Task<import("@molstar/core/math/geometry/gaussian-density").GaussianDensityData>;
export declare function computeStructureGaussianDensityTexture(structure: Structure, sizeTheme: SizeTheme<any>, props: Omit<GaussianDensityProps, 'floodfill'>, graphics: GraphicsContext, texture?: Texture, growTexture?: boolean): import("../../../../geo/gaussian-density.js").GaussianDensityTextureData;
export declare function computeStructureGaussianDensityTexture2d(structure: Structure, sizeTheme: SizeTheme<any>, powerOfTwo: boolean, props: GaussianDensityProps, graphics: GraphicsContext, texture?: Texture): import("../../../../geo/gaussian-density.js").GaussianDensityTextureData;
//# sourceMappingURL=gaussian.d.ts.map