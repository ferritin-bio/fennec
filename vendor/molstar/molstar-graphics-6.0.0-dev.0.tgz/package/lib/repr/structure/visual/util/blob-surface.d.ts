/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { Unit, Structure } from '@molstar/model/model/structure';
import { Task } from '@molstar/core/task';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type BlobSurfaceData } from '@molstar/core/math/geometry/blob-surface';
import type { SizeTheme } from '@molstar/graphics/theme/size';
export declare const BlobSurfaceCoreParams: {
    blobSize: PD.Numeric;
    blobMethod: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "grid"> | PD.NamedParams<PD.Normalize<{
        iterations: number;
    }>, "clustering">>;
    resolution: PD.Numeric;
    adjustResolution: PD.BooleanParam;
    blobShape: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "ellipsoid"> | PD.NamedParams<PD.Normalize<{
        degree: number;
        regularization: number;
    }>, "sphericalHarmonics">>;
    radiusOffset: PD.Numeric;
    smoothness: PD.Numeric;
};
export type BlobSurfaceCoreParams = typeof BlobSurfaceCoreParams;
export type BlobSurfaceCoreProps = PD.Values<BlobSurfaceCoreParams>;
export declare const BlobDensityParams: {
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    blobSize: PD.Numeric;
    blobMethod: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "grid"> | PD.NamedParams<PD.Normalize<{
        iterations: number;
    }>, "clustering">>;
    resolution: PD.Numeric;
    adjustResolution: PD.BooleanParam;
    blobShape: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "ellipsoid"> | PD.NamedParams<PD.Normalize<{
        degree: number;
        regularization: number;
    }>, "sphericalHarmonics">>;
    radiusOffset: PD.Numeric;
    smoothness: PD.Numeric;
};
export declare const DefaultBlobDensityProps: PD.Values<{
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    blobSize: PD.Numeric;
    blobMethod: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "grid"> | PD.NamedParams<PD.Normalize<{
        iterations: number;
    }>, "clustering">>;
    resolution: PD.Numeric;
    adjustResolution: PD.BooleanParam;
    blobShape: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "ellipsoid"> | PD.NamedParams<PD.Normalize<{
        degree: number;
        regularization: number;
    }>, "sphericalHarmonics">>;
    radiusOffset: PD.Numeric;
    smoothness: PD.Numeric;
}>;
export type BlobDensityProps = typeof DefaultBlobDensityProps;
export type BlobDensityData = BlobSurfaceData;
export declare function shouldUpdateBlobGeometry(newProps: BlobDensityProps, currentProps: BlobDensityProps): boolean;
export declare function computeUnitBlobSurface(structure: Structure, unit: Unit, sizeTheme: SizeTheme<any>, props: BlobDensityProps): Task<BlobSurfaceData>;
export declare function computeStructureBlobSurface(structure: Structure, sizeTheme: SizeTheme<any>, props: BlobDensityProps): Task<BlobSurfaceData>;
//# sourceMappingURL=blob-surface.d.ts.map