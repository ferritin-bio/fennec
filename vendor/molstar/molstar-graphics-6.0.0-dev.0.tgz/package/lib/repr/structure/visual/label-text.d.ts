/**
 * Copyright (c) 2019-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type ComplexVisual } from '../complex-visual.js';
import { Vec3 } from '@molstar/core/math/linear-algebra';
export declare const LabelTextParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    fontFamily: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontFamily>;
    fontQuality: PD.Select<number>;
    fontStyle: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontStyle>;
    fontVariant: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontVariant>;
    fontWeight: PD.Select<import("../../../geo/geometry/text/font-atlas.js").FontWeight>;
    sizeFactor: PD.Numeric;
    borderColor: PD.Color;
    offsetX: PD.Numeric;
    offsetY: PD.Numeric;
    offsetZ: PD.Numeric;
    tether: PD.BooleanParam;
    tetherLength: PD.Numeric;
    tetherBaseWidth: PD.Numeric;
    attachment: PD.Select<"bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right">;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    includeParent: PD.BooleanParam;
    background: PD.BooleanParam;
    backgroundMargin: PD.Numeric;
    backgroundColor: PD.Color;
    backgroundOpacity: PD.Numeric;
    borderWidth: PD.Numeric;
    level: PD.Select<"chain" | "element" | "residue">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    chainScale: PD.Numeric;
    residueScale: PD.Numeric;
    elementScale: PD.Numeric;
};
export type LabelTextParams = typeof LabelTextParams;
export type LabelTextProps = PD.Values<LabelTextParams>;
export type LabelLevels = LabelTextProps['level'];
export declare function LabelTextVisual(materialId: number): ComplexVisual<LabelTextParams>;
//# sourceMappingURL=label-text.d.ts.map