/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { BondType } from '@molstar/model/model/structure/model/types';
import { Unit, StructureElement, Structure, Bond } from '@molstar/model/model/structure';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { LocationIterator } from '@molstar/graphics/geo/util/location-iterator';
import { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { type Loci } from '@molstar/model/model/loci';
import { Interval } from '@molstar/core/data/int';
import { type StructureGroup } from './common.js';
export declare const BondParams: {
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
};
export declare const DefaultBondProps: PD.Values<{
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
}>;
export type BondProps = typeof DefaultBondProps;
export declare const BondCylinderParams: {
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    linkCap: PD.BooleanParam;
    aromaticScale: PD.Numeric;
    aromaticSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    dashScale: PD.Numeric;
    dashCap: PD.BooleanParam;
    stubCap: PD.BooleanParam;
    radialSegments: PD.Numeric;
    colorMode: PD.Select<"default" | "interpolate">;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
    adjustCylinderLength: PD.BooleanParam;
};
export declare const DefaultBondCylinderProps: PD.Values<{
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    linkCap: PD.BooleanParam;
    aromaticScale: PD.Numeric;
    aromaticSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    dashScale: PD.Numeric;
    dashCap: PD.BooleanParam;
    stubCap: PD.BooleanParam;
    radialSegments: PD.Numeric;
    colorMode: PD.Select<"default" | "interpolate">;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
    adjustCylinderLength: PD.BooleanParam;
}>;
export type BondCylinderProps = typeof DefaultBondCylinderProps;
export declare const BondLineParams: {
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
};
export declare const DefaultBondLineProps: PD.Values<{
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
}>;
export type BondLineProps = typeof DefaultBondLineProps;
export declare function ignoreBondType(include: BondType.Flag, exclude: BondType.Flag, f: BondType.Flag): boolean;
export declare function makeIntraBondIgnoreTest(structure: Structure, unit: Unit.Atomic, props: BondProps): undefined | ((edgeIndex: number) => boolean);
export declare function makeInterBondIgnoreTest(structure: Structure, props: BondProps): undefined | ((edgeIndex: number) => boolean);
export declare function hasUnitVisibleBonds(unit: Unit.Atomic, props: {
    ignoreHydrogens: boolean;
    ignoreHydrogensVariant: 'all' | 'non-polar' | 'polar';
}): boolean;
export declare function hasStructureVisibleBonds(structure: Structure, props: {
    ignoreHydrogens: boolean;
    ignoreHydrogensVariant: 'all' | 'non-polar' | 'polar';
}): boolean;
export declare namespace BondIterator {
    function fromGroup(structureGroup: StructureGroup, props?: {
        includeLocation2?: boolean;
    }): LocationIterator;
    function fromStructure(structure: Structure, props?: {
        includeLocation2?: boolean;
    }): LocationIterator;
    function fromStructureGroups(structure: Structure, props?: {
        includeLocation2?: boolean;
    }): LocationIterator;
}
export declare function getIntraBondLoci(pickingId: PickingId, structureGroup: StructureGroup, id: number): Bond.Loci | StructureElement.Loci | {
    kind: 'empty-loci';
};
export declare function eachIntraBond(loci: Loci, structureGroup: StructureGroup, apply: (interval: Interval) => boolean, isMarking: boolean): boolean;
export declare function getInterBondLoci(pickingId: PickingId, structure: Structure, id: number): Structure.Loci | Bond.Loci | {
    kind: 'empty-loci';
};
export declare function eachInterBond(loci: Loci, structure: Structure, apply: (interval: Interval) => boolean, isMarking: boolean): boolean;
export declare function getStructureGroupsBondLoci(pickingId: PickingId, structure: Structure, id: number): Bond.Loci | StructureElement.Loci | {
    kind: 'empty-loci';
};
export declare function eachStructureGroupsBond(loci: Loci, structure: Structure, apply: (interval: Interval) => boolean, isMarking: boolean): boolean;
//# sourceMappingURL=bond.d.ts.map