/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Unit, StructureElement, Structure, type ElementIndex } from '@molstar/model/model/structure';
import { type Loci } from '@molstar/model/model/loci';
import { Interval, SortedArray } from '@molstar/core/data/int';
import { Mesh } from '@molstar/graphics/geo/geometry/mesh/mesh';
import { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { LocationIterator } from '@molstar/graphics/geo/util/location-iterator';
import type { VisualContext } from '../../../visual.js';
import type { Theme } from '@molstar/graphics/theme/theme';
import { Spheres } from '@molstar/graphics/geo/geometry/spheres/spheres';
import { type StructureGroup } from './common.js';
type ElementProps = {
    ignoreHydrogens: boolean;
    ignoreHydrogensVariant: 'all' | 'non-polar';
    traceOnly: boolean;
    stride?: number;
};
export type ElementSphereMeshProps = {
    detail: number;
    sizeFactor: number;
} & ElementProps;
export type ElementSphereImpostorProps = {
    sizeFactor: number;
} & ElementProps;
export declare function makeElementIgnoreTest(structure: Structure, unit: Unit, props: ElementProps): undefined | ((i: ElementIndex) => boolean);
export declare function createElementSphereMesh(ctx: VisualContext, unit: Unit, structure: Structure, theme: Theme, props: ElementSphereMeshProps, mesh?: Mesh): Mesh;
export declare function createElementSphereImpostor(ctx: VisualContext, unit: Unit, structure: Structure, theme: Theme, props: ElementSphereImpostorProps, spheres?: Spheres): Spheres;
/** Applies the runs of consecutive `indices`, shifted by `offset`, one interval each */
export declare function applyIndexRuns(indices: SortedArray<number>, offset: number, apply: (interval: Interval) => boolean): boolean;
export declare function eachElement(loci: Loci, structureGroup: StructureGroup, apply: (interval: Interval) => boolean): boolean;
export declare function getElementLoci(pickingId: PickingId, structureGroup: StructureGroup, id: number): StructureElement.Loci | {
    kind: 'empty-loci';
};
export declare function createStructureElementSphereMesh(ctx: VisualContext, structure: Structure, theme: Theme, props: ElementSphereMeshProps, mesh?: Mesh): Mesh;
export declare function createStructureElementSphereImpostor(ctx: VisualContext, structure: Structure, theme: Theme, props: ElementSphereImpostorProps, spheres?: Spheres): Spheres;
export declare function eachSerialElement(loci: Loci, structure: Structure, apply: (interval: Interval) => boolean): boolean;
export declare function getSerialElementLoci(pickingId: PickingId, structure: Structure, id: number): Structure.Loci | StructureElement.Loci | {
    kind: 'empty-loci';
};
export declare namespace ElementIterator {
    function fromGroup(structureGroup: StructureGroup): LocationIterator;
    function fromStructure(structure: Structure): LocationIterator;
}
export {};
//# sourceMappingURL=element.d.ts.map