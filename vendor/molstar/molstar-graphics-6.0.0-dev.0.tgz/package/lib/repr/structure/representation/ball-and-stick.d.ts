/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type StructureRepresentation, StructureRepresentationProvider } from '../representation.js';
import { type RepresentationParamsGetter, type RepresentationContext } from '../../representation.js';
import type { ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { Structure } from '@molstar/model/model/structure';
export declare const BallAndStickParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    doubleSided: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    linkCap: PD.BooleanParam;
    aromaticScale: PD.Numeric;
    aromaticSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    dashScale: PD.Numeric;
    dashCap: PD.BooleanParam;
    stubCap: PD.BooleanParam;
    radialSegments: PD.Numeric;
    colorMode: PD.Select<"default" | "interpolate">;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
    adjustCylinderLength: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    stride: PD.Numeric;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    sizeFactor: PD.Numeric;
    sizeAspectRatio: PD.Numeric;
    visuals: PD.MultiSelect<"element-sphere" | "inter-bond" | "intra-bond" | "structure-element-sphere" | "structure-intra-bond">;
    bumpFrequency: PD.Numeric;
    density: PD.Numeric;
};
export type BallAndStickParams = typeof BallAndStickParams;
export declare function getBallAndStickParams(ctx: ThemeRegistryContext, structure: Structure): {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    doubleSided: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    linkCap: PD.BooleanParam;
    aromaticScale: PD.Numeric;
    aromaticSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    dashScale: PD.Numeric;
    dashCap: PD.BooleanParam;
    stubCap: PD.BooleanParam;
    radialSegments: PD.Numeric;
    colorMode: PD.Select<"default" | "interpolate">;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
    adjustCylinderLength: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    stride: PD.Numeric;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    sizeFactor: PD.Numeric;
    sizeAspectRatio: PD.Numeric;
    visuals: PD.MultiSelect<"element-sphere" | "inter-bond" | "intra-bond" | "structure-element-sphere" | "structure-intra-bond">;
    bumpFrequency: PD.Numeric;
    density: PD.Numeric;
};
export type BallAndStickRepresentation = StructureRepresentation<BallAndStickParams>;
export declare function BallAndStickRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<Structure, BallAndStickParams>): BallAndStickRepresentation;
export declare const BallAndStickRepresentationProvider: StructureRepresentationProvider<{
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    doubleSided: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    linkCap: PD.BooleanParam;
    aromaticScale: PD.Numeric;
    aromaticSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    dashScale: PD.Numeric;
    dashCap: PD.BooleanParam;
    stubCap: PD.BooleanParam;
    radialSegments: PD.Numeric;
    colorMode: PD.Select<"default" | "interpolate">;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    aromaticBonds: PD.BooleanParam;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    metalCoordination: PD.Select<"dashed" | "solid">;
    adjustCylinderLength: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    stride: PD.Numeric;
    traceOnly: PD.BooleanParam;
    includeParent: PD.BooleanParam;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    sizeFactor: PD.Numeric;
    sizeAspectRatio: PD.Numeric;
    visuals: PD.MultiSelect<"element-sphere" | "inter-bond" | "intra-bond" | "structure-element-sphere" | "structure-intra-bond">;
    bumpFrequency: PD.Numeric;
    density: PD.Numeric;
}, "ball-and-stick">;
//# sourceMappingURL=ball-and-stick.d.ts.map