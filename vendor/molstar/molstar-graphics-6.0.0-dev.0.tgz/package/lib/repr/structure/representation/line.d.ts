/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type StructureRepresentation, StructureRepresentationProvider } from '../representation.js';
import { type RepresentationParamsGetter, type RepresentationContext } from '../../representation.js';
import type { ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { Structure } from '@molstar/model/model/structure';
export declare const LineParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    aromaticBonds: PD.BooleanParam;
    metalCoordination: PD.Select<"dashed" | "solid">;
    pointSizeAttenuation: PD.BooleanParam;
    stride: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    crosses: PD.Select<"all" | "lone">;
    crossSize: PD.Numeric;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    includeParent: PD.BooleanParam;
    sizeFactor: PD.Numeric;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    visuals: PD.MultiSelect<"element-cross" | "element-point" | "inter-bond" | "intra-bond" | "structure-element-cross" | "structure-element-point" | "structure-intra-bond">;
    density: PD.Numeric;
};
export type LineParams = typeof LineParams;
export declare function getLineParams(ctx: ThemeRegistryContext, structure: Structure): {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    aromaticBonds: PD.BooleanParam;
    metalCoordination: PD.Select<"dashed" | "solid">;
    pointSizeAttenuation: PD.BooleanParam;
    stride: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    crosses: PD.Select<"all" | "lone">;
    crossSize: PD.Numeric;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    includeParent: PD.BooleanParam;
    sizeFactor: PD.Numeric;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    visuals: PD.MultiSelect<"element-cross" | "element-point" | "inter-bond" | "intra-bond" | "structure-element-cross" | "structure-element-point" | "structure-intra-bond">;
    density: PD.Numeric;
};
export type LineRepresentation = StructureRepresentation<LineParams>;
export declare function LineRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<Structure, LineParams>): LineRepresentation;
export declare const LineRepresentationProvider: StructureRepresentationProvider<{
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    linkScale: PD.Numeric;
    linkSpacing: PD.Numeric;
    aromaticDashCount: PD.Numeric;
    dashCount: PD.Numeric;
    includeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    excludeTypes: PD.MultiSelect<"aromatic" | "computed" | "covalent" | "disulfide" | "hydrogen-bond" | "metal-coordination">;
    aromaticBonds: PD.BooleanParam;
    metalCoordination: PD.Select<"dashed" | "solid">;
    pointSizeAttenuation: PD.BooleanParam;
    stride: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    traceOnly: PD.BooleanParam;
    crosses: PD.Select<"all" | "lone">;
    crossSize: PD.Numeric;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    multipleBonds: PD.Select<"off" | "offset" | "symmetric">;
    includeParent: PD.BooleanParam;
    sizeFactor: PD.Numeric;
    unitKinds: PD.MultiSelect<"atomic" | "gaussians" | "spheres">;
    visuals: PD.MultiSelect<"element-cross" | "element-point" | "inter-bond" | "intra-bond" | "structure-element-cross" | "structure-element-point" | "structure-intra-bond">;
    density: PD.Numeric;
}, "line">;
//# sourceMappingURL=line.d.ts.map