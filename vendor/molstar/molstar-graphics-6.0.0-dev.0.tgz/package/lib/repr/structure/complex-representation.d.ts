/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type ComplexVisual, type StructureRepresentation } from './representation.js';
import { type RepresentationContext, type RepresentationParamsGetter } from '../representation.js';
import { Structure } from '@molstar/model/model/structure';
import type { StructureParams } from './params.js';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
export declare function ComplexRepresentation<P extends StructureParams>(label: string, ctx: RepresentationContext, getParams: RepresentationParamsGetter<Structure, P>, visualCtor: (materialId: number, structure: Structure, props: PD.Values<P>, graphics?: GraphicsContext) => ComplexVisual<P>): StructureRepresentation<P>;
//# sourceMappingURL=complex-representation.d.ts.map