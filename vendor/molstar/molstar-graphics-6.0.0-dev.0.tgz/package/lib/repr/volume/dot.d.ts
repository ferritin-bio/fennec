/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Volume } from '@molstar/model/model/volume';
import type { VisualContext } from '../visual.js';
import type { Theme, ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { Mesh } from '@molstar/graphics/geo/geometry/mesh/mesh';
import { VolumeRepresentation, VolumeRepresentationProvider } from './representation.js';
import { type RepresentationContext, type RepresentationParamsGetter } from '../representation.js';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { Spheres } from '@molstar/graphics/geo/geometry/spheres/spheres';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { Points } from '@molstar/graphics/geo/geometry/points/points';
import { Mat4 } from '@molstar/core/math/linear-algebra';
import { VolumeVisual } from './visual.js';
export declare const VolumeDotParams: {
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
};
export type VolumeDotParams = typeof VolumeDotParams;
export type VolumeDotProps = PD.Values<VolumeDotParams>;
export declare const VolumeSphereParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    bumpFrequency: PD.Numeric;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    sizeFactor: PD.Numeric;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
    solidInterior: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
};
export type VolumeSphereParams = typeof VolumeSphereParams;
export type VolumeSphereProps = PD.Values<VolumeSphereParams>;
export declare function VolumeSphereVisual(materialId: number, volume: Volume, key: number, props: PD.Values<VolumeSphereParams>, graphics?: GraphicsContext): VolumeVisual<{
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    bumpFrequency: PD.Numeric;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    sizeFactor: PD.Numeric;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
    solidInterior: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
}>;
export declare function VolumeSphereImpostorVisual(materialId: number): VolumeVisual<VolumeSphereParams>;
export declare function VolumeSphereMeshVisual(materialId: number): VolumeVisual<VolumeSphereParams>;
export declare function createVolumeSphereImpostor(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: VolumeSphereProps, spheres?: Spheres): Spheres;
export declare function createVolumeSphereMesh(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: VolumeSphereProps, mesh?: Mesh): Mesh;
export declare const VolumePointParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    sizeFactor: PD.Numeric;
    pointSizeAttenuation: PD.BooleanParam;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
};
export type VolumePointParams = typeof VolumePointParams;
export type VolumePointProps = PD.Values<VolumePointParams>;
export declare function VolumePointVisual(materialId: number): VolumeVisual<VolumePointParams>;
export declare function createVolumePoint(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: VolumePointProps, points?: Points): Points;
export declare const DotParams: {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    pointSizeAttenuation: PD.BooleanParam;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
    solidInterior: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"point" | "sphere">;
    bumpFrequency: PD.Numeric;
};
export type DotParams = typeof DotParams;
export declare function getDotParams(ctx: ThemeRegistryContext, volume: Volume): {
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    pointSizeAttenuation: PD.BooleanParam;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
    solidInterior: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"point" | "sphere">;
    bumpFrequency: PD.Numeric;
};
export type DotRepresentation = VolumeRepresentation<DotParams>;
export declare function DotRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<Volume, DotParams>): DotRepresentation;
export declare const DotRepresentationProvider: VolumeRepresentationProvider<{
    alpha: PD.Numeric;
    quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    pointSizeAttenuation: PD.BooleanParam;
    pointStyle: PD.Select<"circle" | "fuzzy" | "square">;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    clipPrimitive: PD.BooleanParam;
    approximate: PD.BooleanParam;
    alphaThickness: PD.Numeric;
    lodLevels: PD.ObjectList<PD.Normalize<{
        minDistance: number;
        maxDistance: number;
        overlap: number;
        stride: number;
        scaleBias: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    perturbPositions: PD.BooleanParam;
    solidInterior: PD.BooleanParam;
    tryUseImpostor: PD.BooleanParam;
    detail: PD.Numeric;
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"point" | "sphere">;
    bumpFrequency: PD.Numeric;
}, "dot">;
//# sourceMappingURL=dot.d.ts.map