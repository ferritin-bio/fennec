/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Volume } from '@molstar/model/model/volume';
import type { VisualContext } from '../visual.js';
import type { Theme, ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { Mesh } from '@molstar/graphics/geo/geometry/mesh/mesh';
import { VolumeRepresentation, VolumeRepresentationProvider } from './representation.js';
import { Lines } from '@molstar/graphics/geo/geometry/lines/lines';
import { type RepresentationContext, type RepresentationParamsGetter } from '../representation.js';
import { type Loci } from '@molstar/model/model/loci';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { Interval } from '@molstar/core/data/int/interval';
import { VolumeVisual } from './visual.js';
export declare const VolumeIsosurfaceParams: {
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
};
export type VolumeIsosurfaceParams = typeof VolumeIsosurfaceParams;
export type VolumeIsosurfaceProps = PD.Values<VolumeIsosurfaceParams>;
export declare const VolumeIsosurfaceTextureParams: {
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
};
export type VolumeIsosurfaceTextureParams = typeof VolumeIsosurfaceTextureParams;
export type VolumeIsosurfaceTextureProps = PD.Values<VolumeIsosurfaceTextureParams>;
export declare function IsosurfaceVisual(materialId: number, volume: Volume, key: number, props: PD.Values<IsosurfaceMeshParams>, graphics?: GraphicsContext): VolumeVisual<{
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpFrequency: PD.Numeric;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
}>;
export declare function eachIsosurface(loci: Loci, volume: Volume, key: number, props: VolumeIsosurfaceProps, apply: (interval: Interval) => boolean): boolean;
export declare function createVolumeIsosurfaceMesh(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: VolumeIsosurfaceProps, mesh?: Mesh): Promise<Mesh>;
export declare const IsosurfaceMeshParams: {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpFrequency: PD.Numeric;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
};
export type IsosurfaceMeshParams = typeof IsosurfaceMeshParams;
export declare function IsosurfaceMeshVisual(materialId: number): VolumeVisual<IsosurfaceMeshParams>;
export declare function IsosurfaceTextureMeshVisual(materialId: number): VolumeVisual<IsosurfaceMeshParams>;
export declare function createVolumeIsosurfaceWireframe(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: VolumeIsosurfaceProps, lines?: Lines): Promise<Lines>;
export declare const IsosurfaceWireframeParams: {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    sizeFactor: PD.Numeric;
};
export type IsosurfaceWireframeParams = typeof IsosurfaceWireframeParams;
export declare function IsosurfaceWireframeVisual(materialId: number): VolumeVisual<IsosurfaceWireframeParams>;
export declare const IsosurfaceParams: {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"solid" | "wireframe">;
    bumpFrequency: PD.Numeric;
};
export type IsosurfaceParams = typeof IsosurfaceParams;
export declare function getIsosurfaceParams(ctx: ThemeRegistryContext, volume: Volume): {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"solid" | "wireframe">;
    bumpFrequency: PD.Numeric;
};
export type IsosurfaceRepresentation = VolumeRepresentation<IsosurfaceParams>;
export declare function IsosurfaceRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<Volume, IsosurfaceParams>): IsosurfaceRepresentation;
export declare const IsosurfaceRepresentationProvider: VolumeRepresentationProvider<{
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue>;
    renderMerged: PD.Select<import("@molstar/graphics/geo/geometry/base").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    lineSizeAttenuation: PD.BooleanParam;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
    doubleSided: PD.BooleanParam;
    flipSided: PD.BooleanParam;
    flatShaded: PD.BooleanParam;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
    solidInterior: PD.BooleanParam;
    bumpAmplitude: PD.Numeric;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    isoValue: PD.Conditioned<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>, PD.Base<Readonly<{
        kind: 'relative';
        relativeValue: number;
    }> | Readonly<{
        kind: 'absolute';
        absoluteValue: number;
    }>>, {
        absolute: PD.Converted<Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, number>;
        relative: PD.Converted<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }>, number>;
    }>;
    wrap: PD.Select<"auto" | "off" | "on">;
    floodfill: PD.Select<"inside" | "off" | "outside">;
    tryUseGpu: PD.BooleanParam;
    gpuDataType: PD.Select<"byte" | "float" | "halfFloat">;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    sizeFactor: PD.Numeric;
    visuals: PD.MultiSelect<"solid" | "wireframe">;
    bumpFrequency: PD.Numeric;
}, "isosurface">;
//# sourceMappingURL=isosurface.d.ts.map