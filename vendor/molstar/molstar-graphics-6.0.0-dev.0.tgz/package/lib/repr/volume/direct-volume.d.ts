/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3, Mat4 } from '@molstar/core/math/linear-algebra';
import { Volume } from '@molstar/model/model/volume';
import type { RuntimeContext } from '@molstar/core/task';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { DirectVolume } from '@molstar/graphics/geo/geometry/direct-volume/direct-volume';
import type { VisualContext } from '../visual.js';
import type { Theme, ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { VolumeRepresentation, VolumeRepresentationProvider } from './representation.js';
import type { RepresentationContext, RepresentationParamsGetter } from '../representation.js';
import { type Loci } from '@molstar/model/model/loci';
import type { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { Interval } from '@molstar/core/data/int/interval';
import { VolumeVisual } from './visual.js';
export declare function createDirectVolume2d(ctx: RuntimeContext, graphics: GraphicsContext, volume: Volume, props: PD.Values<DirectVolumeParams>, directVolume?: DirectVolume): DirectVolume;
export declare function createDirectVolume3d(ctx: RuntimeContext, graphics: GraphicsContext, volume: Volume, props: PD.Values<DirectVolumeParams>, directVolume?: DirectVolume): DirectVolume;
export declare function createDirectVolume(ctx: VisualContext, volume: Volume, key: number, theme: Theme, props: PD.Values<DirectVolumeParams>, directVolume?: DirectVolume): Promise<DirectVolume>;
export declare function getDirectVolumeLoci(pickingId: PickingId, volume: Volume, key: number, props: DirectVolumeProps, id: number): Volume.Cell.Loci | {
    kind: 'empty-loci';
};
export declare function eachDirectVolume(loci: Loci, volume: Volume, key: number, props: DirectVolumeProps, apply: (interval: Interval) => boolean): boolean;
export declare const DirectVolumeParams: {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    controlPoints: PD.LineGraph;
    stepsPerCell: PD.Numeric;
    jumpLength: PD.Numeric;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    dataType: PD.Select<"byte" | "float" | "halfFloat">;
};
export type DirectVolumeParams = typeof DirectVolumeParams;
export declare function getDirectVolumeParams(ctx: ThemeRegistryContext, volume: Volume): {
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    controlPoints: PD.LineGraph;
    stepsPerCell: PD.Numeric;
    jumpLength: PD.Numeric;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    dataType: PD.Select<"byte" | "float" | "halfFloat">;
};
export type DirectVolumeProps = PD.Values<DirectVolumeParams>;
export declare function DirectVolumeVisual(materialId: number): VolumeVisual<DirectVolumeParams>;
export declare function DirectVolumeRepresentation(ctx: RepresentationContext, getParams: RepresentationParamsGetter<Volume, DirectVolumeParams>): VolumeRepresentation<DirectVolumeParams>;
export declare const DirectVolumeRepresentationProvider: VolumeRepresentationProvider<{
    alpha: PD.Numeric;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>[];
    }>>;
    emissive: PD.Numeric;
    density: PD.Numeric;
    instanceGranularity: PD.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
    renderMerged: PD.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
    lod: PD.Vec3;
    cellSize: PD.Numeric;
    batchSize: PD.Numeric;
    ignoreLight: PD.BooleanParam;
    celShaded: PD.BooleanParam;
    xrayShaded: PD.Select<"inverted" | boolean>;
    controlPoints: PD.LineGraph;
    stepsPerCell: PD.Numeric;
    jumpLength: PD.Numeric;
    quality: {
        label?: string;
        description?: string;
        legend?: import("@molstar/core/util/legend").Legend;
        fieldLabels?: {
            [name: string]: string;
        };
        isHidden?: boolean;
        shortLabel?: boolean;
        twoColumns?: boolean;
        category?: string;
        hideIf?: (currentGroup: any) => boolean;
        help?: (value: any) => {
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
        };
        isOptional?: boolean;
        defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        type: 'select';
        options: readonly PD.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
        cycle?: boolean;
        isEssential: boolean;
    };
    dataType: PD.Select<"byte" | "float" | "halfFloat">;
}, "direct-volume">;
//# sourceMappingURL=direct-volume.d.ts.map