/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInVolumeRepresentations: {
    'direct-volume': import("./representation.js").VolumeRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        controlPoints: import("@molstar/core/util/param-definition").ParamDefinition.LineGraph;
        stepsPerCell: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        jumpLength: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            type: 'select';
            options: readonly import("@molstar/core/util/param-definition").ParamDefinition.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
            cycle?: boolean;
            isEssential: boolean;
        };
        dataType: import("@molstar/core/util/param-definition").ParamDefinition.Select<"byte" | "float" | "halfFloat">;
    }, "direct-volume">;
    dot: import("./representation.js").VolumeRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        quality: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        pointSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        pointStyle: import("@molstar/core/util/param-definition").ParamDefinition.Select<"circle" | "fuzzy" | "square">;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        clipPrimitive: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        approximate: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        alphaThickness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lodLevels: import("@molstar/core/util/param-definition").ParamDefinition.ObjectList<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            minDistance: number;
            maxDistance: number;
            overlap: number;
            stride: number;
            scaleBias: number;
        }>>;
        isoValue: import("@molstar/core/util/param-definition").ParamDefinition.Conditioned<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, import("@molstar/core/util/param-definition").ParamDefinition.Base<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>>, {
            absolute: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'absolute';
                absoluteValue: number;
            }>, number>;
            relative: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'relative';
                relativeValue: number;
            }>, number>;
        }>;
        perturbPositions: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        tryUseImpostor: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        detail: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"point" | "sphere">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "dot">;
    isosurface: import("./representation.js").VolumeRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lineSizeAttenuation: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        isoValue: import("@molstar/core/util/param-definition").ParamDefinition.Conditioned<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, import("@molstar/core/util/param-definition").ParamDefinition.Base<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>>, {
            absolute: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'absolute';
                absoluteValue: number;
            }>, number>;
            relative: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'relative';
                relativeValue: number;
            }>, number>;
        }>;
        wrap: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auto" | "off" | "on">;
        floodfill: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inside" | "off" | "outside">;
        tryUseGpu: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        gpuDataType: import("@molstar/core/util/param-definition").ParamDefinition.Select<"byte" | "float" | "halfFloat">;
        quality: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            type: 'select';
            options: readonly import("@molstar/core/util/param-definition").ParamDefinition.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
            cycle?: boolean;
            isEssential: boolean;
        };
        sizeFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"solid" | "wireframe">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "isosurface">;
    segment: import("./representation.js").VolumeRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        doubleSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flipSided: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        flatShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        ignoreLight: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        celShaded: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        xrayShaded: import("@molstar/core/util/param-definition").ParamDefinition.Select<"inverted" | boolean>;
        transparentBackfaces: import("@molstar/core/util/param-definition").ParamDefinition.Select<"off" | "on" | "opaque">;
        solidInterior: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        bumpAmplitude: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interior: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        segments: import("@molstar/core/util/param-definition").ParamDefinition.Converted<number[], string[]>;
        quality: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            type: 'select';
            options: readonly import("@molstar/core/util/param-definition").ParamDefinition.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
            cycle?: boolean;
            isEssential: boolean;
        };
        tryUseGpu: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        visuals: import("@molstar/core/util/param-definition").ParamDefinition.MultiSelect<"segment">;
        bumpFrequency: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "segment">;
    slice: import("./representation.js").VolumeRepresentationProvider<{
        alpha: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        material: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        density: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        instanceGranularity: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").InstanceGranularityValue>;
        renderMerged: import("@molstar/core/util/param-definition").ParamDefinition.Select<import("../../geo/geometry/base.js").RenderMergedValue>;
        lod: import("@molstar/core/util/param-definition").ParamDefinition.Vec3;
        cellSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        batchSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        interpolation: import("@molstar/core/util/param-definition").ParamDefinition.Select<"bspline" | "catmulrom" | "mitchell" | "nearest">;
        quality: {
            label?: string;
            description?: string;
            legend?: import("@molstar/core/util/legend").Legend;
            fieldLabels?: {
                [name: string]: string;
            };
            isHidden?: boolean;
            shortLabel?: boolean;
            twoColumns?: boolean;
            category?: string;
            hideIf?: (currentGroup: any) => boolean;
            help?: (value: any) => {
                description?: string;
                legend?: import("@molstar/core/util/legend").Legend;
            };
            isOptional?: boolean;
            defaultValue: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            type: 'select';
            options: readonly import("@molstar/core/util/param-definition").ParamDefinition.SelectOption<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">[];
            cycle?: boolean;
            isEssential: boolean;
        };
        dimension: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "relativeX"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "relativeY"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "relativeZ"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "x"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "y"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<number, "z">>;
        isoValue: import("@molstar/core/util/param-definition").ParamDefinition.Conditioned<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>, import("@molstar/core/util/param-definition").ParamDefinition.Base<Readonly<{
            kind: 'relative';
            relativeValue: number;
        }> | Readonly<{
            kind: 'absolute';
            absoluteValue: number;
        }>>, {
            absolute: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'absolute';
                absoluteValue: number;
            }>, number>;
            relative: import("@molstar/core/util/param-definition").ParamDefinition.Converted<Readonly<{
                kind: 'relative';
                relativeValue: number;
            }>, number>;
        }>;
        mode: import("@molstar/core/util/param-definition").ParamDefinition.Select<"frame" | "grid" | "plane">;
        offset: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        axis: import("@molstar/core/util/param-definition").ParamDefinition.Select<"a" | "b" | "c">;
        rotation: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            axis: import("@molstar/core/math/linear-algebra").Vec3;
            angle: number;
        }>>;
        plane: import("@molstar/core/util/param-definition").ParamDefinition.Group<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            point: import("@molstar/core/math/linear-algebra").Vec3;
            normal: import("@molstar/core/math/linear-algebra").Vec3;
        }>>;
    }, "slice">;
};
//# sourceMappingURL=catalog.d.ts.map