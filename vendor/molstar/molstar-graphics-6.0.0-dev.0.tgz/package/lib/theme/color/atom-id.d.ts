/**
 * Copyright (c) 2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ColorTheme } from '../color.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '../theme.js';
export declare const AtomIdColorThemeParams: {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
};
export type AtomIdColorThemeParams = typeof AtomIdColorThemeParams;
export declare function getAtomIdColorThemeParams(ctx: ThemeDataContext): {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
};
export declare function AtomIdColorTheme(ctx: ThemeDataContext, props: PD.Values<AtomIdColorThemeParams>): ColorTheme<AtomIdColorThemeParams>;
export declare const AtomIdColorThemeProvider: ColorTheme.Provider<AtomIdColorThemeParams, 'atom-id'>;
//# sourceMappingURL=atom-id.d.ts.map