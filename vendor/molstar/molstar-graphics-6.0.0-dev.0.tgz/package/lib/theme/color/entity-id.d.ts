/**
 * Copyright (c) 2021-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { ColorTheme } from '../color.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '../theme.js';
export declare const EntityIdColorThemeParams: {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
    overrideWater: PD.BooleanParam;
    waterColor: PD.Color;
};
export type EntityIdColorThemeParams = typeof EntityIdColorThemeParams;
export declare function getEntityIdColorThemeParams(ctx: ThemeDataContext): {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
    overrideWater: PD.BooleanParam;
    waterColor: PD.Color;
};
export declare function EntityIdColorTheme(ctx: ThemeDataContext, props: PD.Values<EntityIdColorThemeParams>): ColorTheme<EntityIdColorThemeParams>;
export declare const EntityIdColorThemeProvider: ColorTheme.Provider<EntityIdColorThemeParams, 'entity-id'>;
//# sourceMappingURL=entity-id.d.ts.map