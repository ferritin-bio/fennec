/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInColorThemes: {
    'atom-id': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "atom-id", import("../../geo/geometry/color-data.js").ColorType>;
    'carbohydrate-symbol': import("../color.js").ColorTheme.Provider<{}, "carbohydrate-symbol", import("../../geo/geometry/color-data.js").ColorType>;
    cartoon: import("../color.js").ColorTheme.Provider<{
        mainchain: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            value: import("@molstar/core/util/color/color").Color;
            saturation: number;
            lightness: number;
        }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            asymId: "auth" | "label";
        }>, "chain-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            overrideWater: boolean;
            waterColor: import("@molstar/core/util/color/color").Color;
        }>, "entity-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "entity-source"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                water: /*elided*/ any;
                ion: /*elided*/ any;
                protein: /*elided*/ any;
                RNA: /*elided*/ any;
                DNA: /*elided*/ any;
                PNA: /*elided*/ any;
                saccharide: /*elided*/ any;
            }>, "custom">;
        }>, "molecule-type"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "model-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "structure-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                alphaHelix: /*elided*/ any;
                threeTenHelix: /*elided*/ any;
                piHelix: /*elided*/ any;
                betaTurn: /*elided*/ any;
                betaStrand: /*elided*/ any;
                coil: /*elided*/ any;
                bend: /*elided*/ any;
                turn: /*elided*/ any;
                dna: /*elided*/ any;
                rna: /*elided*/ any;
                carbohydrate: /*elided*/ any;
            }>, "custom">;
        }>, "secondary-structure"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "trajectory-index">>;
        sidechain: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            value: import("@molstar/core/util/color/color").Color;
            saturation: number;
            lightness: number;
        }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                ALA: /*elided*/ any;
                ARG: /*elided*/ any;
                ASN: /*elided*/ any;
                ASP: /*elided*/ any;
                CYS: /*elided*/ any;
                GLN: /*elided*/ any;
                GLU: /*elided*/ any;
                GLY: /*elided*/ any;
                HIS: /*elided*/ any;
                ILE: /*elided*/ any;
                LEU: /*elided*/ any;
                LYS: /*elided*/ any;
                MET: /*elided*/ any;
                PHE: /*elided*/ any;
                PRO: /*elided*/ any;
                SER: /*elided*/ any;
                THR: /*elided*/ any;
                TRP: /*elided*/ any;
                TYR: /*elided*/ any;
                VAL: /*elided*/ any;
                A: /*elided*/ any;
                G: /*elided*/ any;
                I: /*elided*/ any;
                C: /*elided*/ any;
                T: /*elided*/ any;
                U: /*elided*/ any;
                DA: /*elided*/ any;
                DG: /*elided*/ any;
                DI: /*elided*/ any;
                DC: /*elided*/ any;
                DT: /*elided*/ any;
                DU: /*elided*/ any;
                APN: /*elided*/ any;
                GPN: /*elided*/ any;
                CPN: /*elided*/ any;
                TPN: /*elided*/ any;
            }>, "custom">;
        }>, "residue-name"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            carbonColor: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "element-symbol"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                value: /*elided*/ any;
                saturation: /*elided*/ any;
                lightness: /*elided*/ any;
            }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
                asymId: /*elided*/ any;
            }>, "chain-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
                overrideWater: /*elided*/ any;
                waterColor: /*elided*/ any;
            }>, "entity-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "entity-source"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "model-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "structure-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "trajectory-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "unit-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: /*elided*/ any;
            }>, "operator-name">;
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                H: /*elided*/ any;
                D: /*elided*/ any;
                T: /*elided*/ any;
                HE: /*elided*/ any;
                LI: /*elided*/ any;
                BE: /*elided*/ any;
                B: /*elided*/ any;
                C: /*elided*/ any;
                N: /*elided*/ any;
                O: /*elided*/ any;
                F: /*elided*/ any;
                NE: /*elided*/ any;
                NA: /*elided*/ any;
                MG: /*elided*/ any;
                AL: /*elided*/ any;
                SI: /*elided*/ any;
                P: /*elided*/ any;
                S: /*elided*/ any;
                CL: /*elided*/ any;
                AR: /*elided*/ any;
                K: /*elided*/ any;
                CA: /*elided*/ any;
                SC: /*elided*/ any;
                TI: /*elided*/ any;
                V: /*elided*/ any;
                CR: /*elided*/ any;
                MN: /*elided*/ any;
                FE: /*elided*/ any;
                CO: /*elided*/ any;
                NI: /*elided*/ any;
                CU: /*elided*/ any;
                ZN: /*elided*/ any;
                GA: /*elided*/ any;
                GE: /*elided*/ any;
                AS: /*elided*/ any;
                SE: /*elided*/ any;
                BR: /*elided*/ any;
                KR: /*elided*/ any;
                RB: /*elided*/ any;
                SR: /*elided*/ any;
                Y: /*elided*/ any;
                ZR: /*elided*/ any;
                NB: /*elided*/ any;
                MO: /*elided*/ any;
                TC: /*elided*/ any;
                RU: /*elided*/ any;
                RH: /*elided*/ any;
                PD: /*elided*/ any;
                AG: /*elided*/ any;
                CD: /*elided*/ any;
                IN: /*elided*/ any;
                SN: /*elided*/ any;
                SB: /*elided*/ any;
                TE: /*elided*/ any;
                I: /*elided*/ any;
                XE: /*elided*/ any;
                CS: /*elided*/ any;
                BA: /*elided*/ any;
                LA: /*elided*/ any;
                CE: /*elided*/ any;
                PR: /*elided*/ any;
                ND: /*elided*/ any;
                PM: /*elided*/ any;
                SM: /*elided*/ any;
                EU: /*elided*/ any;
                GD: /*elided*/ any;
                TB: /*elided*/ any;
                DY: /*elided*/ any;
                HO: /*elided*/ any;
                ER: /*elided*/ any;
                TM: /*elided*/ any;
                YB: /*elided*/ any;
                LU: /*elided*/ any;
                HF: /*elided*/ any;
                TA: /*elided*/ any;
                W: /*elided*/ any;
                RE: /*elided*/ any;
                OS: /*elided*/ any;
                IR: /*elided*/ any;
                PT: /*elided*/ any;
                AU: /*elided*/ any;
                HG: /*elided*/ any;
                TL: /*elided*/ any;
                PB: /*elided*/ any;
                BI: /*elided*/ any;
                PO: /*elided*/ any;
                AT: /*elided*/ any;
                RN: /*elided*/ any;
                FR: /*elided*/ any;
                RA: /*elided*/ any;
                AC: /*elided*/ any;
                TH: /*elided*/ any;
                PA: /*elided*/ any;
                U: /*elided*/ any;
                NP: /*elided*/ any;
                PU: /*elided*/ any;
                AM: /*elided*/ any;
                CM: /*elided*/ any;
                BK: /*elided*/ any;
                CF: /*elided*/ any;
                ES: /*elided*/ any;
                FM: /*elided*/ any;
                MD: /*elided*/ any;
                NO: /*elided*/ any;
                LR: /*elided*/ any;
                RF: /*elided*/ any;
                DB: /*elided*/ any;
                SG: /*elided*/ any;
                BH: /*elided*/ any;
                HS: /*elided*/ any;
                MT: /*elided*/ any;
                DS: /*elided*/ any;
                RG: /*elided*/ any;
                CN: /*elided*/ any;
                UUT: /*elided*/ any;
                NH: /*elided*/ any;
                FL: /*elided*/ any;
                UUP: /*elided*/ any;
                MC: /*elided*/ any;
                LV: /*elided*/ any;
                UUH: /*elided*/ any;
                UUS: /*elided*/ any;
                TS: /*elided*/ any;
                UUO: /*elided*/ any;
                OG: /*elided*/ any;
            }>, "custom">;
        }>, "element-symbol"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
            scale: "DGwif" | "DGwoct" | "Oct-IF";
        }>, "hydrophobicity"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            domain: [number, number];
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "uncertainty"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            domain: [number, number];
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "occupancy"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "sequence-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            domain: [number, number];
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "partial-charge">>;
    }, "cartoon", import("../../geo/geometry/color-data.js").ColorType>;
    'chain-id': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
        asymId: import("@molstar/core/util/param-definition").ParamDefinition.Select<"auth" | "label">;
    }, "chain-id", import("../../geo/geometry/color-data.js").ColorType>;
    'element-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "element-index", import("../../geo/geometry/color-data.js").ColorType>;
    'element-symbol': import("../color.js").ColorTheme.Provider<{
        carbonColor: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "element-symbol"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            value: import("@molstar/core/util/color/color").Color;
            saturation: number;
            lightness: number;
        }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            asymId: "auth" | "label";
        }>, "chain-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            overrideWater: boolean;
            waterColor: import("@molstar/core/util/color/color").Color;
        }>, "entity-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "entity-source"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "model-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "structure-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "trajectory-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "unit-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "operator-name">>;
        saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            H: import("@molstar/core/util/color/color").Color;
            D: import("@molstar/core/util/color/color").Color;
            T: import("@molstar/core/util/color/color").Color;
            HE: import("@molstar/core/util/color/color").Color;
            LI: import("@molstar/core/util/color/color").Color;
            BE: import("@molstar/core/util/color/color").Color;
            B: import("@molstar/core/util/color/color").Color;
            C: import("@molstar/core/util/color/color").Color;
            N: import("@molstar/core/util/color/color").Color;
            O: import("@molstar/core/util/color/color").Color;
            F: import("@molstar/core/util/color/color").Color;
            NE: import("@molstar/core/util/color/color").Color;
            NA: import("@molstar/core/util/color/color").Color;
            MG: import("@molstar/core/util/color/color").Color;
            AL: import("@molstar/core/util/color/color").Color;
            SI: import("@molstar/core/util/color/color").Color;
            P: import("@molstar/core/util/color/color").Color;
            S: import("@molstar/core/util/color/color").Color;
            CL: import("@molstar/core/util/color/color").Color;
            AR: import("@molstar/core/util/color/color").Color;
            K: import("@molstar/core/util/color/color").Color;
            CA: import("@molstar/core/util/color/color").Color;
            SC: import("@molstar/core/util/color/color").Color;
            TI: import("@molstar/core/util/color/color").Color;
            V: import("@molstar/core/util/color/color").Color;
            CR: import("@molstar/core/util/color/color").Color;
            MN: import("@molstar/core/util/color/color").Color;
            FE: import("@molstar/core/util/color/color").Color;
            CO: import("@molstar/core/util/color/color").Color;
            NI: import("@molstar/core/util/color/color").Color;
            CU: import("@molstar/core/util/color/color").Color;
            ZN: import("@molstar/core/util/color/color").Color;
            GA: import("@molstar/core/util/color/color").Color;
            GE: import("@molstar/core/util/color/color").Color;
            AS: import("@molstar/core/util/color/color").Color;
            SE: import("@molstar/core/util/color/color").Color;
            BR: import("@molstar/core/util/color/color").Color;
            KR: import("@molstar/core/util/color/color").Color;
            RB: import("@molstar/core/util/color/color").Color;
            SR: import("@molstar/core/util/color/color").Color;
            Y: import("@molstar/core/util/color/color").Color;
            ZR: import("@molstar/core/util/color/color").Color;
            NB: import("@molstar/core/util/color/color").Color;
            MO: import("@molstar/core/util/color/color").Color;
            TC: import("@molstar/core/util/color/color").Color;
            RU: import("@molstar/core/util/color/color").Color;
            RH: import("@molstar/core/util/color/color").Color;
            PD: import("@molstar/core/util/color/color").Color;
            AG: import("@molstar/core/util/color/color").Color;
            CD: import("@molstar/core/util/color/color").Color;
            IN: import("@molstar/core/util/color/color").Color;
            SN: import("@molstar/core/util/color/color").Color;
            SB: import("@molstar/core/util/color/color").Color;
            TE: import("@molstar/core/util/color/color").Color;
            I: import("@molstar/core/util/color/color").Color;
            XE: import("@molstar/core/util/color/color").Color;
            CS: import("@molstar/core/util/color/color").Color;
            BA: import("@molstar/core/util/color/color").Color;
            LA: import("@molstar/core/util/color/color").Color;
            CE: import("@molstar/core/util/color/color").Color;
            PR: import("@molstar/core/util/color/color").Color;
            ND: import("@molstar/core/util/color/color").Color;
            PM: import("@molstar/core/util/color/color").Color;
            SM: import("@molstar/core/util/color/color").Color;
            EU: import("@molstar/core/util/color/color").Color;
            GD: import("@molstar/core/util/color/color").Color;
            TB: import("@molstar/core/util/color/color").Color;
            DY: import("@molstar/core/util/color/color").Color;
            HO: import("@molstar/core/util/color/color").Color;
            ER: import("@molstar/core/util/color/color").Color;
            TM: import("@molstar/core/util/color/color").Color;
            YB: import("@molstar/core/util/color/color").Color;
            LU: import("@molstar/core/util/color/color").Color;
            HF: import("@molstar/core/util/color/color").Color;
            TA: import("@molstar/core/util/color/color").Color;
            W: import("@molstar/core/util/color/color").Color;
            RE: import("@molstar/core/util/color/color").Color;
            OS: import("@molstar/core/util/color/color").Color;
            IR: import("@molstar/core/util/color/color").Color;
            PT: import("@molstar/core/util/color/color").Color;
            AU: import("@molstar/core/util/color/color").Color;
            HG: import("@molstar/core/util/color/color").Color;
            TL: import("@molstar/core/util/color/color").Color;
            PB: import("@molstar/core/util/color/color").Color;
            BI: import("@molstar/core/util/color/color").Color;
            PO: import("@molstar/core/util/color/color").Color;
            AT: import("@molstar/core/util/color/color").Color;
            RN: import("@molstar/core/util/color/color").Color;
            FR: import("@molstar/core/util/color/color").Color;
            RA: import("@molstar/core/util/color/color").Color;
            AC: import("@molstar/core/util/color/color").Color;
            TH: import("@molstar/core/util/color/color").Color;
            PA: import("@molstar/core/util/color/color").Color;
            U: import("@molstar/core/util/color/color").Color;
            NP: import("@molstar/core/util/color/color").Color;
            PU: import("@molstar/core/util/color/color").Color;
            AM: import("@molstar/core/util/color/color").Color;
            CM: import("@molstar/core/util/color/color").Color;
            BK: import("@molstar/core/util/color/color").Color;
            CF: import("@molstar/core/util/color/color").Color;
            ES: import("@molstar/core/util/color/color").Color;
            FM: import("@molstar/core/util/color/color").Color;
            MD: import("@molstar/core/util/color/color").Color;
            NO: import("@molstar/core/util/color/color").Color;
            LR: import("@molstar/core/util/color/color").Color;
            RF: import("@molstar/core/util/color/color").Color;
            DB: import("@molstar/core/util/color/color").Color;
            SG: import("@molstar/core/util/color/color").Color;
            BH: import("@molstar/core/util/color/color").Color;
            HS: import("@molstar/core/util/color/color").Color;
            MT: import("@molstar/core/util/color/color").Color;
            DS: import("@molstar/core/util/color/color").Color;
            RG: import("@molstar/core/util/color/color").Color;
            CN: import("@molstar/core/util/color/color").Color;
            UUT: import("@molstar/core/util/color/color").Color;
            NH: import("@molstar/core/util/color/color").Color;
            FL: import("@molstar/core/util/color/color").Color;
            UUP: import("@molstar/core/util/color/color").Color;
            MC: import("@molstar/core/util/color/color").Color;
            LV: import("@molstar/core/util/color/color").Color;
            UUH: import("@molstar/core/util/color/color").Color;
            UUS: import("@molstar/core/util/color/color").Color;
            TS: import("@molstar/core/util/color/color").Color;
            UUO: import("@molstar/core/util/color/color").Color;
            OG: import("@molstar/core/util/color/color").Color;
        }>, "custom">>;
    }, "element-symbol", import("../../geo/geometry/color-data.js").ColorType>;
    'entity-id': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
        overrideWater: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        waterColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
    }, "entity-id", import("../../geo/geometry/color-data.js").ColorType>;
    'entity-source': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "entity-source", import("../../geo/geometry/color-data.js").ColorType>;
    'formal-charge': import("../color.js").ColorTheme.Provider<{
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Interval;
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "formal-charge", import("../../geo/geometry/color-data.js").ColorType>;
    hydrophobicity: import("../color.js").ColorTheme.Provider<{
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
        scale: import("@molstar/core/util/param-definition").ParamDefinition.Select<"DGwif" | "DGwoct" | "Oct-IF">;
    }, "hydrophobicity", import("../../geo/geometry/color-data.js").ColorType>;
    illustrative: import("../color.js").ColorTheme.Provider<{
        style: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            value: import("@molstar/core/util/color/color").Color;
            saturation: number;
            lightness: number;
        }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            asymId: "auth" | "label";
        }>, "chain-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
            overrideWater: boolean;
            waterColor: import("@molstar/core/util/color/color").Color;
        }>, "entity-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "entity-source"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                water: /*elided*/ any;
                ion: /*elided*/ any;
                protein: /*elided*/ any;
                RNA: /*elided*/ any;
                DNA: /*elided*/ any;
                PNA: /*elided*/ any;
                saccharide: /*elided*/ any;
            }>, "custom">;
        }>, "molecule-type"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "model-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "structure-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                list: {
                    kind: 'interpolate' | 'set';
                    colors: import("@molstar/core/util/color/color").ColorListEntry[];
                };
            }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                hue: [number, number];
                chroma: [number, number];
                luminance: [number, number];
                sort: "contrast" | "none";
                clusteringStepCount: number;
                minSampleCount: number;
                sampleCountFactor: number;
                maxCount: number;
            }>, "generate">;
        }>, "trajectory-index">>;
        carbonLightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "illustrative", import("../../geo/geometry/color-data.js").ColorType>;
    'model-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "model-index", import("../../geo/geometry/color-data.js").ColorType>;
    'molecule-type': import("../color.js").ColorTheme.Provider<{
        saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            water: import("@molstar/core/util/color/color").Color;
            ion: import("@molstar/core/util/color/color").Color;
            protein: import("@molstar/core/util/color/color").Color;
            RNA: import("@molstar/core/util/color/color").Color;
            DNA: import("@molstar/core/util/color/color").Color;
            PNA: import("@molstar/core/util/color/color").Color;
            saccharide: import("@molstar/core/util/color/color").Color;
        }>, "custom">>;
    }, "molecule-type", import("../../geo/geometry/color-data.js").ColorType>;
    occupancy: import("../color.js").ColorTheme.Provider<{
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Interval;
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "occupancy", import("../../geo/geometry/color-data.js").ColorType>;
    'operator-hkl': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "operator-hkl", import("../../geo/geometry/color-data.js").ColorType>;
    'operator-name': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "operator-name", import("../../geo/geometry/color-data.js").ColorType>;
    'partial-charge': import("../color.js").ColorTheme.Provider<{
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Interval;
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "partial-charge", import("../../geo/geometry/color-data.js").ColorType>;
    'particle-attribute': import("../color.js").ColorTheme.Provider<{
        attribute: import("@molstar/core/util/param-definition").ParamDefinition.Select<string>;
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<[number, number], "custom"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "auto">>;
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "particle-attribute", import("../../geo/geometry/color-data.js").ColorType>;
    'particle-compartment': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "particle-compartment", import("../../geo/geometry/color-data.js").ColorType>;
    'particle-entity': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
        by: import("@molstar/core/util/param-definition").ParamDefinition.Select<"function" | "name">;
    }, "particle-entity", import("../../geo/geometry/color-data.js").ColorType>;
    'particle-hierarchy': import("../color.js").ColorTheme.Provider<{
        by: import("@molstar/core/util/param-definition").ParamDefinition.Select<"function" | "name">;
        variability: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        shift: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        compartmentPalette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            compartmentShift: number;
        }>, "auto"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "particle-hierarchy", import("../../geo/geometry/color-data.js").ColorType>;
    'particle-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "particle-index", import("../../geo/geometry/color-data.js").ColorType>;
    'polymer-id': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "polymer-id", import("../../geo/geometry/color-data.js").ColorType>;
    'polymer-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "polymer-index", import("../../geo/geometry/color-data.js").ColorType>;
    'residue-charge': import("../color.js").ColorTheme.Provider<{
        method: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            saturation: number;
            lightness: number;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                ARG: /*elided*/ any;
                ASP: /*elided*/ any;
                GLU: /*elided*/ any;
                HIS: /*elided*/ any;
                LYS: /*elided*/ any;
                ALA: /*elided*/ any;
                ASN: /*elided*/ any;
                CYS: /*elided*/ any;
                GLN: /*elided*/ any;
                GLY: /*elided*/ any;
                ILE: /*elided*/ any;
                LEU: /*elided*/ any;
                MET: /*elided*/ any;
                PHE: /*elided*/ any;
                PRO: /*elided*/ any;
                SER: /*elided*/ any;
                THR: /*elided*/ any;
                TRP: /*elided*/ any;
                TYR: /*elided*/ any;
                VAL: /*elided*/ any;
                MSE: /*elided*/ any;
                SEP: /*elided*/ any;
                TPO: /*elided*/ any;
                PTR: /*elided*/ any;
                PCA: /*elided*/ any;
                HYP: /*elided*/ any;
                HSD: /*elided*/ any;
                HSE: /*elided*/ any;
                HSP: /*elided*/ any;
                LSN: /*elided*/ any;
                ASPP: /*elided*/ any;
                GLUP: /*elided*/ any;
                HID: /*elided*/ any;
                HIE: /*elided*/ any;
                HIP: /*elided*/ any;
                LYN: /*elided*/ any;
                ASH: /*elided*/ any;
                GLH: /*elided*/ any;
                A: /*elided*/ any;
                G: /*elided*/ any;
                I: /*elided*/ any;
                C: /*elided*/ any;
                T: /*elided*/ any;
                U: /*elided*/ any;
                DA: /*elided*/ any;
                DG: /*elided*/ any;
                DI: /*elided*/ any;
                DC: /*elided*/ any;
                DT: /*elided*/ any;
                DU: /*elided*/ any;
                APN: /*elided*/ any;
                GPN: /*elided*/ any;
                CPN: /*elided*/ any;
                TPN: /*elided*/ any;
            }>, "custom">;
        }>, "by-name">>;
    }, "residue-charge", import("../../geo/geometry/color-data.js").ColorType>;
    'residue-name': import("../color.js").ColorTheme.Provider<{
        saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            ALA: import("@molstar/core/util/color/color").Color;
            ARG: import("@molstar/core/util/color/color").Color;
            ASN: import("@molstar/core/util/color/color").Color;
            ASP: import("@molstar/core/util/color/color").Color;
            CYS: import("@molstar/core/util/color/color").Color;
            GLN: import("@molstar/core/util/color/color").Color;
            GLU: import("@molstar/core/util/color/color").Color;
            GLY: import("@molstar/core/util/color/color").Color;
            HIS: import("@molstar/core/util/color/color").Color;
            ILE: import("@molstar/core/util/color/color").Color;
            LEU: import("@molstar/core/util/color/color").Color;
            LYS: import("@molstar/core/util/color/color").Color;
            MET: import("@molstar/core/util/color/color").Color;
            PHE: import("@molstar/core/util/color/color").Color;
            PRO: import("@molstar/core/util/color/color").Color;
            SER: import("@molstar/core/util/color/color").Color;
            THR: import("@molstar/core/util/color/color").Color;
            TRP: import("@molstar/core/util/color/color").Color;
            TYR: import("@molstar/core/util/color/color").Color;
            VAL: import("@molstar/core/util/color/color").Color;
            A: import("@molstar/core/util/color/color").Color;
            G: import("@molstar/core/util/color/color").Color;
            I: import("@molstar/core/util/color/color").Color;
            C: import("@molstar/core/util/color/color").Color;
            T: import("@molstar/core/util/color/color").Color;
            U: import("@molstar/core/util/color/color").Color;
            DA: import("@molstar/core/util/color/color").Color;
            DG: import("@molstar/core/util/color/color").Color;
            DI: import("@molstar/core/util/color/color").Color;
            DC: import("@molstar/core/util/color/color").Color;
            DT: import("@molstar/core/util/color/color").Color;
            DU: import("@molstar/core/util/color/color").Color;
            APN: import("@molstar/core/util/color/color").Color;
            GPN: import("@molstar/core/util/color/color").Color;
            CPN: import("@molstar/core/util/color/color").Color;
            TPN: import("@molstar/core/util/color/color").Color;
        }>, "custom">>;
    }, "residue-name", import("../../geo/geometry/color-data.js").ColorType>;
    'secondary-structure': import("../color.js").ColorTheme.Provider<{
        saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        colors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            alphaHelix: import("@molstar/core/util/color/color").Color;
            threeTenHelix: import("@molstar/core/util/color/color").Color;
            piHelix: import("@molstar/core/util/color/color").Color;
            betaTurn: import("@molstar/core/util/color/color").Color;
            betaStrand: import("@molstar/core/util/color/color").Color;
            coil: import("@molstar/core/util/color/color").Color;
            bend: import("@molstar/core/util/color/color").Color;
            turn: import("@molstar/core/util/color/color").Color;
            dna: import("@molstar/core/util/color/color").Color;
            rna: import("@molstar/core/util/color/color").Color;
            carbohydrate: import("@molstar/core/util/color/color").Color;
        }>, "custom">>;
    }, "secondary-structure", import("../../geo/geometry/color-data.js").ColorType>;
    'sequence-id': import("../color.js").ColorTheme.Provider<{
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "sequence-id", import("../../geo/geometry/color-data.js").ColorType>;
    'shape-group': import("../color.js").ColorTheme.Provider<{}, "shape-group", import("../../geo/geometry/color-data.js").ColorType>;
    'structure-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "structure-index", import("../../geo/geometry/color-data.js").ColorType>;
    'trajectory-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "trajectory-index", import("../../geo/geometry/color-data.js").ColorType>;
    uncertainty: import("../color.js").ColorTheme.Provider<{
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Interval;
        list: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
    }, "uncertainty", import("../../geo/geometry/color-data.js").ColorType>;
    'unit-index': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "unit-index", import("../../geo/geometry/color-data.js").ColorType>;
    uniform: import("../color.js").ColorTheme.Provider<{
        value: import("@molstar/core/util/param-definition").ParamDefinition.Color;
        saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "uniform", import("../../geo/geometry/color-data.js").ColorType>;
    'volume-instance': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "volume-instance", import("../../geo/geometry/color-data.js").ColorType>;
    'volume-segment': import("../color.js").ColorTheme.Provider<{
        palette: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">>;
    }, "volume-segment", import("../../geo/geometry/color-data.js").ColorType>;
    'volume-value': import("../color.js").ColorTheme.Provider<{
        colorList: import("@molstar/core/util/param-definition").ParamDefinition.ColorList;
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<[number, number], "custom"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            symmetric: boolean;
        }>, "auto">>;
        isRelative: import("@molstar/core/util/param-definition").ParamDefinition.BooleanParam;
        defaultColor: import("@molstar/core/util/param-definition").ParamDefinition.Color;
    }, "volume-value", import("../../geo/geometry/color-data.js").ColorType>;
};
//# sourceMappingURL=catalog.d.ts.map