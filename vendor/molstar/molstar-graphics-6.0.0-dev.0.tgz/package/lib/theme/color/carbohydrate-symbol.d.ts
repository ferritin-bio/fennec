/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ColorTheme } from '../color.js';
import type { ThemeDataContext } from '../theme.js';
export declare const CarbohydrateSymbolColorThemeParams: {};
export type CarbohydrateSymbolColorThemeParams = typeof CarbohydrateSymbolColorThemeParams;
export declare function getCarbohydrateSymbolColorThemeParams(ctx: ThemeDataContext): {};
export declare function CarbohydrateSymbolColorTheme(ctx: ThemeDataContext, props: PD.Values<CarbohydrateSymbolColorThemeParams>): ColorTheme<CarbohydrateSymbolColorThemeParams>;
export declare const CarbohydrateSymbolColorThemeProvider: ColorTheme.Provider<CarbohydrateSymbolColorThemeParams, 'carbohydrate-symbol'>;
//# sourceMappingURL=carbohydrate-symbol.d.ts.map