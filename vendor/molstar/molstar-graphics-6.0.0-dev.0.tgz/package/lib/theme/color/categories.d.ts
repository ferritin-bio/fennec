/**
 * Copyright (c) 2022-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const ColorThemeCategory: {
    Atom: string;
    Chain: string;
    Residue: string;
    Symmetry: string;
    Validation: string;
    Particle: string;
    Misc: string;
};
//# sourceMappingURL=categories.d.ts.map