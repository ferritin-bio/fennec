/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ColorTheme } from '../color.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '../theme.js';
export declare const ElementIndexColorThemeParams: {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
};
export type ElementIndexColorThemeParams = typeof ElementIndexColorThemeParams;
export declare function getElementIndexColorThemeParams(ctx: ThemeDataContext): {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
};
export declare function ElementIndexColorTheme(ctx: ThemeDataContext, props: PD.Values<ElementIndexColorThemeParams>): ColorTheme<ElementIndexColorThemeParams>;
export declare const ElementIndexColorThemeProvider: ColorTheme.Provider<ElementIndexColorThemeParams, 'element-index'>;
//# sourceMappingURL=element-index.d.ts.map