/**
 * Copyright (c) 2019-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Color } from '@molstar/core/util/color';
import type { ColorTheme } from '../color.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '../theme.js';
export declare const IllustrativeColorThemeParams: {
    style: PD.Mapped<PD.NamedParams<PD.Normalize<{
        value: Color;
        saturation: number;
        lightness: number;
    }>, "uniform"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        asymId: "auth" | "label";
    }>, "chain-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        overrideWater: boolean;
        waterColor: Color;
    }>, "entity-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "entity-source"> | PD.NamedParams<PD.Normalize<{
        saturation: number;
        lightness: number;
        colors: PD.NamedParams<PD.Normalize<unknown>, "default"> | PD.NamedParams<PD.Normalize<{
            water: /*elided*/ any;
            ion: /*elided*/ any;
            protein: /*elided*/ any;
            RNA: /*elided*/ any;
            DNA: /*elided*/ any;
            PNA: /*elided*/ any;
            saccharide: /*elided*/ any;
        }>, "custom">;
    }>, "molecule-type"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "model-index"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "structure-index"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "trajectory-index">>;
    carbonLightness: PD.Numeric;
};
export type IllustrativeColorThemeParams = typeof IllustrativeColorThemeParams;
export declare function getIllustrativeColorThemeParams(ctx: ThemeDataContext): {
    style: PD.Mapped<PD.NamedParams<PD.Normalize<{
        value: Color;
        saturation: number;
        lightness: number;
    }>, "uniform"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        asymId: "auth" | "label";
    }>, "chain-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        overrideWater: boolean;
        waterColor: Color;
    }>, "entity-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "entity-source"> | PD.NamedParams<PD.Normalize<{
        saturation: number;
        lightness: number;
        colors: PD.NamedParams<PD.Normalize<unknown>, "default"> | PD.NamedParams<PD.Normalize<{
            water: /*elided*/ any;
            ion: /*elided*/ any;
            protein: /*elided*/ any;
            RNA: /*elided*/ any;
            DNA: /*elided*/ any;
            PNA: /*elided*/ any;
            saccharide: /*elided*/ any;
        }>, "custom">;
    }>, "molecule-type"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "model-index"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "structure-index"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "trajectory-index">>;
    carbonLightness: PD.Numeric;
};
export declare function IllustrativeColorTheme(ctx: ThemeDataContext, props: PD.Values<IllustrativeColorThemeParams>): ColorTheme<IllustrativeColorThemeParams>;
export declare const IllustrativeColorThemeProvider: ColorTheme.Provider<IllustrativeColorThemeParams, 'illustrative'>;
//# sourceMappingURL=illustrative.d.ts.map