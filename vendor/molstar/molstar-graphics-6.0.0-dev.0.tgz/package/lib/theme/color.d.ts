/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Color } from '@molstar/core/util/color';
import type { Location } from '@molstar/model/model/location';
import type { ColorType, ColorTypeDirect, ColorTypeGrid, ColorTypeLocation } from '@molstar/graphics/geo/geometry/color-data';
import type { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type ThemeDataContext, ThemeRegistry, type ThemeProvider } from './theme.js';
import type { BuiltInColorThemes } from './color/catalog.js';
import type { ScaleLegend, TableLegend } from '@molstar/core/util/legend';
import type { Texture, TextureFilter } from '@molstar/graphics/gl/texture';
import type { Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import type { ColorListEntry } from '@molstar/core/util/color/color';
export type LocationColor = (location: Location, isSecondary: boolean) => Color;
export interface ColorVolume {
    colors: Texture;
    dimension: Vec3;
    transform: Vec4;
}
export { ColorTheme };
type ColorThemeShared<P extends PD.Params, G extends ColorType> = {
    readonly factory: ColorTheme.Factory<P, G>;
    readonly props: Readonly<PD.Values<P>>;
    /**
     * if palette is defined, 24bit RGB color value normalized to interval [0, 1]
     * is used as index to the colors
     */
    readonly palette?: Readonly<ColorTheme.Palette>;
    readonly preferSmoothing?: boolean;
    readonly contextHash?: number;
    readonly description?: string;
    readonly legend?: Readonly<ScaleLegend | TableLegend>;
};
type ColorThemeLocation<P extends PD.Params> = {
    readonly granularity: ColorTypeLocation;
    readonly color: LocationColor;
} & ColorThemeShared<P, ColorTypeLocation>;
type ColorThemeGrid<P extends PD.Params> = {
    readonly granularity: ColorTypeGrid;
    readonly grid: ColorVolume;
} & ColorThemeShared<P, ColorTypeGrid>;
type ColorThemeDirect<P extends PD.Params> = {
    readonly granularity: ColorTypeDirect;
} & ColorThemeShared<P, ColorTypeDirect>;
type ColorTheme<P extends PD.Params, G extends ColorType = ColorTypeLocation> = G extends ColorTypeLocation ? ColorThemeLocation<P> : G extends ColorTypeGrid ? ColorThemeGrid<P> : G extends ColorTypeDirect ? ColorThemeDirect<P> : never;
declare namespace ColorTheme {
    export const Category: {
        Atom: string;
        Chain: string;
        Residue: string;
        Symmetry: string;
        Validation: string;
        Particle: string;
        Misc: string;
    };
    export interface Palette {
        colors: Color[];
        filter?: TextureFilter;
        domain?: [number, number];
        defaultColor?: Color;
    }
    export function Palette(list: ColorListEntry[], kind: 'set' | 'interpolate', domain?: [number, number], defaultColor?: Color): Palette;
    export const PaletteScale: number;
    export type Props = {
        [k: string]: any;
    };
    export type Factory<P extends PD.Params, G extends ColorType> = (ctx: ThemeDataContext, props: PD.Values<P>) => ColorTheme<P, G>;
    export const EmptyFactory: () => ColorThemeLocation<{}>;
    export const Empty: ColorTheme<{}>;
    export function areEqual(themeA: ColorTheme<any, any>, themeB: ColorTheme<any, any>): boolean;
    export interface Provider<P extends PD.Params = any, Id extends string = string, G extends ColorType = ColorType> extends ThemeProvider<ColorTheme<P, G>, P, Id, G> {
    }
    export const EmptyProvider: Provider<{}>;
    export type Registry = ThemeRegistry<ColorTheme<any, any>>;
    export function createRegistry(): Registry;
    type _BuiltIn = typeof BuiltInColorThemes;
    export type BuiltIn = keyof _BuiltIn;
    export type ParamValues<C extends ColorTheme.Provider<any>> = C extends ColorTheme.Provider<infer P> ? PD.Values<P> : never;
    export type BuiltInParams<T extends BuiltIn> = Partial<ParamValues<_BuiltIn[T]>>;
    export {};
}
export declare function ColorThemeProvider<P extends PD.Params, Id extends string>(p: ColorTheme.Provider<P, Id>): ColorTheme.Provider<P, Id>;
//# sourceMappingURL=color.d.ts.map