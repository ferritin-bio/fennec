/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInSizeThemes: {
    'particle-size': import("../size.js").SizeTheme.Provider<{
        scale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        defaultSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "particle-size">;
    physical: import("../size.js").SizeTheme.Provider<{
        scale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "physical">;
    'shape-group': import("../size.js").SizeTheme.Provider<{}, "shape-group">;
    uncertainty: import("../size.js").SizeTheme.Provider<{
        bfactorFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        rmsfFactor: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        baseSize: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "uncertainty">;
    uniform: import("../size.js").SizeTheme.Provider<{
        value: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
    }, "uniform">;
    'volume-value': import("../size.js").SizeTheme.Provider<{
        scale: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
        transform: import("@molstar/core/util/param-definition").ParamDefinition.Select<"cubic" | "linear" | "quadratic">;
        domain: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<[number, number], "custom"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "auto">>;
    }, "volume-value">;
};
//# sourceMappingURL=catalog.d.ts.map