/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '@molstar/graphics/theme/theme';
import type { ColorTheme } from '@molstar/graphics/theme/color';
export declare const AccessibleSurfaceAreaColorThemeParams: {
    list: PD.ColorList;
};
export type AccessibleSurfaceAreaColorThemeParams = typeof AccessibleSurfaceAreaColorThemeParams;
export declare function getAccessibleSurfaceAreaColorThemeParams(ctx: ThemeDataContext): {
    list: PD.ColorList;
};
export declare function AccessibleSurfaceAreaColorTheme(ctx: ThemeDataContext, props: PD.Values<AccessibleSurfaceAreaColorThemeParams>): ColorTheme<AccessibleSurfaceAreaColorThemeParams>;
export declare const AccessibleSurfaceAreaColorThemeProvider: ColorTheme.Provider<AccessibleSurfaceAreaColorThemeParams, 'accessible-surface-area'>;
//# sourceMappingURL=accessible-surface-area.d.ts.map