/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '@molstar/graphics/theme/theme';
import type { ColorTheme } from '@molstar/graphics/theme/color';
export declare const InteractionTypeColorThemeParams: {};
export type InteractionTypeColorThemeParams = typeof InteractionTypeColorThemeParams;
export declare function getInteractionTypeColorThemeParams(ctx: ThemeDataContext): {};
export declare function InteractionTypeColorTheme(ctx: ThemeDataContext, props: PD.Values<InteractionTypeColorThemeParams>): ColorTheme<InteractionTypeColorThemeParams>;
export declare const InteractionTypeColorThemeProvider: ColorTheme.Provider<InteractionTypeColorThemeParams, 'interaction-type'>;
//# sourceMappingURL=interaction-type.d.ts.map