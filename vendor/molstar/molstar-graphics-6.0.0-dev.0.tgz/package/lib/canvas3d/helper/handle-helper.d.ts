/**
 * Copyright (c) 2020-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { Scene } from '@molstar/graphics/gl/scene';
import { Vec3, type Mat3 } from '@molstar/core/math/linear-algebra';
import { Sphere3D } from '@molstar/core/math/geometry';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PickingId } from '@molstar/graphics/geo/geometry/picking';
import type { Camera } from '../camera.js';
import { DataLoci, type Loci } from '@molstar/model/model/loci';
import { type MarkerAction } from '@molstar/core/util/marker-action';
export declare const HandleHelperParams: {
    handle: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        material: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        clip: PD.Normalize<{
            variant: /*elided*/ any;
            objects: /*elided*/ any;
        }>;
        emissive: number;
        density: number;
        instanceGranularity: import("../../geo/geometry/base.js").InstanceGranularityValue;
        renderMerged: import("../../geo/geometry/base.js").RenderMergedValue;
        lod: Vec3;
        cellSize: number;
        batchSize: number;
        doubleSided: boolean;
        flipSided: boolean;
        flatShaded: boolean;
        celShaded: boolean;
        xrayShaded: "inverted" | boolean;
        transparentBackfaces: "off" | "on" | "opaque";
        solidInterior: boolean;
        bumpFrequency: number;
        bumpAmplitude: number;
        interior: PD.Normalize<{
            color: /*elided*/ any;
            colorStrength: /*elided*/ any;
            substance: /*elided*/ any;
            substanceStrength: /*elided*/ any;
        }>;
        animation: PD.Normalize<{
            wiggleMode: /*elided*/ any;
            wiggleSpeed: /*elided*/ any;
            wiggleAmplitude: /*elided*/ any;
            wiggleFrequency: /*elided*/ any;
            tumbleSpeed: /*elided*/ any;
            tumbleAmplitude: /*elided*/ any;
            tumbleFrequency: /*elided*/ any;
        }>;
        alpha: number;
        ignoreLight: boolean;
        colorX: import("@molstar/core/util/color/color").Color;
        colorY: import("@molstar/core/util/color/color").Color;
        colorZ: import("@molstar/core/util/color/color").Color;
        scale: number;
    }>, "on">>;
};
export type HandleHelperParams = typeof HandleHelperParams;
export type HandleHelperProps = PD.Values<HandleHelperParams>;
export declare class HandleHelper {
    private graphics;
    scene: Scene;
    props: HandleHelperProps;
    private renderObject;
    private pixelRatio;
    private _transform;
    getBoundingSphere(out: Sphere3D, instanceId: number): Sphere3D;
    setProps(props: Partial<HandleHelperProps>): void;
    get isEnabled(): boolean;
    update(camera: Camera, position: Vec3, rotation: Mat3): void;
    getLoci(pickingId: PickingId): DataLoci<HandleHelper, {
        groupId: number;
        instanceId: number;
    }> | {
        kind: 'empty-loci';
    };
    private eachGroup;
    mark(loci: Loci, action: MarkerAction): boolean;
    constructor(graphics: GraphicsContext, props?: Partial<HandleHelperProps>);
    setContext(graphics: GraphicsContext): void;
}
export declare const HandleGroup: {
    readonly None: 0;
    readonly TranslateScreenXY: 1;
    readonly TranslateObjectX: 3;
    readonly TranslateObjectY: 4;
    readonly TranslateObjectZ: 5;
};
declare function HandleLoci(handleHelper: HandleHelper, groupId: number, instanceId: number): DataLoci<HandleHelper, {
    groupId: number;
    instanceId: number;
}>;
export type HandleLoci = ReturnType<typeof HandleLoci>;
export declare function isHandleLoci(x: Loci): x is HandleLoci;
export {};
//# sourceMappingURL=handle-helper.d.ts.map