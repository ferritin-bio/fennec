import type { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { Scene } from '@molstar/graphics/gl/scene';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { DataLoci, type Loci } from '@molstar/model/model/loci';
import { type MarkerAction } from '@molstar/core/util/marker-action';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Camera, type ICamera } from '../camera.js';
export declare const CameraHelperParams: {
    axes: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        alpha: number;
        colorX: import("@molstar/core/util/color/color").Color;
        colorY: import("@molstar/core/util/color/color").Color;
        colorZ: import("@molstar/core/util/color/color").Color;
        scale: number;
        location: "bottom-left" | "bottom-right" | "top-left" | "top-right";
        locationOffsetX: number;
        locationOffsetY: number;
        originColor: import("@molstar/core/util/color/color").Color;
        radiusScale: number;
        showPlanes: boolean;
        planeColorXY: import("@molstar/core/util/color/color").Color;
        planeColorXZ: import("@molstar/core/util/color/color").Color;
        planeColorYZ: import("@molstar/core/util/color/color").Color;
        showLabels: boolean;
        labelX: string;
        labelY: string;
        labelZ: string;
        labelColorX: import("@molstar/core/util/color/color").Color;
        labelColorY: import("@molstar/core/util/color/color").Color;
        labelColorZ: import("@molstar/core/util/color/color").Color;
        labelOpacity: number;
        labelScale: number;
    }>, "on">>;
};
export type CameraHelperParams = typeof CameraHelperParams;
export type CameraHelperProps = PD.Values<CameraHelperParams>;
export declare class CameraHelper {
    private graphics;
    scene: Scene;
    camera: Camera;
    props: CameraHelperProps;
    private meshRenderObject;
    private textRenderObject;
    private pixelRatio;
    constructor(graphics: GraphicsContext, props?: Partial<CameraHelperProps>);
    setContext(graphics: GraphicsContext): void;
    setProps(props: Partial<CameraHelperProps>): void;
    get isEnabled(): boolean;
    getLoci(pickingId: PickingId): DataLoci<CameraHelper, {
        groupId: number;
        instanceId: number;
    }> | {
        kind: 'empty-loci';
    };
    private eachGroup;
    mark(loci: Loci, action: MarkerAction): boolean;
    update(camera: ICamera): void;
}
export declare enum CameraHelperAxis {
    None = 0,
    X = 1,
    Y = 2,
    Z = 3,
    XY = 4,
    XZ = 5,
    YZ = 6,
    Origin = 7
}
declare function CameraAxesLoci(cameraHelper: CameraHelper, groupId: number, instanceId: number): DataLoci<CameraHelper, {
    groupId: number;
    instanceId: number;
}>;
export type CameraAxesLoci = ReturnType<typeof CameraAxesLoci>;
export declare function isCameraAxesLoci(x: Loci): x is CameraAxesLoci;
export {};
//# sourceMappingURL=camera-helper.d.ts.map