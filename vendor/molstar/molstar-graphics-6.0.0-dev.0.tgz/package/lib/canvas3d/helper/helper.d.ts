/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Scene } from '@molstar/graphics/gl/scene';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { DebugRegistry } from './debug-registry.js';
import { CameraHelper } from './camera-helper.js';
import { HandleHelper } from './handle-helper.js';
import { PointerHelper } from './pointer-helper.js';
export declare const HelperParams: {
    camera: PD.Group<PD.Normalize<{
        helper: PD.Normalize<{
            axes: /*elided*/ any;
        }>;
    }>>;
    handle: PD.Group<PD.Normalize<{
        handle: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            quality: /*elided*/ any;
            material: /*elided*/ any;
            clip: /*elided*/ any;
            emissive: /*elided*/ any;
            density: /*elided*/ any;
            instanceGranularity: /*elided*/ any;
            renderMerged: /*elided*/ any;
            lod: /*elided*/ any;
            cellSize: /*elided*/ any;
            batchSize: /*elided*/ any;
            doubleSided: /*elided*/ any;
            flipSided: /*elided*/ any;
            flatShaded: /*elided*/ any;
            celShaded: /*elided*/ any;
            xrayShaded: /*elided*/ any;
            transparentBackfaces: /*elided*/ any;
            solidInterior: /*elided*/ any;
            bumpFrequency: /*elided*/ any;
            bumpAmplitude: /*elided*/ any;
            interior: /*elided*/ any;
            animation: /*elided*/ any;
            alpha: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            colorX: /*elided*/ any;
            colorY: /*elided*/ any;
            colorZ: /*elided*/ any;
            scale: /*elided*/ any;
        }>, "on">;
    }>>;
    pointer: PD.Group<PD.Normalize<{
        alpha: number;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        material: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        clip: PD.Normalize<{
            variant: /*elided*/ any;
            objects: /*elided*/ any;
        }>;
        emissive: number;
        density: number;
        instanceGranularity: import("../../geo/geometry/base.js").InstanceGranularityValue;
        renderMerged: import("../../geo/geometry/base.js").RenderMergedValue;
        lod: import("@molstar/core/math/linear-algebra").Vec3;
        cellSize: number;
        batchSize: number;
        doubleSided: boolean;
        flipSided: boolean;
        flatShaded: boolean;
        celShaded: boolean;
        xrayShaded: "inverted" | boolean;
        transparentBackfaces: "off" | "on" | "opaque";
        solidInterior: boolean;
        bumpFrequency: number;
        bumpAmplitude: number;
        interior: PD.Normalize<{
            color: /*elided*/ any;
            colorStrength: /*elided*/ any;
            substance: /*elided*/ any;
            substanceStrength: /*elided*/ any;
        }>;
        animation: PD.Normalize<{
            wiggleMode: /*elided*/ any;
            wiggleSpeed: /*elided*/ any;
            wiggleAmplitude: /*elided*/ any;
            wiggleFrequency: /*elided*/ any;
            tumbleSpeed: /*elided*/ any;
            tumbleAmplitude: /*elided*/ any;
            tumbleFrequency: /*elided*/ any;
        }>;
        enabled: "off" | "on";
        ignoreLight: boolean;
        color: import("@molstar/core/util/color/color").Color;
        hitColor: import("@molstar/core/util/color/color").Color;
    }>>;
};
export declare const DefaultHelperProps: PD.Values<{
    camera: PD.Group<PD.Normalize<{
        helper: PD.Normalize<{
            axes: /*elided*/ any;
        }>;
    }>>;
    handle: PD.Group<PD.Normalize<{
        handle: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            quality: /*elided*/ any;
            material: /*elided*/ any;
            clip: /*elided*/ any;
            emissive: /*elided*/ any;
            density: /*elided*/ any;
            instanceGranularity: /*elided*/ any;
            renderMerged: /*elided*/ any;
            lod: /*elided*/ any;
            cellSize: /*elided*/ any;
            batchSize: /*elided*/ any;
            doubleSided: /*elided*/ any;
            flipSided: /*elided*/ any;
            flatShaded: /*elided*/ any;
            celShaded: /*elided*/ any;
            xrayShaded: /*elided*/ any;
            transparentBackfaces: /*elided*/ any;
            solidInterior: /*elided*/ any;
            bumpFrequency: /*elided*/ any;
            bumpAmplitude: /*elided*/ any;
            interior: /*elided*/ any;
            animation: /*elided*/ any;
            alpha: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            colorX: /*elided*/ any;
            colorY: /*elided*/ any;
            colorZ: /*elided*/ any;
            scale: /*elided*/ any;
        }>, "on">;
    }>>;
    pointer: PD.Group<PD.Normalize<{
        alpha: number;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        material: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        clip: PD.Normalize<{
            variant: /*elided*/ any;
            objects: /*elided*/ any;
        }>;
        emissive: number;
        density: number;
        instanceGranularity: import("../../geo/geometry/base.js").InstanceGranularityValue;
        renderMerged: import("../../geo/geometry/base.js").RenderMergedValue;
        lod: import("@molstar/core/math/linear-algebra").Vec3;
        cellSize: number;
        batchSize: number;
        doubleSided: boolean;
        flipSided: boolean;
        flatShaded: boolean;
        celShaded: boolean;
        xrayShaded: "inverted" | boolean;
        transparentBackfaces: "off" | "on" | "opaque";
        solidInterior: boolean;
        bumpFrequency: number;
        bumpAmplitude: number;
        interior: PD.Normalize<{
            color: /*elided*/ any;
            colorStrength: /*elided*/ any;
            substance: /*elided*/ any;
            substanceStrength: /*elided*/ any;
        }>;
        animation: PD.Normalize<{
            wiggleMode: /*elided*/ any;
            wiggleSpeed: /*elided*/ any;
            wiggleAmplitude: /*elided*/ any;
            wiggleFrequency: /*elided*/ any;
            tumbleSpeed: /*elided*/ any;
            tumbleAmplitude: /*elided*/ any;
            tumbleFrequency: /*elided*/ any;
        }>;
        enabled: "off" | "on";
        ignoreLight: boolean;
        color: import("@molstar/core/util/color/color").Color;
        hitColor: import("@molstar/core/util/color/color").Color;
    }>>;
}>;
export type HelperProps = PD.Values<typeof HelperParams>;
export declare class Helper {
    readonly debug: DebugRegistry;
    readonly camera: CameraHelper;
    readonly handle: HandleHelper;
    readonly pointer: PointerHelper;
    constructor(graphics: GraphicsContext, scene: Scene, props?: Partial<HelperProps>);
}
//# sourceMappingURL=helper.d.ts.map