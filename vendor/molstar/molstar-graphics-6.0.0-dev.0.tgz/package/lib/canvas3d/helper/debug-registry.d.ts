/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Scene } from '@molstar/graphics/gl/scene';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
export interface DebugHelper<T extends {} = {}> {
    readonly scene: Scene;
    update(): void;
    syncVisibility(): void;
    clear(): void;
    readonly isEnabled: boolean;
    readonly props: T;
    setProps(props: Partial<T>): void;
}
export declare class DebugRegistry {
    ctx: GraphicsContext;
    readonly parent: Scene;
    private readonly entries;
    constructor(ctx: GraphicsContext, parent: Scene);
    /** the render objects of the entries are in the parent scene, which changes its context itself */
    setContext(ctx: GraphicsContext): void;
    register<T extends {}>(name: string, entry: DebugHelper<T>): void;
    unregister(name: string): void;
    get scenes(): Scene[];
    update(): void;
    syncVisibility(): void;
    clear(): void;
    get isEnabled(): boolean;
    setProps<T extends {}>(props: Partial<T>): void;
}
//# sourceMappingURL=debug-registry.d.ts.map