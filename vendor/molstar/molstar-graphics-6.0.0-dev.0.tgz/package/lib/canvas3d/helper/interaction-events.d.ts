/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type InputObserver } from '@molstar/core/util/input/input-observer';
import type { Camera } from '../camera.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { TrackballControls } from '../controls/trackball.js';
type Canvas3D = import('../canvas3d.js').Canvas3D;
export declare const Canvas3dInteractionHelperParams: {
    maxFps: PD.Numeric;
    preferAtomPixelPadding: PD.Numeric;
    convertCoordsToRay: PD.BooleanParam;
};
export type Canvas3dInteractionHelperParams = typeof Canvas3dInteractionHelperParams;
export type Canvas3dInteractionHelperProps = PD.Values<Canvas3dInteractionHelperParams>;
export declare class Canvas3dInteractionHelper {
    private canvasIdentify;
    private canvasAsyncIdentify;
    private lociGetter;
    private input;
    private camera;
    private controls;
    /** false if `canvasIdentify` can't read pick data synchronously, clicks then wait for `canvasAsyncIdentify` */
    private synchronousIdentify;
    private ev;
    readonly events: {
        hover: import("rxjs").Subject<import("../canvas3d.js").Canvas3D.HoverEvent>;
        drag: import("rxjs").Subject<import("../canvas3d.js").Canvas3D.DragEvent>;
        click: import("rxjs").Subject<import("../canvas3d.js").Canvas3D.ClickEvent>;
    };
    private startX;
    private startY;
    private endX;
    private endY;
    private ray;
    private pickData;
    /** a click whose pick data is read asynchronously, see `synchronousIdentify` */
    private pendingClick;
    private position;
    private isInteracting;
    private prevLoci;
    private prevT;
    private inside;
    private buttons;
    private button;
    private modifiers;
    readonly props: Canvas3dInteractionHelperProps;
    setProps(props: Partial<Canvas3dInteractionHelperProps>): void;
    private getTarget;
    private handleMove;
    private handleClick;
    private emitClick;
    private tickPendingClick;
    private handleDrag;
    /**
     * Work the next tick does: a click's pick being read (also after leaving), a hover pick under way, a move or drag not
     * handled yet (it is throttled to `maxFps`).
     */
    get isPending(): boolean;
    tick(t: number): void;
    private leave;
    private move;
    private click;
    private drag;
    private modify;
    private outsideViewport;
    private getLoci;
    resetTime(t: number): void;
    dispose(): void;
    /**
     * After the graphics context changed: `synchronousIdentify` of the new pick helpers, pending reads of the previous
     * ones (which resolve to nothing) are requested again
     */
    resetPicks(synchronousIdentify: boolean): void;
    constructor(canvasIdentify: Canvas3D['identify'], canvasAsyncIdentify: Canvas3D['asyncIdentify'], lociGetter: Canvas3D['getLoci'], input: InputObserver, camera: Camera, controls: TrackballControls, props?: Partial<Canvas3dInteractionHelperProps>, 
    /** false if `canvasIdentify` can't read pick data synchronously, clicks then wait for `canvasAsyncIdentify` */
    synchronousIdentify?: boolean);
}
export {};
//# sourceMappingURL=interaction-events.d.ts.map