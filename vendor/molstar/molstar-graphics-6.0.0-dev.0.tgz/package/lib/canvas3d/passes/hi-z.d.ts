/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type PassBuilder } from './pass-builder.js';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Sphere3D } from '@molstar/core/math/geometry';
import type { Camera } from '../camera.js';
import type { DrawPass } from './draw.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export declare const HiZParams: {
    enabled: PD.BooleanParam;
    maxFrameLag: PD.Numeric;
    minLevel: PD.Numeric;
};
export type HiZProps = PD.Values<typeof HiZParams>;
export declare class HiZPass {
    private graphics;
    private drawPass;
    private readonly viewport;
    private near;
    private far;
    private readonly view;
    private readonly projection;
    private nextNear;
    private nextFar;
    private readonly nextView;
    private readonly nextProjection;
    private readonly aabb;
    private readonly vp;
    private readonly levelData;
    /** `minLevel` the `levelData` offsets and `tex` size were computed for */
    private layoutMinLevel;
    private readonly reader;
    private readonly tex;
    private readonly renderable;
    private readonly renderBuilder;
    private readonly supported;
    /** whether a read of `tex` was started and is pending */
    private reading;
    private buffer;
    private frameLag;
    private ready;
    readonly props: HiZProps;
    getByteCount(): number;
    clear(): void;
    render(camera: Camera): void;
    /**
     * What `render` draws, see `PassBuilder`; preparing covers the first level (from the scene depth) and one of the
     * following ones (each from the level before), and keeps the reading state
     */
    plan(b: PassBuilder, camera: Camera): void;
    /** A readback under way: `tick` polls it. */
    get isPending(): boolean;
    tick(): void;
    private transform;
    private project;
    isOccluded: (s: Sphere3D) => boolean;
    setViewport(x: number, y: number, width: number, height: number): void;
    setProps(props: Partial<HiZProps>): void;
    private debug?;
    private initDebug;
    private canDebug;
    private showRect;
    private showBuffer;
    debugOcclusion(s: Sphere3D | undefined): void;
    dispose(): void;
    constructor(graphics: GraphicsContext, drawPass: DrawPass, canvas: HTMLCanvasElement | undefined, props: Partial<HiZProps>);
}
//# sourceMappingURL=hi-z.d.ts.map