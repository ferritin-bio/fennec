/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PassBuilder } from './pass-builder.js';
import { TextureSpec, UniformSpec, DefineSpec } from '@molstar/graphics/gl/renderable/schema';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { type Texture } from '@molstar/graphics/gl/texture';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Viewport } from '../camera/util.js';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
import type { ICamera } from '../camera.js';
import type { Sphere3D } from '@molstar/core/math/geometry';
import type { PostprocessingProps } from './postprocessing.js';
export declare const DofParams: {
    blurSize: PD.Numeric;
    blurSpread: PD.Numeric;
    inFocus: PD.Numeric;
    PPM: PD.Numeric;
    center: PD.Select<"camera-target" | "scene-center">;
    mode: PD.Select<"plane" | "sphere">;
};
export type DofProps = PD.Values<typeof DofParams>;
export declare class DofPass {
    private graphics;
    static isEnabled(props: PostprocessingProps): boolean;
    readonly target: RenderTarget;
    private readonly renderable;
    constructor(graphics: GraphicsContext, width: number, height: number);
    getByteCount(): number;
    private updateState;
    setSize(width: number, height: number): void;
    update(camera: ICamera, input: Texture, depthOpaque: Texture, depthTransparent: Texture, props: DofProps, sphere: Sphere3D): void;
    render(b: PassBuilder, viewport: Viewport, target: undefined | RenderTarget): void;
}
export declare const DofSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tDepthOpaque: TextureSpec<"texture">;
    tDepthTransparent: TextureSpec<"texture">;
    tColor: TextureSpec<"texture">;
    uTexSize: UniformSpec<"v2">;
    uProjection: {
        type: 'uniform';
        kind: "m4";
        variant?: "buffered" | "material";
        block?: import("@molstar/graphics/gl/renderable/schema").UniformScope;
        length?: number;
        lengthDefine?: string;
        loopBound?: boolean;
        windowRect?: import("../../gl/window-rect.js").WindowRectTag;
        depthRange: 'projection';
    };
    uInvProjection: {
        type: 'uniform';
        kind: "m4";
        variant?: "buffered" | "material";
        block?: import("@molstar/graphics/gl/renderable/schema").UniformScope;
        length?: number;
        lengthDefine?: string;
        loopBound?: boolean;
        windowRect?: import("../../gl/window-rect.js").WindowRectTag;
        depthRange: 'inverse';
    };
    uBounds: {
        type: 'uniform';
        kind: "v4";
        variant?: "buffered" | "material";
        block?: import("@molstar/graphics/gl/renderable/schema").UniformScope;
        length?: number;
        lengthDefine?: string;
        loopBound?: boolean;
        depthRange?: import("../../gl/depth-range.js").DepthRangeTag;
        windowRect: 'bounds';
    };
    uCenter: UniformSpec<"v3">;
    uMode: UniformSpec<"i">;
    dOrthographic: DefineSpec<"number">;
    uNear: UniformSpec<"f">;
    uFar: UniformSpec<"f">;
    dBlurSize: DefineSpec<"number">;
    uBlurSpread: UniformSpec<"f">;
    uInFocus: UniformSpec<"f">;
    uPPM: UniformSpec<"f">;
};
export declare const DofShaderCode: ShaderCode;
//# sourceMappingURL=dof.d.ts.map