/**
 * Copyright (c) 2022-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { PassBuilder } from './pass-builder.js';
import { AttributeSpec, DefineSpec, TextureSpec, UniformSpec, ValueSpec } from '@molstar/graphics/gl/renderable/schema';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type ICamera } from '../camera.js';
import { Color } from '@molstar/core/util/color';
import { Asset, type AssetManager } from '@molstar/core/util/assets';
import type { PostprocessingProps } from './postprocessing.js';
export declare const BackgroundParams: {
    variant: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        opacity: number;
        saturation: number;
        lightness: number;
        faces: PD.NamedParams<PD.Normalize<{
            nx: /*elided*/ any;
            ny: /*elided*/ any;
            nz: /*elided*/ any;
            px: /*elided*/ any;
            py: /*elided*/ any;
            pz: /*elided*/ any;
        }>, "urls"> | PD.NamedParams<PD.Normalize<{
            nx: /*elided*/ any;
            ny: /*elided*/ any;
            nz: /*elided*/ any;
            px: /*elided*/ any;
            py: /*elided*/ any;
            pz: /*elided*/ any;
        }>, "files">;
        blur: number;
        rotation: PD.Normalize<{
            x: /*elided*/ any;
            y: /*elided*/ any;
            z: /*elided*/ any;
        }>;
    }>, "skybox"> | PD.NamedParams<PD.Normalize<{
        opacity: number;
        saturation: number;
        lightness: number;
        source: PD.NamedParams<any, "url"> | PD.NamedParams<Asset.File | null, "file">;
        blur: number;
        coverage: "canvas" | "viewport";
    }>, "image"> | PD.NamedParams<PD.Normalize<{
        topColor: Color;
        bottomColor: Color;
        ratio: number;
        coverage: "canvas" | "viewport";
    }>, "horizontalGradient"> | PD.NamedParams<PD.Normalize<{
        centerColor: Color;
        edgeColor: Color;
        ratio: number;
        coverage: "canvas" | "viewport";
    }>, "radialGradient">>;
};
export type BackgroundProps = PD.Values<typeof BackgroundParams>;
export declare class BackgroundPass {
    private readonly graphics;
    private readonly assetManager;
    private renderable;
    private skybox;
    private image;
    private readonly camera;
    private readonly target;
    private readonly position;
    private readonly dir;
    constructor(graphics: GraphicsContext, assetManager: AssetManager, width: number, height: number);
    setSize(width: number, height: number): void;
    private clearSkybox;
    private updateSkybox;
    private clearImage;
    private updateImage;
    private updateImageScaling;
    private updateGradient;
    update(camera: ICamera, props: BackgroundProps, onload?: (changed: boolean) => void): void;
    private _isEnabled;
    isEnabled(props: PostprocessingProps): boolean;
    private isReady;
    private readonly bgColor;
    clear(props: BackgroundProps, transparentBackground: boolean, backgroundColor: Color): void;
    render(b: PassBuilder, props: BackgroundProps): void;
    /**
     * What `render` draws for `props`, without changing the background (prepare mode, with props that may never be set):
     * the program of the props' variant, no images loaded or freed
     */
    prepare(b: PassBuilder, props: BackgroundProps): void;
    dispose(): void;
}
export declare const BackgroundSchema: {
    drawCount: ValueSpec<"number">;
    instanceCount: ValueSpec<"number">;
    aPosition: AttributeSpec<"float32">;
    tSkybox: TextureSpec<"texture">;
    tImage: TextureSpec<"texture">;
    uImageScale: UniformSpec<"v2">;
    uImageOffset: UniformSpec<"v2">;
    uTexSize: UniformSpec<"v2">;
    uViewport: {
        type: 'uniform';
        kind: "v4";
        variant?: "buffered" | "material";
        block?: import("@molstar/graphics/gl/renderable/schema").UniformScope;
        length?: number;
        lengthDefine?: string;
        loopBound?: boolean;
        depthRange?: import("../../gl/depth-range.js").DepthRangeTag;
        windowRect: 'pixels';
    };
    uViewportAdjusted: UniformSpec<"b">;
    uViewDirectionProjectionInverse: UniformSpec<"m4">;
    uGradientColorA: UniformSpec<"v3">;
    uGradientColorB: UniformSpec<"v3">;
    uGradientRatio: UniformSpec<"f">;
    uBlur: UniformSpec<"f">;
    uOpacity: UniformSpec<"f">;
    uSaturation: UniformSpec<"f">;
    uLightness: UniformSpec<"f">;
    uRotation: UniformSpec<"m3">;
    dVariant: DefineSpec<"string">;
};
export declare const SkyboxShaderCode: ShaderCode;
//# sourceMappingURL=background.d.ts.map