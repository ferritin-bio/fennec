/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 *
 * Partially adapted from three.js, The MIT License, Copyright © 2010-2024 three.js authors
 */
import type { PassBuilder } from './pass-builder.js';
import { TextureSpec, UniformSpec, DefineSpec } from '@molstar/graphics/gl/renderable/schema';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { type Texture } from '@molstar/graphics/gl/texture';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Viewport } from '../camera/util.js';
import type { ICamera } from '../camera.js';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
import type { PostprocessingProps } from './postprocessing.js';
export declare const BloomParams: {
    strength: PD.Numeric;
    radius: PD.Numeric;
    threshold: PD.Numeric;
    mode: PD.Select<"emissive" | "luminosity">;
    transparency: PD.BooleanParam;
};
export type BloomProps = PD.Values<typeof BloomParams>;
export declare class BloomPass {
    private graphics;
    static isEnabled(props: PostprocessingProps): boolean;
    readonly emissiveTarget: RenderTarget;
    readonly compositeTarget: RenderTarget;
    private readonly luminosityTarget;
    private readonly horizontalBlurTargets;
    private readonly verticalBlurTargets;
    private readonly luminosityRenderable;
    private readonly blurRenderable;
    private readonly compositeRenderable;
    constructor(graphics: GraphicsContext, width: number, height: number);
    getByteCount(): number;
    setSize(width: number, height: number): void;
    update(colorOpaque: Texture, colorTransparent: Texture, emissive: Texture, depthOpaque: Texture, depthTransparent: Texture, props: BloomProps, camera: ICamera, opaqueFogged: boolean): void;
    /** Writes bloom to `compositeTarget`; caller blends it. */
    render(b: PassBuilder, viewport: Viewport): void;
}
export declare const LuminositySchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tColorOpaque: TextureSpec<"texture">;
    tColorTransparent: TextureSpec<"texture">;
    tEmissive: TextureSpec<"texture">;
    tDepthOpaque: TextureSpec<"texture">;
    tDepthTransparent: TextureSpec<"texture">;
    uTexSizeInv: UniformSpec<"v2">;
    uDefaultColor: UniformSpec<"v3">;
    uDefaultOpacity: UniformSpec<"f">;
    uLuminosityThreshold: UniformSpec<"f">;
    uSmoothWidth: UniformSpec<"f">;
    uNear: UniformSpec<"f">;
    uFar: UniformSpec<"f">;
    uIsOrtho: UniformSpec<"f">;
    uFogNear: UniformSpec<"f">;
    uFogFar: UniformSpec<"f">;
    uOpaqueFogged: UniformSpec<"b">;
    dMode: DefineSpec<"string">;
};
export declare const LuminosityShaderCode: ShaderCode;
export declare const BlurSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tInput: TextureSpec<"texture">;
    uTexSizeInv: UniformSpec<"v2">;
    uDirection: UniformSpec<"v2">;
    uGaussianCoefficients: UniformSpec<"f[]">;
    dKernelRadius: DefineSpec<"number">;
};
export declare const BlurShaderCode: ShaderCode;
export declare const CompositeSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tBlur1: TextureSpec<"texture">;
    tBlur2: TextureSpec<"texture">;
    tBlur3: TextureSpec<"texture">;
    tBlur4: TextureSpec<"texture">;
    tBlur5: TextureSpec<"texture">;
    uTexSizeInv: UniformSpec<"v2">;
    uBloomStrength: UniformSpec<"f">;
    uBloomRadius: UniformSpec<"f">;
    uBloomFactors: UniformSpec<"f[]">;
    uBloomTints: UniformSpec<"v3[]">;
};
export declare const CompositeShaderCode: ShaderCode;
//# sourceMappingURL=bloom.d.ts.map