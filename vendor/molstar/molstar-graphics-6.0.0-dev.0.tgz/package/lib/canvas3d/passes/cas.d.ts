/**
 * Copyright (c) 2023-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PassBuilder } from './pass-builder.js';
import { DefineSpec, TextureSpec, UniformSpec } from '@molstar/graphics/gl/renderable/schema';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Texture } from '@molstar/graphics/gl/texture';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Viewport } from '../camera/util.js';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
export declare const CasParams: {
    sharpness: PD.Numeric;
    denoise: PD.BooleanParam;
};
export type CasProps = PD.Values<typeof CasParams>;
export declare class CasPass {
    private graphics;
    private readonly renderable;
    constructor(graphics: GraphicsContext, input: Texture);
    private updateState;
    setSize(width: number, height: number): void;
    update(input: Texture, props: CasProps): void;
    render(b: PassBuilder, viewport: Viewport, target: RenderTarget | undefined): void;
}
export declare const CasSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tColor: TextureSpec<"texture">;
    uTexSizeInv: UniformSpec<"v2">;
    uSharpness: UniformSpec<"f">;
    dDenoise: DefineSpec<"boolean">;
};
export declare const CasShaderCode: ShaderCode;
//# sourceMappingURL=cas.d.ts.map