/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
import { type Renderer } from '@molstar/graphics/gl/renderer';
import type { Scene } from '@molstar/graphics/gl/scene';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Camera } from '../camera.js';
import { Viewport } from '../camera/util.js';
import type { Helper } from '../helper/helper.js';
import type { AssetManager } from '@molstar/core/util/assets';
import type { RuntimeContext } from '@molstar/core/task';
export declare const ImageParams: {
    transparentBackground: PD.BooleanParam;
    dpoitIterations: PD.Numeric;
    multiSample: PD.Group<PD.Normalize<{
        mode: string;
        sampleLevel: number;
        reduceFlicker: boolean;
        reuseOcclusion: boolean;
    }>>;
    postprocessing: PD.Group<PD.Normalize<{
        enabled: boolean;
        occlusion: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            samples: /*elided*/ any;
            multiScale: /*elided*/ any;
            radius: /*elided*/ any;
            bias: /*elided*/ any;
            blurKernelSize: /*elided*/ any;
            blurDepthBias: /*elided*/ any;
            resolutionScale: /*elided*/ any;
            color: /*elided*/ any;
            transparentThreshold: /*elided*/ any;
        }>, "on">;
        shadow: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            steps: /*elided*/ any;
            maxDistance: /*elided*/ any;
            tolerance: /*elided*/ any;
        }>, "on">;
        outline: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            scale: /*elided*/ any;
            threshold: /*elided*/ any;
            color: /*elided*/ any;
            includeTransparent: /*elided*/ any;
        }>, "on">;
        dof: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            blurSize: /*elided*/ any;
            blurSpread: /*elided*/ any;
            inFocus: /*elided*/ any;
            PPM: /*elided*/ any;
            center: /*elided*/ any;
            mode: /*elided*/ any;
        }>, "on">;
        antialiasing: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            edgeThresholdMin: /*elided*/ any;
            edgeThresholdMax: /*elided*/ any;
            iterations: /*elided*/ any;
            subpixelQuality: /*elided*/ any;
        }>, "fxaa"> | PD.NamedParams<PD.Normalize<{
            edgeThreshold: /*elided*/ any;
            maxSearchSteps: /*elided*/ any;
        }>, "smaa">;
        sharpening: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            sharpness: /*elided*/ any;
            denoise: /*elided*/ any;
        }>, "on">;
        background: PD.Normalize<{
            variant: /*elided*/ any;
        }>;
        bloom: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            strength: /*elided*/ any;
            radius: /*elided*/ any;
            threshold: /*elided*/ any;
            mode: /*elided*/ any;
            transparency: /*elided*/ any;
        }>, "on">;
    }>>;
    marking: PD.Group<PD.Normalize<{
        enabled: boolean;
        highlightEdgeColor: import("@molstar/core/util/color/color").Color;
        selectEdgeColor: import("@molstar/core/util/color/color").Color;
        edgeScale: number;
        highlightEdgeStrength: number;
        selectEdgeStrength: number;
        ghostEdgeStrength: number;
        innerEdgeFactor: number;
    }>>;
    illumination: PD.Group<PD.Normalize<{
        rendersPerFrame: [number, number];
        targetFps: number;
        steps: number;
        refineSteps: number;
        rayDistance: number;
        thicknessMode: "auto" | "fixed";
        minThickness: number;
        thicknessFactor: number;
        thickness: number;
        bounces: number;
        shadowEnable: boolean;
        shadowSoftness: number;
        shadowThickness: number;
        enabled: boolean;
        maxIterations: number;
        denoise: boolean;
        denoiseThreshold: [number, number];
        ignoreOutline: boolean;
    }>>;
    cameraHelper: PD.Group<PD.Normalize<{
        axes: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            alpha: /*elided*/ any;
            colorX: /*elided*/ any;
            colorY: /*elided*/ any;
            colorZ: /*elided*/ any;
            scale: /*elided*/ any;
            location: /*elided*/ any;
            locationOffsetX: /*elided*/ any;
            locationOffsetY: /*elided*/ any;
            originColor: /*elided*/ any;
            radiusScale: /*elided*/ any;
            showPlanes: /*elided*/ any;
            planeColorXY: /*elided*/ any;
            planeColorXZ: /*elided*/ any;
            planeColorYZ: /*elided*/ any;
            showLabels: /*elided*/ any;
            labelX: /*elided*/ any;
            labelY: /*elided*/ any;
            labelZ: /*elided*/ any;
            labelColorX: /*elided*/ any;
            labelColorY: /*elided*/ any;
            labelColorZ: /*elided*/ any;
            labelOpacity: /*elided*/ any;
            labelScale: /*elided*/ any;
        }>, "on">;
    }>>;
    renderer: PD.Group<PD.Normalize<{
        backgroundColor: import("@molstar/core/util/color/color").Color;
        pickingAlphaThreshold: number;
        colorMarker: boolean;
        highlightColor: import("@molstar/core/util/color/color").Color;
        selectColor: import("@molstar/core/util/color/color").Color;
        dimColor: import("@molstar/core/util/color/color").Color;
        highlightStrength: number;
        selectStrength: number;
        dimStrength: number;
        markerPriority: number;
        xrayEdgeFalloff: number;
        celSteps: number;
        exposure: number;
        light: PD.Normalize<{
            inclination: number;
            azimuth: number;
            color: import("@molstar/core/util/color/color").Color;
            intensity: number;
        }>[];
        ambientColor: import("@molstar/core/util/color/color").Color;
        ambientIntensity: number;
        enableAnimation: boolean;
    }>>;
};
export type ImageProps = PD.Values<typeof ImageParams>;
export declare class ImagePass {
    private graphics;
    private assetManager;
    private renderer;
    private scene;
    private camera;
    private _width;
    private _height;
    private _camera;
    /** bumped once per render() call, shared by every sub-render issued during that call */
    private _frame;
    readonly props: ImageProps;
    private _colorTarget;
    get colorTarget(): RenderTarget;
    private drawPass;
    private illuminationPass;
    private multiSamplePass;
    private multiSampleHelper;
    private helper;
    private limitToSupported;
    get width(): number;
    get height(): number;
    constructor(graphics: GraphicsContext, assetManager: AssetManager, renderer: Renderer, scene: Scene, camera: Camera, helper: Helper, props: Partial<ImageProps>);
    private init;
    /**
     * Renders with `graphics`, `renderer` and `helper` from now on, the passes are created again (the graphics context
     * changed, see `Canvas3D.contextChanged`)
     */
    /** advanced by `setContext`: a render or read awaited across it starts over on the new context */
    private contextVersion;
    setContext(graphics: GraphicsContext, renderer: Renderer, helper: Helper): void;
    getByteCount(): number;
    /** Updates the background to the props and resolves when its images are loaded (pending work, see `render`) */
    updateBackground(): Promise<void>;
    setSize(width: number, height: number): void;
    setProps(props?: Partial<ImageProps>): void;
    render(runtime: RuntimeContext): Promise<void>;
    /**
     * Makes the pipelines and resources `render` needs ready without drawing anything (see `PassBuilder`): the
     * programs of the scene's variants, the images of the background and lookups, and the pipelines of every pass the
     * props enable; resolves when they are
     */
    prepare(): Promise<void>;
    private plan;
    private getRenderContext;
    /** Renders on the context of `version`, returning early when it changed (`setContext`) */
    private renderOnce;
    getImageData(runtime: RuntimeContext, width: number, height: number, viewport?: Viewport): Promise<ImageData>;
}
//# sourceMappingURL=image.d.ts.map