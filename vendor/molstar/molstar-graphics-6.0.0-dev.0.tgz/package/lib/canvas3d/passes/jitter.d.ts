/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Camera } from '../camera.js';
import { StereoCamera } from '../camera/stereo.js';
export declare const JitterVectors: number[][][];
export declare function getJitterOffsets(sampleLevel: number): number[][];
export declare function getTemporalSamplesPerFrame(sampleLevel: number): number;
export declare function setJitter(camera: Camera | StereoCamera, offset: number[]): void;
export declare function clearJitter(camera: Camera | StereoCamera): void;
//# sourceMappingURL=jitter.d.ts.map