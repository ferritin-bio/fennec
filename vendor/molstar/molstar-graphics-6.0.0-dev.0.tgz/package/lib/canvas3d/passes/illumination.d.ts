/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { type PassBuilder } from './pass-builder.js';
import { DefineSpec, TextureSpec, UniformSpec } from '@molstar/graphics/gl/renderable/schema';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { RendererProps } from '@molstar/graphics/gl/renderer';
import { Camera } from '../camera.js';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type PostprocessingProps } from './postprocessing.js';
import type { DrawPass } from './draw.js';
import { type MarkingProps } from './marking.js';
import type { MultiSampleProps } from './multi-sample.js';
import type { RenderContext } from '../util.js';
type Props = {
    transparentBackground: boolean;
    dpoitIterations: number;
    illumination: IlluminationProps;
    renderer: RendererProps;
    postprocessing: PostprocessingProps;
    marking: MarkingProps;
    multiSample: MultiSampleProps;
};
export declare const IlluminationParams: {
    rendersPerFrame: PD.Interval;
    targetFps: PD.Numeric;
    steps: PD.Numeric;
    refineSteps: PD.Numeric;
    rayDistance: PD.Numeric;
    thicknessMode: PD.Select<"auto" | "fixed">;
    minThickness: PD.Numeric;
    thicknessFactor: PD.Numeric;
    thickness: PD.Numeric;
    bounces: PD.Numeric;
    shadowEnable: PD.BooleanParam;
    shadowSoftness: PD.Numeric;
    shadowThickness: PD.Numeric;
    enabled: PD.BooleanParam;
    maxIterations: PD.Numeric;
    denoise: PD.BooleanParam;
    denoiseThreshold: PD.Interval;
    ignoreOutline: PD.BooleanParam;
};
export type IlluminationProps = PD.Values<typeof IlluminationParams>;
export declare class IlluminationPass {
    private readonly graphics;
    private readonly drawPass;
    private readonly tracing;
    private readonly transparentTarget;
    private readonly outputTarget;
    readonly packedDepth: boolean;
    private readonly copyRenderable;
    private readonly composeRenderable;
    private multiSampleComposeTarget;
    private multiSampleHoldTarget;
    private multiSampleAccumulateTarget;
    private multiSampleCompose;
    private readonly renderBuilder;
    private _iteration;
    get iteration(): number;
    private _colorTarget;
    get colorTarget(): RenderTarget;
    private markingShading;
    private _supported;
    get supported(): boolean;
    getByteCount(): number;
    getMaxIterations(props: IlluminationProps): number;
    static getUnsupportedReason(graphics: GraphicsContext): string | undefined;
    static isSupported(graphics: GraphicsContext): boolean;
    static isEnabled(graphics: GraphicsContext, props: IlluminationProps): boolean;
    constructor(graphics: GraphicsContext, drawPass: DrawPass);
    private renderInput;
    private hasHelpers;
    private renderHelpers;
    shouldRender(props: IlluminationProps): boolean;
    setSize(width: number, height: number): void;
    restart(clearAdjustedProps?: boolean): void;
    private renderInternal;
    private setupRenderer;
    private compose;
    private prevSampleIndex;
    private renderMultiSample;
    render(ctx: RenderContext<Camera>, props: Props, toDrawingBuffer: boolean): void;
    /**
     * What `render` draws, see `PassBuilder`; preparing covers the first and the following iterations (the input is
     * drawn on the first and when a multi-sample offset changes) and keeps the iteration and the output target
     */
    plan(b: PassBuilder, ctx: RenderContext<Camera>, props: Props, toDrawingBuffer: boolean): void;
}
export declare const ComposeSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tColor: TextureSpec<"texture">;
    tNormal: TextureSpec<"texture">;
    tShaded: TextureSpec<"texture">;
    tTransparentColor: TextureSpec<"texture">;
    dBlendTransparency: DefineSpec<"boolean">;
    tSsaoDepth: TextureSpec<"texture">;
    tSsaoDepthTransparent: TextureSpec<"texture">;
    /** the SSAO targets have a lower resolution, see `getSsaoUpsampled` */
    dOcclusionUpsample: DefineSpec<"boolean">;
    uOcclusionTexSize: UniformSpec<"v2">;
    tDepthOpaque: TextureSpec<"texture">;
    tDepthTransparent: TextureSpec<"texture">;
    tOutlines: TextureSpec<"texture">;
    tBloom: TextureSpec<"texture">;
    dBloomEnable: DefineSpec<"boolean">;
    uTexSize: UniformSpec<"v2">;
    dDenoise: DefineSpec<"boolean">;
    uDenoiseThreshold: UniformSpec<"f">;
    dOrthographic: DefineSpec<"number">;
    uNear: UniformSpec<"f">;
    uFar: UniformSpec<"f">;
    uFogNear: UniformSpec<"f">;
    uFogFar: UniformSpec<"f">;
    uFogColor: UniformSpec<"v3">;
    uOutlineColor: UniformSpec<"v3">;
    uOcclusionColor: UniformSpec<"v3">;
    uTransparentBackground: UniformSpec<"b">;
    dOcclusionEnable: DefineSpec<"boolean">;
    dOutlineEnable: DefineSpec<"boolean">;
    dOutlineScale: DefineSpec<"number">;
    dTransparentOutline: DefineSpec<"boolean">;
};
export declare const ComposeShaderCode: ShaderCode;
export declare const MultiSampleComposeSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tColor: TextureSpec<"texture">;
    uTexSize: UniformSpec<"v2">;
    uWeight: UniformSpec<"f">;
};
export declare const MultiSampleComposeShaderCode: ShaderCode;
export {};
//# sourceMappingURL=illumination.d.ts.map