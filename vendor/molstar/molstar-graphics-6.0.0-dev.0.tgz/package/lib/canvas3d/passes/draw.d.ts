/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Áron Samuel Kovács <aron.kovacs@mail.muni.cz>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { RenderTarget } from '@molstar/graphics/gl/render-target';
import type { Renderer } from '@molstar/graphics/gl/renderer';
import type { Scene } from '@molstar/graphics/gl/scene';
import type { Texture } from '@molstar/graphics/gl/texture';
import type { ICamera } from '../camera.js';
import { WboitPass } from './wboit.js';
import { DpoitPass } from './dpoit.js';
import { AntialiasingPass, PostprocessingPass, type PostprocessingProps } from './postprocessing.js';
import { MarkingPass, type MarkingProps, type MarkingShading } from './marking.js';
import type { AssetManager } from '@molstar/core/util/assets';
import { DofPass } from './dof.js';
import type { RenderContext } from '../util.js';
import { type PassBuilder } from './pass-builder.js';
type Props = {
    postprocessing: PostprocessingProps;
    marking: MarkingProps;
    transparentBackground: boolean;
    dpoitIterations: number;
};
export type TransparencyMode = 'wboit' | 'dpoit' | 'blended';
export declare class DrawPass {
    private graphics;
    private readonly drawTarget;
    readonly colorTarget: RenderTarget;
    readonly transparentColorTarget: RenderTarget;
    readonly depthTextureTransparent: Texture;
    readonly depthTextureOpaque: Texture;
    readonly packedDepth: boolean;
    readonly depthTargetTransparent: RenderTarget;
    private depthTargetOpaque;
    private copyFbo;
    private readonly renderBuilder;
    readonly wboit: WboitPass;
    readonly dpoit: DpoitPass;
    readonly marking: MarkingPass;
    readonly postprocessing: PostprocessingPass;
    private readonly ssaoShading;
    readonly antialiasing: AntialiasingPass;
    readonly dof: DofPass;
    private transparencyMode;
    /** `transparency` as this context draws it: blended where the mode is not supported */
    resolveTransparency(transparency: TransparencyMode): TransparencyMode;
    setTransparency(transparency: TransparencyMode): void;
    private resetTransparencyAttachments;
    /**
     * Runs `plan` with the passes planning for `transparency` (as this context draws it) instead of the current mode,
     * e.g. to prepare for props not set yet; the current mode is restored after
     */
    withTransparency<T>(transparency: TransparencyMode, plan: () => T): T;
    get transparency(): TransparencyMode;
    constructor(graphics: GraphicsContext, assetManager: AssetManager, width: number, height: number, transparency: 'wboit' | 'dpoit' | 'blended');
    getByteCount(): number;
    setSize(width: number, height: number): void;
    renderEmissiveBloom(b: PassBuilder, renderer: Renderer, camera: ICamera, scene: Scene, transparency: boolean): void;
    private _renderBloom;
    private renderPostprocessing;
    private _renderDpoit;
    private _renderWboit;
    private _renderBlended;
    private planEye;
    private _renderHelpers;
    /** `renderer.renderBlended` as renderer passes */
    renderBlended(b: PassBuilder, renderer: Renderer, scene: Scene, camera: ICamera): void;
    /** Returns the target the finished image ended up in, or undefined when it went to the drawing buffer. */
    private _renderOutput;
    private copyToDrawingBuffer;
    render(ctx: RenderContext, props: Props, toDrawingBuffer: boolean, skipMarking?: boolean): void;
    /**
     * Makes the pipelines and resources of `render` with these arguments ready without drawing (see `PassBuilder`);
     * resolves when they are
     */
    prepare(ctx: RenderContext, props: Props, toDrawingBuffer: boolean, skipMarking?: boolean): Promise<void>;
    /**
     * What `render` draws, see `PassBuilder`; `asIfMarked` draws marking as if objects were marked (preparing marking,
     * which draws only marked objects, before the first hover)
     */
    plan(b: PassBuilder, ctx: RenderContext, props: Props, toDrawingBuffer: boolean, skipMarking?: boolean, asIfMarked?: boolean): void;
    private isTransparentBackground;
    /** shading of the last render that marking tint and dim keep, or null if there is none */
    getMarkingShading(postprocessingProps: PostprocessingProps): MarkingShading | null;
    getColorTarget(postprocessingProps: PostprocessingProps): RenderTarget;
}
export {};
//# sourceMappingURL=draw.d.ts.map