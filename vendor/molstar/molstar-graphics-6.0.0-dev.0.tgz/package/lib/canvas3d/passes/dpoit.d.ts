/**
 * Copyright (c) 2022-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Gianluca Tomasello <giagitom@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * Adapted from https://github.com/tsherif/webgl2examples, The MIT License, Copyright © 2017 Tarek Sherif, Shuai Shao
 */
import type { PassBuilder } from './pass-builder.js';
import { TextureSpec, UniformSpec } from '@molstar/graphics/gl/renderable/schema';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Texture } from '@molstar/graphics/gl/texture';
import type { Renderbuffer } from '@molstar/graphics/gl/renderbuffer';
export declare const BlendBackDpoitSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tDpoitBackColor: TextureSpec<"texture">;
    uTexSize: UniformSpec<"v2">;
};
export declare const BlendBackDpoitShaderCode: ShaderCode;
export declare const EvaluateDpoitSchema: {
    drawCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    instanceCount: import("@molstar/graphics/gl/renderable/schema").ValueSpec<"number">;
    aPosition: import("@molstar/graphics/gl/renderable/schema").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tDpoitFrontColor: TextureSpec<"texture">;
    uTexSize: UniformSpec<"v2">;
};
export declare const EvaluateDpoitShaderCode: ShaderCode;
export declare class DpoitPass {
    private stencil;
    private readonly DEPTH_CLEAR_VALUE;
    private readonly MAX_DEPTH;
    private readonly MIN_DEPTH;
    private passCount;
    private writeId;
    private readId;
    private readonly blendBackRenderable;
    private readonly renderable;
    private readonly depthFramebuffers;
    private readonly colorFramebuffers;
    private readonly depthTextures;
    private readonly colorFrontTextures;
    private readonly colorBackTextures;
    private _supported;
    get supported(): boolean;
    getByteCount(): number;
    bind(b: PassBuilder): {
        depth: Texture;
        frontColor: Texture;
        backColor: Texture;
    };
    bindDualDepthPeeling(b: PassBuilder): {
        depth: Texture;
        frontColor: Texture;
        backColor: Texture;
    };
    renderBlendBack(b: PassBuilder): void;
    render(b: PassBuilder): void;
    setSize(width: number, height: number): void;
    private _init;
    /** Why dpoit is not available, if it is not: programs or capabilities missing */
    static getUnsupportedReason(graphics: GraphicsContext): string | undefined;
    static isSupported(graphics: GraphicsContext): boolean;
    constructor(graphics: GraphicsContext, width: number, height: number, stencil?: Renderbuffer | null);
}
//# sourceMappingURL=dpoit.d.ts.map