/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Viewport } from './camera/util.js';
import { CameraTransitionManager, type CameraTransitionOptions } from './camera/transition.js';
import { BehaviorSubject, Subject } from 'rxjs';
import type { Scene } from '@molstar/graphics/gl/scene';
import type { Ray3D } from '@molstar/core/math/geometry/primitives/ray3d';
import { Mat4 } from '@molstar/core/math/linear-algebra/3d/mat4';
import { Vec4 } from '@molstar/core/math/linear-algebra/3d/vec4';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { Euler } from '@molstar/core/math/linear-algebra/3d/euler';
export type { ICamera };
interface ICamera {
    readonly viewport: Viewport;
    readonly view: Mat4;
    readonly projection: Mat4;
    readonly projectionView: Mat4;
    readonly inverseProjectionView: Mat4;
    readonly state: Readonly<Camera.Snapshot>;
    readonly viewOffset: Camera.ViewOffset;
    readonly far: number;
    readonly near: number;
    readonly fogFar: number;
    readonly fogNear: number;
    readonly headRotation: Mat4;
    readonly viewEye: Mat4;
    readonly isAsymmetricProjection: boolean;
    readonly forceFull: boolean;
    readonly scale: number;
    readonly minTargetDistance: number;
    readonly disabled: boolean;
}
export declare class Camera implements ICamera {
    readonly view: Mat4;
    readonly projection: Mat4;
    readonly projectionView: Mat4;
    readonly inverseProjectionView: Mat4;
    readonly headRotation: Mat4;
    readonly viewEye: Mat4;
    readonly isAsymmetricProjection = false;
    readonly viewport: Viewport;
    readonly state: Readonly<Camera.Snapshot>;
    readonly viewOffset: Camera.ViewOffset;
    readonly disabled: false;
    near: number;
    far: number;
    fogNear: number;
    fogFar: number;
    zoom: number;
    forceFull: boolean;
    scale: number;
    minTargetDistance: number;
    readonly transition: CameraTransitionManager;
    readonly stateChanged: BehaviorSubject<Partial<Camera.Snapshot>>;
    /** Fires whenever update() produces a changed view/projection (covers all mutations, including direct ones from controls). */
    readonly changed: Subject<void>;
    get position(): Vec3;
    set position(v: Vec3);
    get up(): Vec3;
    set up(v: Vec3);
    get target(): Vec3;
    set target(v: Vec3);
    private prevProjection;
    private prevView;
    private deltaDirection;
    private newPosition;
    update(): boolean;
    setState(snapshot: Partial<Camera.Snapshot>, durationMs?: number, options?: CameraTransitionOptions): void;
    getSnapshot(): Camera.Snapshot;
    /** The view the camera comes to: the target of a transition under way, else where it is (what a saved state keeps). */
    getSettledSnapshot(): Camera.Snapshot;
    getTargetDistance(radius: number): number;
    getFocus(target: Vec3, radius: number, up?: Vec3, dir?: Vec3, snapshot?: Partial<Camera.Snapshot>): Partial<Camera.Snapshot>;
    getCenter(target: Vec3, radius?: number): Partial<Camera.Snapshot>;
    getInvariantFocus(target: Vec3, radius: number, up: Vec3, dir: Vec3): Partial<Camera.Snapshot>;
    focus(target: Vec3, radius: number, durationMs?: number, up?: Vec3, dir?: Vec3): void;
    center(target: Vec3, durationMs?: number): void;
    /** Transform point into 2D window coordinates (top-left origin, y down). */
    project(out: Vec4, point: Vec3): Vec4;
    /**
     * Transform point from screen space to 3D coordinates.
     * The point must have `x` and `y` set to 2D window coordinates (top-left origin, y down)
     * and `z` between 0 (near) and 1 (far); the optional `w` is not used.
     */
    unproject(out: Vec3, point: Vec3 | Vec4): Vec3;
    /** World space pixel size at given `point` */
    getPixelSize(point: Vec3): number;
    /** The ray through window coordinates `x`, `y` (top-left origin, y down) */
    getRay(out: Ray3D, x: number, y: number): Ray3D;
    /** How much the camera is rotated around its target. Uses 'ZYX' order. */
    getRotation(out: Euler): Euler;
    /** Set the camera rotation around its target. Expects 'ZYX' order. */
    setRotation(rotation: Euler, durationMs?: number): void;
    /** Translation of the camera target relative to world origin (0, 0, 0) */
    getTranslation(out: Vec3): Vec3;
    /** Set the camera target to the given translation, moving position by the same delta so orientation/distance are preserved */
    setTranslation(translation: Vec3, durationMs?: number): void;
    constructor(state?: Partial<Camera.Snapshot>, viewport?: Viewport);
}
export declare namespace Camera {
    type Mode = 'perspective' | 'orthographic';
    type SnapshotProvider = Partial<Snapshot> | ((scene: Scene, camera: Camera) => Partial<Snapshot>);
    /**
     * Sets an offseted view in a larger frustum. This is useful for
     * - multi-window or multi-monitor/multi-machine setups
     * - jittering the camera position for sampling
     */
    interface ViewOffset {
        enabled: boolean;
        fullWidth: number;
        fullHeight: number;
        offsetX: number;
        offsetY: number;
        width: number;
        height: number;
    }
    function ViewOffset(): ViewOffset;
    function setViewOffset(out: ViewOffset, fullWidth: number, fullHeight: number, offsetX: number, offsetY: number, width: number, height: number): void;
    function copyViewOffset(out: ViewOffset, view: ViewOffset): void;
    function targetDistance(radius: number, mode: Mode, fov: number, width: number, height: number): number;
    function createDefaultSnapshot(): Snapshot;
    interface Snapshot {
        mode: Mode;
        fov: number;
        position: Vec3;
        up: Vec3;
        target: Vec3;
        radius: number;
        radiusMax: number;
        fog: number;
        clipFar: boolean;
        minNear: number;
        minFar: number;
    }
    function copySnapshot(out: Snapshot, source?: Partial<Snapshot>): Snapshot;
    function areSnapshotsEqual(a: Snapshot, b: Snapshot): boolean;
}
//# sourceMappingURL=camera.d.ts.map