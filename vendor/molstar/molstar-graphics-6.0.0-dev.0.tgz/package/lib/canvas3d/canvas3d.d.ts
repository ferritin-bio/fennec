/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 * @author Herman Bergwerf <post@hbergwerf.nl>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { BehaviorSubject, type Observable, Subject } from 'rxjs';
import type { PickingId } from '@molstar/graphics/geo/geometry/picking';
import { type GraphicsRenderObject } from '@molstar/graphics/gl/render-object';
import { type RendererStats } from '@molstar/graphics/gl/renderer';
import { type PrecompileList } from '@molstar/graphics/gl/precompile';
import { type GraphicsBackendDescriptor } from '@molstar/graphics/gl/backend';
import type { GraphicsContext, GraphicsDestroyOptions } from '@molstar/graphics/gl/context';
import { type EasingFunction } from '@molstar/core/math/easing';
import { Sphere3D } from '@molstar/core/math/geometry';
import type { Ray3D } from '@molstar/core/math/geometry/primitives/ray3d';
import { Vec2, Vec3 } from '@molstar/core/math/linear-algebra';
import { Representation } from '@molstar/graphics/repr/representation';
import type { AssetManager } from '@molstar/core/util/assets';
import { type ButtonsType, InputObserver, type ModifiersKeys } from '@molstar/core/util/input/input-observer';
import type { MarkerAction } from '@molstar/core/util/marker-action';
import { now } from '@molstar/core/util/now';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Camera } from './camera.js';
import type { CameraTransitionManager } from './camera/transition.js';
import { type TransitionTrajectory } from './camera/transition-functions.js';
import type { DebugRegistry } from './helper/debug-registry.js';
import { Canvas3dInteractionHelper } from './helper/interaction-events.js';
import { ImagePass, type ImageProps } from './passes/image.js';
import type { TransparencyMode } from './passes/draw.js';
import { Passes } from './passes/passes.js';
import { type AsyncPickData, type PickResult } from './passes/pick.js';
export declare const CameraFogParams: {
    intensity: PD.Numeric;
};
export declare const Canvas3DParams: {
    camera: PD.Group<PD.Normalize<{
        mode: "orthographic" | "perspective";
        helper: PD.Normalize<{
            axes: /*elided*/ any;
        }>;
        stereo: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            eyeSeparation: /*elided*/ any;
            focus: /*elided*/ any;
        }>, "on">;
        fov: number;
        manualReset: boolean;
    }>>;
    cameraFog: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        intensity: number;
    }>, "on">>;
    cameraClipping: PD.Group<PD.Normalize<{
        radius: number;
        far: boolean;
        minNear: number;
    }>>;
    viewport: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "canvas"> | PD.NamedParams<PD.Normalize<{
        x: number;
        y: number;
        width: number;
        height: number;
    }>, "static-frame"> | PD.NamedParams<PD.Normalize<{
        x: number;
        y: number;
        width: number;
        height: number;
    }>, "relative-frame">>;
    cameraResetDurationMs: PD.Numeric;
    cameraResetEasing: PD.Select<"bounce-in" | "bounce-in-out" | "bounce-out" | "circle-in" | "circle-in-out" | "circle-out" | "cubic-in" | "cubic-in-out" | "cubic-out" | "exp-in" | "exp-in-out" | "exp-out" | "linear" | "quad-in" | "quad-in-out" | "quad-out" | "sin-in" | "sin-in-out" | "sin-out">;
    cameraResetTrajectory: PD.Select<"leap" | "leap-relative" | "linear" | "linear-relative">;
    sceneRadiusFactor: PD.Numeric;
    transparentBackground: PD.BooleanParam;
    checkeredTransparentBackground: PD.BooleanParam;
    dpoitIterations: PD.Numeric;
    pickPadding: PD.Numeric;
    userInteractionReleaseMs: PD.Numeric;
    multiSample: PD.Group<PD.Normalize<{
        mode: string;
        sampleLevel: number;
        reduceFlicker: boolean;
        reuseOcclusion: boolean;
    }>>;
    postprocessing: PD.Group<PD.Normalize<{
        enabled: boolean;
        occlusion: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            samples: /*elided*/ any;
            multiScale: /*elided*/ any;
            radius: /*elided*/ any;
            bias: /*elided*/ any;
            blurKernelSize: /*elided*/ any;
            blurDepthBias: /*elided*/ any;
            resolutionScale: /*elided*/ any;
            color: /*elided*/ any;
            transparentThreshold: /*elided*/ any;
        }>, "on">;
        shadow: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            steps: /*elided*/ any;
            maxDistance: /*elided*/ any;
            tolerance: /*elided*/ any;
        }>, "on">;
        outline: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            scale: /*elided*/ any;
            threshold: /*elided*/ any;
            color: /*elided*/ any;
            includeTransparent: /*elided*/ any;
        }>, "on">;
        dof: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            blurSize: /*elided*/ any;
            blurSpread: /*elided*/ any;
            inFocus: /*elided*/ any;
            PPM: /*elided*/ any;
            center: /*elided*/ any;
            mode: /*elided*/ any;
        }>, "on">;
        antialiasing: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            edgeThresholdMin: /*elided*/ any;
            edgeThresholdMax: /*elided*/ any;
            iterations: /*elided*/ any;
            subpixelQuality: /*elided*/ any;
        }>, "fxaa"> | PD.NamedParams<PD.Normalize<{
            edgeThreshold: /*elided*/ any;
            maxSearchSteps: /*elided*/ any;
        }>, "smaa">;
        sharpening: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            sharpness: /*elided*/ any;
            denoise: /*elided*/ any;
        }>, "on">;
        background: PD.Normalize<{
            variant: /*elided*/ any;
        }>;
        bloom: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            strength: /*elided*/ any;
            radius: /*elided*/ any;
            threshold: /*elided*/ any;
            mode: /*elided*/ any;
            transparency: /*elided*/ any;
        }>, "on">;
    }>>;
    marking: PD.Group<PD.Normalize<{
        enabled: boolean;
        highlightEdgeColor: import("@molstar/core/util/color/color").Color;
        selectEdgeColor: import("@molstar/core/util/color/color").Color;
        edgeScale: number;
        highlightEdgeStrength: number;
        selectEdgeStrength: number;
        ghostEdgeStrength: number;
        innerEdgeFactor: number;
    }>>;
    illumination: PD.Group<PD.Normalize<{
        rendersPerFrame: [number, number];
        targetFps: number;
        steps: number;
        refineSteps: number;
        rayDistance: number;
        thicknessMode: "auto" | "fixed";
        minThickness: number;
        thicknessFactor: number;
        thickness: number;
        bounces: number;
        shadowEnable: boolean;
        shadowSoftness: number;
        shadowThickness: number;
        enabled: boolean;
        maxIterations: number;
        denoise: boolean;
        denoiseThreshold: [number, number];
        ignoreOutline: boolean;
    }>>;
    hiZ: PD.Group<PD.Normalize<{
        enabled: boolean;
        maxFrameLag: number;
        minLevel: number;
    }>>;
    renderer: PD.Group<PD.Normalize<{
        backgroundColor: import("@molstar/core/util/color/color").Color;
        pickingAlphaThreshold: number;
        colorMarker: boolean;
        highlightColor: import("@molstar/core/util/color/color").Color;
        selectColor: import("@molstar/core/util/color/color").Color;
        dimColor: import("@molstar/core/util/color/color").Color;
        highlightStrength: number;
        selectStrength: number;
        dimStrength: number;
        markerPriority: number;
        xrayEdgeFalloff: number;
        celSteps: number;
        exposure: number;
        light: PD.Normalize<{
            inclination: number;
            azimuth: number;
            color: import("@molstar/core/util/color/color").Color;
            intensity: number;
        }>[];
        ambientColor: import("@molstar/core/util/color/color").Color;
        ambientIntensity: number;
        enableAnimation: boolean;
    }>>;
    trackball: PD.Group<PD.Normalize<{
        rotateSpeed: number;
        zoomSpeed: number;
        panSpeed: number;
        moveSpeed: number;
        boostMoveFactor: number;
        flyMode: boolean;
        animate: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            speed: /*elided*/ any;
            axis: /*elided*/ any;
        }>, "spin"> | PD.NamedParams<PD.Normalize<{
            speed: /*elided*/ any;
            angle: /*elided*/ any;
            axis: /*elided*/ any;
        }>, "rock">;
        staticMoving: boolean;
        dynamicDampingFactor: number;
        minDistance: number;
        maxDistance: number;
        gestureScaleFactor: number;
        maxWheelDelta: number;
        autoAdjustMinMaxDistance: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            minDistanceFactor: /*elided*/ any;
            minDistancePadding: /*elided*/ any;
            maxDistanceFactor: /*elided*/ any;
            maxDistanceMin: /*elided*/ any;
        }>, "on">;
    }>>;
    interaction: PD.Group<PD.Normalize<{
        maxFps: number;
        preferAtomPixelPadding: number;
        convertCoordsToRay: boolean;
    }>>;
    handle: PD.Group<PD.Normalize<{
        handle: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            quality: /*elided*/ any;
            material: /*elided*/ any;
            clip: /*elided*/ any;
            emissive: /*elided*/ any;
            density: /*elided*/ any;
            instanceGranularity: /*elided*/ any;
            renderMerged: /*elided*/ any;
            lod: /*elided*/ any;
            cellSize: /*elided*/ any;
            batchSize: /*elided*/ any;
            doubleSided: /*elided*/ any;
            flipSided: /*elided*/ any;
            flatShaded: /*elided*/ any;
            celShaded: /*elided*/ any;
            xrayShaded: /*elided*/ any;
            transparentBackfaces: /*elided*/ any;
            solidInterior: /*elided*/ any;
            bumpFrequency: /*elided*/ any;
            bumpAmplitude: /*elided*/ any;
            interior: /*elided*/ any;
            animation: /*elided*/ any;
            alpha: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            colorX: /*elided*/ any;
            colorY: /*elided*/ any;
            colorZ: /*elided*/ any;
            scale: /*elided*/ any;
        }>, "on">;
    }>>;
    pointer: PD.Group<PD.Normalize<{
        alpha: number;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        material: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        clip: PD.Normalize<{
            variant: /*elided*/ any;
            objects: /*elided*/ any;
        }>;
        emissive: number;
        density: number;
        instanceGranularity: import("../geo/geometry/base.js").InstanceGranularityValue;
        renderMerged: import("../geo/geometry/base.js").RenderMergedValue;
        lod: Vec3;
        cellSize: number;
        batchSize: number;
        doubleSided: boolean;
        flipSided: boolean;
        flatShaded: boolean;
        celShaded: boolean;
        xrayShaded: "inverted" | boolean;
        transparentBackfaces: "off" | "on" | "opaque";
        solidInterior: boolean;
        bumpFrequency: number;
        bumpAmplitude: number;
        interior: PD.Normalize<{
            color: /*elided*/ any;
            colorStrength: /*elided*/ any;
            substance: /*elided*/ any;
            substanceStrength: /*elided*/ any;
        }>;
        animation: PD.Normalize<{
            wiggleMode: /*elided*/ any;
            wiggleSpeed: /*elided*/ any;
            wiggleAmplitude: /*elided*/ any;
            wiggleFrequency: /*elided*/ any;
            tumbleSpeed: /*elided*/ any;
            tumbleAmplitude: /*elided*/ any;
            tumbleFrequency: /*elided*/ any;
        }>;
        enabled: "off" | "on";
        ignoreLight: boolean;
        color: import("@molstar/core/util/color/color").Color;
        hitColor: import("@molstar/core/util/color/color").Color;
    }>>;
    xr: PD.Group<PD.Normalize<{
        minTargetDistance: number;
        disablePostprocessing: boolean;
        resolutionScale: number;
        sceneRadiusInMeters: number;
    }>>;
};
export declare const DefaultCanvas3DParams: PD.Values<{
    camera: PD.Group<PD.Normalize<{
        mode: "orthographic" | "perspective";
        helper: PD.Normalize<{
            axes: /*elided*/ any;
        }>;
        stereo: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            eyeSeparation: /*elided*/ any;
            focus: /*elided*/ any;
        }>, "on">;
        fov: number;
        manualReset: boolean;
    }>>;
    cameraFog: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        intensity: number;
    }>, "on">>;
    cameraClipping: PD.Group<PD.Normalize<{
        radius: number;
        far: boolean;
        minNear: number;
    }>>;
    viewport: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "canvas"> | PD.NamedParams<PD.Normalize<{
        x: number;
        y: number;
        width: number;
        height: number;
    }>, "static-frame"> | PD.NamedParams<PD.Normalize<{
        x: number;
        y: number;
        width: number;
        height: number;
    }>, "relative-frame">>;
    cameraResetDurationMs: PD.Numeric;
    cameraResetEasing: PD.Select<"bounce-in" | "bounce-in-out" | "bounce-out" | "circle-in" | "circle-in-out" | "circle-out" | "cubic-in" | "cubic-in-out" | "cubic-out" | "exp-in" | "exp-in-out" | "exp-out" | "linear" | "quad-in" | "quad-in-out" | "quad-out" | "sin-in" | "sin-in-out" | "sin-out">;
    cameraResetTrajectory: PD.Select<"leap" | "leap-relative" | "linear" | "linear-relative">;
    sceneRadiusFactor: PD.Numeric;
    transparentBackground: PD.BooleanParam;
    checkeredTransparentBackground: PD.BooleanParam;
    dpoitIterations: PD.Numeric;
    pickPadding: PD.Numeric;
    userInteractionReleaseMs: PD.Numeric;
    multiSample: PD.Group<PD.Normalize<{
        mode: string;
        sampleLevel: number;
        reduceFlicker: boolean;
        reuseOcclusion: boolean;
    }>>;
    postprocessing: PD.Group<PD.Normalize<{
        enabled: boolean;
        occlusion: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            samples: /*elided*/ any;
            multiScale: /*elided*/ any;
            radius: /*elided*/ any;
            bias: /*elided*/ any;
            blurKernelSize: /*elided*/ any;
            blurDepthBias: /*elided*/ any;
            resolutionScale: /*elided*/ any;
            color: /*elided*/ any;
            transparentThreshold: /*elided*/ any;
        }>, "on">;
        shadow: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            steps: /*elided*/ any;
            maxDistance: /*elided*/ any;
            tolerance: /*elided*/ any;
        }>, "on">;
        outline: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            scale: /*elided*/ any;
            threshold: /*elided*/ any;
            color: /*elided*/ any;
            includeTransparent: /*elided*/ any;
        }>, "on">;
        dof: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            blurSize: /*elided*/ any;
            blurSpread: /*elided*/ any;
            inFocus: /*elided*/ any;
            PPM: /*elided*/ any;
            center: /*elided*/ any;
            mode: /*elided*/ any;
        }>, "on">;
        antialiasing: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            edgeThresholdMin: /*elided*/ any;
            edgeThresholdMax: /*elided*/ any;
            iterations: /*elided*/ any;
            subpixelQuality: /*elided*/ any;
        }>, "fxaa"> | PD.NamedParams<PD.Normalize<{
            edgeThreshold: /*elided*/ any;
            maxSearchSteps: /*elided*/ any;
        }>, "smaa">;
        sharpening: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            sharpness: /*elided*/ any;
            denoise: /*elided*/ any;
        }>, "on">;
        background: PD.Normalize<{
            variant: /*elided*/ any;
        }>;
        bloom: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            strength: /*elided*/ any;
            radius: /*elided*/ any;
            threshold: /*elided*/ any;
            mode: /*elided*/ any;
            transparency: /*elided*/ any;
        }>, "on">;
    }>>;
    marking: PD.Group<PD.Normalize<{
        enabled: boolean;
        highlightEdgeColor: import("@molstar/core/util/color/color").Color;
        selectEdgeColor: import("@molstar/core/util/color/color").Color;
        edgeScale: number;
        highlightEdgeStrength: number;
        selectEdgeStrength: number;
        ghostEdgeStrength: number;
        innerEdgeFactor: number;
    }>>;
    illumination: PD.Group<PD.Normalize<{
        rendersPerFrame: [number, number];
        targetFps: number;
        steps: number;
        refineSteps: number;
        rayDistance: number;
        thicknessMode: "auto" | "fixed";
        minThickness: number;
        thicknessFactor: number;
        thickness: number;
        bounces: number;
        shadowEnable: boolean;
        shadowSoftness: number;
        shadowThickness: number;
        enabled: boolean;
        maxIterations: number;
        denoise: boolean;
        denoiseThreshold: [number, number];
        ignoreOutline: boolean;
    }>>;
    hiZ: PD.Group<PD.Normalize<{
        enabled: boolean;
        maxFrameLag: number;
        minLevel: number;
    }>>;
    renderer: PD.Group<PD.Normalize<{
        backgroundColor: import("@molstar/core/util/color/color").Color;
        pickingAlphaThreshold: number;
        colorMarker: boolean;
        highlightColor: import("@molstar/core/util/color/color").Color;
        selectColor: import("@molstar/core/util/color/color").Color;
        dimColor: import("@molstar/core/util/color/color").Color;
        highlightStrength: number;
        selectStrength: number;
        dimStrength: number;
        markerPriority: number;
        xrayEdgeFalloff: number;
        celSteps: number;
        exposure: number;
        light: PD.Normalize<{
            inclination: number;
            azimuth: number;
            color: import("@molstar/core/util/color/color").Color;
            intensity: number;
        }>[];
        ambientColor: import("@molstar/core/util/color/color").Color;
        ambientIntensity: number;
        enableAnimation: boolean;
    }>>;
    trackball: PD.Group<PD.Normalize<{
        rotateSpeed: number;
        zoomSpeed: number;
        panSpeed: number;
        moveSpeed: number;
        boostMoveFactor: number;
        flyMode: boolean;
        animate: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            speed: /*elided*/ any;
            axis: /*elided*/ any;
        }>, "spin"> | PD.NamedParams<PD.Normalize<{
            speed: /*elided*/ any;
            angle: /*elided*/ any;
            axis: /*elided*/ any;
        }>, "rock">;
        staticMoving: boolean;
        dynamicDampingFactor: number;
        minDistance: number;
        maxDistance: number;
        gestureScaleFactor: number;
        maxWheelDelta: number;
        autoAdjustMinMaxDistance: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            minDistanceFactor: /*elided*/ any;
            minDistancePadding: /*elided*/ any;
            maxDistanceFactor: /*elided*/ any;
            maxDistanceMin: /*elided*/ any;
        }>, "on">;
    }>>;
    interaction: PD.Group<PD.Normalize<{
        maxFps: number;
        preferAtomPixelPadding: number;
        convertCoordsToRay: boolean;
    }>>;
    handle: PD.Group<PD.Normalize<{
        handle: PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
            quality: /*elided*/ any;
            material: /*elided*/ any;
            clip: /*elided*/ any;
            emissive: /*elided*/ any;
            density: /*elided*/ any;
            instanceGranularity: /*elided*/ any;
            renderMerged: /*elided*/ any;
            lod: /*elided*/ any;
            cellSize: /*elided*/ any;
            batchSize: /*elided*/ any;
            doubleSided: /*elided*/ any;
            flipSided: /*elided*/ any;
            flatShaded: /*elided*/ any;
            celShaded: /*elided*/ any;
            xrayShaded: /*elided*/ any;
            transparentBackfaces: /*elided*/ any;
            solidInterior: /*elided*/ any;
            bumpFrequency: /*elided*/ any;
            bumpAmplitude: /*elided*/ any;
            interior: /*elided*/ any;
            animation: /*elided*/ any;
            alpha: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            colorX: /*elided*/ any;
            colorY: /*elided*/ any;
            colorZ: /*elided*/ any;
            scale: /*elided*/ any;
        }>, "on">;
    }>>;
    pointer: PD.Group<PD.Normalize<{
        alpha: number;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
        material: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        clip: PD.Normalize<{
            variant: /*elided*/ any;
            objects: /*elided*/ any;
        }>;
        emissive: number;
        density: number;
        instanceGranularity: import("../geo/geometry/base.js").InstanceGranularityValue;
        renderMerged: import("../geo/geometry/base.js").RenderMergedValue;
        lod: Vec3;
        cellSize: number;
        batchSize: number;
        doubleSided: boolean;
        flipSided: boolean;
        flatShaded: boolean;
        celShaded: boolean;
        xrayShaded: "inverted" | boolean;
        transparentBackfaces: "off" | "on" | "opaque";
        solidInterior: boolean;
        bumpFrequency: number;
        bumpAmplitude: number;
        interior: PD.Normalize<{
            color: /*elided*/ any;
            colorStrength: /*elided*/ any;
            substance: /*elided*/ any;
            substanceStrength: /*elided*/ any;
        }>;
        animation: PD.Normalize<{
            wiggleMode: /*elided*/ any;
            wiggleSpeed: /*elided*/ any;
            wiggleAmplitude: /*elided*/ any;
            wiggleFrequency: /*elided*/ any;
            tumbleSpeed: /*elided*/ any;
            tumbleAmplitude: /*elided*/ any;
            tumbleFrequency: /*elided*/ any;
        }>;
        enabled: "off" | "on";
        ignoreLight: boolean;
        color: import("@molstar/core/util/color/color").Color;
        hitColor: import("@molstar/core/util/color/color").Color;
    }>>;
    xr: PD.Group<PD.Normalize<{
        minTargetDistance: number;
        disablePostprocessing: boolean;
        resolutionScale: number;
        sceneRadiusInMeters: number;
    }>>;
}>;
export type Canvas3DProps = PD.Values<typeof Canvas3DParams>;
export type PartialCanvas3DProps = {
    [K in keyof Canvas3DProps]?: Canvas3DProps[K] extends {
        name: string;
        params: any;
    } ? Canvas3DProps[K] : Partial<Canvas3DProps[K]>;
};
export type Canvas3DPrepareOptions = {
    /** props other than the current ones, e.g. before setting them */
    props?: Partial<Canvas3DProps>;
    /** also what the first interaction draws: picking, and marking as if objects were marked */
    interaction?: boolean;
};
/** Props of frames `Canvas3D.precompile` prepares for, with the context's transparency mode (the current by default) */
export type Canvas3DPrecompileProps = Partial<Canvas3DProps> & {
    transparency?: TransparencyMode;
};
export declare const DefaultCanvas3DAttribs: {
    trackball: {
        bindings: {
            dragRotate: import("@molstar/core/util/binding").Binding;
            dragRotateZ: import("@molstar/core/util/binding").Binding;
            dragPan: import("@molstar/core/util/binding").Binding;
            dragZoom: import("@molstar/core/util/binding").Binding;
            dragFocus: import("@molstar/core/util/binding").Binding;
            dragFocusZoom: import("@molstar/core/util/binding").Binding;
            scrollZoom: import("@molstar/core/util/binding").Binding;
            scrollFocus: import("@molstar/core/util/binding").Binding;
            scrollFocusZoom: import("@molstar/core/util/binding").Binding;
            keyMoveForward: import("@molstar/core/util/binding").Binding;
            keyMoveBack: import("@molstar/core/util/binding").Binding;
            keyMoveLeft: import("@molstar/core/util/binding").Binding;
            keyMoveRight: import("@molstar/core/util/binding").Binding;
            keyMoveUp: import("@molstar/core/util/binding").Binding;
            keyMoveDown: import("@molstar/core/util/binding").Binding;
            keyRollLeft: import("@molstar/core/util/binding").Binding;
            keyRollRight: import("@molstar/core/util/binding").Binding;
            keyPitchUp: import("@molstar/core/util/binding").Binding;
            keyPitchDown: import("@molstar/core/util/binding").Binding;
            keyYawLeft: import("@molstar/core/util/binding").Binding;
            keyYawRight: import("@molstar/core/util/binding").Binding;
            boostMove: import("@molstar/core/util/binding").Binding;
            enablePointerLock: import("@molstar/core/util/binding").Binding;
        };
    };
    xr: {
        bindings: {
            exit: import("@molstar/core/util/binding").Binding;
            togglePassthrough: import("@molstar/core/util/binding").Binding;
            gestureScale: import("@molstar/core/util/binding").Binding;
        };
    };
    /**
     * prepare the frame and the first interaction (picking, marking) in idle time after the scene changed, so that the
     * first hover doesn't wait for compiling (`Canvas3D.prepare`)
     */
    warmUp: boolean;
};
export type Canvas3DAttribs = typeof DefaultCanvas3DAttribs;
export type PartialCanvas3DAttribs = {
    [K in keyof Canvas3DAttribs]?: Canvas3DAttribs[K] extends {
        name: string;
        params: any;
    } ? Canvas3DAttribs[K] : Partial<Canvas3DAttribs[K]>;
};
export { Canvas3DContext };
/** Can be used to create multiple Canvas3D objects */
interface Canvas3DContext {
    /** replaced by `setBackend` */
    readonly canvas?: HTMLCanvasElement;
    /** replaced by `setBackend` */
    readonly graphics: GraphicsContext;
    readonly input: InputObserver;
    /** replaced by `setBackend` */
    readonly passes: Passes;
    readonly attribs: Readonly<Canvas3DContext.Attribs>;
    readonly props: Readonly<Canvas3DContext.Props>;
    readonly contextLost?: Subject<now.Timestamp>;
    readonly contextRestored?: Subject<now.Timestamp>;
    /**
     * After `setBackend` replaced `graphics`, `canvas` and `passes`, while the previous context is still alive (it is
     * destroyed once the observers returned): consumers release what they created with it and create it again
     */
    readonly contextChanged?: Subject<Canvas3DContext.ContextChange>;
    readonly assetManager: AssetManager;
    readonly changed?: BehaviorSubject<undefined>;
    readonly pixelScale: number;
    syncPixelScale(): void;
    setProps: (props?: Partial<Canvas3DContext.Props>) => void;
    /**
     * Replaces the graphics context with that of the first of `backends` that can be created, on a new canvas element
     * taking the place of the current one (a canvas keeps the context type it gave out first), see `contextChanged`.
     * Resolves to false, keeping the current context, if none can be created, while presenting XR, without a canvas in
     * a document or while another change is in progress. While released (`release`), the backends are kept for `restore`,
     * which creates the context from them (resolves to true then, the canvas stays released).
     */
    setBackend?: (backends: readonly GraphicsBackendDescriptor[]) => Promise<boolean>;
    /**
     * Releases the graphics context on purpose, freeing its GPU resources (`GraphicsContext.release`, e.g. a canvas out of
     * view): reported as a loss (`contextLost`), but not restored until `restore`. False where it can't (see
     * `GraphicsContext.release`), while presenting XR or changing the backend.
     */
    release?: () => boolean;
    /**
     * Restores a released context (`release`) as after a loss, once the loss was reported (`contextLost`): resolves to
     * whether it was restored (`contextRestored`)
     */
    restore?: () => Promise<boolean>;
    /** Released (`release`) and not restored yet */
    readonly isReleased?: boolean;
    dispose: (options?: GraphicsDestroyOptions) => void;
}
declare namespace Canvas3DContext {
    const DefaultAttribs: {
        powerPreference: WebGLContextAttributes['powerPreference'];
        failIfMajorPerformanceCaveat: boolean;
        /** true by default to avoid issues with Safari (Jan 2021) */
        antialias: boolean;
        /** true to support multiple Canvas3D objects with a single context */
        preserveDrawingBuffer: boolean;
        preferWebGl1: boolean;
        /**
         * Falls back to the next of the backends the context was created from when the context is lost for good (not
         * restored within `ContextRestoreTimeoutMs` while the page is visible, a restore that failed, or more than
         * `MaxContextLosses` losses within `ContextLossWindowMs`); each backend at most once, never back up the list
         */
        contextFallback: boolean;
        handleResize: () => void;
    };
    type Attribs = typeof DefaultAttribs;
    const Params: {
        resolutionMode: PD.Select<"auto" | "native" | "scaled">;
        pixelScale: PD.Numeric;
        pickScale: PD.Numeric;
        transparency: PD.Select<"blended" | "dpoit" | "wboit">;
    };
    const DefaultProps: PD.Values<{
        resolutionMode: PD.Select<"auto" | "native" | "scaled">;
        pixelScale: PD.Numeric;
        pickScale: PD.Numeric;
        transparency: PD.Select<"blended" | "dpoit" | "wboit">;
    }>;
    type Props = PD.Values<typeof Params>;
    interface ContextChange {
        readonly previous: GraphicsContext;
        /**
         * `switch`: `setBackend`; `fallback`: the previous context was lost for good (see `Attribs.contextFallback`);
         * `restore`: the previous context was lost and is replaced by a new one on the same canvas (`GraphicsContext.recreate`)
         */
        readonly reason: 'switch' | 'fallback' | 'restore';
    }
    /** time a lost context has to be restored while the page is visible, before falling back */
    const ContextRestoreTimeoutMs = 3000;
    /** losses within `ContextLossWindowMs` beyond which the context counts as lost for good, even if restored */
    const MaxContextLosses = 3;
    const ContextLossWindowMs = 60000;
    /** The pixel scale of the drawing buffer for `p`, see `resolutionMode` */
    function getPixelScale(p: Props): number;
    /**
     * Creates the graphics context with the first available of `backends`, e.g.
     * `[WebGPUBackend, WebGL2Backend, WebGLBackend]`, see `createGraphicsContext`
     */
    function create(canvas: HTMLCanvasElement, assetManager: AssetManager, backends: readonly GraphicsBackendDescriptor[], attribs?: Partial<Attribs>, props?: Partial<Props>): Promise<Canvas3DContext>;
    /**
     * The context for `graphics`, a context created on `canvas` (e.g. by a backend descriptor, see `create`, or the WebGL
     * convenience `createWebGLCanvas3DContext` of `@molstar/graphics/canvas3d/webgl`); `backends`, the list it was
     * created from, for falling back when it is lost for good (see `Attribs.contextFallback`)
     */
    function fromGraphics(_canvas: HTMLCanvasElement, _graphics: GraphicsContext, assetManager: AssetManager, attribs?: Partial<Attribs>, props?: Partial<Props>, backends?: readonly GraphicsBackendDescriptor[]): Canvas3DContext;
}
export { Canvas3D };
export interface Canvas3DCameraResetOptions {
    durationMs?: number;
    snapshot?: Camera.SnapshotProvider;
    keyframes?: CameraTransitionManager.TransitionKeyframes;
    easing?: EasingFunction;
    trajectory?: TransitionTrajectory;
}
interface Canvas3D {
    /** replaced when the context's backend changes, see `contextChanged` */
    readonly graphics: GraphicsContext;
    /**
     * After the graphics context changed (`Canvas3DContext.setBackend`) and the scene was rebuilt on it: render objects
     * are drawn again as they are (textures loaded from data transferred), representations create and update visuals
     * with the new context (`Representation.setGraphics`) and are updated, which creates again what was rendered or
     * computed with the previous context (e.g. GPU surfaces) and geometry relying on what the new context lacks; image
     * passes (`getImagePass`) follow. Render objects of no representation that hold such textures are not drawn anymore
     * (`dropped`).
     */
    readonly contextChanged: Subject<Canvas3D.ContextChange>;
    add(repr: Representation.Any): void;
    remove(repr: Representation.Any): void;
    /**
     * This function must be called if animate() is not set up so that add/remove actions take place.
     */
    commit(isSynchronous?: boolean): void;
    /**
     * Function for external "animation" control
     * Calls commit.
     */
    tick(t: now.Timestamp, options?: {
        isSynchronous?: boolean;
        manualDraw?: boolean;
        updateControls?: boolean;
        xrFrame?: XRFrame;
    }): void;
    update(repr?: Representation.Any, keepBoundingSphere?: boolean): void;
    clear(): void;
    syncVisibility(): void;
    requestDraw(): void;
    /**
     * Makes the pipelines and resources frames with the props draw ready without drawing anything (see `PassBuilder`);
     * resolves when they are
     */
    prepare(options?: Canvas3DPrepareOptions): Promise<void>;
    /**
     * Makes the programs and pipelines ready that frames with each of `props` (the current ones by default) draw the
     * objects of `list` with, before the objects exist (e.g. the snapshots of a state, before they are applied), including
     * the first interaction; as this device draws them (e.g. blended transparency where the props' mode is not supported).
     * The programs are kept until the next call; entries of unknown kinds are skipped. Resolves when they are ready
     */
    precompile(list: PrecompileList, props?: readonly Canvas3DPrecompileProps[]): Promise<void>;
    /** The objects drawn since the last reset (`resetPrecompileList`), as signatures, see `precompile` */
    getPrecompileList(): PrecompileList;
    resetPrecompileList(): void;
    /**
     * Whether the last tick found nothing to do: nothing drawn or committed, and nothing under way that needs the next
     * tick (a camera transition, the controls' animation or keys, an interaction, a hover pick, a hi-Z readback). A loop
     * may stop asking for frames while it stays idle (`PluginAnimationLoop`, `PluginConfig.General.PauseLoopWhenIdle`)
     * and ask again on `wake`. Code that changes the scene or the camera past this API must call `requestDraw`.
     */
    readonly isIdle: boolean;
    /** Fires once after an idle tick when something gives the next tick work: a draw requested, input, a scene, camera or props change. */
    readonly wake: Observable<void>;
    /** Reset the timers, used by "animate" */
    resetTime(t: number): void;
    animate(): void;
    /**
     * Pause animation loop and optionally any rendering
     * @param noDraw pause any rendering (drawPaused = true)
     */
    pause(noDraw?: boolean): void;
    /** Sets drawPaused = false without starting the built in animation loop */
    resume(): void;
    requestAnimationFrame(callback: FrameRequestCallback | XRFrameRequestCallback): number;
    cancelAnimationFrame(handle: number): void;
    /**
     * The pick data at `target`, `undefined` if nothing is there. Read in the same call where the backend reads
     * synchronously (WebGL); elsewhere (WebGPU) `'pending'` until a read started for the current scene and camera has
     * returned: `asyncIdentify(target)?.wait()` resolves then
     */
    identify(target: Vec2 | Ray3D): PickResult;
    /**
     * Starts reading the pick data at `target`, on every backend: poll the result with `tryGet` (e.g. per frame, as hover
     * and clicks do) or await it with `wait`
     */
    asyncIdentify(target: Vec2 | Ray3D): AsyncPickData | undefined;
    mark(loci: Representation.Loci, action: MarkerAction): void;
    getLoci(pickingId: PickingId | undefined): Representation.Loci;
    notifyDidDraw: boolean;
    readonly didDraw: BehaviorSubject<now.Timestamp>;
    readonly commited: BehaviorSubject<now.Timestamp>;
    readonly commitQueueSize: BehaviorSubject<number>;
    readonly reprCount: BehaviorSubject<number>;
    readonly resized: BehaviorSubject<any>;
    handleResize(): void;
    /** performs handleResize on the next animation frame */
    requestResize(): void;
    /** Focuses camera on scene's bounding sphere, centered and zoomed. */
    requestCameraReset(options?: Canvas3DCameraResetOptions): void;
    readonly camera: Camera;
    readonly boundingSphere: Readonly<Sphere3D>;
    readonly boundingSphereVisible: Readonly<Sphere3D>;
    setProps(props: PartialCanvas3DProps | ((old: Canvas3DProps) => Partial<Canvas3DProps> | void), doNotRequestDraw?: boolean): void;
    setAttribs(attribs: PartialCanvas3DAttribs): void;
    getImagePass(props: Partial<ImageProps>): ImagePass;
    getRenderObjects(): GraphicsRenderObject[];
    /** Returns a copy of the current Canvas3D instance props */
    readonly props: Readonly<Canvas3DProps>;
    readonly attribs: Readonly<Canvas3DAttribs>;
    readonly input: InputObserver;
    readonly stats: RendererStats;
    readonly interaction: Canvas3dInteractionHelper['events'];
    readonly debugRegistry: DebugRegistry;
    readonly xr: {
        request(): Promise<void>;
        end(): Promise<void>;
        readonly isSupported: BehaviorSubject<boolean>;
        readonly isPresenting: BehaviorSubject<boolean>;
        readonly requestFailed: Subject<string>;
    };
    dispose(): void;
}
declare namespace Canvas3D {
    interface ContextChange {
        readonly dropped: readonly GraphicsRenderObject[];
        /** `switch` (`Canvas3DContext.setBackend`) or `fallback` (the previous context was lost for good) */
        readonly reason: Canvas3DContext.ContextChange['reason'];
    }
    interface HoverEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        page?: Vec2;
        position?: Vec3;
    }
    interface DragEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        pageStart: Vec2;
        pageEnd: Vec2;
    }
    interface ClickEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        page?: Vec2;
        position?: Vec3;
    }
    function create(ctx: Canvas3DContext, props?: Partial<Canvas3DProps>, attribs?: Partial<Canvas3DAttribs>): Canvas3D;
}
//# sourceMappingURL=canvas3d.d.ts.map