/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { AttributeKind, AttributeItemSize } from './buffer.js';
import type { RenderableSchema } from './renderable/schema.js';
/**
 * Backend-neutral attribute locations of a schema. Locations are fixed per schema, so they
 * are the same for all programs (variants) of a render item. They become explicit
 * `@location`s / vertex buffer layouts on WebGPU.
 */
export type AttributeLayoutEntry = {
    readonly name: string;
    readonly kind: AttributeKind;
    readonly itemSize: AttributeItemSize;
    readonly divisor: number;
    readonly location: number;
    /** 4 for `mat4` (one per column), 1 otherwise */
    readonly locationCount: number;
};
export interface AttributeLayout {
    readonly entries: readonly AttributeLayoutEntry[];
    readonly byName: {
        readonly [k: string]: AttributeLayoutEntry;
    };
    /** number of locations used */
    readonly size: number;
    readonly hash: string;
}
/**
 * Locations in schema order, except that location 0 goes to the first per-vertex attribute
 * without `usedIf` (or else to the first attribute without `usedIf`): some drivers emulate
 * a disabled or instanced attribute 0.
 */
export declare function getAttributeLayout(schema: RenderableSchema): AttributeLayout;
//# sourceMappingURL=attribute-layout.d.ts.map