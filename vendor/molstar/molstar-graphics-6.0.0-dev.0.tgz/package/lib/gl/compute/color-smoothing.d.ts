/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Vec3 } from '@molstar/core/math/linear-algebra';
import { type ComputeContext, KernelCode, type KernelRequest, type StorageBuffer, StorageBufferSpec, StorageTextureSpec } from '../compute.js';
import type { GraphicsContext } from '../context.js';
import { DefineSpec, TextureSpec, UniformSpec } from '../renderable/schema.js';
import type { Texture } from '../texture.js';
/**
 * Color smoothing of texture meshes in the vertex arena (see `computeChunkedIsosurface`) with compute kernels: the
 * colors of sampled vertices, read through the page table, are accumulated into the cells
 * of a grid, weighted by distance (`color-smoothing-accumulate`, fixed-point atomic sums), then normalized into the 2d
 * atlas of the grid (`color-smoothing-normalize`), as the point sprite accumulation on WebGL. Grids whose sums exceed
 * the storage buffer limit are processed in slabs of slices.
 */
export declare const ColorAccumulateKernel: KernelCode;
export declare const ColorNormalizeKernel: KernelCode;
export declare const ColorAccumulateSchema: {
    /** an upper bound of the vertex count, the drawn count is in the page table */
    uVertexCount: UniformSpec<"i">;
    uSampleCount: UniformSpec<"i">;
    uInstanceCount: UniformSpec<"i">;
    uStride: UniformSpec<"i">;
    uGroupCount: UniformSpec<"i">;
    uGridDim: UniformSpec<"iv3">;
    /** first slice and slice count of the slab */
    uSlab: UniformSpec<"iv2">;
    uBboxMin: UniformSpec<"v3">;
    uBboxSize: UniformSpec<"v3">;
    uResolution: UniformSpec<"f">;
    tColor: TextureSpec<"texture">;
    dColorType: DefineSpec<"string">;
    isoTable: StorageBufferSpec;
    isoPositions: StorageBufferSpec;
    transforms: StorageBufferSpec;
    instances: StorageBufferSpec;
    sums: StorageBufferSpec;
};
/** The kernels of `computeColorSmoothing` for `colorType`, see `ComputeContext.prepareKernels` */
export declare function getColorSmoothingKernels(colorType: 'group' | 'groupInstance'): KernelRequest[];
export declare const ColorNormalizeSchema: {
    uGridDim: UniformSpec<"iv3">;
    uSlab: UniformSpec<"iv2">;
    uTexCols: UniformSpec<"i">;
    sums: StorageBufferSpec;
    outColor: StorageTextureSpec;
};
export declare function isComputeColorSmoothingSupported(graphics: GraphicsContext): graphics is GraphicsContext & {
    compute: ComputeContext;
};
export interface ColorSmoothingSamples {
    /** an upper bound, the drawn count is in the page table */
    vertexCount: number;
    /** every `stride`-th vertex is sampled */
    stride: number;
    instanceCount: number;
    groupCount: number;
    transformBuffer: Float32Array;
    instanceBuffer: Float32Array;
    /** the page table and positions of the surface in the vertex arena */
    chunks: {
        table: StorageBuffer;
        positions: StorageBuffer;
    };
    colorData: Texture;
    colorType: 'group' | 'groupInstance';
}
export interface ColorSmoothingGrid {
    gridDim: Vec3;
    /** slices per row of the atlas */
    texCols: number;
    /** size of the atlas, `texCols` × `gridDim[0]` wide */
    width: number;
    height: number;
    bboxMin: Vec3;
    bboxSize: Vec3;
    resolution: number;
}
/** Writes the smoothed colors of `samples` on `grid` into the rgba `texture` (defined to the atlas size) */
export declare function computeColorSmoothing(compute: ComputeContext, samples: ColorSmoothingSamples, grid: ColorSmoothingGrid, texture: Texture): void;
//# sourceMappingURL=color-smoothing.d.ts.map