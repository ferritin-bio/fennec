/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Box3D } from '@molstar/core/math/geometry';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { type ComputeContext, KernelCode, type KernelRequest, StorageBufferSpec, StorageTextureSpec } from '../compute.js';
import type { GraphicsContext } from '../context.js';
import { UniformSpec } from '../renderable/schema.js';
import type { Texture } from '../texture.js';
/**
 * The Gaussian density of atoms into a 3d texture with compute kernels, as the splatting into its slices on WebGL: per
 * atom the cells of its quad in each slice near the atom, the density summed (fixed-point atomics) and the nearness of
 * the nearest atom (`gd-accumulate`), then the group of the nearest atom (`gd-group`), written as rgb (packed group)
 * and alpha (density) into the texture (`gd-write`). Grids whose cells exceed the storage buffer limit are processed in
 * slabs of slices.
 */
export declare const GdAccumulateKernel: KernelCode;
export declare const GdGroupKernel: KernelCode;
export declare const GdWriteKernel: KernelCode;
export declare const GdAccumulateSchema: {
    uGridDim: UniformSpec<"iv3">;
    /** first slice and slice count of the slab */
    uSlab: UniformSpec<"iv2">;
    uAtomCount: UniformSpec<"i">;
    /** cells per side of the largest quad */
    uFootprint: UniformSpec<"i">;
    uBboxMin: UniformSpec<"v3">;
    uBboxSize: UniformSpec<"v3">;
    uResolution: UniformSpec<"f">;
    uRadiusFactorInv: UniformSpec<"f">;
    /** slices above and below an atom with a contribution */
    uZRange: UniformSpec<"f">;
    /** position and radius */
    atoms: StorageBufferSpec;
    uAlpha: UniformSpec<"f">;
    density: StorageBufferSpec;
    nearness: StorageBufferSpec;
};
export declare const GdGroupSchema: {
    uGridDim: UniformSpec<"iv3">;
    /** first slice and slice count of the slab */
    uSlab: UniformSpec<"iv2">;
    uAtomCount: UniformSpec<"i">;
    /** cells per side of the largest quad */
    uFootprint: UniformSpec<"i">;
    uBboxMin: UniformSpec<"v3">;
    uBboxSize: UniformSpec<"v3">;
    uResolution: UniformSpec<"f">;
    uRadiusFactorInv: UniformSpec<"f">;
    /** slices above and below an atom with a contribution */
    uZRange: UniformSpec<"f">;
    /** position and radius */
    atoms: StorageBufferSpec;
    nearness: StorageBufferSpec;
    winner: StorageBufferSpec;
};
export declare const GdWriteSchema: {
    uGridDim: UniformSpec<"iv3">;
    /** first slice and slice count of the slab */
    uSlab: UniformSpec<"iv2">;
    density: StorageBufferSpec;
    winner: StorageBufferSpec;
    groups: StorageBufferSpec;
    outDensity: StorageTextureSpec;
};
export declare function isComputeGaussianDensitySupported(graphics: GraphicsContext): graphics is GraphicsContext & {
    compute: ComputeContext;
};
export interface GaussianDensityAtoms {
    count: number;
    /** xyz per atom */
    positions: Float32Array;
    radii: Float32Array;
    groups: Float32Array;
    maxRadius: number;
}
export interface GaussianDensityGrid {
    box: Box3D;
    dim: Vec3;
    resolution: number;
    /** `alpha` of the Gaussian */
    smoothness: number;
    radiusFactor: number;
}
/** The kernels of `computeGaussianDensity`, see `ComputeContext.prepareKernels` */
export declare const GaussianDensityKernels: readonly KernelRequest[];
/**
 * Writes the density of `atoms` on `grid` into the rgba fp16 3d `texture`, defined to the grid size; with `growTexture`
 * only grown (a texture shared by grids of varying size, read by grid coordinates: the cells beyond the grid are left
 * as they were)
 */
export declare function computeGaussianDensity(compute: ComputeContext, atoms: GaussianDensityAtoms, grid: GaussianDensityGrid, texture: Texture, options?: {
    growTexture?: boolean;
}): void;
//# sourceMappingURL=gaussian-density.d.ts.map