/**
 * Copyright (c) 2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsContext } from '../context.js';
import { type ComputeRenderable } from '../renderable.js';
import { TextureSpec, UniformSpec, type Values } from '../renderable/schema.js';
import { ShaderCode } from '../shader-code.js';
import type { Texture } from '../texture.js';
export declare const HiZSchema: {
    drawCount: import("../renderable/schema.js").ValueSpec<"number">;
    instanceCount: import("../renderable/schema.js").ValueSpec<"number">;
    aPosition: import("../renderable/schema.js").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tPreviousLevel: TextureSpec<"texture">;
    uInvSize: UniformSpec<"v2">;
    /** the region of the previous level sampled, in uv (`xy` its corner, `zw` its extent) */
    uRect: {
        type: 'uniform';
        kind: "v4";
        variant?: "buffered" | "material";
        block?: import("../renderable/schema.js").UniformScope;
        length?: number;
        lengthDefine?: string;
        loopBound?: boolean;
        depthRange?: import("../depth-range.js").DepthRangeTag;
        windowRect: 'rect';
    };
    /** size of the level rendered */
    uTexSize: UniformSpec<"v2">;
};
export declare const HiZShaderCode: ShaderCode;
export type HiZRenderable = ComputeRenderable<Values<typeof HiZSchema>>;
export declare function createHiZRenderable(ctx: GraphicsContext, previousLevel: Texture): HiZRenderable;
//# sourceMappingURL=hi-z.d.ts.map