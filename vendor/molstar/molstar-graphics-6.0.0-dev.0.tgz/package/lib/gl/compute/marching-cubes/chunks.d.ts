/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Mat4, type Vec3 } from '@molstar/core/math/linear-algebra';
import { ValueCell } from '@molstar/core/util';
import type { ComputeContext, DrawIndirect, StorageBuffer } from '../../compute.js';
import { type IsosurfaceInput } from './compute.js';
import type { GraphicsTimer } from '../../timer.js';
/** The pages of the chunked surfaces of a context */
export interface VertexArena {
    /** `vec4<f32>` per vertex: the position, the group's packed rgba bits in `w` */
    readonly positions: ValueCell<StorageBuffer>;
    /** `vec2<u32>` per vertex: the normal as snorm16 (`pack2x16snorm` of xy and of z) */
    readonly normals: ValueCell<StorageBuffer>;
    /** the free page stack: its size, then the page ids */
    free: StorageBuffer;
    pageCount: number;
    /** free pages at the last readback */
    freeRead: number;
    /** pages extractions since that readback may take */
    reserved: number;
    /** called after the arena grew (its buffers replaced), see `onVertexArenaGrow` */
    readonly listeners: Set<() => void>;
}
/** The vertex arena of `compute`, created with `InitialPages` */
export declare function getVertexArena(compute: ComputeContext): VertexArena;
/** Free pages to expect: at the last readback, minus those reserved since */
export declare function getAvailablePages(arena: VertexArena): number;
/**
 * Grows the arena by at least `pages` (by `GrowthFactor` at least, up to the storage buffer limit): new buffers with
 * the contents of the old ones (page ids stay valid), the new pages pushed onto the free stack; returns whether it grew
 */
export declare function growVertexArena(compute: ComputeContext, arena: VertexArena, pages: number): boolean;
/** Calls `listener` whenever the arena of `compute` grew (e.g. to bind its new buffers); returns the unsubscribe */
export declare function onVertexArenaGrow(compute: ComputeContext, listener: () => void): () => void;
/** A surface in the arena: its page table and draw arguments */
export interface ChunkedSurface {
    /** the counts (`TableHeader` words), then the page ids */
    table: StorageBuffer;
    /**
     * tables the surface grew out of: what draws the surface may still bind one, released when it binds the current
     * table (`releaseRetiredTables`)
     */
    readonly retired: StorageBuffer[];
    readonly drawArgs: StorageBuffer;
    /** pages of the surface at its last readback */
    pages: number;
}
/** Destroys the tables `surface` grew out of, once what draws it binds the current one */
export declare function releaseRetiredTables(surface: ChunkedSurface): void;
/** The state of a surface after an extraction, read back */
export interface ChunkedSurfaceCount {
    /** the vertex count of the surface (more than drawn when it did not get the pages it needed) */
    readonly count: number;
    readonly drawn: number;
    readonly pages: number;
    /** pages missing, 0 if the surface got all it needed */
    readonly missingPages: number;
}
export interface ChunkedIsosurfaceResult {
    readonly surface: ChunkedSurface;
    readonly drawIndirect: DrawIndirect;
    /** the state after the extraction, read back (not needed to draw it) */
    readonly count: Promise<ChunkedSurfaceCount>;
}
/**
 * Extracts the isosurface of `input` into the arena (`surface` reuses its pages and draw arguments); `estimate`, the
 * expected vertex count, grows the arena beforehand when its free pages may not cover it
 */
export declare function computeChunkedIsosurface(compute: ComputeContext, input: IsosurfaceInput, gridDim: Vec3, isoValue: number, transform: Mat4, invert: boolean, surface?: ChunkedSurface, estimate?: number, 
/** times the extraction's passes (timing mode) */
timer?: GraphicsTimer): Promise<ChunkedIsosurfaceResult>;
/** Returns the pages of `surface` to the arena and destroys its buffers */
export declare function destroyChunkedSurface(compute: ComputeContext, surface: ChunkedSurface): void;
/**
 * The first `count` vertices of the surface of `table`, gathered from its pages and read back: positions (`w` 1),
 * normals and groups (packed rgba bytes) per vertex, as the texture readback of a texture mesh gives them
 */
export declare function readChunkedVertices(compute: ComputeContext, table: StorageBuffer, count: number): Promise<{
    vertices: Float32Array<ArrayBuffer>;
    normals: Float32Array<ArrayBuffer>;
    groups: Uint8Array<ArrayBuffer>;
    vertexCount: number;
}>;
/** Bytes of `pages` pages of the arena */
export declare function getChunkByteCount(pages: number): number;
/** The arena of `compute`, if created: its pages, the free ones at the last readback, and their bytes */
export declare function getVertexArenaStats(compute: ComputeContext): {
    pages: number;
    usedPages: number;
    byteCount: number;
    usedByteCount: number;
} | undefined;
/** Pages a surface of `vertexCount` vertices takes */
export declare function getChunkPages(vertexCount: number): number;
//# sourceMappingURL=chunks.d.ts.map