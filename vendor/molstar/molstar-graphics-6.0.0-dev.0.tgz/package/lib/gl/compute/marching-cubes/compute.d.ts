/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { ValueCell } from '@molstar/core/util';
import { type ComputeContext, KernelCode, type KernelRequest, type StorageBuffer, StorageBufferSpec } from '../../compute.js';
import type { GraphicsContext } from '../../context.js';
import { DefineSpec, TextureSpec, UniformSpec } from '../../renderable/schema.js';
import type { Texture } from '../../texture.js';
/**
 * Marching cubes with compute kernels, into chunks of a vertex arena (`computeChunkedIsosurface`): the inputs, the
 * kernels and the tables they share. Results follow the WebGL isosurface: positions and normals in the space of the
 * transform, groups constant per triangle.
 */
export declare const WorkgroupSize: [number, number, number];
export declare const McChunkCountKernel: KernelCode;
export declare const McChunkEmitKernel: KernelCode;
export declare const McChunkAllocateKernel: KernelCode;
export declare const McChunkFreeKernel: KernelCode;
export declare const McChunkPushKernel: KernelCode;
/** Volume data in a storage buffer of f32, cell `(x, y, z)` at `dot((x, y, z), uStrides)`; groups are the data index */
export declare const McBufferInput: {
    uGridDim: UniformSpec<"iv3">;
    uIsoValue: UniformSpec<"f">;
    uStrides: UniformSpec<"iv3">;
    /** points of the data per axis: grid positions past them wrap (periodic volumes, the grid one point larger) */
    uDataDim: UniformSpec<"iv3">;
    volume: StorageBufferSpec;
    dInput: DefineSpec<"string">;
};
/** Volume data in a 3d texture, the value in `dChannel`; with `dPackedGroup`, the group packed in rgb */
export declare const McTextureInput: {
    uGridDim: UniformSpec<"iv3">;
    uIsoValue: UniformSpec<"f">;
    tVolume: TextureSpec<"texture">;
    dInput: DefineSpec<"string">;
    dChannel: DefineSpec<"string">;
    dPackedGroup: DefineSpec<"boolean">;
};
export declare const McChunkCountOutput: {
    triCounts: StorageBufferSpec;
    table: StorageBufferSpec;
    bases: StorageBufferSpec;
};
export declare const McChunkAllocateSchema: {
    table: StorageBufferSpec;
    free: StorageBufferSpec;
    drawArgs: StorageBufferSpec;
};
export declare const McChunkEmitOutput: {
    uInvert: UniformSpec<"b">;
    uTransform: UniformSpec<"m4">;
    uTransformAdjoint: UniformSpec<"m3">;
    triCounts: StorageBufferSpec;
    triTable: StorageBufferSpec;
    bases: StorageBufferSpec;
    table: StorageBufferSpec;
    positions: StorageBufferSpec;
    normals: StorageBufferSpec;
};
export declare const McChunkFreeSchema: {
    table: StorageBufferSpec;
    free: StorageBufferSpec;
};
export declare const McChunkPushSchema: {
    uFirst: UniformSpec<"i">;
    uCount: UniformSpec<"i">;
    free: StorageBufferSpec;
};
export type IsosurfaceInput = {
    readonly kind: 'buffer';
    /** f32 values */
    readonly volume: StorageBuffer;
    /** data offset per axis step */
    readonly strides: Vec3;
    /** the data's points per axis where the grid wraps around them (one point more per axis); the grid's by default */
    readonly dataDim?: Vec3;
} | {
    readonly kind: 'texture';
    /** a 3d texture */
    readonly texture: Texture;
    readonly channel: 'red' | 'alpha';
    readonly packedGroup: boolean;
};
export declare function isComputeIsosurfaceSupported(graphics: GraphicsContext): graphics is GraphicsContext & {
    compute: ComputeContext;
};
type Shared = {
    triCounts: StorageBuffer;
    triTable: StorageBuffer;
};
/** The marching cubes tables per context */
export declare function getShared(compute: ComputeContext): Shared;
/** What selects the kernels of an input: its kind and how its values are read */
export type IsosurfaceInputKind = {
    readonly kind: 'buffer';
} | {
    readonly kind: 'texture';
    readonly channel: 'red' | 'alpha';
    readonly packedGroup: boolean;
};
export declare function getInputKernelSchema(input: IsosurfaceInputKind): {
    schema: typeof McBufferInput | typeof McTextureInput;
    defines: {
        [k: string]: string | boolean;
    };
};
export declare function getInputValues(input: IsosurfaceInput, gridDim: Vec3, isoValue: number): {
    schema: {
        uGridDim: UniformSpec<"iv3">;
        uIsoValue: UniformSpec<"f">;
        uStrides: UniformSpec<"iv3">;
        /** points of the data per axis: grid positions past them wrap (periodic volumes, the grid one point larger) */
        uDataDim: UniformSpec<"iv3">;
        volume: StorageBufferSpec;
        dInput: DefineSpec<"string">;
    } | {
        uGridDim: UniformSpec<"iv3">;
        uIsoValue: UniformSpec<"f">;
        tVolume: TextureSpec<"texture">;
        dInput: DefineSpec<"string">;
        dChannel: DefineSpec<"string">;
        dPackedGroup: DefineSpec<"boolean">;
    };
    values: {
        uGridDim: ValueCell<Vec3, never>;
        uIsoValue: ValueCell<number, never>;
        uStrides: ValueCell<Vec3, never>;
        uDataDim: ValueCell<Vec3, never>;
        volume: ValueCell<StorageBuffer, never>;
    };
} | {
    schema: {
        uGridDim: UniformSpec<"iv3">;
        uIsoValue: UniformSpec<"f">;
        uStrides: UniformSpec<"iv3">;
        /** points of the data per axis: grid positions past them wrap (periodic volumes, the grid one point larger) */
        uDataDim: UniformSpec<"iv3">;
        volume: StorageBufferSpec;
        dInput: DefineSpec<"string">;
    } | {
        uGridDim: UniformSpec<"iv3">;
        uIsoValue: UniformSpec<"f">;
        tVolume: TextureSpec<"texture">;
        dInput: DefineSpec<"string">;
        dChannel: DefineSpec<"string">;
        dPackedGroup: DefineSpec<"boolean">;
    };
    values: {
        uGridDim: ValueCell<Vec3, never>;
        uIsoValue: ValueCell<number, never>;
        tVolume: ValueCell<Texture, never>;
    };
};
/** The kernels of `computeChunkedIsosurface` for `input`, see `ComputeContext.prepareKernels` */
export declare function getIsosurfaceKernels(input: IsosurfaceInputKind): KernelRequest[];
export {};
//# sourceMappingURL=compute.d.ts.map