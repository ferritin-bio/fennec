/**
 * Copyright (c) 2020-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type RegularGrid3d } from '@molstar/core/math/geometry/common';
import type { RuntimeContext } from '@molstar/core/task';
import type { GraphicsContext } from '../context.js';
import { type RenderableSchema, type UnboxedValues, type Values } from '../renderable/schema.js';
/**
 * Whether `computable` (from `createGrid3dComputeRenderable`) runs on the GPU of `graphics`: compute kernels for specs
 * with WGSL code, or fragment shaders (WebGL); without `computable`, whether fragment shaders are available
 */
export declare function canComputeGrid3dOnGPU(graphics?: GraphicsContext, computable?: Grid3dComputable<any>): boolean;
/** The computation of a spec with fragment shaders */
export type Grid3dFragmentCompute<P> = (ctx: RuntimeContext, graphics: GraphicsContext, grid: RegularGrid3d, params: P) => Promise<Float32Array>;
/** grid3d with fragment shaders, an implementation a backend registers (WebGL, `gl/webgl/compute/grid3d`) */
export interface Grid3dFragmentImplementation {
    /** whether it runs on `graphics` (its backend) */
    isSupported(graphics: GraphicsContext): boolean;
    create<S extends RenderableSchema, P, CS>(id: string, spec: Grid3DComputeRenderableSpec<S, P, CS>): Grid3dFragmentCompute<P>;
}
/** Called by backends that implement it, when they create a context */
export declare function registerGrid3dFragmentImplementation(implementation: Grid3dFragmentImplementation): void;
/** Computes the grid values (axis order fast to slow z, y, x) */
export interface Grid3dComputable<P> {
    (ctx: RuntimeContext, graphics: GraphicsContext, grid: RegularGrid3d, params: P): Promise<Float32Array>;
    isSupported(graphics: GraphicsContext): boolean;
}
export interface Grid3DComputeRenderableSpec<S extends RenderableSchema, P, CS> {
    schema: S;
    loopBounds?: (keyof S)[];
    utilCode?: string;
    mainCode: string;
    returnCode: string;
    /**
     * The code in WGSL, for compute kernels (WebGPU): uniforms are `uParams.<name>`, textures are read with `textureLoad`,
     * `xyz` is the cell position and `current` the accumulated value (cumulative)
     */
    wgsl?: {
        utilCode?: string;
        mainCode: string;
        returnCode: string;
    };
    values(params: P, grid: RegularGrid3d): UnboxedValues<S>;
    cumulative?: {
        states(params: P): CS[];
        update(params: P, state: CS, values: Values<S>): void;
        yieldPeriod?: number;
    };
}
export declare function createGrid3dComputeRenderable<S extends RenderableSchema, P, CS>(spec: Grid3DComputeRenderableSpec<S, P, CS>): Grid3dComputable<P>;
//# sourceMappingURL=grid3d.d.ts.map