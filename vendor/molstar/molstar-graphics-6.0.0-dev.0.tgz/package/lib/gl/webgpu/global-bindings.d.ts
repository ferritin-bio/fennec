/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GlobalBindings } from '../render-item.js';
import type { RenderableSchema } from '../renderable/schema.js';
import type { Textures } from '../texture.js';
import type { UniformsList } from '../uniform.js';
import { type TextureBinding } from '../uniform-layout.js';
import type { WebGPUProgram } from './program.js';
import { type Release } from './texture.js';
import { type UniformRing } from './uniform-ring.js';
import { type WgslSampler } from './wgsl-declarations.js';
export interface WebGPUBindingContext {
    readonly device: GPUDevice;
    readonly release: Release;
    readonly ring: UniformRing;
    /**
     * The ring of the global blocks only: their snapshots of a submission take offsets in the order the frame's passes
     * change the globals, so a frame of the same passes binds the same offsets (what a recorded pass relies on), whatever
     * other blocks and compute kernels write in between
     */
    readonly globalRing: UniformRing;
    readonly samplers: {
        readonly [k in WgslSampler]: GPUSampler;
    };
}
export interface WebGPUGlobalBindings extends GlobalBindings {
    /** 'draw' uniforms of the global schema, written per draw by the render items */
    readonly drawUniforms: UniformsList;
    /** bind group 0 for `program` and its dynamic offset */
    getBindGroup: (program: WebGPUProgram) => {
        group: GPUBindGroup;
        offset: number;
    };
}
export declare function asWebGPUGlobalBindings(globals: GlobalBindings): WebGPUGlobalBindings;
/**
 * Entries for the textures of `bindings` (from the layout); textures that are not set or have no storage get a
 * placeholder
 */
export declare function getTextureEntries(device: GPUDevice, textures: Textures, bindings: readonly TextureBinding[], referenced: ReadonlySet<string>): {
    entries: GPUBindGroupEntry[];
    key: string;
};
export declare function createWebGPUGlobalBindings(ctx: WebGPUBindingContext, schema: RenderableSchema, uniforms: UniformsList, textures: Textures): WebGPUGlobalBindings;
//# sourceMappingURL=global-bindings.d.ts.map