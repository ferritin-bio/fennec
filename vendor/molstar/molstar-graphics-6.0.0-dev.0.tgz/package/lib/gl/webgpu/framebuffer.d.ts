/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Framebuffer } from '../framebuffer.js';
import type { TextureAttachment } from '../texture.js';
/** A texture or renderbuffer attached to a framebuffer */
export interface WebGPUAttachment {
    readonly format: GPUTextureFormat;
    readonly hasStencil: boolean;
    /** the slice of a 3d texture rendered into */
    readonly depthSlice?: number;
    getAttachmentView: () => GPUTextureView | undefined;
    getGPUTexture: () => GPUTexture | undefined;
    getWidth: () => number;
    getHeight: () => number;
}
/** Attachments of a render pass target; WebGPU has no framebuffer objects, passes name their attachments */
export interface WebGPUFramebuffer extends Framebuffer {
    attach: (attachment: TextureAttachment, target: WebGPUAttachment) => void;
    detach: (attachment: TextureAttachment) => void;
    /** color attachments `0` to `drawBuffers - 1`, empty for depth-only targets */
    getColorAttachments: () => (WebGPUAttachment | undefined)[];
    getColorAttachment: (index: number) => WebGPUAttachment | undefined;
    getDepthAttachment: () => WebGPUAttachment | undefined;
}
export declare function isWebGPUFramebuffer(framebuffer: Framebuffer): framebuffer is WebGPUFramebuffer;
/** Narrows to `WebGPUFramebuffer`, throws for framebuffers of another backend */
export declare function asWebGPUFramebuffer(framebuffer: Framebuffer): WebGPUFramebuffer;
export declare function createWebGPUFramebuffer(): WebGPUFramebuffer;
//# sourceMappingURL=framebuffer.d.ts.map