/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** A feature the WebGPU backend doesn't implement yet */
export declare class WebGPUUnsupportedError extends Error {
    constructor(feature: string);
}
export declare function notSupported(feature: string): never;
//# sourceMappingURL=errors.d.ts.map