/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** Copies `tColor`, filtered as on WebGL when the source texture is linear (e.g. depth downsampling) */
export declare const copy_wgsl: string;
//# sourceMappingURL=copy.wgsl.d.ts.map