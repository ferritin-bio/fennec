/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Direct volume rendering: the back faces of the grid box, ray marched front to back through the 3d grid texture
 * (\`tGridTex\`, values in alpha, gradients in rgb) with a transfer function, lighting, markers and fog; color variants
 * only, as on WebGL
 */
export declare const direct_volume_wgsl: string;
//# sourceMappingURL=direct-volume.wgsl.d.ts.map