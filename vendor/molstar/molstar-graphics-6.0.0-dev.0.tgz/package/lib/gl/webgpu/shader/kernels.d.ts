/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** Registers the WGSL source of a kernel; the bindings are declared from its schema, see `getWgslKernelDeclarations` */
export declare function registerWgslKernel(name: string, source: string): void;
export declare function getWgslKernel(name: string): string | undefined;
//# sourceMappingURL=kernels.d.ts.map