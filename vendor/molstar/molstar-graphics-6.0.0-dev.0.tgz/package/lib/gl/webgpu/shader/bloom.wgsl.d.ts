/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** Bloom seed: bright parts of the composited scene (luminosity) or the emissive prepass */
export declare const bloom_luminosity_wgsl: string;
/** Separable gaussian blur */
export declare const bloom_blur_wgsl: string;
/** Combines the blur levels */
export declare const bloom_composite_wgsl: string;
//# sourceMappingURL=bloom.wgsl.d.ts.map