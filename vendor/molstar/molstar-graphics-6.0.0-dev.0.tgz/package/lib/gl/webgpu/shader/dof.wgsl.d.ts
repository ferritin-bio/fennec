/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Depth of field: the color blurred by the circle of confusion of the nearest depth, planar or spherical around the
 * focus; bounded by the \`oBlurSize\` override constant. Depth textures are always available on
 * WebGPU.
 */
export declare const dof_wgsl: string;
//# sourceMappingURL=dof.wgsl.d.ts.map