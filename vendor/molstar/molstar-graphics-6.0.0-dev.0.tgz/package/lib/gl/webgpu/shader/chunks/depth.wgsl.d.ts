/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * View space z of window depth values, depth in [0, 1] as the fragment stage's position.z and depth textures; depth is
 * reversed (near 1, far 0, see `DepthRangeTag`), which keeps the precision of small (far) depths
 */
export declare const depth_wgsl = "\nfn perspectiveDepthToViewZ(depth: f32, near: f32, far: f32) -> f32 {\n    return -(near * far) / (near + (far - near) * depth);\n}\n\nfn orthographicDepthToViewZ(depth: f32, near: f32, far: f32) -> f32 {\n    return depth * (far - near) - far;\n}\n\nfn depthToViewZ(isOrtho: f32, depth: f32, near: f32, far: f32) -> f32 {\n    if (isOrtho == 1.0) {\n        return orthographicDepthToViewZ(depth, near, far);\n    }\n    return perspectiveDepthToViewZ(depth, near, far);\n}\n";
//# sourceMappingURL=depth.wgsl.d.ts.map