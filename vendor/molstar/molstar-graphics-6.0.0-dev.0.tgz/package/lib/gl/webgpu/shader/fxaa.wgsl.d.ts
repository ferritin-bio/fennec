/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Fast approximate anti-aliasing (FXAA 3.11 by Timothy Lottes, as explained in
 * http://blog.simonrodriguez.fr/articles/2016/07/implementing_fxaa.html); thresholds, iterations
 * and subpixel quality are override constants
 */
export declare const fxaa_wgsl: string;
//# sourceMappingURL=fxaa.wgsl.d.ts.map