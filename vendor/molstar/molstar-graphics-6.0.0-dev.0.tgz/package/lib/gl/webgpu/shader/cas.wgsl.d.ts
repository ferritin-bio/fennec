/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Robust contrast adaptive sharpening (RCAS of AMD FidelityFX FSR 1, MIT License, https://gpuopen.com/fsr), as
 * adapted for WebGL in https://www.shadertoy.com/view/stXSWB
 */
export declare const cas_wgsl: string;
//# sourceMappingURL=cas.wgsl.d.ts.map