/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** Cylinder impostors: a box per cylinder (6 vertices, 4 triangles), ray-cylinder intersection per fragment */
export declare const cylinders_wgsl: string;
//# sourceMappingURL=cylinders.wgsl.d.ts.map