/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
/**
 * Screen space path tracing of the opaque scene, averaged with the previous frames (`tAccumulate`); the random numbers
 * are seeded with the GL fragment coordinates, so that the noise matches WebGL
 *
 * parts adapted from
 * - https://blog.demofox.org/2020/05/25/casual-shadertoy-path-tracing-1-basic-camera-diffuse-emissive/
 * - https://github.com/0beqz/realism-effects/blob/v2-debug/src/ssgi/shader/ssgi.frag
 */
export declare const trace_wgsl: string;
/**
 * Denoises the traced image and composes fog, occlusion, outlines, blended transparency and bloom onto it. Depth
 * textures are always available on WebGPU, so the opaque depth is never packed.
 */
export declare const illumination_compose_wgsl: string;
//# sourceMappingURL=illumination.wgsl.d.ts.map