/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Images: a textured quad per instance with colors (\`tImageTex\`), groups (\`tGroupTex\`) and values (\`tValueTex\`,
 * for iso-level cut-offs) per texel, optionally cubic interpolation, trimmed by a shape
 */
export declare const image_wgsl: string;
//# sourceMappingURL=image.wgsl.d.ts.map