/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** The front color of the dual depth peeling layers */
export declare const evaluate_dpoit_wgsl: string;
/** Blends the back color of a dual depth peeling layer */
export declare const blend_back_dpoit_wgsl: string;
//# sourceMappingURL=dpoit.wgsl.d.ts.map