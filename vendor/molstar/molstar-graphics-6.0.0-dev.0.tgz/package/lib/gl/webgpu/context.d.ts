/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type GraphicsContext } from '../context.js';
import { type DrawMode, type ComputeRenderItem, type GraphicsRenderItem, type ProgramItem, type ProgramVariant } from '../render-item.js';
import { type RenderState } from '../render-state.js';
import { type GraphicsStats } from '../stats.js';
import { type WebGPUBindingContext } from './global-bindings.js';
import { type WebGPUProgram, type WebGPUProgramCache } from './program.js';
import { type WebGPUTargetDescriptor } from './render-pass.js';
import { type WebGPUResourceEnv } from './texture.js';
import { type PassState } from './pass-state.js';
/** Internals the WebGPU render items draw with */
export interface WebGPUDrawContext extends WebGPUBindingContext, WebGPUResourceEnv {
    readonly stats: GraphicsStats;
    /** The state of the open render pass (its encoder begun on first use), with the dynamic state applied */
    getPassState: () => PassState;
    /** Pipeline of `program` for the current render state and pass target, `undefined` while it compiles */
    getPipeline: (program: WebGPUProgram, drawMode: DrawMode) => GPURenderPipeline | undefined;
    /** Starts compiling the pipeline of `program` for `state` and `target` unless it exists (pending work) */
    preparePipeline: (program: WebGPUProgram, drawMode: DrawMode, state: RenderState, target: WebGPUTargetDescriptor) => void;
    /** How render items request their pipelines for `resources.preparePipelines` */
    readonly itemPreparers: WeakMap<GraphicsRenderItem | ComputeRenderItem | ProgramItem, WebGPUItemPreparer>;
    /** Programs shared by the render items of the context */
    readonly programs: WebGPUProgramCache;
    /** Current render state, for dynamic state (stencil reference) */
    readonly renderState: RenderState;
    onError: (message: string) => void;
    /** Whether render items of programs that are not ported throw instead of drawing nothing */
    readonly strict: boolean;
    /** Warns once per message about a render item that draws nothing */
    warnUnsupported: (message: string) => void;
    /** Render items whose programs `linkPrograms` creates ahead of their first draw */
    readonly linkables: WebGPULinkables;
}
/**
 * Render items with programs to link per variant: added when created or when their programs changed, `linkPrograms`
 * links the pending ones of the requested variants
 */
export interface WebGPULinkables {
    /** marks `linkable` pending for all variants */
    add: (linkable: WebGPULinkable) => void;
    delete: (linkable: WebGPULinkable) => void;
}
/** Requests the pipeline of a render item's program for `variant`, `state` and `target` */
export type WebGPUItemPreparer = (variant: ProgramVariant, state: RenderState, target: WebGPUTargetDescriptor) => void;
/** Creates the programs of a render item for a render variant (shader module, pipelines of known keys) */
export interface WebGPULinkable {
    link: (variant: ProgramVariant) => void;
}
export interface WebGPUContext extends GraphicsContext {
    readonly device: GPUDevice;
    /**
     * Records the draws of `draw` into a render bundle for the open pass's target, instead of the pass; undefined when
     * the draws can't be replayed from one (a clear between them, a pipeline still compiling, the viewport, scissor or
     * stencil reference changing between them): the caller draws them directly then
     */
    recordRenderBundle: (draw: () => void) => GPURenderBundle | undefined;
    /** Replays `bundles` in the open pass, with the pass's viewport, scissor and stencil reference */
    executeRenderBundles: (bundles: readonly GPURenderBundle[]) => void;
    /**
     * Reads the drawing buffer, rows top to bottom; ends the open pass and submits pending commands. With a canvas, call it
     * in the task that rendered the frame (the canvas texture changes per frame).
     */
    readDrawingBuffer: () => Promise<ImageData>;
    /** Submits the recorded commands now (otherwise at the end of the task); the browser presents the canvas texture */
    present: () => void;
    /** Returns and clears device and shader compilation errors */
    takeErrors: () => string[];
    setDrawingBufferSize: (width: number, height: number) => void;
}
export declare function isWebGPUContext(ctx: GraphicsContext): ctx is WebGPUContext;
/**
 * Limits of a device: the maxima of its adapter (`adapter`), or the core defaults of the spec (`core`, the minimum
 * spec)
 */
export type WebGPULimits = 'adapter' | 'core';
/** Optional features of a device: those of `OptionalFeatures` its adapter has (`optional`), or none (the minimum spec) */
export type WebGPUFeatures = 'optional' | 'none';
/**
 * Every `max*` limit of `adapter` at its value; alignment limits (`min*`) keep their defaults (smaller is "better"
 * there, and the uniform ring assumes 256 bytes)
 */
export declare function getAdapterMaxLimits(adapter: Pick<GPUAdapter, 'limits'>): Record<string, number>;
/**
 * The device of an adapter of `gpu` (by default the browser's `navigator.gpu`, e.g. Dawn's in Node.js); `undefined`
 * where the adapter lacks one of `requiredFeatures` (callers fall back, e.g. to WebGL)
 */
export declare function requestWebGPUDevice(powerPreference?: 'default' | 'high-performance' | 'low-power', gpu?: GPU | undefined, limits?: WebGPULimits, features?: WebGPUFeatures, requiredFeatures?: readonly GPUFeatureName[]): Promise<GPUDevice | undefined>;
/**
 * WebGPU graphics context. The drawing buffer is the canvas texture of the current frame (the preferred canvas format,
 * see `getCanvasFormat`, with a `depth24plus-stencil8` attachment), or an offscreen `rgba8unorm` texture without canvas. Recorded commands are submitted at the
 * end of the task that recorded them, as WebGL flushes implicitly.
 */
export interface WebGPUContextOptions {
    width: number;
    height: number;
    canvas?: HTMLCanvasElement;
    pixelScale?: number;
    /**
     * Unported programs are reported as supported and using them throws a `WebGPUUnsupportedError`, instead of passes
     * falling back and render items drawing nothing (with a warning)
     */
    strict?: boolean;
    /** Requests a device for a new context replacing a lost one (`recreate`); without it a lost context is not replaced */
    requestDevice?: () => Promise<GPUDevice | undefined>;
    /**
     * The context owns its device (requested for it): `destroy` destroys it, and contexts replacing it (`recreate`) own
     * theirs; not for a device shared with others (e.g. tests creating contexts on one device)
     */
    ownsDevice?: boolean;
}
export declare function createWebGPUContext(device: GPUDevice, options: WebGPUContextOptions): WebGPUContext;
//# sourceMappingURL=context.d.ts.map