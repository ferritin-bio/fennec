/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ComputeContext, KernelCode, KernelSchema, StorageBuffer } from '../compute.js';
import type { PendingWork } from '../pending-work.js';
import type { DefineValues } from '../shader-code.js';
import type { GraphicsStats } from '../stats.js';
import { type Release, type WebGPUByteCounts } from './texture.js';
import { type UniformRing } from './uniform-ring.js';
/** What the compute context needs of the WebGPU context */
export interface WebGPUComputeEnv {
    readonly device: GPUDevice;
    readonly ring: UniformRing;
    readonly stats: GraphicsStats;
    readonly pending: PendingWork;
    release: Release;
    /** Records commands outside of passes (ends the open pass encoder) */
    encode: (commands: (encoder: GPUCommandEncoder) => void) => void;
    /** Submits the recorded commands */
    flush: () => void;
    /** The encoder of the open compute pass, begun on first use */
    getComputePassEncoder: () => GPUComputePassEncoder;
    beginComputePass: (options: {
        label: string;
    }) => void;
    endComputePass: () => void;
    onError: (message: string) => void;
    /** bytes of the storage buffers created and not destroyed yet */
    storageBufferBytes: number;
    /** bytes of the other live resources, here the staging buffers of reads (`pixelPack`) */
    readonly byteCounts: WebGPUByteCounts;
}
export interface WebGPUStorageBuffer extends StorageBuffer {
    getGPUBuffer: () => GPUBuffer;
    /** bumped when the GPU buffer is recreated (device loss) */
    readonly version: number;
}
export declare function asWebGPUStorageBuffer(buffer: StorageBuffer): WebGPUStorageBuffer;
export declare function getWgslKernelDeclarations(code: KernelCode, schema: KernelSchema, defines: DefineValues): string;
export declare function createWebGPUComputeContext(env: WebGPUComputeEnv): ComputeContext;
//# sourceMappingURL=compute.d.ts.map