/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsBackendDescriptor } from '../backend.js';
import { type WebGPUFeatures, type WebGPULimits } from './context.js';
/**
 * `strict`: see `WebGPUContextOptions`; `limits`: the adapter's maxima (default) or the core defaults of the spec;
 * `features`: the optional features the adapter has (default) or none; `requiredFeatures`: adapters without them create
 * no context, so that the next backend of a list is used
 */
export declare function createWebGPUBackend(options?: {
    strict?: boolean;
    limits?: WebGPULimits;
    features?: WebGPUFeatures;
    requiredFeatures?: readonly GPUFeatureName[];
}): GraphicsBackendDescriptor;
export declare const WebGPUBackend: GraphicsBackendDescriptor;
/**
 * WebGPU for default backend lists, where it competes with WebGL2: skipped (the next backend of the list is used) where
 * the adapter cannot blend into float32 targets (`float32-blendable`, e.g. older Firefox), as WebGL2 then has more
 * features (the transparency modes wboit and dpoit and illumination, with `EXT_float_blend`); `WebGPUBackend` when
 * WebGPU is asked for
 */
export declare const AutoWebGPUBackend: GraphicsBackendDescriptor;
//# sourceMappingURL=backend.d.ts.map