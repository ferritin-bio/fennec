/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4 } from '@molstar/core/math/linear-algebra';
import type { ValueCell } from '@molstar/core/util';
import type { UniformValues } from './uniform.js';
import type { RenderableSchema } from './renderable/schema.js';
/**
 * Depth is reversed on all backends: the near plane at depth 1, the far plane at depth 0 (the background, and the
 * cleared depth), so that floating-point depth keeps its precision far from the camera. The camera builds GL
 * projections (clip depth in `[-1, 1]`, near at -1); uniforms holding a projection are tagged (`UniformSpec.depthRange`)
 * and each backend maps them to its clip depth when it binds them, in double precision before they become `f32`:
 * WebGPU, and WebGL with `EXT_clip_control`, to `[0, 1]` reversed (depth equals clip z / w); WebGL without it to
 * `[-1, 1]` reversed (z negated; window depth is `(z / w + 1) / 2`, without the precision gain). Window depth is
 * `1 - d` of a GL projection's depth `d` on all.
 */
export type DepthRangeTag = 'projection' | 'inverse';
/** How a backend maps the clip coordinates of the camera's GL projections, see `DepthRangeTag` */
export interface DepthRangeConversion {
    /** a matrix that ends in the projection (`P`, `P * MV`) */
    readonly projection: (out: Mat4, m: Mat4) => Mat4;
    /** the inverse of such a matrix */
    readonly inverse: (out: Mat4, m: Mat4) => Mat4;
}
/** The conversion that multiplies clip coordinates by `clip` (column-major) */
export declare function createDepthRangeConversion(clip: Mat4): DepthRangeConversion;
/** `[0, 1]` reversed: `z' = (w - z) / 2` */
export declare const ReversedZeroToOne: DepthRangeConversion;
/** `[-1, 1]` reversed: `z' = -z` */
export declare const ReversedMinusOneToOne: DepthRangeConversion;
/**
 * A cell with the converted value of `cell`, recomputed when its version changes; observers are those of `cell`
 * (`ValueCell.observe`)
 */
export declare function convertedCell(cell: ValueCell<Mat4>, convert: (out: Mat4, m: Mat4) => Mat4): ValueCell<Mat4>;
/** The cell to bind for uniform `name` of `schema`: tagged projections converted with `conversion` */
export declare function getDepthRangeCell<T>(schema: RenderableSchema, name: string, cell: ValueCell<T>, conversion: DepthRangeConversion | undefined): ValueCell<T>;
/** `values` with the tagged projections converted, see `getDepthRangeCell` */
export declare function convertDepthRange(schema: RenderableSchema, values: UniformValues, conversion: DepthRangeConversion | undefined): UniformValues;
//# sourceMappingURL=depth-range.d.ts.map