/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsCapabilities } from '../capabilities.js';
import { type GLRenderingContext } from './compat.js';
import type { WebGLExtensions } from './extensions.js';
export declare function getWebGLCapabilities(gl: GLRenderingContext, extensions: WebGLExtensions): GraphicsCapabilities;
//# sourceMappingURL=capabilities.d.ts.map