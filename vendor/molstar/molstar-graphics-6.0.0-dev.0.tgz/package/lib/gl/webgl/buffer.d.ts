/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { WebGLContext } from './context.js';
import { type DefineLookup, type RenderableSchema } from '../renderable/schema.js';
import { type GLRenderingContext } from './compat.js';
import type { WebGLExtensions } from './extensions.js';
import type { WebGLState } from './state.js';
import { type TextureFormat, type TextureType } from '../texture.js';
import type { ArrayType, AttributeItemSize, AttributeKind, AttributeValues, DataType, ElementsType, UsageHint } from '../buffer.js';
import type { AttributeLayout } from '../attribute-layout.js';
export type BufferType = 'attribute' | 'elements' | 'uniform' | 'pixel-pack';
export declare function getUsageHint(gl: GLRenderingContext, usageHint: UsageHint): 35040 | 35044 | 35048;
export declare function getDataType(gl: GLRenderingContext, dataType: DataType): 5120 | 5121 | 5122 | 5123 | 5124 | 5125 | 5126;
export declare function getBufferType(gl: GLRenderingContext, bufferType: BufferType): 34962 | 34963 | 35051 | 35345;
export interface Buffer {
    readonly id: number;
    readonly _usageHint: number;
    readonly _bufferType: number;
    readonly _dataType: number;
    readonly _bpe: number;
    readonly length: number;
    getByteCount: () => number;
    getBuffer: () => WebGLBuffer;
    updateData: (array: ArrayType) => void;
    updateSubData: (array: ArrayType, offset: number, count: number) => void;
    destroy: () => void;
}
export declare function getBuffer(gl: GLRenderingContext): WebGLBuffer;
export declare function getAttribType(gl: GLRenderingContext, kind: AttributeKind, itemSize: AttributeItemSize): 5126 | 35664 | 35665 | 35666 | 35676;
export type AttributeBuffers = [string, AttributeBuffer][];
export interface AttributeBuffer extends Buffer {
    readonly itemSize: AttributeItemSize;
    readonly divisor: number;
    bind: (location: number) => void;
    changeOffset: (location: number, offset: number) => void;
}
export declare function createAttributeBuffer<T extends ArrayType, S extends AttributeItemSize>(gl: GLRenderingContext, state: WebGLState, extensions: WebGLExtensions, array: T, itemSize: S, divisor: number, usageHint?: UsageHint): AttributeBuffer;
/**
 * Binds each buffer at its fixed location, whether a program uses it or not,
 * so the state (or VAO) is the same for all programs of a render item.
 */
export declare function bindAttributeBuffers(state: WebGLState, layout: AttributeLayout, attributeBuffers: AttributeBuffers): void;
export declare function createAttributeBuffers(ctx: WebGLContext, schema: RenderableSchema, values: AttributeValues, defines: DefineLookup): AttributeBuffers;
export interface ElementsBuffer extends Buffer {
    bind: () => void;
}
export declare function createElementsBuffer(gl: GLRenderingContext, array: ElementsType, usageHint?: UsageHint): ElementsBuffer;
export interface PixelPackBuffer {
    readonly id: number;
    readonly _type: number;
    readonly _format: number;
    readonly _bpe: number;
    getByteCount: () => number;
    read: (x: number, y: number, width: number, height: number) => void;
    getSubData: (array: ArrayType) => void;
    destroy: () => void;
}
export declare function createPixelPackBuffer(gl: WebGL2RenderingContext, extensions: WebGLExtensions, format: TextureFormat, type: TextureType): PixelPackBuffer;
//# sourceMappingURL=buffer.d.ts.map