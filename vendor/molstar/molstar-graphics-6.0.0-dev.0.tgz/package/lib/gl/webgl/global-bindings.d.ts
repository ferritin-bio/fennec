/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GlobalBindings } from '../render-item.js';
import type { RenderableSchema } from '../renderable/schema.js';
import type { Textures } from '../texture.js';
import type { UniformsList } from '../uniform.js';
import type { WebGLContext } from './context.js';
import type { Program } from './program.js';
export interface WebGLGlobalBindings extends GlobalBindings {
    /** Uses `program` and applies the bindings if it changed or they were invalidated */
    apply: (program: Program) => void;
}
export declare function isWebGLGlobalBindings(globals: GlobalBindings): globals is WebGLGlobalBindings;
/** Narrows to `WebGLGlobalBindings`, throws for global bindings of another backend */
export declare function asWebGLGlobalBindings(globals: GlobalBindings): WebGLGlobalBindings;
export declare function createGlobalBindings(ctx: WebGLContext, schema: RenderableSchema, uniforms: UniformsList, textures: Textures): WebGLGlobalBindings;
//# sourceMappingURL=global-bindings.d.ts.map