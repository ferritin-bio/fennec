/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsBackendDescriptor } from '../backend.js';
import { type WebGLContextProps } from './context.js';
/** A WebGL backend; `options.uniformBlocks`: see `WebGLContextProps` */
export declare function createWebGLBackend(id: 'webgl' | 'webgl2', options?: Partial<Pick<WebGLContextProps, 'uniformBlocks'>>): GraphicsBackendDescriptor;
/** WebGL 2 */
export declare const WebGL2Backend: GraphicsBackendDescriptor;
/** WebGL 1 with extensions */
export declare const WebGLBackend: GraphicsBackendDescriptor;
//# sourceMappingURL=backend.d.ts.map