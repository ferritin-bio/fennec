/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { type GLRenderingContext } from './compat.js';
import { type WebGLExtensions } from './extensions.js';
import { type WebGLState } from './state.js';
import { type WebGLResources } from './resources.js';
import { type GraphicsContext } from '../context.js';
import type { ComputeRenderVariant, DrawMode, GraphicsRenderVariant, Transparency } from '../render-item.js';
import type { RenderableSchema, RenderableValues } from '../renderable/schema.js';
import type { ShaderCode } from '../shader-code.js';
import { type WebGLRenderItem } from './render-item.js';
import { type DepthRangeConversion } from '../depth-range.js';
export declare function getGLContext(canvas: HTMLCanvasElement, attribs?: WebGLContextAttributes & {
    preferWebGl1?: boolean;
}): GLRenderingContext | null;
export declare function getErrorDescription(gl: GLRenderingContext, error: number): "context lost" | "invalid enum" | "invalid framebuffer operation" | "invalid operation" | "invalid value" | "no error" | "out of memory" | "unknown error";
export declare function checkError(gl: GLRenderingContext, message?: string): void;
export declare function glEnumToString(gl: GLRenderingContext, value: number): string;
export declare function readPixels(gl: GLRenderingContext, x: number, y: number, width: number, height: number, buffer: Uint8Array | Float32Array | Int32Array): void;
declare function getShaderPrecisionFormats(gl: GLRenderingContext, shader: 'vertex' | 'fragment'): {
    lowFloat: WebGLShaderPrecisionFormat | null;
    mediumFloat: WebGLShaderPrecisionFormat | null;
    highFloat: WebGLShaderPrecisionFormat | null;
    lowInt: WebGLShaderPrecisionFormat | null;
    mediumInt: WebGLShaderPrecisionFormat | null;
    highInt: WebGLShaderPrecisionFormat | null;
};
type WebGLShaderPrecisionFormats = ReturnType<typeof getShaderPrecisionFormats>;
declare function createParameters(gl: GLRenderingContext, extensions: WebGLExtensions): {
    maxTextureSize: number;
    max3dTextureSize: number;
    maxRenderbufferSize: number;
    maxDrawBuffers: number;
    maxTextureImageUnits: number;
    maxVertexTextureImageUnits: number;
    maxVertexAttribs: number;
};
export type WebGLParameters = ReturnType<typeof createParameters>;
/** A WebGL context object, including the rendering context, resource caches and counts */
export interface WebGLContext extends GraphicsContext {
    readonly gl: GLRenderingContext;
    readonly isWebGL2: boolean;
    /** Whether uniform blocks are backed by uniform buffers, see `WebGLContextProps` */
    readonly uniformBlocks: boolean;
    readonly extensions: WebGLExtensions;
    readonly state: WebGLState;
    readonly resources: WebGLResources;
    readonly shaderPrecisionFormats: {
        vertex: WebGLShaderPrecisionFormats;
        fragment: WebGLShaderPrecisionFormats;
    };
    /**
     * How the projection uniforms are mapped to clip depth (see `DepthRangeTag`): reversed `[0, 1]` with
     * `EXT_clip_control` (as WebGPU, with the precision gain of reversed depth), reversed `[-1, 1]` otherwise; GLSL sees
     * the former as `clipZeroToOne`
     */
    readonly depthRangeConversion: DepthRangeConversion;
    createGraphicsRenderItem: (drawMode: DrawMode, shaderCode: ShaderCode, schema: RenderableSchema, values: RenderableValues, materialId: number, transparency: Transparency) => WebGLRenderItem<GraphicsRenderVariant>;
    createComputeRenderItem: (drawMode: DrawMode, shaderCode: ShaderCode, schema: RenderableSchema, values: RenderableValues, materialId?: number) => WebGLRenderItem<ComputeRenderVariant>;
    /** Binds the drawing buffer outside of render passes, e.g. for readback */
    bindDrawingBuffer: () => void;
    /** Reads from the bound framebuffer, ends the open render pass */
    readPixels: (x: number, y: number, width: number, height: number, buffer: Uint8Array | Float32Array | Int32Array) => void;
    waitForGpuCommandsComplete: () => Promise<void>;
    waitForGpuCommandsCompleteSync: () => void;
    getFenceSync: () => WebGLSync | null;
    checkSyncStatus: (sync: WebGLSync) => boolean;
    deleteSync: (sync: WebGLSync) => void;
    checkError: (message?: string) => void;
    checkFramebufferStatus: (message?: string) => void;
}
/** Narrows to the WebGL backend, for code paths that are WebGL-only so far */
export declare function isWebGLContext(ctx: GraphicsContext): ctx is WebGLContext;
export interface WebGLContextProps {
    readonly pixelScale: number;
    /** Uniform blocks backed by uniform buffers (WebGL2 only, on by default); off, all uniforms are set one by one */
    readonly uniformBlocks: boolean;
}
export declare function createContext(gl: GLRenderingContext, props?: Partial<WebGLContextProps>): WebGLContext;
export {};
//# sourceMappingURL=context.d.ts.map