/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Items drawn as a quad of two triangles (6 vertices, no elements) with the item data pulled
 * from `tPositionGroup`: sets `mapping` (the quad corner, -1 or 1 per axis), `vertexId` (the item),
 * `position` and `group`
 */
export declare const assign_quad_position_group = "\nvec2 mapping = vec2(1.0, 1.0); // vertices 2 and 5\n#if __VERSION__ == 100\n    int m = imod(VertexID, 6);\n#else\n    int m = VertexID % 6;\n#endif\nif (m == 0) {\n    mapping = vec2(-1.0, 1.0);\n} else if (m == 1 || m == 3) {\n    mapping = vec2(-1.0, -1.0);\n} else if (m == 4) {\n    mapping = vec2(1.0, -1.0);\n}\n\nint vertexId = VertexID / 6;\n\nvec4 positionGroup = readFromTexture(tPositionGroup, vertexId, uTexDim);\nvec3 position = positionGroup.rgb;\nfloat group = positionGroup.a;\n";
//# sourceMappingURL=assign-quad-position-group.glsl.d.ts.map