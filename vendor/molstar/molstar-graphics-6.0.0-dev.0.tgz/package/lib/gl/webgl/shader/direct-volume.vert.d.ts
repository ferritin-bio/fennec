/**
 * Copyright (c) 2017-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Michael Krone <michael.krone@uni-tuebingen.de>
 */
export declare const directVolume_vert = "\nprecision highp float;\n\nvarying vec3 vModelPosition;\nvarying float vInstance;\nvarying vec4 vBoundingSphere;\nvarying mat4 vTransform;\n\nvoid main() {\n    vec4 unitCoord = vec4(aPosition + vec3(0.5), 1.0);\n    vec4 mvPosition = uModelView * aTransform * uUnitToCartn * unitCoord;\n\n    vModelPosition = (uModel * aTransform * uUnitToCartn * unitCoord).xyz;\n    vInstance = aInstance;\n    vBoundingSphere = vec4(\n        (uModel * aTransform * vec4(uInvariantBoundingSphere.xyz, 1.0)).xyz,\n        uModelScale * uInvariantBoundingSphere.w\n    );\n    vTransform = aTransform;\n\n    gl_Position = uProjection * mvPosition;\n\n    // move z position to the far clip plane (but not too close to get precision issues; clip z is reversed)\n    #ifdef clipZeroToOne\n        gl_Position.z = 0.005;\n    #else\n        gl_Position.z = -gl_Position.w + 0.01;\n    #endif\n}\n";
//# sourceMappingURL=direct-volume.vert.d.ts.map