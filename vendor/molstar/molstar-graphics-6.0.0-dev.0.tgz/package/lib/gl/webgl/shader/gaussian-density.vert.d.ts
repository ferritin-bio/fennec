/**
 * Copyright (c) 2018-2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Michael Krone <michael.krone@uni-tuebingen.de>
 */
export declare const gaussianDensity_vert = "\nprecision highp float;\n\nvarying vec3 vPosition;\nvarying float vRadiusSqInv;\n\n#if defined(dCalcType_groupId)\n    varying float vGroup;\n#endif\n\nvoid main() {\n    vRadiusSqInv = 1.0 / (aRadius * aRadius);\n    #if defined(dCalcType_groupId)\n        vGroup = aGroup;\n    #endif\n    // a quad around the atom covering its splat, in pixels of the slice (uGridDim.xy)\n    float size = ceil(((aRadius * 3.0) / uResolution) + uResolution);\n    vPosition = (aPosition - uBboxMin) / uResolution;\n    gl_Position = vec4(((aPosition - uBboxMin) / uBboxSize) * 2.0 - 1.0, 1.0);\n    #ifdef clipZeroToOne\n        // z inside the clip depth range, as with [-1, 1]\n        gl_Position.z = gl_Position.z * 0.5 + 0.5;\n    #endif\n    gl_Position.xy += aMapping * size / uGridDim.xy;\n}\n";
//# sourceMappingURL=gaussian-density.vert.d.ts.map