/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type GLRenderingContext, type COMPAT_instanced_arrays, type COMPAT_standard_derivatives, type COMPAT_vertex_array_object, type COMPAT_element_index_uint, type COMPAT_texture_float, type COMPAT_texture_float_linear, type COMPAT_blend_minmax, type COMPAT_frag_depth, type COMPAT_color_buffer_float, type COMPAT_float_blend, type COMPAT_draw_buffers, type COMPAT_shader_texture_lod, type COMPAT_depth_texture, type COMPAT_sRGB, type COMPAT_texture_half_float, type COMPAT_texture_half_float_linear, type COMPAT_color_buffer_half_float, type COMPAT_disjoint_timer_query, type COMPAT_multi_draw, type COMPAT_draw_instanced_base_vertex_base_instance, type COMPAT_multi_draw_instanced_base_vertex_base_instance, type COMPAT_draw_buffers_indexed, type COMPAT_parallel_shader_compile, type COMPAT_fboRenderMipmap, type COMPAT_provoking_vertex, type COMPAT_clip_cull_distance, type COMPAT_conservative_depth, type COMPAT_stencil_texturing, type COMPAT_clip_control, type COMPAT_render_snorm, type COMPAT_render_shared_exponent, type COMPAT_texture_norm16, type COMPAT_depth_clamp, type COMPAT_multiview2 } from './compat.js';
export type WebGLExtensions = {
    instancedArrays: COMPAT_instanced_arrays;
    elementIndexUint: COMPAT_element_index_uint;
    standardDerivatives: COMPAT_standard_derivatives;
    textureFloat: COMPAT_texture_float;
    blendMinMax: COMPAT_blend_minmax;
    textureFloatLinear: COMPAT_texture_float_linear | null;
    textureHalfFloat: COMPAT_texture_half_float | null;
    textureHalfFloatLinear: COMPAT_texture_half_float_linear | null;
    depthTexture: COMPAT_depth_texture | null;
    vertexArrayObject: COMPAT_vertex_array_object | null;
    fragDepth: COMPAT_frag_depth | null;
    colorBufferFloat: COMPAT_color_buffer_float | null;
    floatBlend: COMPAT_float_blend | null;
    colorBufferHalfFloat: COMPAT_color_buffer_half_float | null;
    drawBuffers: COMPAT_draw_buffers | null;
    drawBuffersIndexed: COMPAT_draw_buffers_indexed | null;
    shaderTextureLod: COMPAT_shader_texture_lod | null;
    sRGB: COMPAT_sRGB | null;
    disjointTimerQuery: COMPAT_disjoint_timer_query | null;
    multiDraw: COMPAT_multi_draw | null;
    drawInstancedBaseVertexBaseInstance: COMPAT_draw_instanced_base_vertex_base_instance | null;
    multiDrawInstancedBaseVertexBaseInstance: COMPAT_multi_draw_instanced_base_vertex_base_instance | null;
    parallelShaderCompile: COMPAT_parallel_shader_compile | null;
    fboRenderMipmap: COMPAT_fboRenderMipmap | null;
    provokingVertex: COMPAT_provoking_vertex | null;
    clipCullDistance: COMPAT_clip_cull_distance | null;
    conservativeDepth: COMPAT_conservative_depth | null;
    stencilTexturing: COMPAT_stencil_texturing | null;
    clipControl: COMPAT_clip_control | null;
    renderSnorm: COMPAT_render_snorm | null;
    renderSharedExponent: COMPAT_render_shared_exponent | null;
    textureNorm16: COMPAT_texture_norm16 | null;
    depthClamp: COMPAT_depth_clamp | null;
    multiview2: COMPAT_multiview2 | null;
    noNonInstancedActiveAttribs: boolean;
};
export declare function createExtensions(gl: GLRenderingContext): WebGLExtensions;
//# sourceMappingURL=extensions.d.ts.map