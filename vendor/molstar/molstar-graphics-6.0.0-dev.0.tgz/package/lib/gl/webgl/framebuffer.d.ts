/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type GLRenderingContext } from './compat.js';
import type { Framebuffer } from '../framebuffer.js';
import type { WebGLExtensions } from './extensions.js';
import type { WebGLState } from './state.js';
export declare function checkFramebufferStatus(gl: GLRenderingContext, message?: string): void;
/** Records the height of an attachment of `framebuffer` (all attachments have the same size) */
export declare function setFramebufferHeight(framebuffer: Framebuffer, getHeight: () => number): void;
/** The height of the attachments of `framebuffer`, 0 without attachments */
export declare function getFramebufferHeight(framebuffer: Framebuffer): number;
/** Records whether the first color attachment of the bound framebuffer is an integer texture */
export declare function setIntegerColorAttachment(gl: GLRenderingContext, isInteger: boolean): void;
/** Whether the first color attachment of the bound framebuffer is an integer texture */
export declare function hasIntegerColorAttachment(gl: GLRenderingContext): boolean;
export declare function createFramebuffer(gl: GLRenderingContext, extensions: WebGLExtensions, state: WebGLState): Framebuffer;
export declare function createNullFramebuffer(): Framebuffer;
//# sourceMappingURL=framebuffer.d.ts.map