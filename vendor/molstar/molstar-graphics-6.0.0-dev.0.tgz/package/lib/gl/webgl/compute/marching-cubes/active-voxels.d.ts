/**
 * Copyright (c) 2019-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsContext } from '../../../context.js';
import { TextureSpec, UniformSpec, DefineSpec } from '../../../renderable/schema.js';
import type { Texture } from '../../../texture.js';
import { ShaderCode } from '../../../shader-code.js';
import type { Vec3, Vec2 } from '@molstar/core/math/linear-algebra';
/** Channel of the volume data texture holding the value, e.g. `alpha` for densities with a packed group in `rgb` */
export type ValueChannel = 'red' | 'alpha';
export declare const ActiveVoxelsSchema: {
    drawCount: import("../../../renderable/schema.js").ValueSpec<"number">;
    instanceCount: import("../../../renderable/schema.js").ValueSpec<"number">;
    aPosition: import("../../../renderable/schema.js").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tTriCount: TextureSpec<"image-uint8">;
    tVolumeData: TextureSpec<"texture">;
    dValueChannel: DefineSpec<"string">;
    uIsoValue: UniformSpec<"f">;
    uGridDim: UniformSpec<"v3">;
    uGridTexDim: UniformSpec<"v3">;
    uScale: UniformSpec<"v2">;
};
export declare const ActiveVoxelsShaderCode: ShaderCode;
export declare function calcActiveVoxels(ctx: GraphicsContext, volumeData: Texture, valueChannel: ValueChannel, gridDim: Vec3, gridTexDim: Vec3, isoValue: number, gridScale: Vec2): Texture;
//# sourceMappingURL=active-voxels.d.ts.map