/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type WebGLContext } from '../../context.js';
import type { AtlasIsosurfaceExtraction } from '../../../compute/marching-cubes/atlas.js';
import { TextureSpec, UniformSpec, DefineSpec } from '../../../renderable/schema.js';
import type { Texture } from '../../../texture.js';
import { ShaderCode } from '../../../shader-code.js';
import { type Vec3, type Vec2, type Mat4 } from '@molstar/core/math/linear-algebra';
import { type HistogramPyramid } from '../histogram-pyramid/reduction.js';
import { type ValueChannel } from './active-voxels.js';
export declare const IsosurfaceSchema: {
    drawCount: import("../../../renderable/schema.js").ValueSpec<"number">;
    instanceCount: import("../../../renderable/schema.js").ValueSpec<"number">;
    aPosition: import("../../../renderable/schema.js").AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tTriIndices: TextureSpec<"image-uint8">;
    tActiveVoxelsPyramid: TextureSpec<"texture">;
    tActiveVoxelsBase: TextureSpec<"texture">;
    tVolumeData: TextureSpec<"texture">;
    dValueChannel: DefineSpec<"string">;
    uIsoValue: UniformSpec<"f">;
    uSize: UniformSpec<"f">;
    uLevels: UniformSpec<"f">;
    uCount: UniformSpec<"f">;
    uInvert: UniformSpec<"b">;
    uGridDim: UniformSpec<"v3">;
    uGridTexDim: UniformSpec<"v3">;
    uGridDataDim: UniformSpec<"v3">;
    uGridTransform: UniformSpec<"m4">;
    uGridTransformAdjoint: UniformSpec<"m3">;
    uScale: UniformSpec<"v2">;
    dPackedGroup: DefineSpec<"boolean">;
    dAxisOrder: DefineSpec<"string">;
    dConstantGroup: DefineSpec<"boolean">;
};
export declare const IsosurfaceShaderCode: ShaderCode;
export declare function createIsosurfaceBuffers(ctx: WebGLContext, activeVoxelsBase: Texture, volumeData: Texture, valueChannel: ValueChannel, histogramPyramid: HistogramPyramid, gridDim: Vec3, gridTexDim: Vec3, gridDataDim: Vec3, transform: Mat4, isoValue: number, invert: boolean, packedGroup: boolean, axisOrder: Vec3, constantGroup: boolean, vertexTexture?: Texture, groupTexture?: Texture, normalTexture?: Texture): {
    vertexTexture: Texture;
    groupTexture: Texture;
    normalTexture: Texture;
    vertexCount: number;
};
/**
 * GPU isosurface extraction
 *
 * Algorithm from "High‐speed Marching Cubes using HistoPyramids"
 * by C Dyken, G Ziegler, C Theobalt, HP Seidel
 * https://doi.org/10.1111/j.1467-8659.2008.01182.x
 *
 * Implementation based on http://www.miaumiau.cat/2016/10/stream-compaction-in-webgl/
 */
export declare function extractIsosurface(ctx: WebGLContext, volumeData: Texture, valueChannel: ValueChannel, gridDim: Vec3, gridTexDim: Vec3, gridDataDim: Vec3, gridTexScale: Vec2, transform: Mat4, isoValue: number, invert: boolean, packedGroup: boolean, axisOrder: Vec3, constantGroup: boolean, vertexTexture?: Texture, groupTexture?: Texture, normalTexture?: Texture): {
    vertexTexture: Texture;
    groupTexture: Texture;
    normalTexture: Texture;
    vertexCount: number;
};
/** The fragment-shader marching cubes of WebGL, registered with each WebGL context */
export declare const WebGLAtlasIsosurfaceExtraction: AtlasIsosurfaceExtraction;
//# sourceMappingURL=isosurface.d.ts.map