/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Grid3DComputeRenderableSpec, Grid3dFragmentImplementation } from '../../compute/grid3d.js';
import { type RenderableSchema } from '../../renderable/schema.js';
/** fragment shader code, declarations are generated from `getGrid3dComputeSchema` */
export declare function getGrid3dComputeFrag(spec: Grid3DComputeRenderableSpec<any, any, any>): string;
/** loop bounds are number defines on WebGL1 (constant loop bounds) */
export declare function getGrid3dComputeSchema(spec: Grid3DComputeRenderableSpec<any, any, any>, isWebGL2: boolean): RenderableSchema;
export declare const WebGLGrid3dFragment: Grid3dFragmentImplementation;
//# sourceMappingURL=grid3d.d.ts.map