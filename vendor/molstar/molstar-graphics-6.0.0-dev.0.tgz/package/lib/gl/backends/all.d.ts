/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsBackendDescriptor } from '../backend.js';
/**
 * Backend set all: WebGPU where it has the features of WebGL2 (`AutoWebGPUBackend`), else WebGL2, then WebGL; WebGL only
 * with `preferWebGl1`
 */
export declare function getDefaultGraphicsBackends(options?: {
    preferWebGl1?: boolean;
}): GraphicsBackendDescriptor[];
//# sourceMappingURL=all.d.ts.map