/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type Mat4 } from '@molstar/core/math/linear-algebra';
export interface Cage {
    /** Float32Array, so that loops over it keep one array kind (`Vec3.fromFloat32Array`) */
    readonly vertices: Float32Array;
    readonly edges: ArrayLike<number>;
}
/** Keeps a Float32Array of `vertices` as it is; copies other arrays into one */
export declare function createCage(vertices: ArrayLike<number>, edges: ArrayLike<number>): Cage;
export declare function cloneCage(cage: Cage): Cage;
/** Transform primitive in-place */
export declare function transformCage(cage: Cage, t: Mat4): Cage;
//# sourceMappingURL=cage.d.ts.map