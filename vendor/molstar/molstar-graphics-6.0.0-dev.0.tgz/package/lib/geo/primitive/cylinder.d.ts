/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Primitive } from './primitive.js';
export declare const DefaultCylinderProps: {
    radiusTop: number;
    radiusBottom: number;
    height: number;
    radialSegments: number;
    heightSegments: number;
    topCap: boolean;
    bottomCap: boolean;
    thetaStart: number;
    thetaLength: number;
};
export type CylinderProps = Partial<typeof DefaultCylinderProps>;
export declare function Cylinder(props?: CylinderProps): Primitive;
//# sourceMappingURL=cylinder.d.ts.map