/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { type Primitive } from './primitive.js';
import { type Cage } from './cage.js';
export declare function Box(): Primitive;
export declare function PerforatedBox(): Primitive;
export declare function BoxCage(): Cage;
//# sourceMappingURL=box.d.ts.map