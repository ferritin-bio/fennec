/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Primitive } from './primitive.js';
import { type Cage } from './cage.js';
export declare const dodecahedronVertices: ReadonlyArray<number>;
/** indices of pentagonal faces, groups of five  */
export declare const dodecahedronFaces: ReadonlyArray<number>;
export declare function Dodecahedron(): Primitive;
export declare function DodecahedronCage(): Cage;
//# sourceMappingURL=dodecahedron.d.ts.map