import type { Box3D, PositionData } from '@molstar/core/math/geometry';
import type { GaussianDensityProps } from '@molstar/core/math/geometry/gaussian-density';
import type { Mat4, Vec3, Vec2 } from '@molstar/core/math/linear-algebra';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Texture } from '@molstar/graphics/gl/texture';
import { Task } from '@molstar/core/task/task';
export type GaussianDensityTextureData = {
    radiusFactor: number;
    resolution: number;
    maxRadius: number;
    transform: Mat4;
    texture: Texture;
    bbox: Box3D;
    gridDim: Vec3;
    gridTexDim: Vec3;
    gridDataDim: Vec3;
    gridTexScale: Vec2;
};
export declare function computeGaussianDensityTexture(position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps, graphics: GraphicsContext, texture?: Texture): Task<GaussianDensityTextureData>;
export declare function computeGaussianDensityTexture2d(position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps, graphics: GraphicsContext, texture?: Texture): Task<GaussianDensityTextureData>;
export declare function computeGaussianDensityTexture3d(position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps, graphics: GraphicsContext, texture?: Texture): Task<GaussianDensityTextureData>;
//# sourceMappingURL=gaussian-density.d.ts.map