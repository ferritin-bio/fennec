import type { GaussianDensityTextureData } from '../gaussian-density.js';
/**
 * Copyright (c) 2017-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Michael Krone <michael.krone@uni-tuebingen.de>
 */
import type { PositionData } from '@molstar/core/math/geometry/common';
import { Box3D } from '@molstar/core/math/geometry';
import type { GaussianDensityProps } from '@molstar/core/math/geometry/gaussian-density';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Texture } from '@molstar/graphics/gl/texture';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import { ValueSpec, AttributeSpec, UniformSpec, TextureSpec, DefineSpec } from '@molstar/graphics/gl/renderable/schema';
export declare const GaussianDensitySchema: {
    drawCount: ValueSpec<"number">;
    instanceCount: ValueSpec<"number">;
    /** quad corners, one instance per atom */
    aMapping: AttributeSpec<"float32">;
    aRadius: AttributeSpec<"float32">;
    aPosition: AttributeSpec<"float32">;
    aGroup: AttributeSpec<"float32">;
    uCurrentSlice: UniformSpec<"f">;
    uCurrentX: UniformSpec<"f">;
    uCurrentY: UniformSpec<"f">;
    uBboxMin: UniformSpec<"v3">;
    uBboxSize: UniformSpec<"v3">;
    uGridDim: UniformSpec<"v3">;
    uGridTexDim: UniformSpec<"v3">;
    uGridTexScale: UniformSpec<"v2">;
    uAlpha: UniformSpec<"f">;
    uResolution: UniformSpec<"f">;
    uRadiusFactorInv: UniformSpec<"f">;
    tMinDistanceTex: TextureSpec<"texture">;
    dGridTexType: DefineSpec<"string">;
    dCalcType: DefineSpec<"string">;
};
export declare const GaussianDensityShaderCode: ShaderCode;
/** Whether the GPU gaussian density is available: the splatting program, or compute kernels for the 3d texture */
export declare function isGaussianDensityTextureSupported(graphics: GraphicsContext): boolean;
/**
 * `growTexture`: with compute kernels, `oldTexture` is only grown (a texture shared by grids of varying size, read by
 * grid coordinates; `gridTexDim` is then its size)
 */
export declare function GaussianDensityTexture(graphics: GraphicsContext, position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps, oldTexture?: Texture, growTexture?: boolean): GaussianDensityTextureData;
export declare function GaussianDensityTexture2d(graphics: GraphicsContext, position: PositionData, box: Box3D, radius: (index: number) => number, powerOfTwo: boolean, props: GaussianDensityProps, oldTexture?: Texture): GaussianDensityTextureData;
export declare function GaussianDensityTexture3d(graphics: GraphicsContext, position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps, oldTexture?: Texture, growTexture?: boolean): GaussianDensityTextureData;
//# sourceMappingURL=gpu.d.ts.map