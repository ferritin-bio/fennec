/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import { Tensor } from '@molstar/core/math/linear-algebra';
import type { Mesh } from '../../geometry/mesh/mesh.js';
import type { Lines } from '../../geometry/lines/lines.js';
/**
 * The parameters required by the algorithm.
 */
export interface MarchingCubesParams {
    isoLevel: number;
    scalarField: Tensor;
    bottomLeft?: ReadonlyArray<number>;
    topRight?: ReadonlyArray<number>;
    idField?: Tensor;
}
export declare function computeMarchingCubesMesh(params: MarchingCubesParams, mesh?: Mesh): Task<Mesh>;
export declare function computeMarchingCubesLines(params: MarchingCubesParams, lines?: Lines): Task<Lines>;
//# sourceMappingURL=algorithm.d.ts.map