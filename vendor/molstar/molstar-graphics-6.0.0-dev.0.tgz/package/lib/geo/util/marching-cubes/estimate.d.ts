/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Vertex count of the marching cubes isosurface of `data` at `isoLevel`, unindexed (three per triangle, as the compute
 * extraction writes, see `computeChunkedIsosurface`): the triangles of the cells (`TriTable`, corners at or below
 * `isoLevel` as the compute kernels' `cubeCase`). Exact for grids up to `MaxCells` cells; larger ones visit every n-th slice of cells
 * along z, scaled, with headroom. `dim` is the grid's point count per axis, `strides` the data offsets of a step along
 * each axis, `dataDim` the data's point count per axis where the grid wraps around it (periodic volumes, the grid one
 * point larger, as the compute kernels' `value`).
 */
export declare function estimateIsosurfaceVertexCount(data: ArrayLike<number>, dim: ArrayLike<number>, strides: ArrayLike<number>, isoLevel: number, dataDim?: ArrayLike<number>): number;
//# sourceMappingURL=estimate.d.ts.map