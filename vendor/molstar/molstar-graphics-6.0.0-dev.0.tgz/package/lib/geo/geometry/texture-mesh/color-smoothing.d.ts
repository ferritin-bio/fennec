/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { type Texture } from '@molstar/graphics/gl/texture';
import { ShaderCode } from '@molstar/graphics/gl/shader-code';
import { ValueSpec, AttributeSpec, UniformSpec, TextureSpec, DefineSpec } from '@molstar/graphics/gl/renderable/schema';
import { Vec2, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import { Box3D, type Sphere3D } from '@molstar/core/math/geometry';
import type { TextureMeshValues } from '@molstar/graphics/gl/renderable/texture-mesh';
import type { StorageBuffer } from '@molstar/graphics/gl/compute';
export declare const ColorAccumulateSchema: {
    drawCount: ValueSpec<"number">;
    instanceCount: ValueSpec<"number">;
    stride: ValueSpec<"number">;
    uGroupCount: UniformSpec<"i">;
    aTransform: AttributeSpec<"float32">;
    aInstance: AttributeSpec<"float32">;
    aSample: AttributeSpec<"float32">;
    uGeoTexDim: UniformSpec<"v2">;
    tPosition: TextureSpec<"texture">;
    tGroup: TextureSpec<"texture">;
    uColorTexDim: UniformSpec<"v2">;
    tColor: TextureSpec<"texture">;
    dColorType: DefineSpec<"string">;
    uCurrentSlice: UniformSpec<"f">;
    uCurrentX: UniformSpec<"f">;
    uCurrentY: UniformSpec<"f">;
    uBboxMin: UniformSpec<"v3">;
    uBboxSize: UniformSpec<"v3">;
    uResolution: UniformSpec<"f">;
};
export declare const ColorAccumulateShaderCode: ShaderCode;
interface AccumulateInput {
    /** an upper bound for vertices in the vertex arena (`chunks`) */
    vertexCount: number;
    instanceCount: number;
    groupCount: number;
    transformBuffer: Float32Array;
    instanceBuffer: Float32Array;
    positionTexture: Texture;
    groupTexture: Texture;
    /** the page table and positions of a surface in the vertex arena (WebGPU), instead of the textures; smoothed with
     * compute kernels */
    chunks?: {
        table: StorageBuffer;
        positions: StorageBuffer;
    };
    colorData: Texture;
    colorType: 'group' | 'groupInstance';
}
export declare const ColorNormalizeSchema: {
    drawCount: ValueSpec<"number">;
    instanceCount: ValueSpec<"number">;
    aPosition: AttributeSpec<"float32">;
    uQuadScale: UniformSpec<"v2">;
    tColor: TextureSpec<"texture">;
    tCount: TextureSpec<"texture">;
    uTexSize: UniformSpec<"v2">;
};
export declare const ColorNormalizeShaderCode: ShaderCode;
interface ColorSmoothingInput extends AccumulateInput {
    boundingSphere: Sphere3D;
    invariantBoundingSphere: Sphere3D;
}
export type ColorSmoothingOptions = {
    resolution: number;
    stride: number;
};
/** Grid of the smoothing: the box expanded by `1 + resolution`, two extra cells per axis */
export declare function getGridDim(box: Box3D, resolution: number): Vec3;
/**
 * `resolution`, coarsened in steps of 10% until the 2d atlas of the grid (largest side by `getTextureSide`) fits
 * textures of `maxTextureSize` (larger grids would fail to allocate; WebGPU's limit is often half of WebGL's)
 */
export declare function getFittingResolution(box: Box3D, resolution: number, maxTextureSize: number, getTextureSide: (gridDim: Vec3) => number): number;
export declare function calcTextureMeshColorSmoothing(input: ColorSmoothingInput, options: ColorSmoothingOptions, graphics: GraphicsContext, texture?: Texture): {
    texture: Texture;
    gridDim: Vec3;
    gridTexDim: Vec2;
    gridTransform: Vec4;
    type: string;
};
export declare function applyTextureMeshColorSmoothing(values: TextureMeshValues, options: ColorSmoothingOptions, graphics: GraphicsContext, colorTexture?: Texture): void;
export declare function applyTextureMeshOverpaintSmoothing(values: TextureMeshValues, options: ColorSmoothingOptions, graphics: GraphicsContext, colorTexture?: Texture): void;
export declare function applyTextureMeshTransparencySmoothing(values: TextureMeshValues, options: ColorSmoothingOptions, graphics: GraphicsContext, colorTexture?: Texture): void;
export declare function applyTextureMeshEmissiveSmoothing(values: TextureMeshValues, options: ColorSmoothingOptions, graphics: GraphicsContext, colorTexture?: Texture): void;
export declare function applyTextureMeshSubstanceSmoothing(values: TextureMeshValues, options: ColorSmoothingOptions, graphics: GraphicsContext, colorTexture?: Texture): void;
export {};
//# sourceMappingURL=color-smoothing.d.ts.map