/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Sphere3D } from '@molstar/core/math/geometry';
import type { Mat4, Vec3 } from '@molstar/core/math/linear-algebra';
import type { ComputeContext } from '@molstar/graphics/gl/compute';
import { type ChunkedIsosurfaceResult, type ChunkedSurface } from '@molstar/graphics/gl/compute/marching-cubes/chunks';
import type { IsosurfaceInput } from '@molstar/graphics/gl/compute/marching-cubes/compute';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import { TextureMesh } from './texture-mesh.js';
/**
 * Where an extraction writes: pages of the vertex arena, `surface` reused; `estimate`, the expected vertex count, grows
 * the arena beforehand when needed
 */
export type IsosurfaceTarget = {
    readonly surface?: ChunkedSurface;
    readonly estimate?: number;
};
/**
 * Extracts an isosurface into `target` (see `extractIsosurface`). Called again when the surface did not get all its
 * pages, so it must not rely on inputs that may have changed in between (e.g. shared density textures).
 */
export type IsosurfaceExtraction = (target: IsosurfaceTarget) => Promise<ChunkedIsosurfaceResult>;
/** `computeChunkedIsosurface` into `target` */
export declare function extractIsosurface(graphics: GraphicsContext & {
    compute: ComputeContext;
}, input: IsosurfaceInput, gridDim: Vec3, isoValue: number, transform: Mat4, invert: boolean, target: IsosurfaceTarget): Promise<ChunkedIsosurfaceResult>;
/**
 * The isosurface in pages of the vertex arena, drawn indirectly with the count on the GPU: nothing is read back before
 * drawing. The count, read back afterwards, is drawn directly from then on (`TextureMesh.setDrawnVertexCount`), and keeps
 * the upper bound of the texture mesh (`vertexCount`) and the position iterator's data right; a surface that did not get all its pages (the arena's free pages ran out) is extracted again
 * after the arena grew. The re-extraction handlers of the mesh (`TextureMesh.setReextractionHandler`) run after either
 * changed the vertices data derived from them saw. The expected count, which grows the arena beforehand, is the last
 * count of `textureMesh` (with headroom), else `estimate` (a function: called only then, e.g. a pass over the grid,
 * `estimateIsosurfaceVertexCount`).
 */
export declare function computeTextureMeshIsosurface(graphics: GraphicsContext & {
    compute: ComputeContext;
}, extract: IsosurfaceExtraction, groupCount: number, boundingSphere: Sphere3D, textureMesh?: TextureMesh, estimate?: number | (() => number)): Promise<TextureMesh>;
//# sourceMappingURL=compute-isosurface.d.ts.map