/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { RenderableState } from '@molstar/graphics/gl/renderable';
import { ValueCell } from '@molstar/core/util';
import type { BaseValues } from '@molstar/graphics/gl/renderable/schema';
import type { DrawIndirect } from '@molstar/graphics/gl/compute';
import { LocationIterator } from '../util/location-iterator.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type TransformData } from './transform-data.js';
import type { Theme } from '@molstar/graphics/theme/theme';
import { Clip } from '@molstar/core/util/clip';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { Vec4 } from '@molstar/core/math/linear-algebra/3d/vec4';
export declare const VisualQualityInfo: {
    custom: {};
    auto: {};
    highest: {};
    higher: {};
    high: {};
    medium: {};
    low: {};
    lower: {};
    lowest: {};
};
export type VisualQuality = keyof typeof VisualQualityInfo;
export declare const VisualQualityNames: VisualQuality[];
export declare const VisualQualityOptions: ["auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium", string][];
export declare const ColorSmoothingParams: {
    smoothColors: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "auto"> | PD.NamedParams<PD.Normalize<unknown>, "off"> | PD.NamedParams<PD.Normalize<{
        resolutionFactor: number;
        sampleStride: number;
    }>, "on">>;
};
export type ColorSmoothingParams = typeof ColorSmoothingParams;
export declare function hasColorSmoothingProp(props: PD.Values<any>): props is PD.Values<ColorSmoothingParams>;
export declare function getColorSmoothingProps(smoothColors: PD.Values<ColorSmoothingParams>['smoothColors'], preferSmoothing?: boolean, resolution?: number): {
    resolution: number;
    stride: number;
} | undefined;
export type InstanceGranularityValue = true | false | 'auto';
export declare const InstanceGranularityOptions: [InstanceGranularityValue, string][];
/**
 * Threshold (in `groupCount * instanceCount`, e.g. number of marker-texture
 * slots) above which `instanceGranularity: 'auto'` resolves to `true`.
 */
export declare const AutoInstanceGranularityThreshold = 50000000;
/**
 * Resolves the `instanceGranularity` param value to a boolean.
 */
export declare function resolveInstanceGranularity(value: InstanceGranularityValue, groupCount: number, instanceCount: number): boolean;
export type RenderMergedValue = true | false | 'auto';
export declare const RenderMergedOptions: [RenderMergedValue, string][];
/**
 * Threshold (in number of mergeable units) above which `renderMerged: 'auto'`
 * resolves to `true`.
 */
export declare const AutoRenderMergedThreshold = 100;
/**
 * Resolves the `renderMerged` param value to a boolean.
 */
export declare function resolveRenderMerged(value: RenderMergedValue, unitCount: number): boolean;
export declare namespace BaseGeometry {
    const MaterialCategory: PD.Info;
    const ShadingCategory: PD.Info;
    const CullingLodCategory: PD.Info;
    const CustomQualityParamInfo: PD.Info;
    const Params: {
        alpha: PD.Numeric;
        quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: PD.Group<PD.Normalize<{
            variant: Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: Vec3;
                rotation: PD.Normalize<Clip.Rotation>;
                scale: Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        emissive: PD.Numeric;
        density: PD.Numeric;
        instanceGranularity: PD.Select<InstanceGranularityValue>;
        renderMerged: PD.Select<RenderMergedValue>;
        lod: PD.Vec3;
        cellSize: PD.Numeric;
        batchSize: PD.Numeric;
    };
    type Params = typeof Params;
    type Counts = {
        drawCount: number;
        vertexCount: number;
        groupCount: number;
        instanceCount: number;
    };
    function createSimple(colorValue?: import("@molstar/core/util/color/color").Color, sizeValue?: number, transform?: TransformData): {
        transform: TransformData;
        locationIterator: LocationIterator;
        theme: Theme;
    };
    function createValues(props: PD.Values<Params>, counts: Counts): {
        alpha: ValueCell<number, never>;
        uAlpha: ValueCell<number, never>;
        uVertexCount: ValueCell<number, never>;
        aVertex: ValueCell<Float32Array<ArrayBuffer>, never>;
        uGroupCount: ValueCell<number, never>;
        drawCount: ValueCell<number, never>;
        drawIndirect: ValueCell<DrawIndirect | undefined, never>;
        uMetalness: ValueCell<number, never>;
        uRoughness: ValueCell<number, never>;
        uBumpiness: ValueCell<number, never>;
        uEmissive: ValueCell<number, never>;
        uDensity: ValueCell<number, never>;
        dClipObjectCount: ValueCell<number, never>;
        dClipVariant: ValueCell<Clip.Variant, never>;
        uClipObjectType: ValueCell<number[], never>;
        uClipObjectInvert: ValueCell<boolean[], never>;
        uClipObjectPosition: ValueCell<number[], never>;
        uClipObjectRotation: ValueCell<number[], never>;
        uClipObjectScale: ValueCell<number[], never>;
        uClipObjectTransform: ValueCell<number[], never>;
        uInstanceGranularity: ValueCell<boolean, never>;
        uLod: ValueCell<Vec4, never>;
    };
    function updateValues(values: BaseValues, props: PD.Values<Params>): void;
    function createRenderableState(props?: Partial<PD.Values<Params>>): RenderableState;
    function updateRenderableState(state: RenderableState, props: PD.Values<Params>): void;
}
//# sourceMappingURL=base.d.ts.map