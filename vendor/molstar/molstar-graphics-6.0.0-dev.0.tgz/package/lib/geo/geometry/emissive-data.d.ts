/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ValueCell } from '@molstar/core/util/value-cell';
import { Vec2, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import { type Texture } from '@molstar/graphics/gl/texture';
import { type LayerType } from './layer-type.js';
export type EmissiveType = LayerType;
export type EmissiveData = {
    tEmissive: ValueCell<TextureImage<Uint8Array>>;
    uEmissiveTexDim: ValueCell<Vec2>;
    dEmissive: ValueCell<boolean>;
    emissiveAverage: ValueCell<number>;
    tEmissiveGrid: ValueCell<Texture>;
    uEmissiveGridDim: ValueCell<Vec3>;
    uEmissiveGridTransform: ValueCell<Vec4>;
    /** the layer type (`EmissiveType`) */
    emissiveType: ValueCell<string>;
    /** its define (`getLayerTypeDefine`) */
    dEmissiveType: ValueCell<string>;
    uEmissiveStrength: ValueCell<number>;
};
export declare function applyEmissiveValue(array: Uint8Array, start: number, end: number, value: number): boolean;
export declare function getEmissiveAverage(array: Uint8Array, count: number): number;
export declare function clearEmissive(array: Uint8Array, start: number, end: number): void;
/** Sets the layer type `type` and its define (`getLayerTypeDefine`) of `values` */
export declare function setEmissiveType(values: Pick<EmissiveData, 'emissiveType' | 'dEmissiveType'>, type: EmissiveType | string): void;
export declare function createEmissive(count: number, type: EmissiveType, emissiveData?: EmissiveData): EmissiveData;
export declare function createEmptyEmissive(emissiveData?: EmissiveData): EmissiveData;
//# sourceMappingURL=emissive-data.d.ts.map