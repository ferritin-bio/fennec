/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ValueCell } from '@molstar/core/util';
import { Vec2 } from '@molstar/core/math/linear-algebra';
import { Sphere3D } from '@molstar/core/math/geometry';
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import { type GroupMapping } from '../util.js';
/**
 * Center (xyz) and group per item, shared by the geometries drawn as one quad of 6 vertices per item
 * (spheres, points): the buffers, the derived bounding sphere and group mapping, and the
 * `tPositionGroup` texture the shaders read the item data from (vertex pulling)
 */
export interface CenterGroupData {
    readonly centerBuffer: ValueCell<Float32Array>;
    readonly groupBuffer: ValueCell<Float32Array>;
    /** center xyz and group per item, ordered by level of detail when strides are given */
    readonly positionGroup: ValueCell<TextureImage<Float32Array>>;
    readonly texDim: ValueCell<Vec2>;
    getBoundingSphere(): Sphere3D;
    getGroupMapping(): GroupMapping;
    setBoundingSphere(boundingSphere: Sphere3D): void;
    hasBoundingSphere(): boolean;
    /**
     * Writes the items to `positionGroup`; with `strides`, items are reordered into levels of detail
     * (items of a coarser level first) and the vertex offsets of the levels are returned
     */
    updatePositionGroup(strides?: number[]): number[] | undefined;
}
export declare function createCenterGroupData(centers: Float32Array, groups: Float32Array, getCount: () => number): CenterGroupData;
/**
 * Writes center and group per item to `out`; returns the vertex offsets (6 per item) of the levels
 * of detail when `strides` are given
 */
export declare function setPositionGroup(out: TextureImage<Float32Array>, centers: Float32Array, groups: Float32Array, count: number, strides: number[]): number[] | undefined;
//# sourceMappingURL=center-group.d.ts.map