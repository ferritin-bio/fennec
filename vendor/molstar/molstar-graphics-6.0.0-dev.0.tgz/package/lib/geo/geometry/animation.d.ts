/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ValueCell } from '@molstar/core/util';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export type AnimationData = {
    uWiggleSpeed: ValueCell<number>;
    uWiggleAmplitude: ValueCell<number>;
    uWiggleFrequency: ValueCell<number>;
    uWiggleMode: ValueCell<number>;
    uTumbleSpeed: ValueCell<number>;
    uTumbleAmplitude: ValueCell<number>;
    uTumbleFrequency: ValueCell<number>;
};
export declare function getAnimationParam(): PD.Group<PD.Normalize<{
    wiggleMode: "group" | "position";
    wiggleSpeed: number;
    wiggleAmplitude: number;
    wiggleFrequency: number;
    tumbleSpeed: number;
    tumbleAmplitude: number;
    tumbleFrequency: number;
}>>;
export type AnimationParam = ReturnType<typeof getAnimationParam>;
export type AnimationProps = AnimationParam['defaultValue'];
export declare function areAnimationPropsEqual(a: AnimationProps, b: AnimationProps): boolean;
export declare function createAnimationValues(props: AnimationProps): {
    uWiggleSpeed: ValueCell<number, never>;
    uWiggleAmplitude: ValueCell<number, never>;
    uWiggleFrequency: ValueCell<number, never>;
    uWiggleMode: ValueCell<number, never>;
    uTumbleSpeed: ValueCell<number, never>;
    uTumbleAmplitude: ValueCell<number, never>;
    uTumbleFrequency: ValueCell<number, never>;
};
export declare function updateAnimationValues(values: AnimationData, props: AnimationProps): void;
//# sourceMappingURL=animation.d.ts.map