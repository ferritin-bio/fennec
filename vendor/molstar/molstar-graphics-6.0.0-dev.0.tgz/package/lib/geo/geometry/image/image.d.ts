/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import { Sphere3D } from '@molstar/core/math/geometry';
import { Vec2, Vec3, Quat, Mat4 } from '@molstar/core/math/linear-algebra';
import { ValueCell } from '@molstar/core/util';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { GeometryUtils } from '../geometry.js';
export declare const InterpolationTypes: {
    nearest: string;
    catmulrom: string;
    mitchell: string;
    bspline: string;
};
export type InterpolationTypes = keyof typeof InterpolationTypes;
export declare const InterpolationTypeNames: InterpolationTypes[];
export { Image };
interface Image {
    readonly kind: 'image';
    readonly imageTexture: ValueCell<TextureImage<Uint8Array>>;
    readonly imageTextureDim: ValueCell<Vec2>;
    readonly cornerBuffer: ValueCell<Float32Array>;
    readonly groupTexture: ValueCell<TextureImage<Uint8Array>>;
    readonly valueTexture: ValueCell<TextureImage<Float32Array>>;
    readonly trimType: ValueCell<number>;
    readonly trimCenter: ValueCell<Vec3>;
    readonly trimRotation: ValueCell<Quat>;
    readonly trimScale: ValueCell<Vec3>;
    readonly trimTransform: ValueCell<Mat4>;
    readonly isoLevel: ValueCell<number>;
    /** Bounding sphere of the image */
    readonly boundingSphere: Sphere3D;
    setBoundingSphere(boundingSphere: Sphere3D): void;
    hasBoundingSphere(): boolean;
    readonly meta: {
        [k: string]: unknown;
    };
}
declare namespace Image {
    type Trim = {
        type: 0 | 1 | 2 | 3 | 4 | 5;
        center: Vec3;
        rotation: Quat;
        scale: Vec3;
        transform: Mat4;
    };
    function createEmptyTrim(): Trim;
    function create(imageTexture: TextureImage<Uint8Array>, corners: Float32Array, groupTexture: TextureImage<Uint8Array>, valueTexture: TextureImage<Float32Array>, trim: Trim, isoLevel: number, image?: Image): Image;
    function createEmpty(image?: Image): Image;
    const Params: {
        alpha: PD.Numeric;
        quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: PD.Group<PD.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: Vec3;
                rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: Vec3;
                transform: Mat4;
            }>[];
        }>>;
        emissive: PD.Numeric;
        density: PD.Numeric;
        instanceGranularity: PD.Select<import("../base.js").InstanceGranularityValue>;
        renderMerged: PD.Select<import("../base.js").RenderMergedValue>;
        lod: PD.Vec3;
        cellSize: PD.Numeric;
        batchSize: PD.Numeric;
        interpolation: PD.Select<"bspline" | "catmulrom" | "mitchell" | "nearest">;
    };
    type Params = typeof Params;
    const Utils: GeometryUtils<Image, Params>;
}
//# sourceMappingURL=image.d.ts.map