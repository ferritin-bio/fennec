/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ValueCell } from '@molstar/core/util/value-cell';
import { Vec2 } from '@molstar/core/math/linear-algebra';
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import type { Clipping } from '@molstar/graphics/theme/clipping';
export type ClippingType = 'instance' | 'groupInstance';
export type ClippingData = {
    tClipping: ValueCell<TextureImage<Uint8Array>>;
    uClippingTexDim: ValueCell<Vec2>;
    dClipping: ValueCell<boolean>;
    /** the type (`ClippingType`); the object uniform `uInstanceGranularity` selects the index */
    clippingType: ValueCell<string>;
};
export declare function applyClippingGroups(array: Uint8Array, start: number, end: number, groups: Clipping.Groups): boolean;
export declare function clearClipping(array: Uint8Array, start: number, end: number): void;
export declare function createClipping(count: number, type: ClippingType, clippingData?: ClippingData): ClippingData;
export declare function createEmptyClipping(clippingData?: ClippingData): ClippingData;
//# sourceMappingURL=clipping-data.d.ts.map