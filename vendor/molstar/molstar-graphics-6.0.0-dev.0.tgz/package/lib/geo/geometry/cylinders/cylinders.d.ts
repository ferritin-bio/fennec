/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ValueCell } from '@molstar/core/util';
import { type Mat4, Vec3 } from '@molstar/core/math/linear-algebra';
import { type GroupMapping } from '../../util.js';
import type { GeometryUtils } from '../geometry.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Sphere3D } from '@molstar/core/math/geometry';
import type { Color } from '@molstar/core/util/color';
export interface Cylinders {
    readonly kind: 'cylinders';
    /** Number of cylinders */
    cylinderCount: number;
    /** Mapping buffer as array of uvw values wrapped in a value cell */
    readonly mappingBuffer: ValueCell<Float32Array>;
    /** Index buffer as array of vertex index triplets wrapped in a value cell */
    readonly indexBuffer: ValueCell<Uint32Array>;
    /** Group buffer as array of group ids for each vertex wrapped in a value cell */
    readonly groupBuffer: ValueCell<Float32Array>;
    /** Cylinder start buffer as array of xyz values wrapped in a value cell */
    readonly startBuffer: ValueCell<Float32Array>;
    /** Cylinder end buffer as array of xyz values wrapped in a value cell */
    readonly endBuffer: ValueCell<Float32Array>;
    /** Cylinder scale buffer as array of scaling factors wrapped in a value cell */
    readonly scaleBuffer: ValueCell<Float32Array>;
    /** Cylinder cap buffer as array of cap flags wrapped in a value cell */
    readonly capBuffer: ValueCell<Float32Array>;
    /**
     * Cylinder colorMode buffer as array of coloring modes flags wrapped in a value cell
     * - for colorMode between 0 and 1 use colorMode to interpolate
     * - for colorMode == 2 do nothing, i.e., use given theme color
     * - for colorMode == 3 use position on cylinder axis to interpolate
     */
    readonly colorModeBuffer: ValueCell<Float32Array>;
    /** Bounding sphere of the cylinders */
    readonly boundingSphere: Sphere3D;
    /** Maps group ids to cylinder indices */
    readonly groupMapping: GroupMapping;
    setBoundingSphere(boundingSphere: Sphere3D): void;
    hasBoundingSphere(): boolean;
}
export declare namespace Cylinders {
    function create(mappings: Float32Array, indices: Uint32Array, groups: Float32Array, starts: Float32Array, ends: Float32Array, scales: Float32Array, caps: Float32Array, colorModes: Float32Array, cylinderCount: number, cylinders?: Cylinders): Cylinders;
    function createEmpty(cylinders?: Cylinders): Cylinders;
    function transform(cylinders: Cylinders, t: Mat4): void;
    const Params: {
        alpha: PD.Numeric;
        quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: PD.Group<PD.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: Vec3;
                rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: Vec3;
                transform: Mat4;
            }>[];
        }>>;
        emissive: PD.Numeric;
        density: PD.Numeric;
        instanceGranularity: PD.Select<import("../base.js").InstanceGranularityValue>;
        renderMerged: PD.Select<import("../base.js").RenderMergedValue>;
        lod: PD.Vec3;
        cellSize: PD.Numeric;
        batchSize: PD.Numeric;
        sizeFactor: PD.Numeric;
        sizeAspectRatio: PD.Numeric;
        doubleSided: PD.BooleanParam;
        ignoreLight: PD.BooleanParam;
        celShaded: PD.BooleanParam;
        xrayShaded: PD.Select<"inverted" | boolean>;
        transparentBackfaces: PD.Select<"off" | "on" | "opaque">;
        solidInterior: PD.BooleanParam;
        bumpFrequency: PD.Numeric;
        bumpAmplitude: PD.Numeric;
        interior: PD.Group<PD.Normalize<{
            color: Color;
            colorStrength: number;
            substance: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: PD.Group<PD.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
        colorMode: PD.Select<"default" | "interpolate">;
    };
    type Params = typeof Params;
    const Utils: GeometryUtils<Cylinders, Params>;
}
//# sourceMappingURL=cylinders.d.ts.map