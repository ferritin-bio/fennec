/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec4 } from '@molstar/core/math/linear-algebra/3d/vec4';
import { Color } from '@molstar/core/util/color/color';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { ValueCell } from '@molstar/core/util/value-cell';
export type InteriorData = {
    uInteriorColor: ValueCell<Vec4>;
    uInteriorSubstance: ValueCell<Vec4>;
};
export declare function getInteriorParam(): PD.Group<PD.Normalize<{
    color: Color;
    colorStrength: number;
    substance: PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    substanceStrength: number;
}>>;
export type InteriorParam = ReturnType<typeof getInteriorParam>;
export type InteriorProps = InteriorParam['defaultValue'];
export declare function areInteriorPropsEquals(a: InteriorProps, b: InteriorProps): boolean;
export declare function getInteriorColor(props: InteriorProps, out: Vec4): Vec4;
export declare function getInteriorSubstance(props: InteriorProps, out: Vec4): Vec4;
export declare function createInteriorValues(props: InteriorProps): {
    uInteriorColor: ValueCell<Vec4, never>;
    uInteriorSubstance: ValueCell<Vec4, never>;
};
export declare function updateInteriorValues(values: InteriorData, props: InteriorProps): void;
//# sourceMappingURL=interior.d.ts.map