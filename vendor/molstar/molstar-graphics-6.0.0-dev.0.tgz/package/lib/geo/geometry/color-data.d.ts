/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ValueCell } from '@molstar/core/util';
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import { Color } from '@molstar/core/util/color';
import { Vec2, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import type { LocationIterator } from '../util/location-iterator.js';
import type { ColorTheme, ColorVolume } from '@molstar/graphics/theme/color';
import { type Texture } from '@molstar/graphics/gl/texture';
export type ColorTypeLocation = 'uniform' | 'instance' | 'group' | 'groupInstance' | 'vertex' | 'vertexInstance';
export type ColorTypeGrid = 'volume' | 'volumeInstance';
export type ColorTypeDirect = 'direct';
export type ColorType = ColorTypeLocation | ColorTypeGrid | ColorTypeDirect;
export type ColorData = {
    uColor: ValueCell<Vec3>;
    tColor: ValueCell<TextureImage<Uint8Array>>;
    tColorGrid: ValueCell<Texture>;
    uPaletteDomain: ValueCell<Vec2>;
    uPaletteDefault: ValueCell<Vec3>;
    tPalette: ValueCell<TextureImage<Uint8Array>>;
    uColorTexDim: ValueCell<Vec2>;
    uColorGridDim: ValueCell<Vec3>;
    uColorGridTransform: ValueCell<Vec4>;
    uColorIndexType: ValueCell<number>;
    dColorType: ValueCell<string>;
    /** the `ColorType` */
    colorType: ValueCell<string>;
    dUsePalette: ValueCell<boolean>;
};
/**
 * How the color types that share a define read their data (`uColorIndexType`): one program for each of 'texture' (the
 * index of `tColor`) and 'grid' (the position `tColorGrid` is sampled at), the shaders select at runtime
 */
export declare const ColorTypeIndex: {
    readonly [T in ColorType]?: number;
};
/**
 * The define value of the color type `type`: the types read from `tColor` by index share 'texture', the grid types
 * share 'grid' (see `ColorTypeIndex`)
 */
export declare function getColorTypeDefine(type: ColorType | string): string;
/** Sets the color type `type` (a `ColorType`), its define and index (`ColorTypeIndex`) of `values` */
export declare function setColorType(values: Pick<ColorData, 'colorType' | 'dColorType' | 'uColorIndexType'>, type: ColorType | string): void;
/** Whether colors of `type` are sampled at vertex positions (the position iterator of `createColors`) */
export declare function isPositionColorType(type: ColorType): type is "vertex" | "vertexInstance";
export declare function createColors(locationIt: LocationIterator, positionIt: LocationIterator, colorTheme: ColorTheme<any, any>, colorData?: ColorData): ColorData;
export declare function createValueColor(value: Color, colorData?: ColorData): ColorData;
export declare function createTextureColor(colors: TextureImage<Uint8Array>, type: ColorType, colorData?: ColorData): ColorData;
export declare function createGridColor(grid: ColorVolume, type: ColorType, colorData?: ColorData): ColorData;
//# sourceMappingURL=color-data.d.ts.map