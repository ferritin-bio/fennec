/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Box3D, Axes3D } from '@molstar/core/math/geometry';
import { MeshBuilder } from '../mesh-builder.js';
export declare function addBoundingBox(state: MeshBuilder.State, box: Box3D, radius: number, detail: number, radialSegments: number): void;
export declare function addOrientedBox(state: MeshBuilder.State, axes: Axes3D, radiusScale: number, detail: number, radialSegments: number): void;
//# sourceMappingURL=box.d.ts.map