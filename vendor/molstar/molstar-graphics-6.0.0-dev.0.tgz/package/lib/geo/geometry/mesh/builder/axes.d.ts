/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { MeshBuilder } from '../mesh-builder.js';
import { Axes3D } from '@molstar/core/math/geometry';
export declare function addAxes(state: MeshBuilder.State, axes: Axes3D, radiusScale: number, detail: number, radialSegments: number): void;
//# sourceMappingURL=axes.d.ts.map