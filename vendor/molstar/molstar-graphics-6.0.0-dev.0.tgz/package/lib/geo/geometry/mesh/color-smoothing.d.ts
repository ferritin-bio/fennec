/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { MeshValues } from '@molstar/graphics/gl/renderable/mesh';
import { type TextureImage } from '@molstar/graphics/gl/renderable/util';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { Texture } from '@molstar/graphics/gl/texture';
import { type Sphere3D } from '@molstar/core/math/geometry';
import { Vec2, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
interface ColorSmoothingInput {
    vertexCount: number;
    instanceCount: number;
    groupCount: number;
    transformBuffer: Float32Array;
    instanceBuffer: Float32Array;
    positionBuffer: Float32Array;
    groupBuffer: Float32Array;
    colorData: TextureImage<Uint8Array>;
    colorType: 'group' | 'groupInstance';
    boundingSphere: Sphere3D;
    invariantBoundingSphere: Sphere3D;
    itemSize: 4 | 1;
}
export type ColorSmoothingOptions = {
    resolution: number;
    stride: number;
};
export declare function calcMeshColorSmoothing(input: ColorSmoothingInput, options: ColorSmoothingOptions, graphics?: GraphicsContext, texture?: Texture): {
    kind: 'volume';
    texture: Texture;
    gridTexDim: Vec2;
    gridDim: Vec3;
    gridTransform: Vec4;
    type: "volume" | "volumeInstance";
    texDim?: undefined;
} | {
    gridTexDim?: undefined;
    gridDim?: undefined;
    gridTransform?: undefined;
    kind: 'vertex';
    texture: TextureImage<Uint8Array<ArrayBufferLike>>;
    texDim: Vec2;
    type: string;
};
interface ColorInterpolationInput {
    vertexCount: number;
    instanceCount: number;
    transformBuffer: Float32Array;
    positionBuffer: Float32Array;
    colorType: 'volumeInstance' | 'volume';
    grid: Uint8Array;
    gridTexDim: Vec2;
    gridDim: Vec3;
    gridTransform: Vec4;
    vertexStride: 3 | 4;
    colorStride: 1 | 3 | 4;
    outputStride: 1 | 3 | 4;
    itemOffset?: 0 | 1 | 2 | 3;
}
export declare function getTrilinearlyInterpolated(input: ColorInterpolationInput): TextureImage<Uint8Array>;
export declare function applyMeshColorSmoothing(values: MeshValues, options: ColorSmoothingOptions, graphics?: GraphicsContext, colorTexture?: Texture): void;
export declare function applyMeshOverpaintSmoothing(values: MeshValues, options: ColorSmoothingOptions, graphics?: GraphicsContext, colorTexture?: Texture): void;
export declare function applyMeshTransparencySmoothing(values: MeshValues, options: ColorSmoothingOptions, graphics?: GraphicsContext, colorTexture?: Texture): void;
export declare function applyMeshEmissiveSmoothing(values: MeshValues, options: ColorSmoothingOptions, graphics?: GraphicsContext, colorTexture?: Texture): void;
export declare function applyMeshSubstanceSmoothing(values: MeshValues, options: ColorSmoothingOptions, graphics?: GraphicsContext, colorTexture?: Texture): void;
export {};
//# sourceMappingURL=color-smoothing.d.ts.map