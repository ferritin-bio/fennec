/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Texture } from '@molstar/graphics/gl/texture';
import { Box3D, Sphere3D } from '@molstar/core/math/geometry';
import { Mat4, Vec3, Vec4 } from '@molstar/core/math/linear-algebra';
import { ValueCell } from '@molstar/core/util';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { GeometryUtils } from '../geometry.js';
import { Grid } from '@molstar/model/model/volume';
export interface DirectVolume {
    readonly kind: 'direct-volume';
    readonly gridTexture: ValueCell<Texture>;
    readonly gridTextureDim: ValueCell<Vec3>;
    readonly gridDimension: ValueCell<Vec3>;
    readonly gridStats: ValueCell<Vec4>;
    readonly bboxSize: ValueCell<Vec3>;
    readonly bboxMin: ValueCell<Vec3>;
    readonly bboxMax: ValueCell<Vec3>;
    readonly transform: ValueCell<Mat4>;
    readonly cellDim: ValueCell<Vec3>;
    readonly unitToCartn: ValueCell<Mat4>;
    readonly cartnToUnit: ValueCell<Mat4>;
    readonly packedGroup: ValueCell<boolean>;
    readonly axisOrder: ValueCell<Vec3>;
    readonly dataType: ValueCell<'byte' | 'float' | 'halfFloat'>;
    /** Bounding sphere of the volume */
    readonly boundingSphere: Sphere3D;
    setBoundingSphere(boundingSphere: Sphere3D): void;
    hasBoundingSphere(): boolean;
    readonly meta: {
        [k: string]: unknown;
    };
}
export declare namespace DirectVolume {
    function create(bbox: Box3D, gridDimension: Vec3, transform: Mat4, unitToCartn: Mat4, cellDim: Vec3, texture: Texture, stats: Grid['stats'], packedGroup: boolean, axisOrder: Vec3, dataType: 'byte' | 'float' | 'halfFloat', directVolume?: DirectVolume): DirectVolume;
    function createEmpty(directVolume?: DirectVolume): DirectVolume;
    const Params: {
        alpha: PD.Numeric;
        quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: PD.Group<PD.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: Vec3;
                rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: Vec3;
                transform: Mat4;
            }>[];
        }>>;
        emissive: PD.Numeric;
        density: PD.Numeric;
        instanceGranularity: PD.Select<import("../base.js").InstanceGranularityValue>;
        renderMerged: PD.Select<import("../base.js").RenderMergedValue>;
        lod: PD.Vec3;
        cellSize: PD.Numeric;
        batchSize: PD.Numeric;
        ignoreLight: PD.BooleanParam;
        celShaded: PD.BooleanParam;
        xrayShaded: PD.Select<"inverted" | boolean>;
        controlPoints: PD.LineGraph;
        stepsPerCell: PD.Numeric;
        jumpLength: PD.Numeric;
    };
    type Params = typeof Params;
    const Utils: GeometryUtils<DirectVolume, Params>;
}
//# sourceMappingURL=direct-volume.d.ts.map