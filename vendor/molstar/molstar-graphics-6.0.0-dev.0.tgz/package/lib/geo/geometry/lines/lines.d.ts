/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ValueCell } from '@molstar/core/util';
import { type Mat4, Vec3 } from '@molstar/core/math/linear-algebra';
import { type GroupMapping } from '../../util.js';
import type { GeometryUtils } from '../geometry.js';
import type { Mesh } from '../mesh/mesh.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Sphere3D } from '@molstar/core/math/geometry';
/** Wide line */
export interface Lines {
    readonly kind: 'lines';
    /** Number of lines */
    lineCount: number;
    /** Number of vertices */
    vertexCount: number;
    /** Mapping buffer as array of xy values wrapped in a value cell */
    readonly mappingBuffer: ValueCell<Float32Array>;
    /** Index buffer as array of vertex index triplets wrapped in a value cell */
    readonly indexBuffer: ValueCell<Uint32Array>;
    /** Group buffer as array of group ids for each vertex wrapped in a value cell */
    readonly groupBuffer: ValueCell<Float32Array>;
    /** Line start buffer as array of xyz values wrapped in a value cell */
    readonly startBuffer: ValueCell<Float32Array>;
    /** Line end buffer as array of xyz values wrapped in a value cell */
    readonly endBuffer: ValueCell<Float32Array>;
    /** Number of strips wrapped in a value cell */
    readonly stripCount: ValueCell<number>;
    /** Strip buffer as array of vertex offsets wrapped in a value cell */
    readonly stripBuffer: ValueCell<Uint32Array>;
    /** Bounding sphere of the lines */
    readonly boundingSphere: Sphere3D;
    /** Maps group ids to line indices */
    readonly groupMapping: GroupMapping;
    setBoundingSphere(boundingSphere: Sphere3D): void;
    hasBoundingSphere(): boolean;
}
export declare namespace Lines {
    function create(mappings: Float32Array, indices: Uint32Array, groups: Float32Array, starts: Float32Array, ends: Float32Array, strips: Uint32Array, lineCount: number, vertexCount: number, stripCount: number, lines?: Lines): Lines;
    function createEmpty(lines?: Lines): Lines;
    function fromMesh(mesh: Mesh, lines?: Lines): Lines;
    function transform(lines: Lines, t: Mat4): void;
    const Params: {
        alpha: PD.Numeric;
        quality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        material: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clip: PD.Group<PD.Normalize<{
            variant: import("@molstar/core/util/clip").Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: Vec3;
                rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                scale: Vec3;
                transform: Mat4;
            }>[];
        }>>;
        emissive: PD.Numeric;
        density: PD.Numeric;
        instanceGranularity: PD.Select<import("../base.js").InstanceGranularityValue>;
        renderMerged: PD.Select<import("../base.js").RenderMergedValue>;
        lod: PD.Vec3;
        cellSize: PD.Numeric;
        batchSize: PD.Numeric;
        sizeFactor: PD.Numeric;
        lineSizeAttenuation: PD.BooleanParam;
        animation: PD.Group<PD.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
    };
    type Params = typeof Params;
    const Utils: GeometryUtils<Lines, Params>;
}
//# sourceMappingURL=lines.d.ts.map