/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { LinesBuilder } from '../lines-builder.js';
import type { Mat4 } from '@molstar/core/math/linear-algebra/3d/mat4';
/**
 * Add a wireframe box to a LinesBuilder.
 */
export declare function addBox(builder: LinesBuilder, transform: Mat4, group: number): void;
//# sourceMappingURL=box.d.ts.map