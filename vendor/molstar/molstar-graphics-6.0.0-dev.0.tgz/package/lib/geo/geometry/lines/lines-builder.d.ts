/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { Lines } from './lines.js';
import { type Mat4, Vec3 } from '@molstar/core/math/linear-algebra';
import type { Cage } from '../../primitive/cage.js';
export interface LinesBuilder {
    add(startX: number, startY: number, startZ: number, endX: number, endY: number, endZ: number, group: number): void;
    addVec(start: Vec3, end: Vec3, group: number): void;
    addFixedCountDashes(start: Vec3, end: Vec3, segmentCount: number, group: number): void;
    addFixedLengthDashes(start: Vec3, end: Vec3, segmentLength: number, group: number): void;
    addCage(t: Mat4, cage: Cage, group: number): void;
    getLines(): Lines;
}
export declare namespace LinesBuilder {
    function create(initialCount?: number, chunkSize?: number, lines?: Lines): LinesBuilder;
}
export interface StripLinesBuilder {
    start(group: number): void;
    add(x: number, y: number, z: number): void;
    addVec(v: Vec3): void;
    end(): void;
    getLines(): Lines;
}
export declare namespace StripLinesBuilder {
    function create(initialCount?: number, chunkSize?: number, lines?: Lines): StripLinesBuilder;
}
//# sourceMappingURL=lines-builder.d.ts.map