/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mesh } from './mesh/mesh.js';
import { Points } from './points/points.js';
import { Text } from './text/text.js';
import type { RenderableState } from '@molstar/graphics/gl/renderable';
import type { LocationIterator } from '../util/location-iterator.js';
import type { ColorType } from './color-data.js';
import type { SizeType } from './size-data.js';
import { Lines } from './lines/lines.js';
import type { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { DirectVolume } from './direct-volume/direct-volume.js';
import type { Color } from '@molstar/core/util/color';
import { Spheres } from './spheres/spheres.js';
import type { TransformData } from './transform-data.js';
import type { Theme } from '@molstar/graphics/theme/theme';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { GeometryRequest } from './request.js';
import type { RenderObjectValues } from '@molstar/graphics/gl/render-object';
import { TextureMesh } from './texture-mesh/texture-mesh.js';
import { Image } from './image/image.js';
import { Cylinders } from './cylinders/cylinders.js';
export type GeometryKind = 'mesh' | 'points' | 'spheres' | 'cylinders' | 'text' | 'lines' | 'direct-volume' | 'image' | 'texture-mesh';
export type Geometry<T extends GeometryKind = GeometryKind> = T extends 'mesh' ? Mesh : T extends 'points' ? Points : T extends 'spheres' ? Spheres : T extends 'cylinders' ? Cylinders : T extends 'text' ? Text : T extends 'lines' ? Lines : T extends 'direct-volume' ? DirectVolume : T extends 'image' ? Image : T extends 'texture-mesh' ? TextureMesh : never;
type GeometryParams<T extends GeometryKind> = T extends 'mesh' ? Mesh.Params : T extends 'points' ? Points.Params : T extends 'spheres' ? Spheres.Params : T extends 'cylinders' ? Cylinders.Params : T extends 'text' ? Text.Params : T extends 'lines' ? Lines.Params : T extends 'direct-volume' ? DirectVolume.Params : T extends 'image' ? Image.Params : T extends 'texture-mesh' ? TextureMesh.Params : never;
export interface GeometryUtils<G extends Geometry, P extends PD.Params = GeometryParams<G['kind']>, V = RenderObjectValues<G['kind']>> {
    Params: P;
    createEmpty(geometry?: G): G;
    createValues(geometry: G, transform: TransformData, locationIt: LocationIterator, theme: Theme, props: PD.Values<P>): V;
    createValuesSimple(geometry: G, props: Partial<PD.Values<P>>, colorValue: Color, sizeValue: number, transform?: TransformData): V;
    updateValues(values: V, props: PD.Values<P>): void;
    updateBoundingSphere(values: V, geometry: G): void;
    createRenderableState(props: PD.Values<P>): RenderableState;
    updateRenderableState(state: RenderableState, props: PD.Values<P>): void;
    createPositionIterator(geometry: G, transform: TransformData): LocationIterator;
    /**
     * Readies data of `geometry` that creating or updating values needs (`request`, e.g. GPU data read back for the
     * position iterator); undefined when there is nothing to do, so that updates stay synchronous (kinds whose data is on
     * the CPU omit it)
     */
    prepare?(geometry: G, request: GeometryRequest, graphics: GraphicsContext | undefined): Promise<void> | undefined;
    /**
     * False where `geometry` relies on what `graphics` lacks (e.g. a mesh with varying groups without flat
     * interpolation), see `makeCompatible`; kinds without such dependencies omit it
     */
    isCompatible?(geometry: G, graphics: GraphicsContext): boolean;
    /** Changes `geometry` in place so that it draws correctly with `graphics` (where `isCompatible` is false) */
    makeCompatible?(geometry: G, graphics: GraphicsContext): void;
}
export declare namespace Geometry {
    type Params<G extends Geometry> = GeometryParams<G['kind']>;
    function getDrawCount(geometry: Geometry): number;
    function getVertexCount(geometry: Geometry): number;
    function getGroupCount(geometry: Geometry): number;
    function getUtils<G extends Geometry>(geometry: G): GeometryUtils<G>;
    function getGranularity<T extends ColorType | SizeType>(locationIt: LocationIterator, granularity: T): "group" | T;
}
export {};
//# sourceMappingURL=geometry.d.ts.map