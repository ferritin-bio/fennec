/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { StringLike } from '@molstar/core/util/string-like';
import { ReaderResult as Result } from '../result.js';
import { DynamoTblSchema, type DynamoTblTable } from './schema.js';
export type DynamoTblFieldName = keyof DynamoTblSchema;
export interface DynamoTblFile {
    readonly rowCount: number;
    readonly fieldNames: ReadonlyArray<DynamoTblFieldName>;
    readonly fields: DynamoTblTable;
}
export declare function parseDynamoTbl(data: StringLike): Task<Result<DynamoTblFile>>;
//# sourceMappingURL=tbl.d.ts.map