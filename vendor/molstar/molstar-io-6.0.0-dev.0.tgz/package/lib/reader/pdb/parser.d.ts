/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PdbFile } from './schema.js';
import { Task } from '@molstar/core/task';
import { ReaderResult } from '../result.js';
import type { StringLike } from '@molstar/core/util/string-like';
export declare function parsePDB(data: StringLike, id?: string, variant?: 'pdb' | 'pdbqt' | 'pqr'): Task<ReaderResult<PdbFile>>;
//# sourceMappingURL=parser.d.ts.map