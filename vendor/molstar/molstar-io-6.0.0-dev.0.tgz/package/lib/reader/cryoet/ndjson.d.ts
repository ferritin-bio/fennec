/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { StringLike } from '@molstar/core/util/string-like';
import { ReaderResult as Result } from '../result.js';
interface OrientedPoint {
    readonly type: 'orientedPoint';
    readonly location: {
        readonly x: number;
        readonly y: number;
        readonly z: number;
    };
    readonly xyz_rotation_matrix: [[number, number, number], [number, number, number], [number, number, number]];
}
interface Point {
    readonly type: 'point';
    readonly location: {
        readonly x: number;
        readonly y: number;
        readonly z: number;
    };
}
export type CryoEtDataPortalNdjsonRecord = OrientedPoint | Point;
export interface CryoEtDataPortalNdjsonFile {
    readonly records: ReadonlyArray<CryoEtDataPortalNdjsonRecord>;
}
export declare function parseCryoEtDataPortalNdjson(data: StringLike): Task<Result<CryoEtDataPortalNdjsonFile>>;
export {};
//# sourceMappingURL=ndjson.d.ts.map