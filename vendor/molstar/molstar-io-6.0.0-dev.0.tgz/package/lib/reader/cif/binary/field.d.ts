/**
 * Copyright (c) 2017-2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type * as Data from '../data-model.js';
import { type EncodedColumn } from '@molstar/io/common/binary-cif';
export declare function Field(column: EncodedColumn): Data.CifField;
//# sourceMappingURL=field.d.ts.map