/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Ivan Niukanen <57656076+niukanen1@users.noreply.github.com>
 */
import * as Data from '../data-model.js';
import { ReaderResult as Result } from '../../result.js';
import { Task } from '@molstar/core/task';
export declare function parseCifBinary(data: Uint8Array): Task<Result<Data.CifFile>>;
//# sourceMappingURL=parser.d.ts.map