/**
 * Copyright (c) 2018-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Column } from '@molstar/core/data/db';
export declare const mmCIF_residueId_schema: {
    label_comp_id: Column.Schema.Str;
    label_seq_id: Column.Schema.Int;
    pdbx_PDB_ins_code: Column.Schema.Str;
    label_asym_id: Column.Schema.Str;
    label_entity_id: Column.Schema.Str;
    auth_comp_id: Column.Schema.Str;
    auth_seq_id: Column.Schema.Int;
    auth_asym_id: Column.Schema.Str;
};
export declare const mmCIF_chemCompBond_schema: {
    atom_id_1: Column.Schema.Str;
    atom_id_2: Column.Schema.Str;
    comp_id: Column.Schema.Str;
    value_order: Column.Schema.Aliased<"arom" | "delo" | "doub" | "pi" | "poly" | "quad" | "sing" | "trip">;
    pdbx_ordinal: Column.Schema.Int;
    pdbx_stereo_config: Column.Schema.Aliased<"e" | "n" | "z">;
    pdbx_aromatic_flag: Column.Schema.Aliased<"n" | "y">;
    /** Indicates if the bond entry was taken from the protonation variant dictionary */
    molstar_protonation_variant: Column.Schema.Str;
};
/** Has `type` extended with 'ION' and 'LIPID' */
export declare const mmCIF_chemComp_schema: {
    formula: Column.Schema.Str;
    formula_weight: Column.Schema.Float;
    id: Column.Schema.Str;
    mon_nstd_flag: Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
    name: Column.Schema.Str;
    pdbx_synonyms: Column.Schema.List<string>;
    type: Column.Schema.Aliased<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
};
export type mmCIF_chemComp_schema = typeof mmCIF_chemComp_schema;
//# sourceMappingURL=mmcif-extras.d.ts.map