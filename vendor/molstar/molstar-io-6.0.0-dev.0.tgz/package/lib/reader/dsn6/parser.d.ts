/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { Dsn6File, Dsn6Header } from './schema.js';
import { ReaderResult as Result } from '../result.js';
import { FileHandle } from '@molstar/io/common/file-handle';
export declare const dsn6HeaderSize = 512;
export declare function readDsn6Header(file: FileHandle): Promise<{
    header: Dsn6Header;
    littleEndian: boolean;
}>;
export declare function parseDsn6Values(header: Dsn6Header, source: Uint8Array, target: Float32Array, littleEndian: boolean): Promise<void>;
export declare function getDsn6Counts(header: Dsn6Header): {
    count: number;
    byteCount: number;
    valueCount: number;
};
export declare function parseFile(file: FileHandle, size: number): Task<Result<Dsn6File>>;
export declare function parse(buffer: Uint8Array, name: string): Task<Result<Dsn6File>>;
//# sourceMappingURL=parser.d.ts.map