/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * Parser for Simularium trajectory files (JSON and binary variants).
 * The binary layout mirrors the reference implementation in
 * https://github.com/simularium/simularium-viewer (BinaryFileReader.ts).
 */
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../result.js';
import type { SimulariumFile } from './schema.js';
export declare function parseSimularium(data: Uint8Array): Task<Result<SimulariumFile>>;
//# sourceMappingURL=parser.d.ts.map