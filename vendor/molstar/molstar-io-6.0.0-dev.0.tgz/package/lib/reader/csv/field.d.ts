/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { CifField } from '../cif/data-model.js';
export declare const Field: typeof CifField.ofTokens;
//# sourceMappingURL=field.d.ts.map