/**
 * Copyright (c) 2020-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Panagiotis Tourlas <panagiot_tourlov@hotmail.com>
 */
import { Column } from '@molstar/core/data/db';
import { Task } from '@molstar/core/task';
import type { StringLike } from '@molstar/core/util/string-like';
import { Tokenizer } from '../common/text/tokenizer.js';
import { ReaderResult as Result } from '../result.js';
/** Subset of the MolFile V2000 format */
export interface MolFile {
    readonly title: string;
    readonly program: string;
    readonly comment: string;
    readonly atoms: {
        readonly count: number;
        readonly x: Column<number>;
        readonly y: Column<number>;
        readonly z: Column<number>;
        readonly type_symbol: Column<string>;
        readonly formal_charge: Column<number>;
    };
    readonly bonds: {
        readonly count: number;
        readonly atomIdxA: Column<number>;
        readonly atomIdxB: Column<number>;
        readonly order: Column<number>;
    };
    readonly formalCharges: {
        readonly atomIdx: Column<number>;
        readonly charge: Column<number>;
    };
    readonly attachmentPoints?: {
        readonly atomIdx: number;
        readonly kind: number;
    }[];
}
/**
 * @param key - The value found at the atom block.
 * @returns The actual formal charge based on the mapping.
 */
export declare function formalChargeMapper(key: number): -3 | -2 | -1 | 0 | 1 | 2 | 3;
export declare function handleAtoms(tokenizer: Tokenizer, count: number): MolFile['atoms'];
export declare function handleBonds(tokenizer: Tokenizer, count: number): MolFile['bonds'];
interface FormalChargesRawData {
    atomIdx: Array<number>;
    charge: Array<number>;
}
export declare function handleFormalCharges(tokenizer: Tokenizer, lineStart: number, formalCharges: FormalChargesRawData): void;
/** Call an appropriate handler based on the property type.
 */
export declare function handlePropertiesBlock(tokenizer: Tokenizer): {
    formalCharges: MolFile['formalCharges'];
    attachmentPoints: MolFile['attachmentPoints'];
};
export declare function parseMol(data: StringLike): Task<Result<MolFile>>;
export {};
//# sourceMappingURL=parser.d.ts.map