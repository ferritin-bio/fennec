/**
 * Copyright (c) 2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Column } from '@molstar/core/data/db';
import { Task } from '@molstar/core/task';
import type { StringLike } from '@molstar/core/util/string-like';
import { ReaderResult as Result } from '../result.js';
export interface XyzFile {
    readonly molecules: {
        readonly comment: string;
        readonly count: number;
        readonly x: Column<number>;
        readonly y: Column<number>;
        readonly z: Column<number>;
        readonly type_symbol: Column<string>;
    }[];
}
export declare function parseXyz(data: StringLike): Task<Result<XyzFile>>;
//# sourceMappingURL=parser.d.ts.map