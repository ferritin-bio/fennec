/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ReaderResult as Result } from '../result.js';
import { Task } from '@molstar/core/task';
import { PlyFile } from './schema.js';
import type { StringLike } from '@molstar/core/util/string-like';
export declare function parsePly(data: StringLike | Uint8Array): Task<Result<PlyFile>>;
//# sourceMappingURL=parser.d.ts.map