/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 */
import type { StringLike } from '@molstar/core/util/string-like';
export declare const B64_DECODE: Int8Array<ArrayBuffer>;
export declare function decodeB64Bytes(src: Uint8Array, srcStart: number, nOut: number): Uint8Array;
export declare function decodeB64Str(src: StringLike, srcStart: number, nOut: number): Uint8Array;
//# sourceMappingURL=decode.d.ts.map