/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../result.js';
import type { MtzFile } from './schema.js';
/**
 * Parse a binary MTZ reflection file.
 *
 * MTZ binary layout (all values IEEE float32 / int32, endianness determined
 * from the machine stamp):
 *
 *   Bytes 0–3   : magic "MTZ "
 *   Bytes 4–7   : int32  = 1-indexed word position of the main header
 *   Bytes 8–11  : machine stamp (endianness indicator)
 *   Bytes 80+   : float32 reflection data, row-major (nRefl × nCols)
 *   Bytes hdr*4 : 80-byte ASCII header records until "END "
 *
 * @param buffer  Raw file bytes (Uint8Array or SimpleBuffer).
 * @param name    File name / identifier stored on the result.
 */
export declare function parseMtz(buffer: Uint8Array, name: string): Task<Result<MtzFile>>;
//# sourceMappingURL=parser.d.ts.map