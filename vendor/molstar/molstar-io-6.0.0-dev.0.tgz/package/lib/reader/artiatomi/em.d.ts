/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../result.js';
/** EM file header size in bytes. */
export declare const EmHeader_Size = 512;
/** Machine coding values stored in byte 0 of the EM header. */
export declare const EmMachineCoding: {
    readonly OS9: 0;
    readonly VAX: 1;
    readonly Convex: 2;
    readonly SGI: 3;
    readonly Mac: 5;
    readonly PC: 6;
};
/** Data type coding values stored in byte 3 of the EM header. */
export declare const EmDataType: {
    readonly Byte: 1;
    readonly Short: 2;
    readonly Int: 4;
    readonly Float: 5;
    readonly Complex: 8;
    readonly Double: 9;
};
export interface ArtiatomiEmHeader {
    readonly machineCoding: number;
    readonly dataType: number;
    readonly dimX: number;
    readonly dimY: number;
    readonly dimZ: number;
    readonly isLittleEndian: boolean;
}
/** Typed array union for EM data. For Complex, the array has length 2*N with interleaved (real, imaginary) pairs. */
export type EmData = Int8Array | Int16Array | Int32Array | Float32Array | Float64Array;
export interface ArtiatomiEmFile {
    readonly header: ArtiatomiEmHeader;
    /**
     * Raw numeric data stored in the appropriate typed array for the data type:
     * - Byte    → Int8Array,   length = N
     * - Short   → Int16Array,  length = N
     * - Int     → Int32Array,  length = N
     * - Float   → Float32Array, length = N
     * - Complex → Float32Array, length = 2*N, interleaved as (r0,i0, r1,i1, ...)
     * - Double  → Float64Array, length = N
     * where N = dimX * dimY * dimZ and X is the fastest-varying dimension.
     */
    readonly data: EmData;
}
export declare function parseArtiatomiEm(data: Uint8Array): Task<Result<ArtiatomiEmFile>>;
//# sourceMappingURL=em.d.ts.map