/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { CifBlock, CifFile } from '../cif.js';
import { ReaderResult as Result } from '../result.js';
import { type RelionStar_Database } from './schema.js';
export interface RelionStarFile {
    readonly source: CifFile;
    readonly particleBlock: CifBlock;
    readonly opticsBlock?: CifBlock;
    readonly particles: RelionStar_Database['particles'];
    readonly optics?: RelionStar_Database['optics'];
}
export declare function parseRelionStar(file: CifFile): Result<RelionStarFile>;
export declare function getRelionStarTomogramNames(file: CifFile): string[];
export declare function getRelionStarMicrographNames(file: CifFile): string[];
//# sourceMappingURL=star.d.ts.map