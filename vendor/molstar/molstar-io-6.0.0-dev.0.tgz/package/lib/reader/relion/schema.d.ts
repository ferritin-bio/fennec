/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Database, Column } from '@molstar/core/data/db';
import type { CifAliases } from '../cif/data-model.js';
import Schema = Column.Schema;
export declare const RelionStar_Schema: {
    particles: {
        /** X-coordinate (in Angstrom) for the origin of rotation */
        rlnOriginXAngst: Schema.Float;
        /** Y-coordinate (in Angstrom) for the origin of rotation */
        rlnOriginYAngst: Schema.Float;
        /** Z-coordinate (in Angstrom) for the origin of rotation */
        rlnOriginZAngst: Schema.Float;
        /** X-coordinate (in pixels) for the origin of rotation */
        rlnOriginX: Schema.Float;
        /** Y-coordinate (in pixels) for the origin of rotation */
        rlnOriginY: Schema.Float;
        /** Z-coordinate (in pixels) for the origin of rotation */
        rlnOriginZ: Schema.Float;
        /** First Euler angle (rot, in degrees) */
        rlnAngleRot: Schema.Float;
        /** Second Euler angle (tilt, in degrees) */
        rlnAngleTilt: Schema.Float;
        /** Third Euler, or in-plane angle (psi, in degrees) */
        rlnAnglePsi: Schema.Float;
        /** ID (i.e. a unique number) for a micrograph */
        rlnMicrographId: Schema.Int;
        /** Name of the micrograph */
        rlnMicrographName: Schema.Str;
        /** First Euler angle of a subtomogram (rot, in degrees) */
        rlnTomoSubtomogramRot: Schema.Float;
        /** Second Euler angle of a subtomogram (tilt, in degrees) */
        rlnTomoSubtomogramTilt: Schema.Float;
        /** Third Euler angle of a subtomogram (psi, in degrees) */
        rlnTomoSubtomogramPsi: Schema.Float;
        /** X-Position of an image in a micrograph (in pixels) */
        rlnCoordinateX: Schema.Float;
        /** Y-Position of an image in a micrograph (in pixels) */
        rlnCoordinateY: Schema.Float;
        /** Z-Position of an image in a 3D micrograph, i.e. tomogram (in pixels) */
        rlnCoordinateZ: Schema.Float;
        /** X-Position of an image in a micrograph (in Angstroms, with the center being 0,0) */
        rlnCenteredCoordinateXAngst: Schema.Float;
        /** Y-Position of an image in a micrograph (in Angstroms, with the center being 0,0) */
        rlnCenteredCoordinateYAngst: Schema.Float;
        /** Z-Position of an image in a 3D micrograph, i.e. tomogram (in Angstroms, with the center being 0,0,0) */
        rlnCenteredCoordinateZAngst: Schema.Float;
        /** Class number for which a particle has its highest probability */
        rlnClassNumber: Schema.Int;
        /** Maximum value of probability distribution over classes */
        rlnMaxValueProbDistribution: Schema.Float;
        /** Contribution to the log-likelihood for this particle */
        rlnLogLikeliContribution: Schema.Float;
        /** Normalisation correction factor for this particle */
        rlnNormCorrection: Schema.Float;
        /** ID (i.e. a unique number) for a particle */
        rlnParticleId: Schema.Int;
        /** Name for a particle */
        rlnParticleName: Schema.Str;
        /** Original name for a particle */
        rlnOriginalParticleName: Schema.Str;
        /** Group of particles with identical optical properties */
        rlnOpticsGroup: Schema.Int;
        /** Tomogram name */
        rlnTomoName: Schema.Str;
        /** Name of each individual particle */
        rlnTomoParticleName: Schema.Str;
        /** Unique particle index */
        rlnTomoParticleId: Schema.Int;
        /** Size of the pixels in the references and images (in Angstroms) */
        rlnPixelSize: Schema.Float;
        /** The number of a group of images */
        rlnGroupNumber: Schema.Int;
        /** Pixel size of the original tilt series */
        rlnTomoTiltSeriesPixelSize: Schema.Float;
        /** Pixel size (in Angstrom) */
        rlnImagePixelSize: Schema.Float;
        /** Pixel size of (averaged) micrographs after binning in Angstrom/pixel */
        rlnMicrographPixelSize: Schema.Float;
        /** Pixel size of the detector (in micrometers) */
        rlnDetectorPixelSize: Schema.Float;
    };
    optics: {
        /** Group of particles with identical optical properties */
        rlnOpticsGroup: Schema.Int;
        /** Pixel size of the original tilt series */
        rlnTomoTiltSeriesPixelSize: Schema.Float;
        /** Pixel size (in Angstrom) */
        rlnImagePixelSize: Schema.Float;
        /** Pixel size of (averaged) micrographs after binning in Angstrom/pixel */
        rlnMicrographPixelSize: Schema.Float;
        /** Pixel size of the detector (in micrometers) */
        rlnDetectorPixelSize: Schema.Float;
    };
};
export declare const RelionStar_Aliases: CifAliases;
export type RelionStar_Schema = typeof RelionStar_Schema;
export interface RelionStar_Database extends Database<RelionStar_Schema> {
}
//# sourceMappingURL=schema.d.ts.map