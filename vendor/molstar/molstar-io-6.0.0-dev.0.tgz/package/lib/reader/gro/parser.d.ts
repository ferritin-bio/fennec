/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type * as Schema from './schema.js';
import { ReaderResult as Result } from '../result.js';
import { Task } from '@molstar/core/task';
import type { StringLike } from '@molstar/core/util/string-like';
export declare function parseGRO(data: StringLike): Task<Result<Schema.GroFile>>;
//# sourceMappingURL=parser.d.ts.map