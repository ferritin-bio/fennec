/**
 * Copyright (c) 2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../../result.js';
import type { LammpsTrajectoryFile } from '../schema.js';
import type { StringLike } from '@molstar/core/util/string-like';
export declare function parseLammpsTrajectory(data: StringLike): Task<Result<LammpsTrajectoryFile>>;
//# sourceMappingURL=parser.d.ts.map