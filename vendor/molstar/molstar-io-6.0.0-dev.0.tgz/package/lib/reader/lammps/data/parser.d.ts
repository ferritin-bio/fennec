/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 * @author Himanshu Raj <himanshuraj6771@gmail.com>
 */
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../../result.js';
import type { LammpsDataFile } from '../schema.js';
import type { StringLike } from '@molstar/core/util/string-like';
export declare function parseLammpsData(data: StringLike): Task<Result<LammpsDataFile>>;
//# sourceMappingURL=parser.d.ts.map