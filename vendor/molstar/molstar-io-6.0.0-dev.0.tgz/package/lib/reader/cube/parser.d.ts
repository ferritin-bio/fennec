/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * Adapted from NGL.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { Column } from '@molstar/core/data/db';
import { Task } from '@molstar/core/task';
import { ReaderResult as Result } from '../result.js';
import type { StringLike } from '@molstar/core/util/string-like';
export interface CubeFile {
    name: string;
    header: CubeFile.Header;
    atoms: CubeFile.Atoms;
    values: Float64Array;
}
export declare namespace CubeFile {
    interface Header {
        orbitals: boolean;
        comment1: string;
        comment2: string;
        atomCount: number;
        origin: Vec3;
        dim: Vec3;
        basisX: Vec3;
        basisY: Vec3;
        basisZ: Vec3;
        dataSetIds: number[];
    }
    interface Atoms {
        count: number;
        number: Column<number>;
        nuclearCharge: Column<number>;
        x: Column<number>;
        y: Column<number>;
        z: Column<number>;
    }
}
export declare function parseCube(data: StringLike, name: string): Task<Result<CubeFile>>;
//# sourceMappingURL=parser.d.ts.map