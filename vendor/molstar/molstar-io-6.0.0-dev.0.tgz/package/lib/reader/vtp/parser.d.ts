/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { ReaderResult as Result } from '../result.js';
import { Task } from '@molstar/core/task';
import { type VtpFile } from './schema.js';
export declare function parseVtp(data: Uint8Array): Task<Result<VtpFile>>;
//# sourceMappingURL=parser.d.ts.map