/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * Adapted from https://github.com/rcsb/mmtf-javascript
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
/**
 * Decode an extension value from its type code and payload (a view into the buffer: copy what is kept).
 * Returning undefined gives `{ type, data }`.
 */
export type MsgPackExtDecoder = (type: number, data: Uint8Array) => unknown;
export declare function decodeMsgPack(buffer: Uint8Array, ext?: MsgPackExtDecoder): any;
export interface MsgPackState {
    buffer: Uint8Array;
    offset: number;
    dataView: DataView;
    ext?: MsgPackExtDecoder;
}
export declare function createMsgPackState(buffer: Uint8Array): MsgPackState;
/** Decode the value at the current offset and advance past it. */
export { parse as parseMsgPackValue };
/** Advance past a map header and return the number of key-value pairs it contains. */
export declare function readMsgPackMapLength(state: MsgPackState): number;
/** Advance past an array header and return the number of elements it contains. */
export declare function readMsgPackArrayLength(state: MsgPackState): number;
/**
 * recursively parse the MessagePack data and return decoded MessagePack data
 */
declare function parse(state: MsgPackState): any;
/**
 * Advance past the value at the current offset without decoding it.
 * Mirrors the type dispatch of `parse` but allocates nothing, which makes it suitable for
 * cheaply skipping large payloads (e.g. BinaryCIF column data) when only some fields are needed.
 */
export declare function skipMsgPackValue(state: MsgPackState): void;
//# sourceMappingURL=decode.d.ts.map