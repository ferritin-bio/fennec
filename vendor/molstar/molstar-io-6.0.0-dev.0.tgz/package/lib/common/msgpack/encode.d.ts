/** An extension value: its type code and payload. */
export interface MsgPackExtData {
    type: number;
    data: Uint8Array;
}
/**
 * Asked for every object and array before it is encoded (twice: size, then write), so it should be cheap.
 * A returned value is written as that extension.
 */
export type MsgPackExtEncoder = (value: object) => MsgPackExtData | undefined;
export declare function encodeMsgPack(value: any, ext?: MsgPackExtEncoder): Uint8Array<ArrayBuffer>;
//# sourceMappingURL=encode.d.ts.map