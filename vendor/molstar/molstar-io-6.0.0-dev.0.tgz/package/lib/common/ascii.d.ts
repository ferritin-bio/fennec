/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sukolsak Sakshuwong <sukolsak@stanford.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare function asciiWrite(data: Uint8Array, str: string): void;
/**
 * Decode a region of a Uint8Array as an ASCII string.
 */
export declare function asciiSlice(buf: Uint8Array, start: number, end: number): string;
//# sourceMappingURL=ascii.d.ts.map