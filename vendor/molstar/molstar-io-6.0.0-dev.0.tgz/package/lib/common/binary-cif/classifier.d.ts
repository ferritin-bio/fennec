/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type ArrayEncoder } from './array-encoder.js';
export declare function classifyIntArray(xs: ArrayLike<number>): ArrayEncoder;
export declare function classifyFloatArray(xs: ArrayLike<number>): ArrayEncoder;
//# sourceMappingURL=classifier.d.ts.map