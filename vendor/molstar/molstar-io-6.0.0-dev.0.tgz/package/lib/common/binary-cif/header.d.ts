/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Metadata of a BinaryCIF file without any column data.
 * Enough to content-sniff a file (e.g. in `DataFormatProvider.isApplicable`) at a small
 * fraction of the cost of decoding it with `decodeMsgPack`.
 */
export interface BinaryCifHeader {
    version: string;
    encoder: string;
    dataBlocks: BinaryCifBlockHeader[];
}
export interface BinaryCifBlockHeader {
    header: string;
    categories: BinaryCifCategoryHeader[];
}
export interface BinaryCifCategoryHeader {
    /** Category name including the leading underscore, e.g. `_atom_site`. */
    name: string;
    rowCount: number;
    columnNames: string[];
}
/** Memoized `decodeBinaryCifHeader`, keyed by the data buffer instance. */
export declare function getBinaryCifHeader(data: Uint8Array): BinaryCifHeader;
/** Throws if the data is not valid MessagePack, mirroring `decodeMsgPack`. */
export declare function decodeBinaryCifHeader(data: Uint8Array): BinaryCifHeader;
/** `categoryName` must include the leading underscore, e.g. `_atom_site`. */
export declare function binaryCifHasCategory(header: BinaryCifHeader, categoryName: string): boolean;
/** `categoryName` must include the leading underscore, e.g. `_atom_site`. */
export declare function binaryCifHasColumn(header: BinaryCifHeader, categoryName: string, columnName: string): boolean;
//# sourceMappingURL=header.d.ts.map