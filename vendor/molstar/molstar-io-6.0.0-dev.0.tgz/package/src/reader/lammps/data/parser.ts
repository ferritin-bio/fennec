/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 * @author Himanshu Raj <himanshuraj6771@gmail.com>
 */

import { Task, type RuntimeContext, chunkedSubtask } from '@molstar/core/task';
import { Tokenizer, TokenBuilder } from '../../common/text/tokenizer.js';
import { ReaderResult as Result } from '../../result.js';
import { TokenColumnProvider as TokenColumn } from '../../common/text/column/token.js';
import { Column } from '@molstar/core/data/db';
import type { LammpsDataFile } from '../schema.js';
import type { StringLike } from '@molstar/core/util/string-like';

const { readLine, skipWhitespace, eatValue, eatLine, markStart, skipStrictWhitespace } = Tokenizer;

const reWhitespace = /\s+/;

function State(tokenizer: Tokenizer, runtimeCtx: RuntimeContext) {
  return {
    tokenizer,
    runtimeCtx,
  };
}
type State = ReturnType<typeof State>;

async function handleAtoms(state: State, count: number, atom_style: AtomStyle): Promise<LammpsDataFile['atoms']> {
  const { tokenizer } = state;
  // default atom style is atomic
  // depending on the atom style the number of columns can change
  const atomId = TokenBuilder.create(tokenizer.data, count * 2);
  const moleculeId = TokenBuilder.create(tokenizer.data, count * 2);
  const atomType = TokenBuilder.create(tokenizer.data, count * 2);
  const charge = TokenBuilder.create(tokenizer.data, count * 2);
  const x = TokenBuilder.create(tokenizer.data, count * 2);
  const y = TokenBuilder.create(tokenizer.data, count * 2);
  const z = TokenBuilder.create(tokenizer.data, count * 2);
  const columns = {
    full: [atomId, moleculeId, atomType, charge, x, y, z],
    atomic: [atomId, atomType, x, y, z],
    bond: [atomId, moleculeId, atomType, x, y, z],
    molecular: [atomId, moleculeId, atomType, x, y, z],
  };
  const n = columns[atom_style].length;
  const { position } = tokenizer;
  readLine(tokenizer).trim();
  tokenizer.position = position;

  const { length } = tokenizer;
  let linesAlreadyRead = 0;

  await chunkedSubtask(
    state.runtimeCtx,
    100000,
    void 0,
    (chunkSize) => {
      const linesToRead = Math.min(count - linesAlreadyRead, chunkSize);
      for (let i = 0; i < linesToRead; ++i) {
        for (let j = 0; j < n; ++j) {
          skipWhitespace(tokenizer);
          markStart(tokenizer);
          eatValue(tokenizer);
          const column = columns[atom_style][j];
          if (column) {
            TokenBuilder.addUnchecked(column, tokenizer.tokenStart, tokenizer.tokenEnd);
          }
        }
        // ignore any extra columns
        eatLine(tokenizer);
        markStart(tokenizer);
      }
      linesAlreadyRead += linesToRead;
      return linesToRead;
    },
    (ctx) => ctx.update({ message: 'Parsing...', current: tokenizer.position, max: length }),
  );

  return {
    count,
    atomId: TokenColumn(atomId)(Column.Schema.int),
    moleculeId: TokenColumn(moleculeId)(Column.Schema.int),
    atomType: TokenColumn(atomType)(Column.Schema.int),
    charge: TokenColumn(charge)(Column.Schema.float),
    x: TokenColumn(x)(Column.Schema.float),
    y: TokenColumn(y)(Column.Schema.float),
    z: TokenColumn(z)(Column.Schema.float),
  };
}

async function handleBonds(state: State, count: number): Promise<LammpsDataFile['bonds']> {
  const { tokenizer } = state;

  const bondId = TokenBuilder.create(tokenizer.data, count * 2);
  const bondType = TokenBuilder.create(tokenizer.data, count * 2);
  const atomIdA = TokenBuilder.create(tokenizer.data, count * 2);
  const atomIdB = TokenBuilder.create(tokenizer.data, count * 2);

  const { length } = tokenizer;
  let bondsAlreadyRead = 0;
  await chunkedSubtask(
    state.runtimeCtx,
    10,
    void 0,
    (chunkSize) => {
      const bondsToRead = Math.min(count - bondsAlreadyRead, chunkSize);
      for (let i = 0; i < bondsToRead; ++i) {
        for (let j = 0; j < 4; ++j) {
          skipWhitespace(tokenizer);
          markStart(tokenizer);
          eatValue(tokenizer);
          switch (j) {
            case 0:
              TokenBuilder.addUnchecked(bondId, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
            case 1:
              TokenBuilder.addUnchecked(bondType, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
            case 2:
              TokenBuilder.addUnchecked(atomIdA, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
            case 3:
              TokenBuilder.addUnchecked(atomIdB, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
          }
        }
      }
      bondsAlreadyRead += bondsToRead;
      return bondsToRead;
    },
    (ctx) => ctx.update({ message: 'Parsing...', current: tokenizer.position, max: length }),
  );

  return {
    count,
    bondId: TokenColumn(bondId)(Column.Schema.int),
    bondType: TokenColumn(bondType)(Column.Schema.int),
    atomIdA: TokenColumn(atomIdA)(Column.Schema.int),
    atomIdB: TokenColumn(atomIdB)(Column.Schema.int),
  };
}

async function handleMasses(state: State, count: number): Promise<NonNullable<LammpsDataFile['masses']>> {
  const { tokenizer } = state;

  const atomType = TokenBuilder.create(tokenizer.data, count * 2);
  const mass = TokenBuilder.create(tokenizer.data, count * 2);
  const symbol = TokenBuilder.create(tokenizer.data, count * 2);

  const { length } = tokenizer;
  let itemsAlreadyRead = 0;
  await chunkedSubtask(
    state.runtimeCtx,
    10,
    void 0,
    (chunkSize) => {
      const itemsToRead = Math.min(count - itemsAlreadyRead, chunkSize);
      for (let i = 0; i < itemsToRead; ++i) {
        // skip any comment lines before the actual data line
        skipWhitespace(tokenizer);
        while (
          tokenizer.position < tokenizer.length &&
          tokenizer.data.charCodeAt(tokenizer.position) === 35 /* '#' */
        ) {
          eatLine(tokenizer);
          skipWhitespace(tokenizer);
        }
        for (let j = 0; j < 2; ++j) {
          skipWhitespace(tokenizer);
          markStart(tokenizer);
          eatValue(tokenizer);
          switch (j) {
            case 0:
              TokenBuilder.addUnchecked(atomType, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
            case 1:
              TokenBuilder.addUnchecked(mass, tokenizer.tokenStart, tokenizer.tokenEnd);
              break;
          }
        }

        // optional trailing "# <symbol>" comment, e.g. "1 12.011  # C"
        skipStrictWhitespace(tokenizer);
        if (tokenizer.position < tokenizer.length && tokenizer.data.charCodeAt(tokenizer.position) === 35 /* '#' */) {
          ++tokenizer.position;
          skipStrictWhitespace(tokenizer);
          markStart(tokenizer);
          eatValue(tokenizer);
          TokenBuilder.addUnchecked(symbol, tokenizer.tokenStart, tokenizer.tokenEnd);
        } else {
          // keep column length == count even when no comment is present
          TokenBuilder.addUnchecked(symbol, tokenizer.position, tokenizer.position);
        }

        eatLine(tokenizer);
        markStart(tokenizer);
      }
      itemsAlreadyRead += itemsToRead;
      return itemsToRead;
    },
    (ctx) => ctx.update({ message: 'Parsing...', current: tokenizer.position, max: length }),
  );

  return {
    count,
    atomType: TokenColumn(atomType)(Column.Schema.int),
    mass: TokenColumn(mass)(Column.Schema.float),
    symbol: TokenColumn(symbol)(Column.Schema.str),
  };
}

const AtomStyles = ['full', 'atomic', 'bond', 'molecular'] as const;
type AtomStyle = (typeof AtomStyles)[number];

async function parseInternal(data: StringLike, ctx: RuntimeContext): Promise<Result<LammpsDataFile>> {
  const tokenizer = Tokenizer(data);
  const state = State(tokenizer, ctx);

  let atoms = undefined as LammpsDataFile['atoms'] | undefined;
  let bonds = undefined as LammpsDataFile['bonds'] | undefined;
  let masses = undefined as LammpsDataFile['masses'] | undefined;
  let numAtoms = 0;
  let numAtomTypes = 0;
  let numBonds = 0;
  let atom_style: AtomStyle = 'full';
  let xlo = NaN,
    xhi = NaN,
    ylo = NaN,
    yhi = NaN,
    zlo = NaN,
    zhi = NaN;
  // full list of atom_style
  // https://docs.lammps.org/atom_style.html
  while (tokenizer.tokenEnd < tokenizer.length) {
    const line = readLine(state.tokenizer).trim();
    if (line.includes('atom types')) {
      numAtomTypes = parseInt(line.split(reWhitespace)[0]);
    } else if (line.includes('atoms')) {
      numAtoms = parseInt(line.split(reWhitespace)[0]);
    } else if (line.includes('bonds')) {
      numBonds = parseInt(line.split(reWhitespace)[0]);
    } else if (line.includes('xlo xhi')) {
      const parts = line.split(reWhitespace);
      xlo = parseFloat(parts[0]);
      xhi = parseFloat(parts[1]);
    } else if (line.includes('ylo yhi')) {
      const parts = line.split(reWhitespace);
      ylo = parseFloat(parts[0]);
      yhi = parseFloat(parts[1]);
    } else if (line.includes('zlo zhi')) {
      const parts = line.split(reWhitespace);
      zlo = parseFloat(parts[0]);
      zhi = parseFloat(parts[1]);
    } else if (line.includes('Masses')) {
      masses = await handleMasses(state, numAtomTypes);
    } else if (line.includes('Atoms')) {
      // usually atom style is indicated as a comment after Atoms. e.g. Atoms # full
      const parts = line.split('#');
      if (parts.length > 1) {
        const atomStyle = parts[1].trim();
        if (AtomStyles.includes(atomStyle as AtomStyle)) {
          atom_style = atomStyle as AtomStyle;
        } else {
          console.warn(`Unknown atom style: ${atomStyle}`);
        }
      }
      atoms = await handleAtoms(state, numAtoms, atom_style);
    } else if (line.includes('Bonds')) {
      bonds = await handleBonds(state, numBonds);
    }
  }

  if (atoms === undefined) {
    return Result.error('no atoms data');
  }

  if (bonds === undefined) {
    bonds = {
      count: 0,
      bondId: Column.ofIntArray([]),
      bondType: Column.ofIntArray([]),
      atomIdA: Column.ofIntArray([]),
      atomIdB: Column.ofIntArray([]),
    };
  }

  const box =
    !isNaN(xlo) && !isNaN(xhi) && !isNaN(ylo) && !isNaN(yhi) && !isNaN(zlo) && !isNaN(zhi)
      ? {
          lower: [xlo, ylo, zlo] as [number, number, number],
          length: [xhi - xlo, yhi - ylo, zhi - zlo] as [number, number, number],
          periodicity: ['p', 'p', 'p'] as [string, string, string],
        }
      : undefined;

  const result: LammpsDataFile = {
    atoms,
    bonds,
    masses,
    box,
  };
  return Result.success(result);
}

export function parseLammpsData(data: StringLike) {
  return Task.create<Result<LammpsDataFile>>('Parse LammpsData', async (ctx) => {
    return await parseInternal(data, ctx);
  });
}
