/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */

import { Column, Table } from '@molstar/core/data/db';
import type { Model } from '@molstar/model/model/structure/model/model';
import type { AtomicHierarchy } from '@molstar/model/model/structure/model/properties/atomic';
import type {
  ChemicalComponent,
  MissingResidue,
  StructAsym,
} from '@molstar/model/model/structure/model/properties/common';
import {
  getComponentType,
  getDefaultChemicalComponent,
  getMoleculeType,
  MoleculeType,
} from '@molstar/model/model/structure/model/types';
import {
  SaccharideCompIdMap,
  type SaccharideComponent,
  type SaccharideComponentMap,
  SaccharidesSnfgMap,
  UnknownSaccharideComponent,
} from '@molstar/model/model/structure/structure/carbohydrates/constants';
import { memoize1 } from '@molstar/core/util/memoize';
import type { BasicData } from './schema.js';

export function getMissingResidues(data: BasicData): Model['properties']['missingResidues'] {
  const map = new Map<string, MissingResidue>();
  const getKey = (model_num: number, asym_id: string, seq_id: number) => {
    return `${model_num}|${asym_id}|${seq_id}`;
  };

  const c = data.pdbx_unobs_or_zero_occ_residues;
  if (c._rowCount > 0) {
    for (let i = 0, il = c._rowCount; i < il; ++i) {
      const key = getKey(c.PDB_model_num.value(i), c.label_asym_id.value(i), c.label_seq_id.value(i));
      map.set(key, { polymer_flag: c.polymer_flag.value(i), occupancy_flag: c.occupancy_flag.value(i) });
    }
  } else if (data.entity_poly_seq._rowCount > 0) {
    // `pdbx_unobs_or_zero_occ_residues` is not always present (e.g., files converted
    // from other formats). In that case, derive missing residues by comparing the
    // full polymer sequence in `entity_poly_seq` against the residues that actually
    // have coordinates in `atom_site`.
    addMissingResiduesFromEntityPolySeq(data, map, getKey);
  }

  return {
    has: (model_num: number, asym_id: string, seq_id: number) => {
      return map.has(getKey(model_num, asym_id, seq_id));
    },
    get: (model_num: number, asym_id: string, seq_id: number) => {
      return map.get(getKey(model_num, asym_id, seq_id));
    },
    size: map.size,
  };
}

function addMissingResiduesFromEntityPolySeq(
  data: BasicData,
  map: Map<string, MissingResidue>,
  getKey: (model_num: number, asym_id: string, seq_id: number) => string,
) {
  // map entity_id to the asym_ids (chains) that belong to it
  const entityAsymIds = new Map<string, string[]>();
  const { id: struct_asym_id, entity_id: struct_asym_entity_id } = data.struct_asym;
  for (let i = 0, il = struct_asym_id.rowCount; i < il; ++i) {
    const entity_id = struct_asym_entity_id.value(i);
    const asym_id = struct_asym_id.value(i);
    if (entityAsymIds.has(entity_id)) entityAsymIds.get(entity_id)!.push(asym_id);
    else entityAsymIds.set(entity_id, [asym_id]);
  }

  // collect the (model_num, asym_id, seq_id) triples that have coordinates
  const observed = new Set<string>();
  const _models = new Set<number>();
  const { label_asym_id, label_seq_id, pdbx_PDB_model_num } = data.atom_site;
  for (let i = 0, il = label_asym_id.rowCount; i < il; ++i) {
    if (label_seq_id.valueKind(i) !== Column.ValueKinds.Present) continue;
    const model_num = pdbx_PDB_model_num.value(i);
    _models.add(model_num);
    observed.add(getKey(model_num, label_asym_id.value(i), label_seq_id.value(i)));
  }
  if (_models.size === 0) _models.add(1);
  const models = Array.from(_models);

  const { entity_id, num } = data.entity_poly_seq;
  for (let i = 0, il = entity_id.rowCount; i < il; ++i) {
    const asym_ids = entityAsymIds.get(entity_id.value(i));
    if (!asym_ids) continue;

    const seq_id = num.value(i);
    for (const asym_id of asym_ids) {
      for (const model_num of models) {
        const key = getKey(model_num, asym_id, seq_id);
        if (!observed.has(key)) {
          map.set(key, { polymer_flag: 'y', occupancy_flag: 1 });
        }
      }
    }
  }
}

export function getChemicalComponentMap(data: BasicData): Model['properties']['chemicalComponentMap'] {
  const map = new Map<string, ChemicalComponent>();

  if (data.chem_comp._rowCount > 0) {
    const { id, type } = data.chem_comp;
    for (let i = 0, il = id.rowCount; i < il; ++i) {
      const _id = id.value(i);
      const row = Table.getRow(data.chem_comp, i);
      // some tools like gemmi list `chem_comp` rows without a meaningful `type`
      if (type.valueKind(i) !== Column.ValueKinds.Present) {
        row.type = getComponentType(_id);
      }
      map.set(_id, row);
    }
  } else {
    const uniqueNames = getUniqueComponentNames(data);
    uniqueNames.forEach((n) => {
      map.set(n, getDefaultChemicalComponent(n));
    });
  }
  return map;
}

export function getSaccharideComponentMap(data: BasicData): SaccharideComponentMap {
  const map = new Map<string, SaccharideComponent>();

  if (data.pdbx_chem_comp_identifier._rowCount > 0) {
    // note that `pdbx_chem_comp_identifier` does not contain
    // a 'SNFG CARBOHYDRATE SYMBOL' entry for 'Unknown' saccharide components
    // so we always need to check `chem_comp` for those
    const { comp_id, type, identifier } = data.pdbx_chem_comp_identifier;
    for (let i = 0, il = comp_id.rowCount; i < il; ++i) {
      if (
        type.value(i) === 'SNFG CARBOHYDRATE SYMBOL' ||
        type.value(i) === 'SNFG CARB SYMBOL' // legacy, to be removed from mmCIF dictionary
      ) {
        const snfgName = identifier.value(i);
        const saccharideComp = SaccharidesSnfgMap.get(snfgName);
        if (saccharideComp) {
          map.set(comp_id.value(i), saccharideComp);
        } else {
          console.warn(`Unknown SNFG name '${snfgName}'`);
        }
      }
    }
  }

  if (data.chem_comp._rowCount > 0) {
    const { id, type } = data.chem_comp;
    for (let i = 0, il = id.rowCount; i < il; ++i) {
      const _id = id.value(i);
      if (map.has(_id)) continue;
      const _type = type.value(i);
      if (SaccharideCompIdMap.has(_id)) {
        map.set(_id, SaccharideCompIdMap.get(_id)!);
      } else if (getMoleculeType(_type, _id) === MoleculeType.Saccharide) {
        map.set(_id, UnknownSaccharideComponent);
      }
    }
  } else {
    const uniqueNames = getUniqueComponentNames(data);
    SaccharideCompIdMap.forEach((v, k) => {
      if (!map.has(k) && uniqueNames.has(k)) map.set(k, v);
    });
  }
  return map;
}

const getUniqueComponentNames = memoize1((data: BasicData) => {
  const uniqueNames = new Set<string>();
  const { label_comp_id, auth_comp_id } = data.atom_site;
  const comp_id = label_comp_id.isDefined ? label_comp_id : auth_comp_id;
  for (let i = 0, il = comp_id.rowCount; i < il; ++i) {
    uniqueNames.add(comp_id.value(i));
  }
  return uniqueNames;
});

export function getStructAsymMap(atomic: AtomicHierarchy, data?: BasicData): Model['properties']['structAsymMap'] {
  const map = new Map<string, StructAsym>();

  const { auth_asym_id, label_asym_id, label_entity_id } = atomic.chains;

  for (let i = 0, _i = atomic.chains._rowCount; i < _i; i++) {
    const id = label_asym_id.value(i);
    map.set(id, { id, auth_id: auth_asym_id.value(i), entity_id: label_entity_id.value(i) });
  }

  // to get asym mapping for coarse/ihm data
  if (data?.struct_asym._rowCount) {
    const { id, entity_id } = data.struct_asym;
    for (let i = 0, il = id.rowCount; i < il; ++i) {
      const _id = id.value(i);
      if (!map.has(_id)) {
        map.set(_id, {
          id: _id,
          auth_id: '',
          entity_id: entity_id.value(i),
        });
      }
    }
  }

  return map;
}
