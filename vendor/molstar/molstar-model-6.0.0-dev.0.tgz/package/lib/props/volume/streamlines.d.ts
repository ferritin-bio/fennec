/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { CustomVolumeProperty } from '../common/custom-volume-property.js';
import type { Streamlines } from './streamlines/shared.js';
export declare const StreamlinesParams: {
    type: PD.Mapped<PD.NamedParams<PD.Normalize<{
        seedDensity: number;
        stepSize: number;
        minSeparation: number;
    }>, "basic">>;
};
export type StreamlinesParams = typeof StreamlinesParams;
export type StreamlinesProps = PD.Values<StreamlinesParams>;
export type StreamlinesValue = Streamlines;
export declare const StreamlinesProvider: CustomVolumeProperty.Provider<StreamlinesParams, StreamlinesValue>;
//# sourceMappingURL=streamlines.d.ts.map