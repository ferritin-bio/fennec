/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { OrderedSet } from '@molstar/core/data/int/ordered-set';
import type { Sphere3D } from '@molstar/core/math/geometry/primitives/sphere3d';
import { DataLocation } from '@molstar/model/model/location';
import { DataLoci } from '@molstar/model/model/loci';
import type { Volume } from '@molstar/model/model/volume/volume';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import type { Mat4 } from '@molstar/core/math/linear-algebra/3d/mat4';
export type StreamlinePoint = Vec3;
export type Streamline = StreamlinePoint[];
export type Streamlines = Streamline[];
export type StreamlinesIndex = {
    readonly '@type': 'streamlines-index';
} & number;
type VolumeStreamlines = {
    readonly volume: Volume;
    readonly streamlines: Streamlines;
};
export interface StreamlinesLocation extends DataLocation<VolumeStreamlines, {
    index: StreamlinesIndex;
    instance: Volume.InstanceIndex;
}> {
}
export declare function StreamlinesLocation(streamlines: Streamlines, volume: Volume, index?: StreamlinesIndex, instance?: Volume.InstanceIndex): StreamlinesLocation;
export declare function isStreamlinesLocation(x: any): x is StreamlinesLocation;
export declare function areStreamlinesLocationsEqual(locA: StreamlinesLocation, locB: StreamlinesLocation): boolean;
export declare function streamlinesLocationLabel(streamlines: Streamlines, volume: Volume, index: StreamlinesIndex, instance: Volume.InstanceIndex): string;
export declare function streamlinesLociLabel(streamlines: Streamlines, volume: Volume, elements: ReadonlyArray<StreamlinesElement>): string;
type StreamlinesElement = {
    readonly indices: OrderedSet<StreamlinesIndex>;
    readonly instances: OrderedSet<Volume.InstanceIndex>;
};
export interface StreamlinesLoci extends DataLoci<VolumeStreamlines, StreamlinesElement> {
}
export declare function StreamlinesLoci(streamlines: Streamlines, volume: Volume, elements: ReadonlyArray<StreamlinesElement>): StreamlinesLoci;
export declare function isStreamlinesLoci(x: any): x is StreamlinesLoci;
export declare function getStreamlinesLociSize(elements: StreamlinesLoci['elements']): number;
export declare function getStreamlinesLociBoundingSphere(streamlines: Streamlines, volume: Volume, elements: StreamlinesLoci['elements'], boundingSphere?: Sphere3D): Sphere3D;
export declare function areStreamlinesLociEqual(a: StreamlinesLoci, b: StreamlinesLoci): boolean;
export declare function isStreamlinesLociEmpty(loci: StreamlinesLoci): boolean;
export declare const CommonStreamlinesParams: {
    anchorEnabled: PD.BooleanParam;
    anchorCenter: PD.Vec3;
    anchorRadius: PD.Numeric;
    dashEnabled: PD.BooleanParam;
    dashPoints: PD.Numeric;
    dashShift: PD.BooleanParam;
};
export type CommonStreamlinesParams = typeof CommonStreamlinesParams;
export type CommonStreamlinesProps = PD.Values<CommonStreamlinesParams>;
/**
 * Check if a streamline passes the sphere filter.
 * A streamline passes if its start or end point is within the filter sphere.
 */
export declare function streamlinePassesFilter(streamline: Streamline, gridToCartn: Mat4, props: CommonStreamlinesProps): boolean;
export {};
//# sourceMappingURL=shared.d.ts.map