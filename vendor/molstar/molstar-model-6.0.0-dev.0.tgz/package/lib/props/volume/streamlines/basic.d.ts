/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { CustomProperty } from '../../common/custom-property.js';
import type { Volume } from '@molstar/model/model/volume';
import type { Streamlines } from './shared.js';
export declare const BasicStreamlineCalculationParams: {
    seedDensity: PD.Numeric;
    stepSize: PD.Numeric;
    minSeparation: PD.Numeric;
};
export type BasicStreamlineCalculationParams = typeof BasicStreamlineCalculationParams;
export type BasicStreamlineCalculationProps = PD.Values<BasicStreamlineCalculationParams>;
export declare function calculateBasicStreamlines(ctx: CustomProperty.Context, volume: Volume, props: BasicStreamlineCalculationProps): Promise<Streamlines>;
//# sourceMappingURL=basic.d.ts.map