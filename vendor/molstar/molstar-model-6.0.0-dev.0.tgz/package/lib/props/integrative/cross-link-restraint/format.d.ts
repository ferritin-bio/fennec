/**
 * Copyright (c) 2018-2020 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Model } from '@molstar/model/model/structure/model/model';
import type { Table } from '@molstar/core/data/db';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { Unit } from '@molstar/model/model/structure';
import type { ElementIndex } from '@molstar/model/model/structure/model/indexing';
import { FormatPropertyProvider } from '@molstar/model/formats/structure/common/property';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
export { ModelCrossLinkRestraint };
interface ModelCrossLinkRestraint {
    getIndicesByElement: (element: ElementIndex, kind: Unit.Kind) => number[];
    data: Table<mmCIF_Schema['ihm_cross_link_restraint']>;
}
declare namespace ModelCrossLinkRestraint {
    const Descriptor: CustomPropertyDescriptor;
    const Provider: FormatPropertyProvider<ModelCrossLinkRestraint>;
    function fromTable(table: Table<mmCIF_Schema['ihm_cross_link_restraint']>, model: Model): ModelCrossLinkRestraint;
}
//# sourceMappingURL=format.d.ts.map