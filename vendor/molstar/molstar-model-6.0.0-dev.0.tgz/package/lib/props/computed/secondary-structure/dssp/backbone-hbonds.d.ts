/**
 * Copyright (c) 2019-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 */
import type { Unit } from '@molstar/model/model/structure';
import type { GridLookup3D } from '@molstar/core/math/geometry';
import type { DsspHbonds } from './common.js';
import type { ProteinInfo } from './protein-info.js';
export declare function calcUnitBackboneHbonds(unit: Unit.Atomic, proteinInfo: ProteinInfo, lookup3d: GridLookup3D): DsspHbonds;
//# sourceMappingURL=backbone-hbonds.d.ts.map