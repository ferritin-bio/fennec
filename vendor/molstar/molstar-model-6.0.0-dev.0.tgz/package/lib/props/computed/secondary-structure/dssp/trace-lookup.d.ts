/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { GridLookup3D } from '@molstar/core/math/geometry';
import { SortedArray } from '@molstar/core/data/int';
import type { Unit } from '@molstar/model/model/structure/structure';
import type { ResidueIndex } from '@molstar/model/model/structure';
export declare function calcUnitProteinTraceLookup3D(unit: Unit.Atomic, unitProteinResidues: SortedArray<ResidueIndex>): GridLookup3D;
//# sourceMappingURL=trace-lookup.d.ts.map