/**
 * Copyright (c) 2019-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 */
import type { Unit } from '@molstar/model/model/structure';
import type { ProteinInfo } from './protein-info.js';
export interface DihedralAngles {
    phi: Float32Array;
    psi: Float32Array;
}
export declare function calculateUnitDihedralAngles(unit: Unit.Atomic, proteinInfo: ProteinInfo): DihedralAngles;
//# sourceMappingURL=dihedral-angles.d.ts.map