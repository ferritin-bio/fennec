/**
 * Copyright (c) 2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { CustomModelProperty } from '../common/custom-model-property.js';
import { type HelixOrientation } from './helix-orientation/helix-orientation.js';
export declare const HelixOrientationParams: {};
export type HelixOrientationParams = typeof HelixOrientationParams;
export type HelixOrientationProps = PD.Values<HelixOrientationParams>;
export type HelixOrientationValue = HelixOrientation;
export declare const HelixOrientationProvider: CustomModelProperty.Provider<HelixOrientationParams, HelixOrientationValue>;
//# sourceMappingURL=helix-orientation.d.ts.map