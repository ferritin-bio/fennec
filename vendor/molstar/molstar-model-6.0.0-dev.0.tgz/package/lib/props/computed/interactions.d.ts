/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type Interactions } from './interactions/interactions.js';
import { CustomStructureProperty } from '../common/custom-structure-property.js';
export declare const InteractionsParams: {
    providers: PD.Group<PD.Normalize<{
        ionic: PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'pi-stacking': PD.NamedParams<{
            distanceMax: PD.Numeric;
            offsetMax: PD.Numeric;
            angleDevMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'cation-pi': PD.NamedParams<{
            distanceMax: PD.Numeric;
            offsetMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'halogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            angleMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'hydrogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            backbone: PD.BooleanParam;
            accAngleDevMax: PD.Numeric;
            ignoreHydrogens: PD.BooleanParam;
            donAngleDevMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
            water: PD.BooleanParam;
            sulfurDistanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'weak-hydrogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            backbone: PD.BooleanParam;
            accAngleDevMax: PD.Numeric;
            ignoreHydrogens: PD.BooleanParam;
            donAngleDevMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        hydrophobic: PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'metal-coordination': PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
    }>>;
    bridges: PD.Group<PD.Normalize<{
        'water-bridges': PD.NamedParams<{
            backbone: PD.BooleanParam;
            ignoreHydrogens: PD.BooleanParam;
            legDistMin: PD.Numeric;
            legDistMax: PD.Numeric;
            donAngleDevMax: PD.Numeric;
            accAngleDevMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            omegaMin: PD.Numeric;
            omegaMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
    }>>;
    contacts: PD.Group<PD.Normalize<{
        lineOfSightDistFactor: number;
    }>>;
};
export type InteractionsParams = typeof InteractionsParams;
export type InteractionsProps = PD.Values<InteractionsParams>;
export type InteractionsValue = Interactions;
export declare const InteractionsProvider: CustomStructureProperty.Provider<InteractionsParams, InteractionsValue>;
//# sourceMappingURL=interactions.d.ts.map