/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Fred Ludlow <Fred.Ludlow@astx.com>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 *
 * based in part on NGL (https://github.com/arose/ngl)
 */
import { Features } from './features.js';
import type { ContactProvider } from './contacts.js';
import { IonicParams, PiStackingParams, CationPiParams } from './params.js';
export declare const NegativChargeProvider: Features.Provider;
export declare const PositiveChargeProvider: Features.Provider;
export declare const AromaticRingProvider: Features.Provider;
export declare const IonicProvider: ContactProvider<IonicParams>;
export declare const PiStackingProvider: ContactProvider<PiStackingParams>;
export declare const CationPiProvider: ContactProvider<CationPiParams>;
//# sourceMappingURL=charged.d.ts.map