/**
 * Copyright (c) 2019-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { IntAdjacencyGraph } from '@molstar/core/math/graph';
import { InterUnitGraph } from '@molstar/core/math/graph/inter-unit-graph';
import type { Unit } from '@molstar/model/model/structure';
import type { AssignableArrayLike } from '@molstar/core/util/type-helpers';
import type { Features } from './features.js';
import type { StructureElement } from '@molstar/model/model/structure/structure';
import type { IntMap } from '@molstar/core/data/int';
export { InteractionsIntraContacts };
interface InteractionsIntraContacts extends IntAdjacencyGraph<Features.FeatureIndex, InteractionsIntraContacts.Props> {
    readonly elementsIndex: InteractionsIntraContacts.ElementsIndex;
}
declare namespace InteractionsIntraContacts {
    type Props = {
        readonly type: ArrayLike<InteractionType>;
        readonly flag: AssignableArrayLike<InteractionFlag>;
    };
    /** maps unit elements to contacts, range for unit element i is offsets[i] to offsets[i + 1] */
    type ElementsIndex = {
        /** intra contact indices */
        readonly indices: ArrayLike<number>;
        /** range for unit element i is offsets[i] to offsets[i + 1] */
        readonly offsets: ArrayLike<number>;
    };
    /**
     * Note: assumes that feature members of a contact are non-overlapping
     */
    function createElementsIndex(contacts: IntAdjacencyGraph<Features.FeatureIndex, Props>, features: Features, elementsCount: number): {
        indices: Int32Array<ArrayBuffer>;
        offsets: Int32Array<ArrayBuffer>;
    };
}
export { InteractionsInterContacts };
declare class InteractionsInterContacts extends InterUnitGraph<number, Features.FeatureIndex, InteractionsInterContacts.Props> {
    private readonly elementKeyIndex;
    getContactIndicesForElement(index: StructureElement.UnitIndex, unit: Unit): ReadonlyArray<number>;
    private getElementKey;
    constructor(map: Map<number, InterUnitGraph.UnitPairEdges<number, Features.FeatureIndex, InteractionsInterContacts.Props>[]>, unitsFeatures: IntMap<Features>);
}
declare namespace InteractionsInterContacts {
    type Props = {
        type: InteractionType;
        flag: InteractionFlag;
    };
}
export declare enum InteractionFlag {
    None = 0,
    Filtered = 1
}
export declare enum InteractionType {
    Unknown = 0,
    Ionic = 1,
    CationPi = 2,
    PiStacking = 3,
    HydrogenBond = 4,
    HalogenBond = 5,
    Hydrophobic = 6,
    MetalCoordination = 7,
    WeakHydrogenBond = 8,
    WaterBridge = 9
}
export declare function interactionTypeLabel(type: InteractionType): string;
export declare const enum FeatureType {
    None = 0,
    PositiveCharge = 1,
    NegativeCharge = 2,
    AromaticRing = 3,
    HydrogenDonor = 4,
    HydrogenAcceptor = 5,
    HalogenDonor = 6,
    HalogenAcceptor = 7,
    HydrophobicAtom = 8,
    WeakHydrogenDonor = 9,
    IonicTypePartner = 10,
    DativeBondPartner = 11,
    TransitionMetal = 12,
    IonicTypeMetal = 13
}
export declare enum FeatureTypes {
    None = 0,
    PositiveCharge = 1,
    NegativeCharge = 2,
    AromaticRing = 3,
    HydrogenDonor = 4,
    HydrogenAcceptor = 5,
    HalogenDonor = 6,
    HalogenAcceptor = 7,
    HydrophobicAtom = 8,
    WeakHydrogenDonor = 9,
    IonicTypePartner = 10,
    DativeBondPartner = 11,
    TransitionMetal = 12,
    IonicTypeMetal = 13
}
export declare function featureTypeLabel(type: FeatureType): string;
export declare enum FeatureGroup {
    None = 0,
    QuaternaryAmine = 1,
    TertiaryAmine = 2,
    Sulfonium = 3,
    SulfonicAcid = 4,
    Sulfate = 5,
    Phosphate = 6,
    Halocarbon = 7,
    Guanidine = 8,
    Acetamidine = 9,
    Carboxylate = 10
}
export declare function featureGroupLabel(group: FeatureGroup): string;
//# sourceMappingURL=common.d.ts.map