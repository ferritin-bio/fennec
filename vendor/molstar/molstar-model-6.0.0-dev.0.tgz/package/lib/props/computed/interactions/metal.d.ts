/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * based in part on NGL (https://github.com/arose/ngl)
 */
import { Features } from './features.js';
import type { ContactProvider } from './contacts.js';
import { MetalCoordinationParams } from './params.js';
export declare const MetalProvider: Features.Provider;
export declare const MetalBindingProvider: Features.Provider;
export declare const MetalCoordinationProvider: ContactProvider<MetalCoordinationParams>;
//# sourceMappingURL=metal.d.ts.map