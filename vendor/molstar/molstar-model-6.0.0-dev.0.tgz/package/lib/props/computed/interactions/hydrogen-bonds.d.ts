/**
 * Copyright (c) 2019-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Fred Ludlow <Fred.Ludlow@astx.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 *
 * based in part on NGL (https://github.com/arose/ngl)
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Structure } from '@molstar/model/model/structure';
import { Features } from './features.js';
import type { ContactProvider } from './contacts.js';
import { GeometryParams, HydrogenBondsParams, WeakHydrogenBondsParams } from './params.js';
type GeometryProps = PD.Values<GeometryParams>;
export declare function getGeometryOptions(props: GeometryProps): {
    ignoreHydrogens: boolean;
    includeBackbone: boolean;
    maxAccAngleDev: number;
    maxDonAngleDev: number;
    maxAccOutOfPlaneAngle: number;
    maxDonOutOfPlaneAngle: number;
};
export type GeometryOptions = ReturnType<typeof getGeometryOptions>;
export declare function checkGeometry(structure: Structure, don: Features.Info, acc: Features.Info, opts: GeometryOptions): true | undefined;
export declare const HydrogenDonorProvider: Features.Provider;
export declare const WeakHydrogenDonorProvider: Features.Provider;
export declare const HydrogenAcceptorProvider: Features.Provider;
export declare const HydrogenBondsProvider: ContactProvider<HydrogenBondsParams>;
export declare const WeakHydrogenBondsProvider: ContactProvider<WeakHydrogenBondsParams>;
export {};
//# sourceMappingURL=hydrogen-bonds.d.ts.map