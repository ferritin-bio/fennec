/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Structure, Unit } from '@molstar/model/model/structure';
import { Features } from './features.js';
import { type InteractionsIntraContacts, type InteractionsInterContacts, type InteractionType, type InteractionFlag } from './common.js';
import { IntMap } from '@molstar/core/data/int';
import { type InteractionsProps } from './params.js';
import type { CustomProperty } from '../../common/custom-property.js';
import { DataLocation } from '@molstar/model/model/location';
import type { Sphere3D } from '@molstar/core/math/geometry';
import { DataLoci } from '@molstar/model/model/loci';
export { Interactions, Bridges };
export type { BridgeContact, BridgeContacts };
interface BridgeContact {
    readonly unitA: number;
    readonly indexA: Features.FeatureIndex;
    readonly unitB: number;
    readonly indexB: Features.FeatureIndex;
    /** mediator unit id */
    readonly unitM: number;
    /** mediator feature facing endpoint A */
    readonly indexMA: Features.FeatureIndex;
    /** mediator feature facing endpoint B */
    readonly indexMB: Features.FeatureIndex;
    props: {
        type: InteractionType;
        flag: InteractionFlag;
    };
}
type BridgeContacts = ReadonlyArray<BridgeContact>;
interface Interactions {
    /** Features of each unit */
    unitsFeatures: IntMap<Features>;
    /** Interactions of each unit */
    unitsContacts: IntMap<InteractionsIntraContacts>;
    /** Interactions between units */
    contacts: InteractionsInterContacts;
    /** Bridge-mediated interactions covering the whole structure */
    bridges: BridgeContacts;
}
declare namespace Interactions {
    type StructureInteractions = {
        readonly structure: Structure;
        readonly interactions: Interactions;
    };
    export interface Element {
        unitA: Unit;
        /** Index into features of unitA */
        indexA: Features.FeatureIndex;
        unitB: Unit;
        /** Index into features of unitB */
        indexB: Features.FeatureIndex;
    }
    export interface Location extends DataLocation<StructureInteractions, Element> {
    }
    export function Location(interactions: Interactions, structure: Structure, unitA?: Unit, indexA?: Features.FeatureIndex, unitB?: Unit, indexB?: Features.FeatureIndex): Location;
    export function isLocation(x: any): x is Location;
    export function areLocationsEqual(locA: Location, locB: Location): boolean;
    export function locationLabel(location: Location): string;
    export interface Loci extends DataLoci<StructureInteractions, Element> {
    }
    export function Loci(structure: Structure, interactions: Interactions, elements: ReadonlyArray<Element>): Loci;
    export function isLoci(x: any): x is Loci;
    export function getBoundingSphere(interactions: Interactions, elements: ReadonlyArray<Element>, boundingSphere: Sphere3D): Sphere3D;
    export function getLabel(structure: Structure, interactions: Interactions, elements: ReadonlyArray<Element>): string;
    export {};
}
declare namespace Bridges {
    interface Data {
        readonly structure: Structure;
        readonly bridges: BridgeContacts;
        readonly unitsFeatures: IntMap<Features>;
    }
    interface Element {
        bridgeIndex: number;
    }
    interface Location extends DataLocation<Data, Element> {
    }
    function Location(data: Data, bridgeIndex?: number): Location;
    function isLocation(x: any): x is Location;
    interface Loci extends DataLoci<Data, Element> {
    }
    function Loci(data: Data, elements: ReadonlyArray<Element>): Loci;
    function isLoci(x: any): x is Loci;
}
export interface ComputeInterctionsOptions {
    skipIntraContacts?: boolean;
    unitPairTest?: (unitA: Unit, unitB: Unit) => boolean;
}
export declare function computeInteractions(ctx: CustomProperty.Context, structure: Structure, props: Partial<InteractionsProps>, options?: ComputeInterctionsOptions): Promise<Interactions>;
//# sourceMappingURL=interactions.d.ts.map