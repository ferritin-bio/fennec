/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 *
 * based in part on NGL (https://github.com/arose/ngl)
 */
import type { Interactions } from './interactions.js';
import { type Structure } from '@molstar/model/model/structure';
export declare function refineInteractions(structure: Structure, interactions: Interactions): void;
//# sourceMappingURL=refine.d.ts.map