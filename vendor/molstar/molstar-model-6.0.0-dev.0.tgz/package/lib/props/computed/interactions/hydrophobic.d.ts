/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Fred Ludlow <Fred.Ludlow@astx.com>
 *
 * based in part on NGL (https://github.com/arose/ngl)
 */
import { Features } from './features.js';
import type { ContactProvider } from './contacts.js';
import { HydrophobicParams } from './params.js';
export declare const HydrophobicAtomProvider: Features.Provider;
export declare const HydrophobicProvider: ContactProvider<HydrophobicParams>;
//# sourceMappingURL=hydrophobic.d.ts.map