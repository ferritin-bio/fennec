/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Fred Ludlow <Fred.Ludlow@astx.com>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * Parameter definitions of the interactions computation. This module holds no computation code, so UI and
 * state code can describe the interaction params without loading the interaction providers.
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export declare const ContactsParams: {
    lineOfSightDistFactor: PD.Numeric;
};
export type ContactsParams = typeof ContactsParams;
export type ContactsProps = PD.Values<ContactsParams>;
export declare const IonicParams: {
    distanceMax: PD.Numeric;
};
export type IonicParams = typeof IonicParams;
export declare const PiStackingParams: {
    distanceMax: PD.Numeric;
    offsetMax: PD.Numeric;
    angleDevMax: PD.Numeric;
};
export type PiStackingParams = typeof PiStackingParams;
export declare const CationPiParams: {
    distanceMax: PD.Numeric;
    offsetMax: PD.Numeric;
};
export type CationPiParams = typeof CationPiParams;
export declare const HalogenBondsParams: {
    distanceMax: PD.Numeric;
    angleMax: PD.Numeric;
};
export type HalogenBondsParams = typeof HalogenBondsParams;
export declare const GeometryParams: {
    distanceMax: PD.Numeric;
    backbone: PD.BooleanParam;
    accAngleDevMax: PD.Numeric;
    ignoreHydrogens: PD.BooleanParam;
    donAngleDevMax: PD.Numeric;
    accOutOfPlaneAngleMax: PD.Numeric;
    donOutOfPlaneAngleMax: PD.Numeric;
};
export type GeometryParams = typeof GeometryParams;
export declare const HydrogenBondsParams: {
    distanceMax: PD.Numeric;
    backbone: PD.BooleanParam;
    accAngleDevMax: PD.Numeric;
    ignoreHydrogens: PD.BooleanParam;
    donAngleDevMax: PD.Numeric;
    accOutOfPlaneAngleMax: PD.Numeric;
    donOutOfPlaneAngleMax: PD.Numeric;
    water: PD.BooleanParam;
    sulfurDistanceMax: PD.Numeric;
};
export type HydrogenBondsParams = typeof HydrogenBondsParams;
export declare const WeakHydrogenBondsParams: {
    distanceMax: PD.Numeric;
    backbone: PD.BooleanParam;
    accAngleDevMax: PD.Numeric;
    ignoreHydrogens: PD.BooleanParam;
    donAngleDevMax: PD.Numeric;
    accOutOfPlaneAngleMax: PD.Numeric;
    donOutOfPlaneAngleMax: PD.Numeric;
};
export type WeakHydrogenBondsParams = typeof WeakHydrogenBondsParams;
export declare const HydrophobicParams: {
    distanceMax: PD.Numeric;
};
export type HydrophobicParams = typeof HydrophobicParams;
export declare const MetalCoordinationParams: {
    distanceMax: PD.Numeric;
};
export type MetalCoordinationParams = typeof MetalCoordinationParams;
export type MetalCoordinationProps = PD.Values<MetalCoordinationParams>;
export declare const WaterBridgesParams: {
    backbone: PD.BooleanParam;
    ignoreHydrogens: PD.BooleanParam;
    legDistMin: PD.Numeric;
    legDistMax: PD.Numeric;
    donAngleDevMax: PD.Numeric;
    accAngleDevMax: PD.Numeric;
    donOutOfPlaneAngleMax: PD.Numeric;
    accOutOfPlaneAngleMax: PD.Numeric;
    omegaMin: PD.Numeric;
    omegaMax: PD.Numeric;
};
export type WaterBridgesParams = typeof WaterBridgesParams;
export type WaterBridgesProps = PD.Values<WaterBridgesParams>;
export declare const ContactProviderParams: {
    ionic: PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'pi-stacking': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
        offsetMax: PD.Numeric;
        angleDevMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'cation-pi': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
        offsetMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'halogen-bonds': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
        angleMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'hydrogen-bonds': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
        backbone: PD.BooleanParam;
        accAngleDevMax: PD.Numeric;
        ignoreHydrogens: PD.BooleanParam;
        donAngleDevMax: PD.Numeric;
        accOutOfPlaneAngleMax: PD.Numeric;
        donOutOfPlaneAngleMax: PD.Numeric;
        water: PD.BooleanParam;
        sulfurDistanceMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'weak-hydrogen-bonds': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
        backbone: PD.BooleanParam;
        accAngleDevMax: PD.Numeric;
        ignoreHydrogens: PD.BooleanParam;
        donAngleDevMax: PD.Numeric;
        accOutOfPlaneAngleMax: PD.Numeric;
        donOutOfPlaneAngleMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    hydrophobic: PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
    'metal-coordination': PD.Mapped<PD.NamedParams<{
        distanceMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
};
export declare const BridgeProviderParams: {
    'water-bridges': PD.Mapped<PD.NamedParams<{
        backbone: PD.BooleanParam;
        ignoreHydrogens: PD.BooleanParam;
        legDistMin: PD.Numeric;
        legDistMax: PD.Numeric;
        donAngleDevMax: PD.Numeric;
        accAngleDevMax: PD.Numeric;
        donOutOfPlaneAngleMax: PD.Numeric;
        accOutOfPlaneAngleMax: PD.Numeric;
        omegaMin: PD.Numeric;
        omegaMax: PD.Numeric;
    }, "on"> | PD.NamedParams<{}, "off">>;
};
export declare const InteractionsParams: {
    providers: PD.Group<PD.Normalize<{
        ionic: PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'pi-stacking': PD.NamedParams<{
            distanceMax: PD.Numeric;
            offsetMax: PD.Numeric;
            angleDevMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'cation-pi': PD.NamedParams<{
            distanceMax: PD.Numeric;
            offsetMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'halogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            angleMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'hydrogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            backbone: PD.BooleanParam;
            accAngleDevMax: PD.Numeric;
            ignoreHydrogens: PD.BooleanParam;
            donAngleDevMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
            water: PD.BooleanParam;
            sulfurDistanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'weak-hydrogen-bonds': PD.NamedParams<{
            distanceMax: PD.Numeric;
            backbone: PD.BooleanParam;
            accAngleDevMax: PD.Numeric;
            ignoreHydrogens: PD.BooleanParam;
            donAngleDevMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        hydrophobic: PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
        'metal-coordination': PD.NamedParams<{
            distanceMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
    }>>;
    bridges: PD.Group<PD.Normalize<{
        'water-bridges': PD.NamedParams<{
            backbone: PD.BooleanParam;
            ignoreHydrogens: PD.BooleanParam;
            legDistMin: PD.Numeric;
            legDistMax: PD.Numeric;
            donAngleDevMax: PD.Numeric;
            accAngleDevMax: PD.Numeric;
            donOutOfPlaneAngleMax: PD.Numeric;
            accOutOfPlaneAngleMax: PD.Numeric;
            omegaMin: PD.Numeric;
            omegaMax: PD.Numeric;
        }, "on"> | PD.NamedParams<{}, "off">;
    }>>;
    contacts: PD.Group<PD.Normalize<{
        lineOfSightDistFactor: number;
    }>>;
};
export type InteractionsParams = typeof InteractionsParams;
export type InteractionsProps = PD.Values<InteractionsParams>;
//# sourceMappingURL=params.d.ts.map