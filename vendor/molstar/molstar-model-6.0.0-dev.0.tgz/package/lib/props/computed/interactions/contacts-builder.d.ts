/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Features } from './features.js';
import { type InteractionType, InteractionsIntraContacts, InteractionsInterContacts } from './common.js';
import type { Unit } from '@molstar/model/model/structure/structure';
import type { IntMap } from '@molstar/core/data/int';
export { IntraContactsBuilder };
interface IntraContactsBuilder {
    add: (indexA: Features.FeatureIndex, indexB: Features.FeatureIndex, type: InteractionType) => void;
    getContacts: () => InteractionsIntraContacts;
}
declare namespace IntraContactsBuilder {
    function create(features: Features, elementsCount: number): IntraContactsBuilder;
}
export { InterContactsBuilder };
interface InterContactsBuilder {
    startUnitPair: (unitA: Unit, unitB: Unit) => void;
    finishUnitPair: () => void;
    add: (indexA: Features.FeatureIndex, indexB: Features.FeatureIndex, type: InteractionType) => void;
    getContacts: (unitsFeatures: IntMap<Features>) => InteractionsInterContacts;
}
declare namespace InterContactsBuilder {
    function create(): InterContactsBuilder;
}
//# sourceMappingURL=contacts-builder.d.ts.map