/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type Structure, Unit } from '@molstar/model/model/structure';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { FeatureType, InteractionType } from './common.js';
import type { InterContactsBuilder, IntraContactsBuilder } from './contacts-builder.js';
import { Features } from './features.js';
import type { ContactsProps } from './params.js';
export interface ContactProvider<P extends PD.Params> {
    readonly name: string;
    readonly params: P;
    createTester(props: PD.Values<P>): ContactTester;
}
export interface ContactTester {
    readonly maxDistance: number;
    readonly requiredFeatures: ReadonlySet<FeatureType>;
    getType: (structure: Structure, infoA: Features.Info, infoB: Features.Info, distanceSq: number) => InteractionType | undefined;
}
/**
 * Add all intra-unit contacts, i.e. pairs of features
 */
export declare function addUnitContacts(structure: Structure, unit: Unit.Atomic, features: Features, builder: IntraContactsBuilder, testers: ReadonlyArray<ContactTester>, props: ContactsProps): void;
/**
 * Add all inter-unit contacts, i.e. pairs of features
 */
export declare function addStructureContacts(structure: Structure, unitA: Unit.Atomic, featuresA: Features, unitB: Unit.Atomic, featuresB: Features, builder: InterContactsBuilder, testers: ReadonlyArray<ContactTester>, props: ContactsProps): void;
//# sourceMappingURL=contacts.d.ts.map