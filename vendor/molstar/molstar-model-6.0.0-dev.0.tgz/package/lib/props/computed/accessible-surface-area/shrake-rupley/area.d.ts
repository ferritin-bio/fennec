/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type ShrakeRupleyContext } from './common.js';
import type { RuntimeContext } from '@molstar/core/task';
export declare function computeArea(runtime: RuntimeContext, ctx: ShrakeRupleyContext): Promise<void>;
//# sourceMappingURL=area.d.ts.map