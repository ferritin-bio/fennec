/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { type ShrakeRupleyContext } from './common.js';
export declare function assignRadiusForHeavyAtoms(ctx: ShrakeRupleyContext): void;
//# sourceMappingURL=radii.d.ts.map