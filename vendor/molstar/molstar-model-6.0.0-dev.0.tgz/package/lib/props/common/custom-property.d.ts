/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import type { RuntimeContext } from '@molstar/core/task';
import type { ValueBox } from '@molstar/core/util';
import type { Asset, AssetManager } from '@molstar/core/util/assets';
import type { ErrorContext } from '@molstar/core/util/error-context';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export { CustomProperty };
declare namespace CustomProperty {
    interface Context {
        runtime: RuntimeContext;
        assetManager: AssetManager;
        errorContext?: ErrorContext;
    }
    type Data<V> = {
        value: V;
        assets?: Asset.Wrapper[];
    };
    interface Container<P, V> {
        readonly props: P;
        readonly data: ValueBox<V | undefined>;
    }
    interface Provider<Data, Params extends PD.Params, Value> {
        readonly label: string;
        readonly descriptor: CustomPropertyDescriptor;
        /** Hides property in UI (in production) and always attaches */
        readonly isHidden?: boolean;
        readonly getParams: (data: Data) => Params;
        readonly defaultParams: Params;
        readonly isApplicable: (data: Data) => boolean;
        readonly attach: (ctx: Context, data: Data, props?: Partial<PD.Values<Params>>, addRef?: boolean) => Promise<void>;
        readonly ref: (data: Data, add: boolean) => void;
        readonly get: (data: Data) => ValueBox<Value | undefined>;
        readonly set: (data: Data, props: PD.Values<Params>, value?: Value) => void;
        readonly props: (data: Data) => PD.Values<Params>;
    }
    class Registry<Data> {
        private providers;
        private defaultAutoAttachValues;
        /** Get params for all applicable property providers */
        getParams(data?: Data): {
            autoAttach: PD.MultiSelect<string>;
            properties: PD.Group<PD.Normalize<{
                [x: string]: /*elided*/ any;
            }>>;
        };
        setDefaultAutoAttach(name: string, value: boolean): void;
        get(name: string): Provider<Data, any, any> | undefined;
        register(provider: Provider<Data, any, any>, defaultAutoAttach: boolean): void;
        unregister(name: string): void;
    }
}
//# sourceMappingURL=custom-property.d.ts.map