/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { CustomProperty } from './custom-property.js';
import { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import type { Volume } from '@molstar/model/model/volume/volume';
export { CustomVolumeProperty };
declare namespace CustomVolumeProperty {
    interface Provider<Params extends PD.Params, Value> extends CustomProperty.Provider<Volume, Params, Value> {
    }
    interface ProviderBuilder<Params extends PD.Params, Value> {
        readonly label: string;
        readonly descriptor: CustomPropertyDescriptor;
        readonly isHidden?: boolean;
        readonly defaultParams: Params;
        readonly getParams: (data: Volume) => Params;
        readonly isApplicable: (data: Volume) => boolean;
        readonly obtain: (ctx: CustomProperty.Context, data: Volume, props: PD.Values<Params>) => Promise<CustomProperty.Data<Value>>;
    }
    function createProvider<Params extends PD.Params, Value>(builder: ProviderBuilder<Params, Value>): CustomProperty.Provider<Volume, Params, Value>;
    function createSimple<T>(name: string, defaultValue?: T): CustomProperty.Provider<Volume, {
        value: PD.Value<T | undefined>;
    }, T | undefined>;
}
//# sourceMappingURL=custom-volume-property.d.ts.map