/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { Dsn6File } from '@molstar/io/reader/dsn6/schema';
import type { ModelFormat } from '../format.js';
export declare function volumeFromDsn6(source: Dsn6File, params?: {
    voxelSize?: Vec3;
    label?: string;
    entryId?: string;
}): Task<Volume>;
export { Dsn6Format };
type Dsn6Format = ModelFormat<Dsn6File>;
declare namespace Dsn6Format {
    function is(x?: ModelFormat): x is Dsn6Format;
    function create(dsn6: Dsn6File): Dsn6Format;
}
//# sourceMappingURL=dsn6.d.ts.map