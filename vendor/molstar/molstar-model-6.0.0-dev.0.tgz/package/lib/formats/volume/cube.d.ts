/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { CubeFile } from '@molstar/io/reader/cube/parser';
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export declare function volumeFromCube(source: CubeFile, params?: {
    dataIndex?: number;
    label?: string;
    entryId?: string;
}): Task<Volume>;
export { CubeFormat };
type CubeFormat = ModelFormat<CubeFile>;
declare namespace CubeFormat {
    function is(x?: ModelFormat): x is CubeFormat;
    function create(cube: CubeFile): CubeFormat;
}
//# sourceMappingURL=cube.d.ts.map