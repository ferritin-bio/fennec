/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { SF_Database } from '@molstar/io/reader/cif/schema/sf';
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export type StructureFactorMapType = '2fo-fc' | 'fo-fc';
export declare function volumeFromStructureFactors(source: SF_Database, params?: Partial<{
    label: string;
    entryId: string;
    mapType: StructureFactorMapType;
}>): Task<Volume>;
export { SfFormat };
type SfFormat = ModelFormat<SF_Database>;
declare namespace SfFormat {
    function is(x?: ModelFormat): x is SfFormat;
    function create(db: SF_Database): SfFormat;
}
//# sourceMappingURL=structure-factors.d.ts.map