/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { DxFile } from '@molstar/io/reader/dx/parser';
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export declare function volumeFromDx(source: DxFile, params?: {
    label?: string;
    entryId?: string;
}): Task<Volume>;
export { DxFormat };
type DxFormat = ModelFormat<DxFile>;
declare namespace DxFormat {
    function is(x?: ModelFormat): x is DxFormat;
    function create(dx: DxFile): DxFormat;
}
//# sourceMappingURL=dx.d.ts.map