/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { MtzFile, MtzHeader } from '@molstar/io/reader/mtz/schema';
/**
 * Describes a detected amplitude + phase column pair that can be used to
 * compute an electron density map.
 */
export interface MtzColumnPair {
    /** Human-readable label for the map type, e.g. '2fo-fc' or 'fo-fc'. */
    label: string;
    /** Column label of the amplitude (type F) column. */
    ampLabel: string;
    /** Column label of the phase (type P) column. */
    phiLabel: string;
}
/**
 * Scan the MTZ header for recognised amplitude+phase column pairs.
 * Returns an array of detected pairs in priority order (first = most preferred).
 */
export declare function detectMtzColumnPairs(header: MtzHeader): MtzColumnPair[];
export type MtzMapParams = Partial<{
    label: string;
    entryId: string;
    /** Label of the amplitude column (type F). Defaults to 'FWT'. */
    ampLabel: string;
    /** Label of the phase column (type P). Defaults to 'PHWT'. */
    phiLabel: string;
}>;
/**
 * Compute a real-space electron density volume from an MTZ reflection file.
 *
 * The cell is taken from the first non-base dataset's DCELL record; if absent
 * the global CELL header record is used instead.
 *
 * @param source  Parsed MTZ file.
 * @param params  Optional overrides for labels and identifiers.
 */
export declare function volumeFromMtz(source: MtzFile, params?: MtzMapParams): Task<Volume>;
export { MtzFormat };
type MtzFormat = ModelFormat<MtzFile>;
declare namespace MtzFormat {
    function is(x?: ModelFormat): x is MtzFormat;
    function create(mtz: MtzFile): MtzFormat;
}
//# sourceMappingURL=mtz.d.ts.map