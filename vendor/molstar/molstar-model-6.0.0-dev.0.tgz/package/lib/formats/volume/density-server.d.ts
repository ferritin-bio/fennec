/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { DensityServer_Data_Database } from '@molstar/io/reader/cif/schema/density-server';
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export declare function volumeFromDensityServerData(source: DensityServer_Data_Database, params?: Partial<{
    label: string;
    entryId: string;
}>): Task<Volume>;
export { DscifFormat };
type DscifFormat = ModelFormat<DensityServer_Data_Database>;
declare namespace DscifFormat {
    function is(x?: ModelFormat): x is DscifFormat;
    function create(dscif: DensityServer_Data_Database): DscifFormat;
}
//# sourceMappingURL=density-server.d.ts.map