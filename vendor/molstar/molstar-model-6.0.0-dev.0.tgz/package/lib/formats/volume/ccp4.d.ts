/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Volume } from '@molstar/model/model/volume';
import { Task } from '@molstar/core/task';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { Ccp4File, Ccp4Header } from '@molstar/io/reader/ccp4/schema';
import type { ModelFormat } from '../format.js';
/** When available (e.g. in MRC files) use ORIGIN records instead of N[CRS]START */
export declare function getCcp4Origin(header: Ccp4Header): Vec3;
export declare function getCcp4Size(header: Ccp4Header): Vec3;
/**
 * Cell angles outside (0, 180) degrees would give a degenerate fractional
 * transform. Some files leave them unset (e.g. MRC volumes written by IMOD
 * write a zero `cellb`), in which case a right angle is assumed.
 */
export declare function getCcp4Angles(header: Ccp4Header): Vec3;
export declare function volumeFromCcp4(source: Ccp4File, params?: {
    voxelSize?: Vec3;
    offset?: Vec3;
    label?: string;
    entryId?: string;
}): Task<Volume>;
export { Ccp4Format };
type Ccp4Format = ModelFormat<Ccp4File>;
declare namespace Ccp4Format {
    function is(x?: ModelFormat): x is Ccp4Format;
    function create(ccp4: Ccp4File): Ccp4Format;
}
//# sourceMappingURL=ccp4.d.ts.map