/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { RuntimeContext } from '@molstar/core/task';
import type { Spacegroup } from '@molstar/core/math/geometry';
/**
 * Core electron density computation shared by all structure-factor → volume pathways.
 *
 * Given arrays of Miller indices (h, k, l), structure-factor amplitudes, and phases
 * (in degrees), this function:
 *   1. Sizes a reciprocal-space grid (next power-of-2 that accommodates all indices),
 *   2. Expands reflections through all spacegroup symmetry operators,
 *   3. Applies Friedel's law,
 *   4. Computes the 3D forward FFT using the Hermitian half-spectrum shortcut,
 *   5. Returns the real-valued density grid and its dimensions.
 *
 * @param h         Miller index h array (length = number of reflections)
 * @param k         Miller index k array
 * @param l         Miller index l array
 * @param amp       Structure-factor amplitudes (same length)
 * @param phi       Structure-factor phases in degrees (same length)
 * @param sg        Spacegroup (symmetry operators in fractional coordinates)
 * @param ctx       RuntimeContext for progress reporting
 * @returns         Density Float32Array in row-major (N0, N1, N2) order plus grid dims
 */
export declare function computeElectronDensityFromReflections(h: ArrayLike<number>, k: ArrayLike<number>, l: ArrayLike<number>, amp: ArrayLike<number>, phi: ArrayLike<number>, sg: Spacegroup, ctx: RuntimeContext): Promise<{
    density: Float32Array;
    N0: number;
    N1: number;
    N2: number;
}>;
//# sourceMappingURL=reflections.d.ts.map