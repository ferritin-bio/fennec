/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 * @author Tadej Satler <tadej.satler@gmail.com>
 *
 * Minimal MRC/CCP4 binary writer (MODE=2, float32).
 * Spec: https://www.ccpem.ac.uk/mrc_format/mrc2014.php
 */
import { Grid } from '@molstar/model/model/volume';
export declare namespace CCP4Writer {
    function writeMrc(grid: Grid, data: Uint8Array | Float32Array): ArrayBuffer;
}
//# sourceMappingURL=ccp4.d.ts.map