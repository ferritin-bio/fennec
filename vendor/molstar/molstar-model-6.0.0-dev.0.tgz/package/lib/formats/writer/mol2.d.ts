/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 */
import type { Encoder } from '@molstar/io/writer/cif/encoder';
export declare namespace Mol2Writer {
    interface EncoderParams {
        encoderName?: string;
        metaInformation?: boolean;
        hydrogens?: boolean;
    }
    function createEncoder(params?: EncoderParams): Encoder;
}
//# sourceMappingURL=mol2.d.ts.map