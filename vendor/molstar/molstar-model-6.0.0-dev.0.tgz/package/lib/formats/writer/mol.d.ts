/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 */
import type { Encoder } from '@molstar/io/writer/cif/encoder';
export declare namespace MolWriter {
    interface EncoderParams {
        encoderName?: string;
        hydrogens?: boolean;
    }
    function createEncoder(params?: EncoderParams): Encoder;
}
//# sourceMappingURL=mol.d.ts.map