/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { Coordinates } from '@molstar/model/model/structure/coordinates';
import { type LammpsFrame, type LammpsTrajectoryFile, type UnitStyle } from '@molstar/io/reader/lammps/schema';
import { Task } from '@molstar/core/task';
import type { Trajectory } from '@molstar/model/model/structure';
import type { ModelFormat } from '../format.js';
/**
 * A LAMMPS dump may list atoms in a different order in every frame: LAMMPS splits
 * the simulation box across processors (spatial domain decomposition) and writes
 * each processor's atoms as they arrive, so the per-frame order follows how atoms
 * are distributed and migrate between domains rather than their id. That order also
 * generally does not match a separately-loaded topology (e.g. a sorted `.data`
 * file). Each atom row carries its `id`, so we scatter every frame into canonical
 * id order (row for `id` lands at 0-based array slot `id - 1`) to keep all frames
 * consistent with each other and with the topology. Without this, coordinates land
 * on the wrong atoms.
 * (Dumps written with `dump_modify sort id` are already ordered and hit the
 * identity fast-path below.)
 *
 * Returns the source-row -> canonical-index permutation, or `undefined` when no
 * reordering is needed (rows already in id order) or the ids are not a contiguous
 * 1..count set - in both cases callers keep file order. Allocates the permutation
 * only once a row is found out of order, in a single pass (`atomId.value` parses a
 * token, so it is read exactly once per row).
 */
export declare function getCanonicalOrder(frame: Pick<LammpsFrame, 'count' | 'atomId'>): Int32Array | undefined;
export declare function coordinatesFromLammpsTrajectory(file: LammpsTrajectoryFile, unitsStyle?: UnitStyle): Task<Coordinates>;
export { LammpsTrajectoryFormat };
type LammpsTrajectoryFormat = ModelFormat<LammpsTrajectoryFile>;
declare namespace LammpsTrajectoryFormat {
    function is(x?: ModelFormat): x is LammpsTrajectoryFormat;
    function create(mol: LammpsTrajectoryFile): LammpsTrajectoryFormat;
}
export declare function trajectoryFromLammpsTrajectory(mol: LammpsTrajectoryFile, unitsStyle?: UnitStyle): Task<Trajectory>;
//# sourceMappingURL=lammps-trajectory.d.ts.map