/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { DcdFile } from '@molstar/io/reader/dcd/parser';
import { Coordinates } from '@molstar/model/model/structure/coordinates';
export declare function coordinatesFromDcd(dcdFile: DcdFile): Task<Coordinates>;
//# sourceMappingURL=dcd.d.ts.map