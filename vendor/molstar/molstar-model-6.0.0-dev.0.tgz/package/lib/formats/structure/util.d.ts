/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { StringLike } from '@molstar/core/util/string-like';
import { type Tokens } from '@molstar/io/reader/common/text/tokenizer';
export declare function guessElementSymbolTokens(tokens: Tokens, str: StringLike, start: number, end: number): void;
export declare function guessElementSymbolString(atomId: string, compId: string): string;
//# sourceMappingURL=util.d.ts.map