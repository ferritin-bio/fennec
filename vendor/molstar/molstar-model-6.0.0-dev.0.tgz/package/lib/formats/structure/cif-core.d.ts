/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { CifCore_Database } from '@molstar/io/reader/cif/schema/cif-core';
import { type CifFrame } from '@molstar/io/reader/cif';
import type { Trajectory } from '@molstar/model/model/structure';
export { CifCoreFormat };
type CifCoreFormat = ModelFormat<CifCoreFormat.Data>;
declare namespace CifCoreFormat {
    type Data = {
        db: CifCore_Database;
        frame: CifFrame;
    };
    function is(x?: ModelFormat): x is CifCoreFormat;
    function fromFrame(frame: CifFrame, db?: CifCore_Database): CifCoreFormat;
}
export declare function trajectoryFromCifCore(frame: CifFrame): Task<Trajectory>;
//# sourceMappingURL=cif-core.d.ts.map