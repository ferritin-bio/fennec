/**
 * Copyright (c) 2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { SdfFileCompound } from '@molstar/io/reader/sdf/parser';
import type { Trajectory } from '@molstar/model/model/structure';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export { SdfFormat };
type SdfFormat = ModelFormat<SdfFileCompound>;
declare namespace SdfFormat {
    function is(x?: ModelFormat): x is SdfFormat;
    function create(mol: SdfFileCompound): SdfFormat;
}
export declare function trajectoryFromSdf(mol: SdfFileCompound): Task<Trajectory>;
//# sourceMappingURL=sdf.d.ts.map