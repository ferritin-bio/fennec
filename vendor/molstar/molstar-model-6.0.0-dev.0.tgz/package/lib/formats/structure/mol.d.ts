/**
 * Copyright (c) 2019-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Panagiotis Tourlas <panagiot_tourlov@hotmail.com>
 */
import { type MolFile } from '@molstar/io/reader/mol/parser';
import { type RuntimeContext, Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { Trajectory } from '@molstar/model/model/structure';
export declare function getMolModels(mol: MolFile, format: ModelFormat<any> | undefined, ctx: RuntimeContext): Promise<import("@molstar/model/model/structure").ArrayTrajectory>;
export { MolFormat };
type MolFormat = ModelFormat<MolFile>;
declare namespace MolFormat {
    function is(x?: ModelFormat): x is MolFormat;
    function create(mol: MolFile): MolFormat;
}
export declare function trajectoryFromMol(mol: MolFile): Task<Trajectory>;
//# sourceMappingURL=mol.d.ts.map