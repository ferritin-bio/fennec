/**
 * Copyright (c) 2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { NctrajFile } from '@molstar/io/reader/nctraj/parser';
import { Coordinates } from '@molstar/model/model/structure/coordinates';
export declare function coordinatesFromNctraj(file: NctrajFile): Task<Coordinates>;
//# sourceMappingURL=nctraj.d.ts.map