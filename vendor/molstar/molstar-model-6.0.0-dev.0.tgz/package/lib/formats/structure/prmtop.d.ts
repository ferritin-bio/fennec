/**
 * Copyright (c) 2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PrmtopFile } from '@molstar/io/reader/prmtop/parser';
import { Topology } from '@molstar/model/model/structure/topology/topology';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export { PrmtopFormat };
type PrmtopFormat = ModelFormat<PrmtopFile>;
declare namespace PrmtopFormat {
    function is(x?: ModelFormat): x is PrmtopFormat;
    function fromPrmtop(prmtop: PrmtopFile): PrmtopFormat;
}
export declare function topologyFromPrmtop(prmtop: PrmtopFile): Task<Topology>;
//# sourceMappingURL=prmtop.d.ts.map