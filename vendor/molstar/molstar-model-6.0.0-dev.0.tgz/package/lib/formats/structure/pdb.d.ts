/**
 * Copyright (c) 2019-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PdbFile } from '@molstar/io/reader/pdb/schema';
import { Task } from '@molstar/core/task';
import type { Trajectory } from '@molstar/model/model/structure';
import type { ModelFormat } from '../format.js';
export { PdbFormat };
type PdbFormat = ModelFormat<PdbFile>;
declare namespace PdbFormat {
    function is(x?: ModelFormat): x is PdbFormat;
    function create(pdb: PdbFile): PdbFormat;
}
export declare function trajectoryFromPDB(pdb: PdbFile): Task<Trajectory>;
//# sourceMappingURL=pdb.d.ts.map