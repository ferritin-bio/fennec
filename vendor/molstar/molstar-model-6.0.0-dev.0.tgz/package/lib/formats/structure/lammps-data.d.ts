/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 * @author Himanshu Raj <himanshuraj6771@gmail.com>
 */
import { type LammpsDataFile, type UnitStyle } from '@molstar/io/reader/lammps/schema';
import { type Trajectory } from '@molstar/model/model/structure';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export { LammpsDataFormat };
type LammpsDataFormat = ModelFormat<LammpsDataFile>;
declare namespace LammpsDataFormat {
    function is(x?: ModelFormat): x is LammpsDataFormat;
    function create(mol: LammpsDataFile): LammpsDataFormat;
}
export declare function trajectoryFromLammpsData(mol: LammpsDataFile, unitsStyle?: UnitStyle): Task<Trajectory>;
//# sourceMappingURL=lammps-data.d.ts.map