import { type ElementSymbol } from '@molstar/model/model/structure/model/types';
/**
 * Resolve the closest matching element symbol for a given atomic mass.
 *
 * @param mass atomic mass to resolve, in amu
 * @param tolerance max allowed percentage difference between the given mass and the closest element mass
 * @returns the closest element symbol within `tolerance`, or `undefined` if none is close enough
 */
export declare function getElementSymbolFromMass(mass: number, tolerance?: number): ElementSymbol | undefined;
//# sourceMappingURL=element-mass.d.ts.map