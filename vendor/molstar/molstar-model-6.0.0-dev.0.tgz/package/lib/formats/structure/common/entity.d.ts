/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */
import { MoleculeType } from '@molstar/model/model/structure/model/types';
import { Column, Table } from '@molstar/core/data/db';
export type EntityCompound = {
    chains: string[];
    description: string;
};
export declare class EntityBuilder {
    private count;
    private ids;
    private types;
    private descriptions;
    private compoundsMap;
    private seqresMap;
    private namesMap;
    private heteroMap;
    private chainMap;
    private sequenceMap;
    private waterId?;
    private polymerCount;
    private set;
    private addPolymer;
    private isSeqresCap;
    private addNonPolymer;
    getEntityId(compId: string, moleculeType: MoleculeType, chainId: string, options?: {
        customName?: string;
    }): string;
    getEntityTable(): Table<{
        details: Column.Schema.Str;
        formula_weight: Column.Schema.Float;
        id: Column.Schema.Str;
        src_method: Column.Schema.Aliased<"man" | "nat" | "syn">;
        type: Column.Schema.Aliased<"branched" | "macrolide" | "non-polymer" | "polymer" | "water">;
        pdbx_description: Column.Schema.List<string>;
        pdbx_number_of_molecules: Column.Schema.Int;
        pdbx_parent_entity_id: Column.Schema.Str;
        pdbx_mutation: Column.Schema.Str;
        pdbx_fragment: Column.Schema.Str;
        pdbx_ec: Column.Schema.List<string>;
    }>;
    setCompounds(compounds: EntityCompound[]): void;
    setNames(names: [string, string][]): void;
    setSeqres(seqresMap: Map<string, string[]>): void;
    /** Get entity_id for a chain based on SEQRES data. Only valid after all atoms have been processed via getEntityId. */
    getEntityIdForChain(chainId: string): string | undefined;
}
//# sourceMappingURL=entity.d.ts.map