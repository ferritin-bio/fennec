/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Table, Column } from '@molstar/core/data/db';
export declare class ComponentBuilder {
    private seqId;
    private atomId;
    private namesMap;
    private comps;
    private ids;
    private names;
    private types;
    private mon_nstd_flags;
    private set;
    private getAtomIds;
    private hasAtomIds;
    private getType;
    has(compId: string): boolean;
    get(compId: string): Table.Row<Pick<{
        formula: Column.Schema.Str;
        formula_weight: Column.Schema.Float;
        id: Column.Schema.Str;
        mon_nstd_flag: Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        name: Column.Schema.Str;
        pdbx_synonyms: Column.Schema.List<string>;
        type: Column.Schema.Aliased<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
    }, "id" | "name" | "type">> | undefined;
    add(compId: string, index: number): Table.Row<Pick<{
        formula: Column.Schema.Str;
        formula_weight: Column.Schema.Float;
        id: Column.Schema.Str;
        mon_nstd_flag: Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        name: Column.Schema.Str;
        pdbx_synonyms: Column.Schema.List<string>;
        type: Column.Schema.Aliased<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
    }, "id" | "name" | "type">>;
    getChemCompTable(): Table<{
        formula: Column.Schema.Str;
        formula_weight: Column.Schema.Float;
        id: Column.Schema.Str;
        mon_nstd_flag: Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        name: Column.Schema.Str;
        pdbx_synonyms: Column.Schema.List<string>;
        type: Column.Schema.Aliased<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
    }>;
    setNames(names: [string, string][]): void;
    constructor(seqId: Column<number>, atomId: Column<string>);
}
//# sourceMappingURL=component.d.ts.map