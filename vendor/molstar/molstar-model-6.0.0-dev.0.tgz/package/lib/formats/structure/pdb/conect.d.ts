/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { CifCategory, CifField } from '@molstar/io/reader/cif';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import type { Tokens } from '@molstar/io/reader/common/text/tokenizer';
export declare function parseConect(lines: Tokens, lineStart: number, lineEnd: number, sites: {
    [K in keyof mmCIF_Schema['atom_site']]?: CifField;
}): CifCategory;
//# sourceMappingURL=conect.d.ts.map