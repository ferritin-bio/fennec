/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */
import { CifCategory } from '@molstar/io/reader/cif';
import type { Tokens } from '@molstar/io/reader/common/text/tokenizer';
import type { EntityCompound } from '../common/entity.js';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
export declare function parseCmpnd(lines: Tokens, lineStart: number, lineEnd: number): EntityCompound[];
export declare function parseHetnam(lines: Tokens, lineStart: number, lineEnd: number): Map<string, string>;
export declare function parseSeqres(lines: Tokens, lineStart: number, lineEnd: number): Map<string, string[]>;
export declare function getEntityPolySeq(seqresMap: Map<string, string[]>, getEntityIdForChain: (chainId: string) => string | undefined): CifCategory | undefined;
/**
 * Build pdbx_unobs_or_zero_occ_residues by comparing SEQRES with observed ATOM records
 * Collect observed (label_asym_id, label_seq_id) pairs per model, and auth_asym_id -> label_asym_id mapping.
 * Only include atoms belonging to the polymer entity for each SEQRES chain.
 * Non-polymer HETATMs (ions, ligands, water) share auth_asym_id in PDB format
 * and their sequential label_seq_id values can collide with unobserved SEQRES positions.
 */
export declare function getPdbxUnobsOrZeroOccResidues(seqresMap: Map<string, string[]>, getEntityIdForChain: (chainId: string) => string | undefined, atom_site: CifCategory.SomeFields<mmCIF_Schema['atom_site']>, modelCount: number): CifCategory | undefined;
//# sourceMappingURL=entity.d.ts.map