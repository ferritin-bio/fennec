/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Kim Juho <juho_kim@outlook.com>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { CifField } from '@molstar/io/reader/cif';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { Tokenizer } from '@molstar/io/reader/common/text/tokenizer';
import { Column } from '@molstar/core/data/db';
import type { StringLike } from '@molstar/core/util/string-like';
type AtomSiteTemplate = typeof getAtomSiteTemplate extends (...args: any) => infer T ? T : never;
export declare function getAtomSiteTemplate(data: StringLike, count: number): {
    index: number;
    group_PDB: import("@molstar/core/util/token-ranges").Tokens;
    id: string[];
    auth_atom_id: import("@molstar/core/util/token-ranges").Tokens;
    label_alt_id: import("@molstar/core/util/token-ranges").Tokens;
    auth_comp_id: import("@molstar/core/util/token-ranges").Tokens;
    auth_asym_id: import("@molstar/core/util/token-ranges").Tokens;
    auth_seq_id: import("@molstar/core/util/token-ranges").Tokens;
    pdbx_PDB_ins_code: import("@molstar/core/util/token-ranges").Tokens;
    Cartn_x: import("@molstar/core/util/token-ranges").Tokens;
    Cartn_y: import("@molstar/core/util/token-ranges").Tokens;
    Cartn_z: import("@molstar/core/util/token-ranges").Tokens;
    occupancy: import("@molstar/core/util/token-ranges").Tokens;
    B_iso_or_equiv: import("@molstar/core/util/token-ranges").Tokens;
    type_symbol: import("@molstar/core/util/token-ranges").Tokens;
    pdbx_PDB_model_num: string[];
    label_entity_id: string[];
    partial_charge: import("@molstar/core/util/token-ranges").Tokens;
};
export declare class LabelAsymIdHelper {
    private asymIds;
    private modelNums;
    private terIndices;
    private hasAssemblies;
    constructor(asymIds: Column<string>, modelNums: string[], terIndices: Set<number>, hasAssemblies: boolean);
    private asymIdCounts;
    private currModelNum;
    private currAsymId;
    private currLabelAsymId;
    clear(): void;
    get(i: number): string;
}
export declare function getAtomSite(sites: AtomSiteTemplate, labelAsymIdHelper: LabelAsymIdHelper, options: {
    hasAssemblies: boolean;
    seqresMap?: Map<string, string[]>;
}): {
    [K in keyof mmCIF_Schema['atom_site'] | 'partial_charge']?: CifField;
};
export declare function addAtom(sites: AtomSiteTemplate, model: string, data: Tokenizer, s: number, e: number, variant: 'pdb' | 'pdbqt' | 'pqr'): void;
export {};
//# sourceMappingURL=atom-site.d.ts.map