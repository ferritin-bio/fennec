/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yana Rose <yana.v.rose@gmail.com>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */
import { type CifFrame } from '@molstar/io/reader/cif';
import type { PdbFile } from '@molstar/io/reader/pdb/schema';
export declare function pdbToMmCif(pdb: PdbFile): Promise<CifFrame>;
//# sourceMappingURL=to-cif.d.ts.map