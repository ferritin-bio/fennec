/**
 * Copyright (c) 2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { TopFile } from '@molstar/io/reader/top/parser';
import { Topology } from '@molstar/model/model/structure/topology/topology';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export { TopFormat };
type TopFormat = ModelFormat<TopFile>;
declare namespace TopFormat {
    function is(x?: ModelFormat): x is TopFormat;
    function fromTop(top: TopFile): TopFormat;
}
export declare function topologyFromTop(top: TopFile): Task<Topology>;
//# sourceMappingURL=top.d.ts.map