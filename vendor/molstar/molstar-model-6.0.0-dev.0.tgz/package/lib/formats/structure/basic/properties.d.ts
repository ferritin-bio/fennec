/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */
import type { Model } from '@molstar/model/model/structure/model/model';
import type { AtomicHierarchy } from '@molstar/model/model/structure/model/properties/atomic';
import { type SaccharideComponentMap } from '@molstar/model/model/structure/structure/carbohydrates/constants';
import type { BasicData } from './schema.js';
export declare function getMissingResidues(data: BasicData): Model['properties']['missingResidues'];
export declare function getChemicalComponentMap(data: BasicData): Model['properties']['chemicalComponentMap'];
export declare function getSaccharideComponentMap(data: BasicData): SaccharideComponentMap;
export declare function getStructAsymMap(atomic: AtomicHierarchy, data?: BasicData): Model['properties']['structAsymMap'];
//# sourceMappingURL=properties.d.ts.map