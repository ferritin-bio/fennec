/**
 * Copyright (c) 2017-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Column } from '@molstar/core/data/db';
import { SymmetryOperator } from '@molstar/core/math/geometry';
import type { ChainIndex } from '@molstar/model/model/structure';
import type { Model } from '@molstar/model/model/structure/model/model';
import { type AtomicConformation, type AtomicHierarchy } from '@molstar/model/model/structure/model/properties/atomic';
import type { Entities } from '@molstar/model/model/structure/model/properties/common';
import type { ModelFormat } from '../../format.js';
import type { AtomSite } from './schema.js';
export declare function getAtomicHierarchyAndConformation(atom_site: AtomSite, sourceIndex: Column<number>, entities: Entities, chemicalComponentMap: Model['properties']['chemicalComponentMap'], format: ModelFormat, previous?: Model): {
    sameAsPrevious: boolean;
    hierarchy: AtomicHierarchy;
    conformation: AtomicConformation;
    chainOperatorMapping: Map<ChainIndex, SymmetryOperator>;
};
//# sourceMappingURL=atomic.d.ts.map