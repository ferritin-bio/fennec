/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type Entities } from '@molstar/model/model/structure/model/properties/common';
import type { Model } from '@molstar/model/model/structure/model';
import { type BasicData } from './schema.js';
export declare function getEntityData(data: BasicData): Entities;
export declare function getEntitiesWithPRD(data: BasicData, entities: Entities, structAsymMap: Model['properties']['structAsymMap']): Entities;
//# sourceMappingURL=entities.d.ts.map