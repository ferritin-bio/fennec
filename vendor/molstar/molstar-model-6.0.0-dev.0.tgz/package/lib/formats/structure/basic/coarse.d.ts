/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { CoarseHierarchy, type CoarseConformation } from '@molstar/model/model/structure/model/properties/coarse';
import type { Entities } from '@molstar/model/model/structure/model/properties/common';
import type { Column } from '@molstar/core/data/db';
import { type IhmSphereObjSite, type IhmGaussianObjSite, type AtomSite } from './schema.js';
import type { Model } from '@molstar/model/model/structure';
export interface CoarseData {
    model_id: number;
    model_name: string;
    model_group_name: string;
    entities: Entities;
    atom_site: AtomSite;
    atom_site_sourceIndex: Column<number>;
    ihm_sphere_obj_site: IhmSphereObjSite;
    ihm_gaussian_obj_site: IhmGaussianObjSite;
}
export declare const EmptyCoarse: {
    hierarchy: CoarseHierarchy;
    conformation: any;
};
export declare function getCoarse(data: CoarseData, chemicalComponentMap: Model['properties']['chemicalComponentMap']): {
    hierarchy: CoarseHierarchy;
    conformation: CoarseConformation;
};
//# sourceMappingURL=coarse.d.ts.map