/**
 * Copyright (c) 2020-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { Table } from '@molstar/core/data/db';
import { mmCIF_chemComp_schema } from '@molstar/io/reader/cif/schema/mmcif-extras';
export type Entry = Table<mmCIF_Schema['entry']>;
export type Struct = Table<mmCIF_Schema['struct']>;
export type StructAsym = Table<mmCIF_Schema['struct_asym']>;
export type IhmModelList = Table<mmCIF_Schema['ihm_model_list']>;
export type IhmModelGroup = Table<mmCIF_Schema['ihm_model_group']>;
export type IhmModelGroupLink = Table<mmCIF_Schema['ihm_model_group_link']>;
export type Entity = Table<mmCIF_Schema['entity']>;
export type EntityPoly = Table<mmCIF_Schema['entity_poly']>;
export type EntityPolySeq = Table<mmCIF_Schema['entity_poly_seq']>;
export type EntityBranch = Table<mmCIF_Schema['pdbx_entity_branch']>;
export type ChemComp = Table<mmCIF_chemComp_schema>;
export type ChemCompIdentifier = Table<mmCIF_Schema['pdbx_chem_comp_identifier']>;
export type AtomSite = Table<mmCIF_Schema['atom_site']>;
export type IhmSphereObjSite = Table<mmCIF_Schema['ihm_sphere_obj_site']>;
export type IhmGaussianObjSite = Table<mmCIF_Schema['ihm_gaussian_obj_site']>;
export type UnobsOrZeroOccResidues = Table<mmCIF_Schema['pdbx_unobs_or_zero_occ_residues']>;
export type Molecule = Table<mmCIF_Schema['pdbx_molecule']>;
export declare const BasicSchema: {
    entry: {
        id: import("@molstar/core/data/db").Column.Schema.Str;
    };
    struct: {
        entry_id: import("@molstar/core/data/db").Column.Schema.Str;
        title: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_structure_determination_methodology: import("@molstar/core/data/db").Column.Schema.Aliased<"computational" | "experimental" | "integrative">;
        pdbx_descriptor: import("@molstar/core/data/db").Column.Schema.Str;
    };
    struct_asym: {
        details: import("@molstar/core/data/db").Column.Schema.Str;
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        id: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_modified: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_blank_PDB_chainid_flag: import("@molstar/core/data/db").Column.Schema.Aliased<"N" | "Y">;
    };
    ihm_model_list: {
        model_id: import("@molstar/core/data/db").Column.Schema.Int;
        model_name: import("@molstar/core/data/db").Column.Schema.Str;
        assembly_id: import("@molstar/core/data/db").Column.Schema.Int;
        protocol_id: import("@molstar/core/data/db").Column.Schema.Int;
        representation_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    ihm_model_group: {
        id: import("@molstar/core/data/db").Column.Schema.Int;
        name: import("@molstar/core/data/db").Column.Schema.Str;
        details: import("@molstar/core/data/db").Column.Schema.Str;
    };
    ihm_model_group_link: {
        model_id: import("@molstar/core/data/db").Column.Schema.Int;
        group_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    entity: {
        details: import("@molstar/core/data/db").Column.Schema.Str;
        formula_weight: import("@molstar/core/data/db").Column.Schema.Float;
        id: import("@molstar/core/data/db").Column.Schema.Str;
        src_method: import("@molstar/core/data/db").Column.Schema.Aliased<"man" | "nat" | "syn">;
        type: import("@molstar/core/data/db").Column.Schema.Aliased<"branched" | "macrolide" | "non-polymer" | "polymer" | "water">;
        pdbx_description: import("@molstar/core/data/db").Column.Schema.List<string>;
        pdbx_number_of_molecules: import("@molstar/core/data/db").Column.Schema.Int;
        pdbx_parent_entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_mutation: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_fragment: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_ec: import("@molstar/core/data/db").Column.Schema.List<string>;
    };
    entity_poly: {
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        nstd_linkage: import("@molstar/core/data/db").Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        nstd_monomer: import("@molstar/core/data/db").Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        type: import("@molstar/core/data/db").Column.Schema.Aliased<"cyclic-pseudo-peptide" | "other" | "peptide nucleic acid" | "polydeoxyribonucleotide" | "polydeoxyribonucleotide/polyribonucleotide hybrid" | "polypeptide(D)" | "polypeptide(L)" | "polyribonucleotide">;
        pdbx_strand_id: import("@molstar/core/data/db").Column.Schema.List<string>;
        pdbx_seq_one_letter_code: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_seq_one_letter_code_can: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_target_identifier: import("@molstar/core/data/db").Column.Schema.Str;
    };
    entity_poly_seq: {
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        hetero: import("@molstar/core/data/db").Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        mon_id: import("@molstar/core/data/db").Column.Schema.Str;
        num: import("@molstar/core/data/db").Column.Schema.Int;
    };
    pdbx_entity_branch: {
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        type: import("@molstar/core/data/db").Column.Schema.Aliased<"oligosaccharide">;
    };
    chem_comp: {
        formula: import("@molstar/core/data/db").Column.Schema.Str;
        formula_weight: import("@molstar/core/data/db").Column.Schema.Float;
        id: import("@molstar/core/data/db").Column.Schema.Str;
        mon_nstd_flag: import("@molstar/core/data/db").Column.Schema.Aliased<"n" | "no" | "y" | "yes">;
        name: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_synonyms: import("@molstar/core/data/db").Column.Schema.List<string>;
        type: import("@molstar/core/data/db").Column.Schema.Aliased<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
    };
    pdbx_chem_comp_identifier: {
        comp_id: import("@molstar/core/data/db").Column.Schema.Str;
        identifier: import("@molstar/core/data/db").Column.Schema.Str;
        type: import("@molstar/core/data/db").Column.Schema.Aliased<"CAS REGISTRY NUMBER" | "COMMON NAME" | "CONDENSED IUPAC CARB SYMBOL" | "CONDENSED IUPAC CARBOHYDRATE SYMBOL" | "IUPAC CARB SYMBOL" | "IUPAC CARBOHYDRATE SYMBOL" | "MDL Identifier" | "PUBCHEM Identifier" | "SNFG CARB SYMBOL" | "SNFG CARBOHYDRATE SYMBOL" | "SYNONYM" | "SYSTEMATIC NAME">;
        program: import("@molstar/core/data/db").Column.Schema.Str;
        program_version: import("@molstar/core/data/db").Column.Schema.Str;
    };
    atom_site: {
        auth_asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        auth_atom_id: import("@molstar/core/data/db").Column.Schema.Str;
        auth_comp_id: import("@molstar/core/data/db").Column.Schema.Str;
        auth_seq_id: import("@molstar/core/data/db").Column.Schema.Int;
        B_iso_or_equiv: import("@molstar/core/data/db").Column.Schema.Float;
        Cartn_x: import("@molstar/core/data/db").Column.Schema.Coordinate;
        Cartn_y: import("@molstar/core/data/db").Column.Schema.Coordinate;
        Cartn_z: import("@molstar/core/data/db").Column.Schema.Coordinate;
        group_PDB: import("@molstar/core/data/db").Column.Schema.Aliased<"ATOM" | "HETATM">;
        id: import("@molstar/core/data/db").Column.Schema.Int;
        label_alt_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_atom_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_comp_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_seq_id: import("@molstar/core/data/db").Column.Schema.Int;
        occupancy: import("@molstar/core/data/db").Column.Schema.Float;
        type_symbol: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_PDB_ins_code: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_PDB_model_num: import("@molstar/core/data/db").Column.Schema.Int;
        pdbx_formal_charge: import("@molstar/core/data/db").Column.Schema.Int;
        pdbx_label_index: import("@molstar/core/data/db").Column.Schema.Int;
        pdbx_sifts_xref_db_name: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_sifts_xref_db_acc: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_sifts_xref_db_num: import("@molstar/core/data/db").Column.Schema.Str;
        pdbx_sifts_xref_db_res: import("@molstar/core/data/db").Column.Schema.Str;
        ihm_model_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    ihm_sphere_obj_site: {
        id: import("@molstar/core/data/db").Column.Schema.Int;
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        seq_id_begin: import("@molstar/core/data/db").Column.Schema.Int;
        seq_id_end: import("@molstar/core/data/db").Column.Schema.Int;
        asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        Cartn_x: import("@molstar/core/data/db").Column.Schema.Float;
        Cartn_y: import("@molstar/core/data/db").Column.Schema.Float;
        Cartn_z: import("@molstar/core/data/db").Column.Schema.Float;
        object_radius: import("@molstar/core/data/db").Column.Schema.Float;
        rmsf: import("@molstar/core/data/db").Column.Schema.Float;
        model_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    ihm_gaussian_obj_site: {
        id: import("@molstar/core/data/db").Column.Schema.Int;
        entity_id: import("@molstar/core/data/db").Column.Schema.Str;
        seq_id_begin: import("@molstar/core/data/db").Column.Schema.Int;
        seq_id_end: import("@molstar/core/data/db").Column.Schema.Int;
        asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        mean_Cartn_x: import("@molstar/core/data/db").Column.Schema.Float;
        mean_Cartn_y: import("@molstar/core/data/db").Column.Schema.Float;
        mean_Cartn_z: import("@molstar/core/data/db").Column.Schema.Float;
        weight: import("@molstar/core/data/db").Column.Schema.Float;
        covariance_matrix: import("@molstar/core/data/db").Column.Schema.Tensor;
        model_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    pdbx_unobs_or_zero_occ_residues: {
        id: import("@molstar/core/data/db").Column.Schema.Int;
        polymer_flag: import("@molstar/core/data/db").Column.Schema.Aliased<"n" | "y">;
        occupancy_flag: import("@molstar/core/data/db").Column.Schema.Aliased<0 | 1>;
        PDB_model_num: import("@molstar/core/data/db").Column.Schema.Int;
        auth_asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        auth_comp_id: import("@molstar/core/data/db").Column.Schema.Str;
        auth_seq_id: import("@molstar/core/data/db").Column.Schema.Int;
        PDB_ins_code: import("@molstar/core/data/db").Column.Schema.Str;
        label_asym_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_comp_id: import("@molstar/core/data/db").Column.Schema.Str;
        label_seq_id: import("@molstar/core/data/db").Column.Schema.Int;
    };
    pdbx_molecule: {
        prd_id: import("@molstar/core/data/db").Column.Schema.Str;
        instance_id: import("@molstar/core/data/db").Column.Schema.Int;
        asym_id: import("@molstar/core/data/db").Column.Schema.Str;
    };
};
export interface BasicData {
    entry: Entry;
    struct: Struct;
    struct_asym: StructAsym;
    ihm_model_list: IhmModelList;
    ihm_model_group: IhmModelGroup;
    ihm_model_group_link: IhmModelGroupLink;
    entity: Entity;
    entity_poly: EntityPoly;
    entity_poly_seq: EntityPolySeq;
    pdbx_entity_branch: EntityBranch;
    chem_comp: ChemComp;
    pdbx_chem_comp_identifier: ChemCompIdentifier;
    atom_site: AtomSite;
    ihm_sphere_obj_site: IhmSphereObjSite;
    ihm_gaussian_obj_site: IhmGaussianObjSite;
    pdbx_unobs_or_zero_occ_residues: UnobsOrZeroOccResidues;
    pdbx_molecule: Molecule;
}
export declare function createBasic(data: Partial<BasicData>, normalize?: boolean): BasicData;
//# sourceMappingURL=schema.d.ts.map