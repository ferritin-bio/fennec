/**
 * Copyright (c) 2018-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { StructureSequence } from '@molstar/model/model/structure/model/properties/sequence';
import type { AtomicHierarchy } from '@molstar/model/model/structure/model/properties/atomic';
import type { Entities } from '@molstar/model/model/structure/model/properties/common';
import type { CoarseHierarchy } from '@molstar/model/model/structure/model/properties/coarse';
import type { BasicData } from './schema.js';
export declare function getSequence(data: BasicData, entities: Entities, atomicHierarchy: AtomicHierarchy, coarseHierarchy: CoarseHierarchy): StructureSequence;
//# sourceMappingURL=sequence.d.ts.map