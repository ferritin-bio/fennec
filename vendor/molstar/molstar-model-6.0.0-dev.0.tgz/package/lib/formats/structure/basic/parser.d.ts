/**
 * Copyright (c) 2017-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { RuntimeContext } from '@molstar/core/task';
import type { ModelFormat } from '../../format.js';
import type { BasicData } from './schema.js';
import { ArrayTrajectory } from '@molstar/model/model/structure/trajectory';
export declare function createModels(data: BasicData, format: ModelFormat, ctx: RuntimeContext): Promise<ArrayTrajectory>;
//# sourceMappingURL=parser.d.ts.map