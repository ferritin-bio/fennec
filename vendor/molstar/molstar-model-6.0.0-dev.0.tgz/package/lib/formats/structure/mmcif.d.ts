/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Sebastian Bittrich <sebastian.bittrich@rcsb.org>
 */
import { Model } from '@molstar/model/model/structure/model/model';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import { MmcifFormat } from './mmcif-format.js';
import { type CifFrame, type CifFile } from '@molstar/io/reader/cif';
import { type Trajectory } from '@molstar/model/model/structure';
import type { CCD_Database } from '@molstar/io/reader/cif/schema/ccd';
export { MmcifFormat };
export declare function trajectoryFromMmCIF(frame: CifFrame, file?: CifFile): Task<Trajectory>;
export { CCDFormat };
type CCDFormat = ModelFormat<CCDFormat.Data>;
declare namespace CCDFormat {
    type Data = {
        db: CCD_Database;
        frame: CifFrame;
    };
    type CoordinateType = 'ideal' | 'model';
    const CoordinateType: {
        get(model: Model): CoordinateType | undefined;
        set(model: Model, type: CoordinateType): CoordinateType;
    };
    function is(x?: ModelFormat): x is CCDFormat;
    function fromFrame(frame: CifFrame, db?: CCD_Database): CCDFormat;
}
export declare function trajectoryFromCCD(frame: CifFrame): Task<Trajectory>;
//# sourceMappingURL=mmcif.d.ts.map