/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { Mol2File } from '@molstar/io/reader/mol2/schema';
import { type Trajectory } from '@molstar/model/model/structure';
import { Spacegroup, SpacegroupCell } from '@molstar/core/math/geometry/spacegroup/construction';
import type { Mat4 } from '@molstar/core/math/linear-algebra/3d/mat4';
/**
 * A non-default CRYSIN setting: its Hermann-Mauguin name and the recipe for its
 * symmetry operators. `axisPermutation >= 0` indexes `AxisPermutations` (a pure
 * axis relabelling of the canonical monoclinic/orthorhombic group); the sentinel
 * `-1` marks the tetragonal C/F "setting 2" descriptions, which are a genuine
 * cell doubling handled by `transformTetragonalCentering` (below) - this is a
 * CRYSIN/SYBYL-manual-specific convention, not something International Tables
 * catalogs as a numbered per-group setting.
 */
type SettingEntry = readonly [name: string, axisPermutation: number];
/**
 * The single source of non-default CRYSIN setting (2-6) data, keyed by ITA
 * space-group number. Each row is indexed by `[setting - 2]`; `null` marks a
 * setting with no alternate and trailing empties are omitted.
 */
export declare const SettingsByNumber: {
    [spacegroupNumber: number]: (SettingEntry | null)[];
};
/**
 * Computes the alternate-setting name, ITA change-of-basis symbol, and
 * symmetry operators for a MOL2 CRYSIN-style (spacegroupNumber, setting)
 * pair. Monoclinic and orthorhombic settings are a pure axis relabelling of
 * the canonical operators (via the entry's `AxisPermutations` index and
 * `transformOperators`); the tetragonal "setting 2" C/F-centered descriptions
 * are a genuine cell change derived from `baseOperators` (the canonical
 * setting-1 operators). Returns `undefined` when `setting === 1` or the
 * requested setting is unsupported - callers should fall back to the
 * canonical description in that case.
 */
export declare function getOperatorsForSetting(spacegroupNumber: number, setting: number, baseOperators: ReadonlyArray<Mat4>): {
    name: string;
    basisop: string;
    operators: Mat4[];
} | undefined;
/**
 * Resolves a MOL2 `CRYSIN` record's `(spaceGroup, setting)` pair (see
 * `Mol2Crysin` in `mol-io/reader/mol2/schema`) into a full `Spacegroup`.
 * Falls back to the canonical `Spacegroup.create(cell)` result when `setting`
 * is 1, or when the requested (spacegroupNumber, setting) combination is
 * unsupported (blank table entry, or no applicable transform) - this avoids
 * ever applying incorrect operators to a cell measured under a different
 * setting.
 */
export declare function getMol2CrysinSpacegroup(cell: SpacegroupCell, spacegroupNumber: number, setting: number): Spacegroup;
export { Mol2Format };
type Mol2Format = ModelFormat<Mol2File>;
declare namespace Mol2Format {
    function is(x?: ModelFormat): x is Mol2Format;
    function create(mol2: Mol2File): Mol2Format;
}
export declare function trajectoryFromMol2(mol2: Mol2File): Task<Trajectory>;
//# sourceMappingURL=mol2.d.ts.map