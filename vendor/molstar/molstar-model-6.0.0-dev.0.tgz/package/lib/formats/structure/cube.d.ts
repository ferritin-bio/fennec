/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { CubeFile } from '@molstar/io/reader/cube/parser';
import type { Trajectory } from '@molstar/model/model/structure';
export type CubeFormat = ModelFormat<CubeFile>;
export declare namespace CubeFormat {
    function is(x?: ModelFormat): x is CubeFormat;
    function create(cube: CubeFile): CubeFormat;
}
export declare function trajectoryFromCube(cube: CubeFile): Task<Trajectory>;
//# sourceMappingURL=cube.d.ts.map