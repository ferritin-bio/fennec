/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
import type { GroFile } from '@molstar/io/reader/gro/schema';
import type { Trajectory } from '@molstar/model/model/structure';
export { GroFormat };
type GroFormat = ModelFormat<GroFile>;
declare namespace GroFormat {
    function is(x?: ModelFormat): x is GroFormat;
    function fromGro(gro: GroFile): GroFormat;
}
export declare function trajectoryFromGRO(gro: GroFile): Task<Trajectory>;
//# sourceMappingURL=gro.d.ts.map