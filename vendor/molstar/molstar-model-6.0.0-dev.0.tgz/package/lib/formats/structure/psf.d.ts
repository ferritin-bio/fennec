/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PsfFile } from '@molstar/io/reader/psf/parser';
import { Topology } from '@molstar/model/model/structure/topology/topology';
import { Task } from '@molstar/core/task';
import type { ModelFormat } from '../format.js';
export { PsfFormat };
type PsfFormat = ModelFormat<PsfFile>;
declare namespace PsfFormat {
    function is(x?: ModelFormat): x is PsfFormat;
    function fromPsf(psf: PsfFile): PsfFormat;
}
export declare function topologyFromPsf(psf: PsfFile): Task<Topology>;
//# sourceMappingURL=psf.d.ts.map