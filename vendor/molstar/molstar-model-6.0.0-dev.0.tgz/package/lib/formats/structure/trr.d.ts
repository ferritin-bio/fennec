/**
 * Copyright (c) 2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Task } from '@molstar/core/task';
import type { TrrFile } from '@molstar/io/reader/trr/parser';
import { Coordinates } from '@molstar/model/model/structure/coordinates';
export declare function coordinatesFromTrr(file: TrrFile): Task<Coordinates>;
//# sourceMappingURL=trr.d.ts.map