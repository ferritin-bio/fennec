/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { Symmetry } from '@molstar/model/model/structure/model/properties/symmetry';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import { FormatPropertyProvider } from '../common/property.js';
import type { Table } from '@molstar/core/data/db';
export { ModelSymmetry };
declare namespace ModelSymmetry {
    export const Descriptor: CustomPropertyDescriptor;
    export const Provider: FormatPropertyProvider<Symmetry>;
    type Data = {
        symmetry: Table<mmCIF_Schema['symmetry']>;
        cell: Table<mmCIF_Schema['cell']>;
        struct_ncs_oper: Table<mmCIF_Schema['struct_ncs_oper']>;
        atom_sites: Table<mmCIF_Schema['atom_sites']>;
        pdbx_struct_assembly: Table<mmCIF_Schema['pdbx_struct_assembly']>;
        pdbx_struct_assembly_gen: Table<mmCIF_Schema['pdbx_struct_assembly_gen']>;
        pdbx_struct_oper_list: Table<mmCIF_Schema['pdbx_struct_oper_list']>;
    };
    export function fromData(data: Data): Symmetry;
    export function fromCell(size: Vec3, anglesInRadians: Vec3): Symmetry;
    export {};
}
//# sourceMappingURL=symmetry.d.ts.map