/**
 * Copyright (c) 2017-2025 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 */
import type { Model } from '@molstar/model/model/structure/model/model';
import { type Table } from '@molstar/core/data/db';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import type { ElementIndex, ResidueIndex } from '@molstar/model/model/structure/model/indexing';
import { FormatPropertyProvider } from '../../common/property.js';
export interface StructConn {
    readonly data: Table<mmCIF_Schema['struct_conn']>;
    readonly byAtomIndex: Map<ElementIndex, ReadonlyArray<StructConn.Entry>>;
    /** Cantor pairs of residue indices that have a struct-conn record */
    readonly residueCantorPairs: Set<number>;
    readonly entries: ReadonlyArray<StructConn.Entry>;
}
export declare namespace StructConn {
    const Descriptor: CustomPropertyDescriptor;
    const Provider: FormatPropertyProvider<StructConn>;
    /**
     * Heuristic to test if StructConn likely provides all atomic bonds by
     * checking if the fraction of bonds and atoms is high (> 0.95).
     */
    function isExhaustive(model: Model): boolean;
    function getAtomIndexFromEntries(entries: StructConn['entries']): Map<any, any>;
    interface Entry {
        rowIndex: number;
        distance: number;
        order: number;
        flags: number;
        partnerA: {
            residueIndex: ResidueIndex;
            atomIndex: ElementIndex;
            symmetry: string;
        };
        partnerB: {
            residueIndex: ResidueIndex;
            atomIndex: ElementIndex;
            symmetry: string;
        };
    }
    function getEntriesFromStructConn(struct_conn: Table<mmCIF_Schema['struct_conn']>, model: Model): StructConn['entries'];
}
//# sourceMappingURL=struct_conn.d.ts.map