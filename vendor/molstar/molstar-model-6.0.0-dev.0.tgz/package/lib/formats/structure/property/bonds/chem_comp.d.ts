/**
 * Copyright (c) 2017-2026 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Model } from '@molstar/model/model/structure/model/model';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { Table } from '@molstar/core/data/db';
import { FormatPropertyProvider } from '../../common/property.js';
export interface ComponentBond {
    readonly data: Table<mmCIF_Schema['chem_comp_bond']>;
    readonly entries: ReadonlyMap<string, ComponentBond.Entry>;
}
export declare namespace ComponentBond {
    const Descriptor: CustomPropertyDescriptor;
    const Provider: FormatPropertyProvider<ComponentBond>;
    function chemCompBondFromTable(model: Model, table: Table<mmCIF_Schema['chem_comp_bond']>): Table<mmCIF_Schema['chem_comp_bond']>;
    function getEntriesFromChemCompBond(data: Table<mmCIF_Schema['chem_comp_bond']>): Map<string, Entry>;
    class Pairs {
        readonly atomId: string;
        readonly compId: string;
        readonly map: Map<string, {
            order: number;
            flags: number;
            key: number;
        }>;
        get(otherAtomId: string, isHydrogen: boolean): {
            order: number;
            flags: number;
            key: number;
        } | undefined;
        constructor(atomId: string, compId: string);
    }
    class Entry {
        readonly compId: string;
        readonly map: Map<string, Pairs>;
        add(a: string, b: string, order: number, flags: number, key: number, swap?: boolean): void;
        get(a: string, isHydrogen: boolean): Pairs | undefined;
        constructor(compId: string);
    }
}
//# sourceMappingURL=chem_comp.d.ts.map