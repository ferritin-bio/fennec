/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Table, Column } from '@molstar/core/data/db';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
import { FormatPropertyProvider } from '../common/property.js';
export { AtomSiteAnisotrop };
declare const Anisotrop: {
    U: Column.Schema.Tensor;
    U_esd: Column.Schema.Tensor;
};
type Anisotrop = Table<typeof Anisotrop>;
interface AtomSiteAnisotrop {
    data: Anisotrop;
    /** maps atom_site-index to atom_site_anisotrop-index */
    elementToAnsiotrop: Int32Array;
}
declare namespace AtomSiteAnisotrop {
    const Schema: {
        U: Column.Schema.Tensor;
        U_esd: Column.Schema.Tensor;
    };
    const Descriptor: CustomPropertyDescriptor;
    const Provider: FormatPropertyProvider<AtomSiteAnisotrop>;
    function getElementToAnsiotrop(atomId: Column<number>, ansioId: Column<number>): Int32Array<ArrayBuffer>;
    function getElementToAnsiotropFromLabel(atomLabel: Column<string>, ansioLabel: Column<string>): Int32Array<ArrayBuffer>;
}
//# sourceMappingURL=anisotropic.d.ts.map