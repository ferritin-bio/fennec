/**
 * Copyright (c) 2018-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import { AtomicHierarchy } from '@molstar/model/model/structure/model/properties/atomic';
import { SecondaryStructure } from '@molstar/model/model/structure/model/properties/secondary-structure';
import { type Table } from '@molstar/core/data/db';
import { FormatPropertyProvider } from '../common/property.js';
import type { CustomPropertyDescriptor } from '@molstar/model/model/custom-property';
export { ModelSecondaryStructure };
type StructConf = Table<mmCIF_Schema['struct_conf']>;
type StructSheetRange = Table<mmCIF_Schema['struct_sheet_range']>;
declare namespace ModelSecondaryStructure {
    const Descriptor: CustomPropertyDescriptor;
    const Provider: FormatPropertyProvider<SecondaryStructure>;
    function fromStruct(conf: StructConf, sheetRange: StructSheetRange, hierarchy: AtomicHierarchy): SecondaryStructure;
}
//# sourceMappingURL=secondary-structure.d.ts.map