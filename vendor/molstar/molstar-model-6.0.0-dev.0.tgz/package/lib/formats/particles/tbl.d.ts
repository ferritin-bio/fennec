/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { DynamoTblFile } from '@molstar/io/reader/dynamo/tbl';
import type { ModelFormat } from '../format.js';
export interface DynamoParticleListOptions {
    readonly label?: string;
    readonly tomos?: ReadonlyArray<number>;
    /** Override pixel size (Å/pixel) used to convert pixel-space coordinates to angstrom. */
    readonly pixelSize?: number;
    /** Uniform particle radius in angstrom assigned to every particle. Leave 0 or undefined to omit radii. */
    readonly particleRadius?: number;
}
export declare function getDynamoTblTomogramIds(data: DynamoTblFile): number[];
export declare function createParticleListFromDynamoTbl(data: DynamoTblFile, options?: DynamoParticleListOptions): ParticleList;
export { DynamoTblFormat };
type DynamoTblFormat = ModelFormat<DynamoTblFile>;
declare namespace DynamoTblFormat {
    function is(x?: ModelFormat): x is DynamoTblFormat;
    function create(dynamoTbl: DynamoTblFile): DynamoTblFormat;
}
//# sourceMappingURL=tbl.d.ts.map