/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type ParticleList, type ParticleTarget } from '@molstar/model/model/particles/particle-list';
import type { ParticleTrajectory } from '@molstar/model/model/particles/particle-trajectory';
import { type SimulariumFile } from '@molstar/io/reader/simularium/schema';
import type { ModelFormat } from '../format.js';
export interface SimulariumParticleListOptions {
    /** Index of the trajectory frame to convert into a particle list. */
    readonly frameIndex: number;
    /**
     * Spatial scale factor applied to all coordinates (to angstrom). A value `<= 0`
     * (or omitted) auto-derives the factor from `trajectoryInfo.spatialUnits`.
     */
    readonly scale?: number;
    /** Agent type ids to include. An empty/omitted list includes all types. */
    readonly typeFilter?: ReadonlyArray<number>;
    /**
     * Reference objects instanced at each particle, keyed by agent type id (= particle
     * target id). Resolve them with `resolveSimulariumTargets`.
     */
    readonly targets?: ReadonlyMap<number, ParticleTarget>;
}
export declare function createParticleListFromSimularium(file: SimulariumFile, options: SimulariumParticleListOptions): ParticleList;
export interface SimulariumParticleTrajectoryOptions {
    /**
     * Spatial scale factor applied to all coordinates (to angstrom). A value `<= 0`
     * (or omitted) auto-derives the factor from `trajectoryInfo.spatialUnits`.
     */
    readonly scale?: number;
    /** Agent type ids to include. An empty/omitted list includes all types. */
    readonly typeFilter?: ReadonlyArray<number>;
    /** Reference objects instanced at each particle, keyed by agent type id. */
    readonly targets?: ReadonlyMap<number, ParticleTarget>;
    /**
     * Load the geometries referenced by the agent types (see `getSimulariumAgentGeometries`)
     * and instance them at each particle of the matching type. Merged with `targets`, which
     * takes precedence.
     */
    readonly resolveGeometry?: SimulariumGeometryResolver;
}
/**
 * Create a lazy `ParticleTrajectory` from a `SimulariumFile`. Frames are converted on demand;
 * the reference geometries (if any) are resolved once and shared by all frames.
 */
export declare function createSimulariumParticleTrajectory(file: SimulariumFile, options?: SimulariumParticleTrajectoryOptions): Promise<ParticleTrajectory>;
/**
 * Resolves the external geometry referenced by an agent type into a reference object
 * instanced at each particle of that type. Return `undefined` to skip the geometry.
 */
export type SimulariumGeometryResolver = (geometry: SimulariumAgentGeometry) => Promise<ParticleTarget | undefined>;
/** Resolve all external agent geometries of a file into a target id → target map. */
export declare function resolveSimulariumTargets(file: SimulariumFile, resolve: SimulariumGeometryResolver): Promise<Map<number, ParticleTarget>>;
/** Return the number of frames available in the file. */
export declare function getSimulariumFrameCount(file: SimulariumFile): number;
/** Return the agent types declared in `typeMapping`, sorted by id. */
export declare function getSimulariumAgentTypeNames(file: SimulariumFile): {
    id: number;
    name: string;
}[];
/** An external geometry (PDB structure or OBJ mesh) referenced by an agent type. */
export interface SimulariumAgentGeometry {
    readonly id: number;
    readonly name: string;
    /** Normalized to upper case, e.g. `PDB` or `OBJ`. */
    readonly displayType: string;
    readonly url: string;
    readonly color?: string;
}
/**
 * Return the agent types whose `geometry` references an external PDB structure or
 * OBJ mesh (i.e. `displayType` is `PDB` or `OBJ` and a `url` is given), sorted by id.
 */
export declare function getSimulariumAgentGeometries(file: SimulariumFile): SimulariumAgentGeometry[];
/**
 * Return the agent types whose `geometry.displayType` is `SPHERE`, sorted by id.
 * These are agents that are rendered as spheres and can be associated with an
 * external structure file matched by file base name against the agent type name.
 */
export declare function getSimulariumSphereAgentTypes(file: SimulariumFile): {
    id: number;
    name: string;
}[];
/**
 * Resolve the spatial scale factor (to angstrom) for a Simularium file, mirroring the
 * conversion applied to particle coordinates and radii. A `scale <= 0` (or omitted)
 * auto-derives the factor from `trajectoryInfo.spatialUnits`.
 */
export declare function getSimulariumSpatialScale(file: SimulariumFile, scale?: number): number;
export { SimulariumFormat };
type SimulariumFormat = ModelFormat<SimulariumFile>;
declare namespace SimulariumFormat {
    function is(x?: ModelFormat): x is SimulariumFormat;
    function create(simularium: SimulariumFile): SimulariumFormat;
}
//# sourceMappingURL=simularium.d.ts.map