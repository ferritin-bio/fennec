/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { CifFile } from '@molstar/io/reader/cif/data-model';
import type { ModelFormat } from '../format.js';
import type { StringLike } from '@molstar/core/util/string-like';
import type { FileNameInfo } from '@molstar/core/util/file-info';
import { type RuntimeContext } from '@molstar/core/task';
export type MmcifVariant = 'auto' | 'cellpack' | 'petworld' | 'standard';
/**
 * Content-sniff a `.cif`/`.bcif` file (before full parsing) to detect whether it looks like
 * a CellPack or PetWorld mmCIF particle assembly, for use as a `DataFormatProvider.isApplicable`.
 * Returns `false` for ordinary/standard mmCIF structure files so those keep loading as
 * regular trajectories by default.
 */
export declare function looksLikeMmcifParticles(info: FileNameInfo, data: StringLike | Uint8Array): boolean;
export interface MmcifAssemblyParticleListOptions {
    /** Assembly identifier from `_pdbx_struct_assembly.id`. */
    readonly assemblyId: string;
    /**
     * Individual chain IDs (`label_asym_id`) to include.
     * An empty or omitted array means "include all chains for this assembly".
     */
    readonly asymIds?: ReadonlyArray<string>;
    readonly label?: string;
    /**
     * Which mmCIF variant to use for building the particle list.
     * - `'auto'` (default): detect automatically from the CIF block header and categories.
     * - `'cellpack'`: interpret `_entity.pdbx_description` as a dot-separated `compartment.entityName` path;
     *   entities below a `.fibers` compartment use assembly-gen rows as ordered fibers.
     * - `'standard'`: like cellpack but treat `_entity.pdbx_description` as a plain entity name only.
     * - `'petworld'`: read the non-standard `_pdbx_struct_assembly_gen.PDB_model_num` field;
     *   one particle per operator combo per gen row.
     */
    readonly variant?: MmcifVariant;
    /**
     * Build the per-target reference geometry from the same mmCIF data and attach it
     * as `ParticleList.targetMapping`. Defaults to `true`.
     */
    readonly resolveTargets?: boolean;
}
/**
 * Return all unique assembly IDs found in `_pdbx_struct_assembly_gen` of the first CIF block.
 * Results are sorted lexicographically.
 */
export declare function getAssemblyIdsFromMmcif(cifFile: CifFile): string[];
/**
 * Return the sorted unique individual chain IDs for the given assembly in the first CIF block.
 */
export declare function getAsymIdsFromMmcif(cifFile: CifFile, assemblyId: string): string[];
export declare function createParticleListFromMmcifAssembly(ctx: RuntimeContext, cifFile: CifFile, options: MmcifAssemblyParticleListOptions): Promise<ParticleList>;
export { MmcifParticleFormat };
type MmcifParticleFormat = ModelFormat<CifFile>;
declare namespace MmcifParticleFormat {
    function is(x?: ModelFormat): x is MmcifParticleFormat;
    function create(cifFile: CifFile): MmcifParticleFormat;
}
//# sourceMappingURL=mmcif.d.ts.map