/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { CifBlock } from '@molstar/io/reader/cif/data-model';
import { Mat4 } from '@molstar/core/math/linear-algebra';
/**
 * `_pdbx_struct_oper_list` read into one flat array of column-major 4x4 matrices.
 *
 * The generic `getMatrices`/tensor-column path allocates a `Mat4`, two tensors and twelve
 * field-name strings per row, which dominates load time for the 10^5..10^6 operators of a
 * packed particle file.
 */
export interface ParticleOperators {
    readonly count: number;
    /** 16 values per operator, column-major (`j * 4 + i`). */
    readonly data: Float64Array;
    /** Only set when the file deviates from serial 1-based ids; otherwise the id is `index + 1`. */
    readonly ids?: ReadonlyArray<string> | Int32Array;
    readonly index?: ReadonlyMap<string, number> | ReadonlyMap<number, number>;
}
export declare function readParticleOperators(block: CifBlock): ParticleOperators;
export declare function getParticleOperatorId(ops: ParticleOperators, operatorIndex: number): string;
export declare function getParticleOperatorIndex(ops: ParticleOperators, id: string): number;
export declare function getParticleOperator(ops: ParticleOperators, operatorIndex: number, out: Mat4): Mat4;
/** The expanded operator combinations of one `_pdbx_struct_assembly_gen` row, as operator indices. */
export interface OperatorCombinations {
    readonly count: number;
    /** Number of operators per combination. */
    readonly stride: number;
    /** `stride` operator indices per combination. */
    readonly indices: Int32Array;
}
/**
 * Index-based counterpart of `expandOperators`, producing the same combinations in the same
 * order without allocating a `string[]` per combination.
 */
export declare function expandOperatorCombinations(operatorList: string[][], ops: ParticleOperators): OperatorCombinations;
/** Multiply the operators of a combination left-to-right; the first one is outermost. */
export declare function composeOperatorCombination(ops: ParticleOperators, combinations: OperatorCombinations, combinationIndex: number, out: Mat4): Mat4;
/** Takes only the ids so label closures do not retain the whole matrix array. */
export declare function formatOperatorCombination(ids: ReadonlyArray<string> | Int32Array | undefined, combinations: OperatorCombinations, combinationIndex: number): string;
//# sourceMappingURL=operators.d.ts.map