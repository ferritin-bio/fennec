/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { ArtiatomiEmFile } from '@molstar/io/reader/artiatomi/em';
import type { ModelFormat } from '../format.js';
export declare const ArtiatomiMotivelistRowCount = 20;
export interface ArtiatomiMotivelistOptions {
    /**
     * Pixel size (Å/pixel) used to convert voxel-space coordinates to angstrom.
     * Artiatomi EM motivelists do not encode distance units, so this must be supplied.
     */
    readonly pixelSize: number;
    /** If given, only particles whose tomogram number (row 5 in TomoParticle convention) matches are included. */
    readonly tomos?: ReadonlyArray<number>;
    readonly label?: string;
    /** Uniform particle radius in angstrom assigned to every particle. Leave 0 or undefined to omit radii. */
    readonly particleRadius?: number;
}
/** Return the sorted set of unique tomogram IDs from the motivelist (row 5, TomoParticle convention). */
export declare function getArtiatomiMotivelistTomogramIds(data: ArtiatomiEmFile): number[];
export declare function createParticleListFromArtiatomiEm(data: ArtiatomiEmFile, options: ArtiatomiMotivelistOptions): ParticleList;
export { ArtiatomiEmFormat };
type ArtiatomiEmFormat = ModelFormat<ArtiatomiEmFile>;
declare namespace ArtiatomiEmFormat {
    function is(x?: ModelFormat): x is ArtiatomiEmFormat;
    function create(em: ArtiatomiEmFile): ArtiatomiEmFormat;
}
//# sourceMappingURL=em.d.ts.map