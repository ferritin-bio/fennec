/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { RelionStarFile } from '@molstar/io/reader/relion/star';
import type { ModelFormat } from '../format.js';
export interface RelionParticleListOptions {
    readonly tomograms?: ReadonlyArray<string>;
    readonly micrographs?: ReadonlyArray<string>;
    /** Override pixel size (Å/pixel) used to convert pixel-space coordinates to angstrom. */
    readonly pixelSize?: number;
    /** Uniform particle radius in angstrom assigned to every particle. Leave 0 or undefined to omit radii. */
    readonly particleRadius?: number;
}
export declare function createParticleListFromRelionStar(data: RelionStarFile, options?: RelionParticleListOptions): ParticleList;
export { RelionStarFormat };
type RelionStarFormat = ModelFormat<RelionStarFile>;
declare namespace RelionStarFormat {
    function is(x?: ModelFormat): x is RelionStarFormat;
    function create(relionStar: RelionStarFile): RelionStarFormat;
}
//# sourceMappingURL=star.d.ts.map