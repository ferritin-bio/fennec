/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { CryoEtDataPortalNdjsonFile } from '@molstar/io/reader/cryoet/ndjson';
import type { ModelFormat } from '../format.js';
export interface CryoEtDataPortalParticleListOptions {
    /**
     * Pixel size (Å/pixel) used to convert pixel-space NDJSON coordinates to angstrom.
     * CryoET Data Portal NDJSON does not encode distance units, so this must be supplied.
     */
    readonly pixelSize: number;
    readonly type?: string;
    /** Uniform particle radius in angstrom assigned to every particle. Leave 0 or undefined to omit radii. */
    readonly particleRadius?: number;
}
export declare function createParticleListFromCryoEtDataPortalNdjson(data: CryoEtDataPortalNdjsonFile, options: CryoEtDataPortalParticleListOptions): ParticleList;
export { CryoEtDataPortalNdjsonFormat };
type CryoEtDataPortalNdjsonFormat = ModelFormat<CryoEtDataPortalNdjsonFile>;
declare namespace CryoEtDataPortalNdjsonFormat {
    function is(x?: ModelFormat): x is CryoEtDataPortalNdjsonFormat;
    function create(ndjson: CryoEtDataPortalNdjsonFile): CryoEtDataPortalNdjsonFormat;
}
//# sourceMappingURL=ndjson.d.ts.map