/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */
import { type SubstitutionMatrix } from './substitution-matrix.js';
declare const DefaultAlignmentOptions: {
    gapPenalty: number;
    gapExtensionPenalty: number;
    substMatrix: SubstitutionMatrix | 'default';
};
export type AlignmentOptions = typeof DefaultAlignmentOptions;
export declare function align(seqA: ArrayLike<string>, seqB: ArrayLike<string>, options?: Partial<AlignmentOptions>): {
    aliA: string[];
    aliB: string[];
    score: number;
};
export {};
//# sourceMappingURL=alignment.d.ts.map