/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Structure } from '../structure.js';
import type { Boundary } from '@molstar/core/math/geometry/boundary';
export declare function computeStructureBoundary(s: Structure): Boundary;
//# sourceMappingURL=boundary.d.ts.map