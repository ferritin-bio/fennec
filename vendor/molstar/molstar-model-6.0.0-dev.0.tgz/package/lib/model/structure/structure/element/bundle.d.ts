/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { SortedArray } from '@molstar/core/data/int';
import { Structure } from '../structure.js';
import { SortedRanges } from '@molstar/core/data/int/sorted-ranges';
import type { UnitIndex } from './element.js';
import { Loci } from './loci.js';
import type { Expression } from '@molstar/query-language/language/expression';
import { MolScriptBuilder as MS } from '@molstar/query-language/language/builder';
import { type QueryContext, type QueryFn, StructureSelection } from '../../query.js';
import { Schema } from './schema.js';
export interface BundleElement {
    /**
     * Array (sorted by first element in sub-array) of
     * arrays of `Unit.id`s that share the same `Unit.invariantId`
     */
    groupedUnits: SortedArray<number>[];
    set: SortedArray<UnitIndex>;
    ranges: SortedRanges<UnitIndex>;
}
export interface Bundle {
    /** Hash of the structure with which the bundle is compatible */
    readonly hash: number;
    /** Bundle elements */
    readonly elements: ReadonlyArray<Readonly<BundleElement>>;
}
export declare namespace Bundle {
    const Empty: Bundle;
    function fromSubStructure(parent: Structure, structure: Structure): Bundle;
    function fromSelection(selection: StructureSelection): Bundle;
    function fromExpression(structure: Structure, expression: Expression | ((builder: typeof MS) => Expression), queryContext?: QueryContext): Bundle;
    function fromQuery(structure: Structure, query: QueryFn, queryContext?: QueryContext): Bundle;
    function fromSchema(structure: Structure, schema: Schema): Bundle;
    function fromLoci(loci: Loci): Bundle;
    function toLoci(bundle: Bundle, structure: Structure): Loci;
    function toStructure(bundle: Bundle, parent: Structure): Structure;
    function toExpression(bundle: Bundle): Expression;
    function areEqual(a: Bundle, b: Bundle): boolean;
}
//# sourceMappingURL=bundle.d.ts.map