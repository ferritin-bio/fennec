/**
 * Copyright (c) 2017-2026 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { IntraUnitBonds } from './data.js';
import type { Unit } from '../../unit.js';
import { type BondComputationProps } from './common.js';
declare function computeIntraUnitBonds(unit: Unit.Atomic, props?: Partial<BondComputationProps>): IntraUnitBonds;
export { computeIntraUnitBonds };
//# sourceMappingURL=intra-compute.d.ts.map