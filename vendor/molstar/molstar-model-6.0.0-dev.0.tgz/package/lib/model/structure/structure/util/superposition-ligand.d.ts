/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */
import type { ElementIndex } from '../../model.js';
import { IntAdjacencyGraph } from '@molstar/core/math/graph';
import { Mat4 } from '@molstar/core/math/linear-algebra';
import { type Structure, StructureElement, Unit } from '../../structure.js';
/**
 * Ligand MCCS utilities:
 * - fast path: same compId -> match by atom name
 * - MCCS search: connected common subgraph search with configurable vertex/edge matching lambdas
 */
export interface LigandGraphVertex {
    readonly index: number;
    readonly element: ElementIndex;
    readonly atomName: string;
    readonly elementSymbol: string;
}
/** Bond order and BondType flags, stored as parallel per-edge arrays on the adjacency graph. */
export type LigandBondProps = {
    readonly order: ArrayLike<number>;
    readonly flags: ArrayLike<number>;
};
/** Local-vertex-indexed adjacency of one ligand residue (an induced subgraph of `unit.bonds`). */
export type LigandBondGraph = IntAdjacencyGraph<number, LigandBondProps>;
export interface LigandGraph {
    readonly structure: Structure;
    readonly unit: Unit.Atomic;
    readonly compId: string;
    readonly residueKey: number;
    readonly vertices: readonly LigandGraphVertex[];
    readonly bonds: LigandBondGraph;
}
export type LigandMccsVertexTest = (a: LigandGraphVertex, b: LigandGraphVertex) => boolean;
export type LigandMccsEdgeTest = (orderA: number, flagsA: number, orderB: number, flagsB: number) => boolean;
export interface LigandMccsOptions {
    /** Whether atom i of A may be paired with atom j of B (default: same element symbol). */
    readonly vertexTest: LigandMccsVertexTest;
    /** Whether a bond in A may be paired with a bond in B (default: equal order, unknown = wildcard). */
    readonly edgeTest: LigandMccsEdgeTest;
    /** skip hydrogen/deuterium atoms */
    readonly ignoreHydrogens: boolean;
    /**
     * Topological-distance tolerance for "d-edges" (pairs of atoms that are non-bonded in both
     * ligands). These are required for the clique formulation to represent non-complete-graph
     * substructures (e.g. rings), so the default is 1: two non-bonded atom pairs may be matched
     * iff their shortest-path distances differ by at most this much. Higher values are more
     * permissive about topological stretch; 0 disables d-edges entirely (only complete-subgraph
     * matches survive, rarely useful).
     */
    readonly pathCutoff: number;
    readonly maxTimeMs: number;
    readonly minMatchedAtoms: number;
    /** hard backstop on clique-search recursion steps */
    readonly maxIterations: number;
    /** number of equally-sized maximum cliques to retain and RMSD-rank when picking the pose */
    readonly maxCliquesForPose: number;
}
export declare const DefaultLigandMccsOptions: LigandMccsOptions;
/**
 * Returns residueKey/compId iff:
 * - loci is non-empty
 * - all atoms are in the same residue (one ligand residue)
 * - entity type is not polymer
 */
export declare function isSingleLigandLoci(loci: StructureElement.Loci): {
    residueKey: number;
    compId: string;
} | undefined;
export declare function buildLigandGraphFromLoci(loci: StructureElement.Loci): LigandGraph | undefined;
/** Fast path: same compId -> match by atom name (preferring same element symbol). */
export declare function matchLigandsByAtomName(a: LigandGraph, b: LigandGraph): Array<[number, number]> | undefined;
/** Optional out-parameter reporting whether the MCCS search hit its time/iteration budget. */
export interface LigandMccsStatus {
    truncated: boolean;
}
/**
 * Enumerate the maximum-size MCCS atom correspondences between two ligand graphs. Several equally
 * sized candidates may be returned (symmetry-related mappings, e.g. ring flips) so the caller can
 * pick the best pose by RMSD. Each correspondence is a list of [aVertexIndex, bVertexIndex] pairs.
 *
 * The search is best-effort: it stops at `maxTimeMs`/`maxIterations` and returns the best cliques
 * found so far. Pass `status` to learn whether that budget was hit (`status.truncated`).
 */
export declare function findMccsCliques(a: LigandGraph, b: LigandGraph, options?: Partial<LigandMccsOptions>, status?: LigandMccsStatus): Array<Array<[number, number]>>;
/** Convenience wrapper returning a single (the first) maximum MCCS correspondence. */
export declare function findMccsPairs(a: LigandGraph, b: LigandGraph, options?: Partial<LigandMccsOptions>): Array<[number, number]> | undefined;
export type LigandSuperposeMethod = 'atom-name' | 'mccs';
export interface LigandSuperposeResult {
    method: LigandSuperposeMethod;
    atomCount: number;
    rmsd: number;
    bTransform: Mat4;
    /**
     * matched atoms as model ElementIndex, paired 1:1 (by array position) with `targetElements`
     */
    referenceElements: ElementIndex[];
    /** matched atoms in the target ligand as model ElementIndex, paired 1:1 with `referenceElements` */
    targetElements: ElementIndex[];
    /** true if the MCCS search hit its time/iteration budget, so the result may not be the true maximum (always false for the atom-name fast path) */
    truncated: boolean;
}
/**
 * Given two ligand loci (each one ligand residue), compute the bTransform that superposes the
 * target onto the reference. Tries the atom-name fast path first (identical compId), then falls
 * back to an MCCS search whose equally-sized maximum correspondences are each superposed so the
 * lowest-RMSD pose wins (this resolves symmetry-related mappings the largest-clique alone cannot).
 */
export declare function superposeLigandsByMccs(reference: StructureElement.Loci, target: StructureElement.Loci, options?: Partial<LigandMccsOptions>): LigandSuperposeResult | undefined;
//# sourceMappingURL=superposition-ligand.d.ts.map