/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { Expression } from '@molstar/query-language/language/expression';
import type { Structure } from '../structure.js';
import { Bundle } from './bundle.js';
import { Loci } from './loci.js';
export interface SchemaItem {
    /** Corresponds to SymmetryOperator.name, e.g. 1_555, ASM_5 */
    operator_name?: string;
    /** Corresponds to SymmetryOperator.instanceId, e.g. 1_555, ASM-X0-5 */
    instance_id?: string;
    label_entity_id?: string;
    label_asym_id?: string;
    auth_asym_id?: string;
    label_seq_id?: number;
    auth_seq_id?: number;
    residue_index?: number;
    label_comp_id?: string;
    auth_comp_id?: string;
    pdbx_PDB_ins_code?: string;
    beg_label_seq_id?: number;
    end_label_seq_id?: number;
    beg_auth_seq_id?: number;
    end_auth_seq_id?: number;
    /** Insertion code of the first residue of the range which starts at `beg_auth_seq_id` (`''`: the residue without an insertion code).
     *
     * If `beg_auth_ins_code` or `end_auth_ins_code` is given, the range is not a range of `auth_seq_id` values but of residues
     * in the order of the input file: from the first residue with `beg_auth_seq_id` (and this insertion code) to the last residue with
     * `end_auth_seq_id` (and `end_auth_ins_code`), in each auth chain (the chains which share an
     * `auth_asym_id`, e.g. a polymer and its ligands), and the chains which the other criteria select get the part of the range which is theirs.
     * A bound without an insertion code is the whole `auth_seq_id` (the first residue of it for `beg`, the last for `end`). A bound is looked
     * for in the chains which are not waters first (waters are numbered again from the start in many files), and in the waters only if no
     * other chain has it. A bound which is not in the auth chain selects nothing from it, and so does a range which ends before it begins. An insertion code without its `auth_seq_id` selects nothing. */
    beg_auth_ins_code?: string;
    /** Insertion code of the last residue of the range which ends at `end_auth_seq_id`, see `beg_auth_ins_code`. */
    end_auth_ins_code?: string;
    label_atom_id?: string;
    auth_atom_id?: string;
    type_symbol?: string;
    atom_id?: number;
    atom_index?: number;
}
export interface SchemaItems {
    prefix?: SchemaItem;
    items: SchemaItem[] | {
        [K in keyof SchemaItem]: SchemaItem[K][];
    };
}
export type Schema = SchemaItem | SchemaItems;
/** The expression of a schema is the generator `element-schema`: it finds the elements through the indices of the models (instead of testing
 * every element for every item), as a single set of the elements which satisfy at least one item. A table of many rows is given by columns. */
declare function toExpression(schema: Schema): Expression;
/**
 * Iterate over all items in a structure element schema.
 * @param schema Schema to iterate over
 * @param f Function called for each item in the schema.
 *          The value passed to the function can be mutable and should not be
 *          modified => make a copy if the value is used outside the callback.
 */
declare function forEachItem(schema: Schema, f: (item: SchemaItem) => void): void;
declare function toLoci(structure: Structure, schema: Schema): Loci;
declare function toBundle(structure: Structure, schema: Schema): Bundle;
/** The substructure of `structure` of the elements which satisfy at least one item of `schema`
 * (`structure` itself if every element satisfies one). */
declare function toStructure(structure: Structure, schema: Schema): Structure;
export declare const Schema: {
    forEachItem: typeof forEachItem;
    toExpression: typeof toExpression;
    toLoci: typeof toLoci;
    toBundle: typeof toBundle;
    toStructure: typeof toStructure;
};
export {};
//# sourceMappingURL=schema.d.ts.map