/**
 * Copyright (c) 2018-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Structure } from '../structure.js';
import { type Carbohydrates } from './data.js';
export declare function computeCarbohydrates(structure: Structure): Carbohydrates;
//# sourceMappingURL=compute.d.ts.map