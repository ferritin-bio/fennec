/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StructureElement } from '../../element.js';
import type { IntraUnitBonds } from './data.js';
import type { Model } from '../../../model.js';
export declare class ElementSetIntraBondCache {
    private data;
    get(xs: StructureElement.Set): IntraUnitBonds | undefined;
    set(xs: StructureElement.Set, bonds: IntraUnitBonds): void;
    static get(model: Model): ElementSetIntraBondCache;
}
//# sourceMappingURL=element-set-intra-bond-cache.d.ts.map