/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Unit } from '../unit.js';
/**
 * Merge the elements of units from the same model that are known to share
 * the same symmetry operator into a single unit.
 */
export declare function mergeUnitsWithSameOperator(units: readonly Unit[], id: number, invariantId?: number): Unit;
/**
 * Partition the untransformed units of the same model into a grid and merge
 * the units in each grid cell that share the same symmetry operator.
 */
export declare function partitionUntransformedUnits(units: readonly Unit[], cellSize: number): Unit[];
//# sourceMappingURL=unit-merging.d.ts.map