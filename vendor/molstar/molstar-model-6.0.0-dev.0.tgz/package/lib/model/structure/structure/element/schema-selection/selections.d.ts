/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { ElementIndex } from '../../../model/indexing.js';
import type { Model } from '../../../model.js';
import type { CoarseElements } from '../../../model/properties/coarse.js';
import { ElementRanges, ElementRangesBuffer } from './element-ranges.js';
import { IntBuffer } from '@molstar/core/util/int-buffer';
import { type CoarseIndicesAndSortings, IndicesAndSortings } from './indexing.js';
import type { SchemaItem } from '../schema.js';
/** Reusable buffers for `getAtomRangesForRowInto`, so that processing many rows does not allocate per row.
 * (JS is single-threaded and the functions are not reentrant, so one scratch can be shared by callers which never interleave.) */
export declare class AtomRangesScratch {
    /** Result of the last `getAtomRangesForRowInto` call which used this scratch (overwritten by the next call). */
    readonly ranges: ElementRangesBuffer;
    readonly chains: IntBuffer;
    readonly residues: IntBuffer;
    /** Drop buffers which grew very large (so that one huge call does not pin memory forever). */
    trim(limit?: number): void;
}
/** The symmetry operator of a unit, as far as rows can refer to it (`instance_id`, `operator_name`) */
export interface RowOperator {
    /** `SymmetryOperator.instanceId`, e.g. `ASM-X0-5` */
    readonly instanceId: string;
    /** `SymmetryOperator.name`, e.g. `1_555` */
    readonly name: string;
}
/** Does `row` apply to units with this operator? A row which names an instance or an operator applies only to it. */
export declare function rowAppliesToOperator(row: SchemaItem, operator: RowOperator): boolean;
/** `true` if some of `rows` refer to an instance or an operator (otherwise the selected elements do not depend on the unit's operator) */
export declare function rowsUseOperators(rows: readonly SchemaItem[]): boolean;
/** Is the `auth_seq_id` range of `row` a range of residues in file order (it has an insertion code on a bound)? */
export declare function hasInsCodeRange(row: SchemaItem): boolean;
/** Return atom ranges in `model` which satisfy criteria given by `row` (a new object). */
export declare function getAtomRangesForRow(row: SchemaItem, model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges | undefined;
/** Like `getAtomRangesForRow`, but writes the result into `scratch.ranges` and returns it (no allocation per call).
 * The returned buffer is only valid until the next call with the same `scratch`; copy it if you need to keep it. */
export declare function getAtomRangesForRowInto(row: SchemaItem, model: Model, operator: RowOperator, indices: IndicesAndSortings, scratch: AtomRangesScratch): ElementRangesBuffer | undefined;
/** Return atom ranges in `model` which satisfy criteria given by any of `rows` (atoms that satisfy more rows are still included only once) */
export declare function getAtomRangesForRows(rows: readonly SchemaItem[], model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges;
/** Return true if `iAtom`-th atom in `model` satisfies all selection criteria given by `row`
 * (a range with insertion codes, `beg_auth_ins_code` and `end_auth_ins_code`, needs the indices of the model and is not checked here). */
export declare function atomQualifies(model: Model, iAtom: ElementIndex, row: SchemaItem): boolean;
/** Return sphere ranges in `model` which satisfy criteria given by `row` */
export declare function getSphereRangesForRow(row: SchemaItem, model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges | undefined;
/** Return sphere ranges in `model` which satisfy criteria given by any of `rows` (spheres that satisfy more rows are still included only once) */
export declare function getSphereRangesForRows(rows: readonly SchemaItem[], model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges;
/** Return gaussian ranges in `model` which satisfy criteria given by `row` */
export declare function getGaussianRangesForRow(row: SchemaItem, model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges | undefined;
/** Return gaussian ranges in `model` which satisfy criteria given by any of `rows` (gaussians that satisfy more rows are still included only once) */
export declare function getGaussianRangesForRows(rows: readonly SchemaItem[], model: Model, operator: RowOperator, indices: IndicesAndSortings): ElementRanges;
/** Return ranges of coarse elements (spheres or gaussians) which satisfy criteria given by `row` */
export declare function getCoarseElementRangesForRow(row: SchemaItem, coarseElements: CoarseElements, indices: CoarseIndicesAndSortings): ElementRanges | undefined;
//# sourceMappingURL=selections.d.ts.map