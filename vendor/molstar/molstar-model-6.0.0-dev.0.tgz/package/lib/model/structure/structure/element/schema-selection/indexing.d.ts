/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Column } from '@molstar/core/data/db';
import { SortedArray } from '@molstar/core/data/int';
import type { ChainIndex, ElementIndex, ResidueIndex } from '../../../model/indexing.js';
import type { Model } from '../../../model.js';
import { type Mapping } from '@molstar/core/util/multi-map';
export interface IndicesAndSortings {
    atomic?: AtomicIndicesAndSortings;
    spheres?: CoarseIndicesAndSortings;
    gaussians?: CoarseIndicesAndSortings;
}
/** The things the indices (and anything else derived from the hierarchy and the atom ids, but not from the coordinates) depend on.
 * Models with the same `atomicHierarchy`, `coarseHierarchy` and `atomId` column share one scope: these are the frames of a trajectory
 * (a copy of a model with other coordinates), so what is computed for one frame is valid for all of them. */
export interface HierarchyScope {
    readonly coarseHierarchy: Model['coarseHierarchy'];
    readonly atomId: Model['atomicConformation']['atomId'];
    /** Cached `IndicesAndSortings.get` */
    indices?: IndicesAndSortings;
}
export declare const HierarchyScope: {
    /** Get the scope of a model (created if the model is the first with its hierarchies and atom ids). Does not keep the model alive. */
    get(model: Model): HierarchyScope;
    find(model: Model): HierarchyScope;
};
export declare const IndicesAndSortings: {
    /** Get `IndicesAndSortings` for a model (use a cached value or create if not available yet).
     * The cache is shared by the models of a trajectory (see `HierarchyScope`), the indices are created once. */
    get(model: Model): IndicesAndSortings;
    /** Create `IndicesAndSortings` for a model */
    create(model: Model): IndicesAndSortings;
};
/** Auxiliary data structure for efficiently finding chains/residues/atoms in an atomic model by their properties */
export interface AtomicIndicesAndSortings {
    chainsByLabelEntityId: Mapping<string, readonly ChainIndex[]>;
    chainsByLabelAsymId: Mapping<string, readonly ChainIndex[]>;
    chainsByAuthAsymId: Mapping<string, readonly ChainIndex[]>;
    residuesSortedByLabelSeqId: Mapping<ChainIndex, Sorting<ResidueIndex, number>>;
    residuesSortedByAuthSeqId: Mapping<ChainIndex, Sorting<ResidueIndex, number>>;
    residuesSortedBySourceIndex: Mapping<ChainIndex, Sorting<ResidueIndex, number>>;
    residuesByInsCode: Mapping<ChainIndex, Mapping<string, readonly ResidueIndex[]>>;
    residuesByLabelCompId: Mapping<ChainIndex, Mapping<string, readonly ResidueIndex[]>>;
    /** Indicates if each residue is listed only once in `residuesByLabelCompId` (i.e. if each residue has only one label_comp_id) */
    residuesByLabelCompIdIsPure: boolean;
    residuesByAuthCompId: Mapping<ChainIndex, Mapping<string, readonly ResidueIndex[]>>;
    /** Indicates if each residue is listed only once in `residuesByAuthCompId` (i.e. if each residue has only one auth_comp_id) */
    residuesByAuthCompIdIsPure: boolean;
    /** Lookups of atoms by `atom_id` and `atom_index`, each built on first use */
    atoms: AtomIdIndices;
    /** Lookups over all chains at once (for rows without chain criteria), each built on first use */
    global: GlobalResidueIndices;
}
/** Lookups of atoms by `atom_id` and by `atom_index`, for rows which refer to them. They are built (in one pass over the atoms, at 4 bytes per atom
 * for each of the two) when the first such row comes, so models which never see one do not pay for them. */
export declare class AtomIdIndices {
    private readonly nAtoms;
    private readonly atomId;
    private readonly atomSourceIndex;
    private built;
    private _byId;
    private _repeatedIds;
    private _bySourceIndex;
    constructor(nAtoms: number, atomId: Column<number>, atomSourceIndex: Column<number>);
    private build;
    /** The first atom with each `atom_id` (ids are not necessarily unique, e.g. serial numbers wrap around in some formats) */
    get byId(): Mapping<number, ElementIndex>;
    /** All atoms (ascending) of each `atom_id` which is used by more than one atom, other ids are not listed */
    get repeatedIds(): Mapping<number, readonly ElementIndex[]>;
    /** The atom with each `atom_index` (it is unique) */
    get bySourceIndex(): Mapping<number, ElementIndex>;
}
/** Lookups of residues over the whole model, for rows without chain criteria: the per-chain indices would need a lookup in every chain
 * (cost proportional to the number of chains even when there is a single match). Unlike them, these are built from one pass
 * over the residues without sorting, and only when first needed. Residues in each list are ascending. */
export declare class GlobalResidueIndices {
    private readonly h;
    private _bySourceIndex;
    private _byInsCode?;
    private _byLabelCompId?;
    private _byAuthCompId?;
    constructor(h: Model['atomicHierarchy']);
    /** `residue_index` -> residue, or `null` when `residue_index` is not unique in the model (then use the per-chain indices) */
    get residueBySourceIndex(): Map<number, ResidueIndex> | null;
    get residuesByInsCode(): Mapping<string, readonly ResidueIndex[]>;
    /** Residues having an atom with the given `label_comp_id` */
    get residuesByLabelCompId(): Mapping<string, readonly ResidueIndex[]>;
    /** Residues having an atom with the given `auth_comp_id` */
    get residuesByAuthCompId(): Mapping<string, readonly ResidueIndex[]>;
    private byCompId;
}
/** Auxiliary data structure for efficiently finding chains/elements in a coarse model by their properties */
export interface CoarseIndicesAndSortings {
    /** Coarse equivalent to `model.atomicHierarchy.chains` */
    chains: {
        /** Number of chains */
        count: number;
        /** Maps chain index to `label_entity_id` value */
        label_entity_id: string[];
        /** Maps chain index to `label_asym_id` value */
        label_asym_id: string[];
    };
    chainsByEntityId: Mapping<string, readonly ChainIndex[]>;
    chainsByAsymId: Mapping<string, readonly ChainIndex[]>;
    /** Coarse elements (per chain) sorted by `seq_id_begin`.
     * This is used to get the range of elements which may overlap with a certain seq_id interval.
     *
     * (Filtering coarse elements by seq_id range is an interval search problem, so the worst-case-efficient solution would be to use a data structure optimized for that.
     * But that would be overkill if we expect that in most cases the coarse elements cover non-overlapping seq_id ranges.
     * So the current solution should be sufficient (fast for non-overlapping elements, while still correct if there are overlaps).) */
    elementsSortedBySeqIdBegin: Mapping<ChainIndex, Sorting<ElementIndex, number> & {
        /** Non-decreasing upper bound for `seq_id_end` values of elements as listed in `keys` (`seq_id_end.value(keys[i]) <= endUpperBounds[i]`) */
        endUpperBounds: SortedArray;
    }>;
}
/** Represents a set of things (keys) of type `K`, sorted by some property (value) of type `V` */
export interface Sorting<K, V extends number> {
    /** Keys sorted by their corresponding values */
    keys: readonly K[];
    /** Sorted values corresponding to each key (value for `keys[i]` is `values[i]`) */
    values: SortedArray<V>;
}
export declare const Sorting: {
    /** Create a `Sorting` from an array of keys and a function returning their corresponding values.
     * If two keys have the same value, the smaller key will come first.
     * This function modifies `keys` - create a copy if you need the original order! */
    create<K extends number, V extends number>(keys: K[], valueFunction: (k: K) => V): Sorting<K, V>;
    /** Return a newly allocated array of keys which have value equal to `target`.
     * The returned keys are sorted by their value. */
    getKeysWithValue<K, V extends number>(sorting: Sorting<K, V>, target: V): K[];
    /** Set `out.from`, `out.to` so that `keys.slice(out.from, out.to)` are the keys which have value within interval `[min, max]`
     * (inclusive; an undefined or null `min` is negative infinity, an undefined or null `max` is positive infinity). Does not allocate.
     * Bounds are numbers (they need not be integers); a bound of another type, or NaN, selects nothing. */
    findIndexRange<K, V extends number>(sorting: Sorting<K, V>, min: V | undefined | null, max: V | undefined | null, out: {
        from: number;
        to: number;
    }): {
        from: number;
        to: number;
    };
    /** Return a newly allocated array of keys which have value within interval `[min, max]` (inclusive).
     * The returned keys are sorted by their value.
     * Undefined `min` is interpreted as negative infitity, undefined `max` is interpreted as positive infinity. */
    getKeysWithValueInRange<K, V extends number>(sorting: Sorting<K, V>, min: V | undefined | null, max: V | undefined | null): K[];
};
//# sourceMappingURL=indexing.d.ts.map