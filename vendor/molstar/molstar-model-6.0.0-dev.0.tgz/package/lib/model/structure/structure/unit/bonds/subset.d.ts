/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { SortedArray } from '@molstar/core/data/int';
import type { Structure } from '../../structure.js';
import { InterUnitBonds, IntraUnitBonds } from './data.js';
/**
 * The intra-unit bonds of a child unit with `elements`, restricted from `bonds` of its parent unit with
 * `parentElements` (05-model-structure P6, unit.md §4); `undefined` if `elements` is not a subset of `parentElements`.
 *
 * The edges equal a recompute on the child: `computeIntraUnitBonds` decides per atom pair (struct_conn, the component
 * dictionary, the hydrogen fallback, alt-locs, thresholds, index pairs), and from the unit's operator only for index
 * pairs with operators, where the caller restricts a parent of the same operator only. Their order is the parent's. The props
 * (`canRemap`, `cacheable`) are the parent's: a parent that may remap its bonds has children that may too, while a
 * child of one that may not could have been allowed (it then recomputes on a remap). As in the parent, bonds carried
 * over from another frame (`remapModel`) are carried over to the child.
 */
export declare function subsetIntraUnitBonds(bonds: IntraUnitBonds, parentElements: SortedArray<number>, elements: ArrayLike<number>): IntraUnitBonds | undefined;
/**
 * The inter-unit bonds of `child` restricted from `parent`'s, or `undefined` when `child` has a unit that is not a
 * subset of `parent`'s unit with the same id, model and operator (05-model-structure P5). The caller checks that the
 * bond props (`dynamicBonds`, `interBondsValidUnit(Pair)`, `masterModel`) are the parent's.
 *
 * `computeInterUnitBonds` decides mostly per atom pair (thresholds, struct_conn, index pairs, alt-locs), so this
 * equals a recompute on the child except where it decides from atoms the child may lack or from unit sizes:
 * - an atom of the iterated (smaller) unit with a struct_conn bond to the other gets no distance-based bonds there,
 *   so a struct_conn partner outside the child, or a child that swaps which unit is smaller, can change them;
 * - the default pair test classifies water/ion units by their first element, and pairs them only through a common
 *   struct_conn record.
 * In those cases the subset keeps what the parent shows, as it does for bonds the parent carried over from another
 * frame (`remapModel` without `dynamicBonds`). The edge order follows the parent's units, not a recompute's.
 */
export declare function subsetInterUnitBonds(bonds: InterUnitBonds, parent: Structure, child: Structure): InterUnitBonds | undefined;
//# sourceMappingURL=subset.d.ts.map