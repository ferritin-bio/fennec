/**
 * Copyright (c) 2017-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { StructureElement } from './element.js';
import { SecondaryStructureType } from '../model/types.js';
declare const StructureProperties: {
    constant: {
        true: StructureElement.Property<boolean>;
        false: StructureElement.Property<boolean>;
        zero: StructureElement.Property<number>;
    };
    atom: {
        key: StructureElement.Property<import("../model.js").ElementIndex>;
        x: StructureElement.Property<number>;
        y: StructureElement.Property<number>;
        z: StructureElement.Property<number>;
        id: StructureElement.Property<number>;
        occupancy: StructureElement.Property<number>;
        B_iso_or_equiv: StructureElement.Property<number>;
        sourceIndex: StructureElement.Property<number>;
        type_symbol: StructureElement.Property<import("../model/types.js").ElementSymbol>;
        label_atom_id: StructureElement.Property<string>;
        auth_atom_id: StructureElement.Property<string>;
        label_alt_id: StructureElement.Property<string>;
        label_comp_id: StructureElement.Property<string>;
        auth_comp_id: StructureElement.Property<string>;
        pdbx_formal_charge: StructureElement.Property<number>;
        vdw_radius: StructureElement.Property<number>;
    };
    residue: {
        key: StructureElement.Property<import("../model.js").ResidueIndex>;
        group_PDB: StructureElement.Property<"ATOM" | "HETATM">;
        label_comp_id: StructureElement.Property<string>;
        auth_comp_id: StructureElement.Property<string>;
        label_seq_id: StructureElement.Property<number>;
        auth_seq_id: StructureElement.Property<number>;
        pdbx_PDB_ins_code: StructureElement.Property<string>;
        isNonStandard: StructureElement.Property<boolean>;
        hasMicroheterogeneity: StructureElement.Property<boolean>;
        microheterogeneityCompIds: StructureElement.Property<string[]>;
        secondary_structure_type: StructureElement.Property<SecondaryStructureType>;
        secondary_structure_key: StructureElement.Property<number>;
        chem_comp_type: StructureElement.Property<"d-beta-peptide, c-gamma linking" | "d-gamma-peptide, c-delta linking" | "d-peptide cooh carboxy terminus" | "d-peptide linking" | "d-peptide nh3 amino terminus" | "d-saccharide" | "d-saccharide, alpha linking" | "d-saccharide, beta linking" | "dna linking" | "dna oh 3 prime terminus" | "dna oh 5 prime terminus" | "ion" | "l-beta-peptide, c-gamma linking" | "l-dna linking" | "l-gamma-peptide, c-delta linking" | "l-peptide cooh carboxy terminus" | "l-peptide linking" | "l-peptide nh3 amino terminus" | "l-rna linking" | "l-saccharide" | "l-saccharide, alpha linking" | "l-saccharide, beta linking" | "lipid" | "non-polymer" | "other" | "peptide linking" | "peptide-like" | "rna linking" | "rna oh 3 prime terminus" | "rna oh 5 prime terminus" | "saccharide">;
        residueSourceIndex: StructureElement.Property<number>;
    };
    chain: {
        key: StructureElement.Property<import("../model.js").ChainIndex>;
        label_asym_id: StructureElement.Property<string>;
        auth_asym_id: StructureElement.Property<string>;
        label_entity_id: StructureElement.Property<string>;
    };
    entity: {
        key: StructureElement.Property<import("../model.js").EntityIndex>;
        id: StructureElement.Property<string>;
        type: StructureElement.Property<"branched" | "macrolide" | "non-polymer" | "polymer" | "water">;
        src_method: StructureElement.Property<"man" | "nat" | "syn">;
        pdbx_description: StructureElement.Property<string[]>;
        formula_weight: StructureElement.Property<number>;
        pdbx_number_of_molecules: StructureElement.Property<number>;
        details: StructureElement.Property<string>;
        pdbx_mutation: StructureElement.Property<string>;
        pdbx_fragment: StructureElement.Property<string>;
        pdbx_ec: StructureElement.Property<string[]>;
        pdbx_parent_entity_id: StructureElement.Property<string>;
        subtype: StructureElement.Property<import("../model/properties/common.js").EntitySubtype>;
        prd_id: StructureElement.Property<string>;
    };
    unit: {
        id: StructureElement.Property<number>;
        chainGroupId: StructureElement.Property<number>;
        multiChain: StructureElement.Property<boolean>;
        object_primitive: StructureElement.Property<"atomistic" | "gaussian" | "sphere">;
        operator_name: StructureElement.Property<string>;
        instance_id: StructureElement.Property<string>;
        operator_key: StructureElement.Property<number>;
        model_index: StructureElement.Property<number>;
        model_label: StructureElement.Property<string>;
        model_entry_id: StructureElement.Property<string>;
        hkl: StructureElement.Property<import("@molstar/core/math/linear-algebra").Vec3>;
        spgrOp: StructureElement.Property<number>;
        model_num: StructureElement.Property<number>;
        pdbx_struct_assembly_id: StructureElement.Property<string>;
        pdbx_struct_oper_list_ids: StructureElement.Property<any[]>;
        struct_ncs_oper_id: StructureElement.Property<number>;
    };
    coarse: {
        key: StructureElement.Property<import("../model.js").ElementIndex>;
        entityKey: StructureElement.Property<import("../model.js").EntityIndex>;
        x: StructureElement.Property<number>;
        y: StructureElement.Property<number>;
        z: StructureElement.Property<number>;
        asym_id: StructureElement.Property<string>;
        entity_id: StructureElement.Property<string>;
        seq_id_begin: StructureElement.Property<number>;
        seq_id_end: StructureElement.Property<number>;
        sphere_radius: StructureElement.Property<number>;
        sphere_rmsf: StructureElement.Property<number>;
        gaussian_weight: StructureElement.Property<number>;
        gaussian_covariance_matrix: StructureElement.Property<import("@molstar/core/math/linear-algebra").Mat3>;
    };
};
type StructureProperties = typeof StructureProperties;
export { StructureProperties };
//# sourceMappingURL=properties.d.ts.map