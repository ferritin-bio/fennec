/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { IntMap, type Iterator } from '@molstar/core/data/int';
import { SymmetryOperator } from '@molstar/core/math/geometry/symmetry-operator';
import { Model } from '../model.js';
import { StructureElement } from './element.js';
import { Unit } from './unit.js';
import { StructureLookup3D } from './util/lookup3d.js';
import { StructureSubsetBuilder } from './util/subset-builder.js';
import { InterUnitBonds } from './unit/bonds.js';
import type { ResidueIndex, EntityIndex } from '../model/indexing.js';
import type { Carbohydrates } from './carbohydrates/data.js';
import type { Coordination } from './coordination/data.js';
import { Vec3, Mat4 } from '@molstar/core/math/linear-algebra';
import type { UUID } from '@molstar/core/util';
import { CustomProperties } from '../../custom-property.js';
import type { Boundary } from '@molstar/core/math/geometry/boundary';
import type { ElementSymbol } from '../model/types.js';
import type { Trajectory } from '../trajectory.js';
import { type RuntimeContext } from '@molstar/core/task';
import type { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import { type IntraUnitBondMapping, type SerialMapping } from './mapping.js';
/** Internal structure state */
type State = {
    parent?: Structure;
    boundary?: Boundary;
    lookup3d?: StructureLookup3D;
    interUnitBonds?: InterUnitBonds;
    dynamicBonds: boolean;
    interBondsValidUnit?: (unit: Unit) => boolean;
    interBondsValidUnitPair?: (structure: Structure, unitA: Unit, unitB: Unit) => boolean;
    unitSymmetryGroups?: ReadonlyArray<Unit.SymmetryGroup>;
    unitSymmetryGroupsIndexMap?: IntMap<number>;
    unitsSortedByVolume?: ReadonlyArray<Unit>;
    carbohydrates?: Carbohydrates;
    coordination?: Coordination;
    models?: ReadonlyArray<Model>;
    model?: Model;
    masterModel?: Model;
    representativeModel?: Model;
    uniqueResidueNames?: Set<string>;
    uniqueElementSymbols?: Set<ElementSymbol>;
    entityIndices?: ReadonlyArray<EntityIndex>;
    uniqueAtomicResidueIndices?: ReadonlyMap<UUID, ReadonlyArray<ResidueIndex>>;
    serialMapping?: SerialMapping;
    intraUnitBondMapping?: IntraUnitBondMapping;
    hashCode: number;
    transformHash: number;
    elementCount: number;
    bondCount: number;
    uniqueElementCount: number;
    atomicResidueCount: number;
    polymerResidueCount: number;
    polymerGapCount: number;
    polymerUnitCount: number;
    coordinateSystem: SymmetryOperator;
    label: string;
    propertyData?: any;
    customProps?: CustomProperties;
};
declare class Structure {
    readonly units: ReadonlyArray<Unit>;
    readonly unitMap: IntMap<Unit>;
    readonly unitIndexMap: IntMap<number>;
    private readonly state;
    subsetBuilder(isSorted: boolean): StructureSubsetBuilder;
    /** Count of all elements in the structure, i.e. the sum of the elements in the units */
    get elementCount(): number;
    /** Count of all bonds (intra- and inter-unit) in the structure */
    get bondCount(): number;
    get hasCustomProperties(): boolean;
    get customPropertyDescriptors(): CustomProperties;
    /**
     * Property data unique to this instance of the structure.
     */
    get currentPropertyData(): any;
    /**
     * Property data of the parent structure if it exists, currentPropertyData otherwise.
     */
    get inheritedPropertyData(): any;
    /** Count of all polymer residues in the structure */
    get polymerResidueCount(): number;
    /** Count of all polymer gaps in the structure */
    get polymerGapCount(): number;
    get polymerUnitCount(): number;
    get uniqueElementCount(): number;
    get atomicResidueCount(): number;
    /**
     * True if any model the structure is based on is coarse grained.
     * @see Model.isCoarseGrained
     */
    get isCoarseGrained(): boolean;
    get isEmpty(): boolean;
    get hashCode(): number;
    /** Hash based on all unit.id values in the structure, reflecting the units transformation */
    get transformHash(): number;
    private computeHash;
    /** Returns a new element location iterator */
    elementLocations(): Iterator<StructureElement.Location>;
    /** The parent or itself in case this is the root */
    get root(): Structure;
    /** The root/top-most parent or `undefined` in case this is the root */
    get parent(): Structure | undefined;
    /**
     * Conformation transformation that was applied to every unit of this structure.
     *
     * Coordinate system applies to the *current* structure only.
     * A parent structure can have a different coordinate system and thefore it has to be composed "manualy"
     * by the consumer.
     */
    get coordinateSystem(): SymmetryOperator;
    get label(): string;
    get boundary(): Boundary;
    get lookup3d(): StructureLookup3D;
    get interUnitBonds(): InterUnitBonds;
    get dynamicBonds(): boolean;
    get interBondsValidUnit(): ((unit: Unit) => boolean) | undefined;
    get interBondsValidUnitPair(): ((structure: Structure, unitA: Unit, unitB: Unit) => boolean) | undefined;
    get unitSymmetryGroups(): ReadonlyArray<Unit.SymmetryGroup>;
    /** Maps unit.id to index of SymmetryGroup in unitSymmetryGroups array */
    get unitSymmetryGroupsIndexMap(): IntMap<number>;
    get carbohydrates(): Carbohydrates;
    get coordination(): Coordination;
    get models(): ReadonlyArray<Model>;
    get uniqueResidueNames(): Set<string>;
    get uniqueElementSymbols(): Set<ElementSymbol>;
    get entityIndices(): readonly EntityIndex[];
    get uniqueAtomicResidueIndices(): ReadonlyMap<UUID, readonly ResidueIndex[]>;
    /** Contains only atomic units */
    get isAtomic(): boolean;
    /** Contains some atomic units */
    get hasAtomic(): boolean;
    /** Contains only coarse units */
    get isCoarse(): boolean;
    /** Contains some coarse units */
    get hasCoarse(): boolean;
    /**
     * Provides mapping for serial element indices accross all units.
     *
     * Note that this is especially costly for structures with many units that are grouped
     * into few symmetry groups. Use only when needed and prefer `StructureElement`
     * to address elements in a structure.
     */
    get serialMapping(): SerialMapping;
    get intraUnitBondMapping(): IntraUnitBondMapping;
    /**
     * If the structure is based on a single model or has a master-/representative-model, return it.
     * Otherwise throw an exception.
     */
    get model(): Model;
    /** The master-model, other models can have bonds to it  */
    get masterModel(): Model | undefined;
    /** A representative model, e.g. the first model of a trajectory */
    get representativeModel(): Model | undefined;
    hasElement(e: StructureElement.Location): boolean;
    getModelIndex(m: Model): number;
    remapModel(m: Model): Structure;
    private _child;
    private _target;
    private _proxy;
    /**
     * For `structure` with `parent` this returns a proxy that
     * targets `parent` and has `structure` attached as a child.
     */
    asParent(): Structure;
    get child(): Structure | undefined;
    /** Get the proxy target. Usefull for equality checks. */
    get target(): Structure;
    /**
     * @param units Array of all units in the structure, sorted by unit.id
     * @param unitMap Maps unit.id to index of unit in units array
     * @param unitIndexMap Array of all units in the structure, sorted by unit.id
     */
    constructor(units: ReadonlyArray<Unit>, unitMap: IntMap<Unit>, unitIndexMap: IntMap<number>, state: State, asParent?: {
        child: Structure;
        target: Structure;
    });
}
declare namespace Structure {
    const Empty: Structure;
    interface Props {
        parent?: Structure;
        interUnitBonds?: InterUnitBonds;
        /**
         * Ensure bonds are recalculated upon model changes.
         * Also enables calculation of inter-unit bonds in water molecules.
         */
        dynamicBonds?: boolean;
        interBondsValidUnit?: (unit: Unit) => boolean;
        interBondsValidUnitPair?: (structure: Structure, unitA: Unit, unitB: Unit) => boolean;
        coordinateSystem?: SymmetryOperator;
        label?: string;
        /** Master model for structures of a protein model and multiple ligand models */
        masterModel?: Model;
        /** Representative model for structures of a model trajectory */
        representativeModel?: Model;
    }
    /** Represents a single structure */
    interface Loci {
        readonly kind: 'structure-loci';
        readonly structure: Structure;
    }
    function Loci(structure: Structure): Loci;
    function toStructureElementLoci(structure: Structure): StructureElement.Loci;
    function toSubStructureElementLoci(parent: Structure, structure: Structure): StructureElement.Loci;
    function isLoci(x: any): x is Loci;
    function areLociEqual(a: Loci, b: Loci): boolean;
    function isLociEmpty(loci: Loci): boolean;
    function remapLoci(loci: Loci, structure: Structure): Loci;
    function create(units: ReadonlyArray<Unit>, props?: Props): Structure;
    function ofTrajectory(trajectory: Trajectory, ctx: RuntimeContext): Promise<Structure>;
    /**
     * Construct a Structure from a model.
     *
     * Generally, a single unit corresponds to a single chain, with the exception
     * of consecutive "single atom chains" with same entity_id and same auth_asym_id.
     */
    function ofModel(model: Model, props?: Props): Structure;
    function transform(s: Structure, transform: Mat4): Structure;
    function instances(s: Structure, transforms: Mat4[]): Structure;
    /**
     * Merge units that share the exact same symmetry operator (and model/kind) into a single unit.
     * Units that don't share their operator with any other unit are left untouched.
     */
    function mergeUnitsByOperator(s: Structure): Structure;
    class StructureBuilder {
        private props;
        private units;
        private invariantId;
        private chainGroupId;
        private inChainGroup;
        private p;
        private singleElementUnits;
        beginChainGroup(): void;
        endChainGroup(): void;
        addUnit(kind: Unit.Kind, model: Model, operator: SymmetryOperator, elements: StructureElement.Set, traits: Unit.Traits, invariantId?: number): Unit;
        copyUnit(unit: Unit, options?: Unit.GetCopyOptions & {
            invariantId?: number;
        }): Unit;
        private add;
        addWithOperator(unit: Unit, operator: SymmetryOperator, dontCompose?: boolean): Unit;
        getStructure(): Structure;
        get isEmpty(): boolean;
        constructor(props?: Props);
    }
    function Builder(props?: Props): StructureBuilder;
    function hashCode(s: Structure): number;
    /** Hash based on all unit.model conformation values in the structure */
    function conformationHash(s: Structure): number;
    function areUnitIdsEqual(a: Structure, b: Structure): boolean;
    function areUnitIdsAndIndicesEqual(a: Structure, b: Structure): boolean;
    function areHierarchiesEqual(a: Structure, b: Structure): boolean;
    function areEquivalent(a: Structure, b: Structure): boolean;
    /** Check if the structures or their parents are equivalent */
    function areRootsEquivalent(a: Structure, b: Structure): boolean;
    /** Check if the structures or their parents are equal */
    function areRootsEqual(a: Structure, b: Structure): boolean;
    class ElementLocationIterator implements Iterator<StructureElement.Location> {
        private structure;
        private current;
        private unitIndex;
        private elements;
        private maxIdx;
        private idx;
        hasNext: boolean;
        move(): StructureElement.Location;
        private advance;
        constructor(structure: Structure);
    }
    function minDistanceToPoint(s: Structure, point: Vec3, radius: number): number;
    function distance(a: Structure, b: Structure): number;
    function elementDescription(s: Structure): string;
    function validUnitPair(s: Structure, a: Unit, b: Unit): boolean;
    interface EachUnitPairProps {
        maxRadius: number;
        validUnit: (unit: Unit) => boolean;
        validUnitPair: (unitA: Unit, unitB: Unit) => boolean;
    }
    /**
     * Iterate over all unit pairs of a structure and invokes callback for valid units
     * and unit pairs if their boundaries are within a max distance.
     */
    function eachUnitPair(structure: Structure, callback: (unitA: Unit, unitB: Unit) => void, props: EachUnitPairProps): void;
    interface ForEachAtomicHierarchyElementParams {
        chain?: (e: StructureElement.Location<Unit.Atomic>) => void;
        residue?: (e: StructureElement.Location<Unit.Atomic>) => void;
        atom?: (e: StructureElement.Location<Unit.Atomic>) => void;
    }
    function eachAtomicHierarchyElement(structure: Structure, { chain, residue, atom }: ForEachAtomicHierarchyElementParams): void;
    const DefaultSizeThresholds: {
        /** Must be lower to be small */
        smallResidueCount: number;
        /** Must be lower to be medium */
        mediumResidueCount: number;
        /** Must be lower to be large (big ribosomes like 4UG0 should still be `large`) */
        largeResidueCount: number;
        /**
         * Structures above `largeResidueCount` are consider huge when they have
         * a `highSymmetryUnitCount` or gigantic when not
         */
        highSymmetryUnitCount: number;
        /** Fiber-like structure are consider small when below this */
        fiberResidueCount: number;
    };
    type SizeThresholds = typeof DefaultSizeThresholds;
    enum Size {
        Small = 0,
        Medium = 1,
        Large = 2,
        Huge = 3,
        Gigantic = 4
    }
    /**
     * @param residueCountFactor - modifies the threshold counts, useful when estimating
     *                             the size of a structure comprised of multiple models
     */
    function getSize(structure: Structure, thresholds?: Partial<SizeThresholds>, residueCountFactor?: number): Size;
    type Index = number;
    const Index: import("../../../props/common/custom-property.js").CustomProperty.Provider<Structure, {
        value: import("@molstar/core/util/param-definition").ParamDefinition.Value<number | undefined>;
    }, number | undefined>;
    type MaxIndex = number;
    const MaxIndex: import("../../../props/common/custom-property.js").CustomProperty.Provider<Structure, {
        value: import("@molstar/core/util/param-definition").ParamDefinition.Value<number | undefined>;
    }, number | undefined>;
    function getPrincipalAxes(structure: Structure): PrincipalAxes;
}
export { Structure };
//# sourceMappingURL=structure.d.ts.map