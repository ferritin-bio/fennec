/**
 * Copyright (c) 2018-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { Structure } from '../structure.js';
import { Result } from '@molstar/core/math/geometry';
import type { StructureUniqueSubsetBuilder } from './unique-subset-builder.js';
import { StructureElement } from '../element.js';
import type { Unit } from '../unit.js';
import type { UnitIndex } from '../element/util.js';
export interface StructureResult extends Result<StructureElement.UnitIndex> {
    units: Unit[];
}
export declare namespace StructureResult {
    function add(result: StructureResult, unit: Unit, index: StructureElement.UnitIndex, distSq: number): void;
    function create(): StructureResult;
    function copy(out: StructureResult, result: StructureResult): StructureResult;
}
export interface StructureLookup3DResultContext {
    result: StructureResult;
    closeUnitsResult: Result<number>;
    unitGroupResult: Result<UnitIndex>;
}
export declare function StructureLookup3DResultContext(): StructureLookup3DResultContext;
export declare class StructureLookup3D {
    private structure;
    private unitLookup;
    private pivot;
    private heap;
    findUnitIndices(x: number, y: number, z: number, radius: number): Result<number>;
    private findContext;
    find(x: number, y: number, z: number, radius: number, ctx?: StructureLookup3DResultContext): StructureResult;
    private _find;
    nearest(x: number, y: number, z: number, k?: number, ctx?: StructureLookup3DResultContext): StructureResult;
    _nearest(x: number, y: number, z: number, k: number, ctx: StructureLookup3DResultContext): StructureResult;
    findIntoBuilder(x: number, y: number, z: number, radius: number, builder: StructureUniqueSubsetBuilder): void;
    findIntoBuilderIf(x: number, y: number, z: number, radius: number, builder: StructureUniqueSubsetBuilder, test: (l: StructureElement.Location) => boolean): void;
    findIntoBuilderWithRadius(x: number, y: number, z: number, pivotR: number, maxRadius: number, radius: number, eRadius: StructureElement.Property<number>, builder: StructureUniqueSubsetBuilder): void;
    check(x: number, y: number, z: number, radius: number): boolean;
    approxNearest(x: number, y: number, z: number, radius: number, ctx?: StructureLookup3DResultContext): StructureResult;
    _approxNearest(x: number, y: number, z: number, radius: number, ctx: StructureLookup3DResultContext): StructureResult;
    get boundary(): import("@molstar/core/math/geometry/boundary").Boundary;
    constructor(structure: Structure);
}
//# sourceMappingURL=lookup3d.d.ts.map