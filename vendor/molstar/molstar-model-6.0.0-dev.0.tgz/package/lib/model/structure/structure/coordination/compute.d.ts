/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Structure } from '../structure.js';
import { type Coordination } from './data.js';
export declare function computeCoordination(structure: Structure): Coordination;
//# sourceMappingURL=compute.d.ts.map