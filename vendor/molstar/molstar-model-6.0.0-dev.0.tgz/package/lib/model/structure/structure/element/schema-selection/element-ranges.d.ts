/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { SortedArray } from '@molstar/core/data/int';
import type { ElementIndex } from '../../../model/indexing.js';
/** Represents a collection of disjoint elements ranges in a model (atoms, spheres, or gaussians).
 * The number of ranges is `ElementRanges.count(ranges)`,
 * the i-th range covers elements `[ranges.from[i], ranges.to[i])`. */
export interface ElementRanges {
    from: ElementIndex[];
    to: ElementIndex[];
}
/** Growable buffer of element ranges (not necessarily disjoint or sorted when filled via `append`), for reuse across calls.
 * Unlike `ElementRanges` it keeps an explicit `count` (see `IntBuffer` for why), so only the first `count` entries are valid. */
export declare class ElementRangesBuffer {
    from: Int32Array<ArrayBuffer>;
    to: Int32Array<ArrayBuffer>;
    count: number;
    clear(): this;
    private ensureCapacity;
    /** Same as `ElementRanges.add`: the added range must start after the end of the last range (touching ranges get merged). */
    add(from: number, to: number): this;
    /** Append ranges from `other` without any checks or merging (use `ElementRanges.normalize` on the result). */
    append(other: {
        from: ArrayLike<number>;
        to: ArrayLike<number>;
        count: number;
    } | ElementRanges): this;
    /** Copy the ranges into a new `ElementRanges`. */
    toRanges(): ElementRanges;
    /** Free the memory if the capacity grew above `limit` (so one huge call does not pin memory forever). */
    trim(limit: number): void;
}
export declare const ElementRanges: {
    /** Return the number of disjoined ranges in a `ElementRanges` object */
    count(ranges: ElementRanges): number;
    /** Create new `ElementRanges` without any elements */
    empty(): ElementRanges;
    /** Create new `ElementRanges` containing a single range of elements `[from, to)` */
    single(from: ElementIndex, to: ElementIndex): ElementRanges;
    /** Add a range of elements `[from, to)` to existing `ElementRanges` and return the modified original.
     * The added range must start after the end of the last existing range
     * (if it starts just on the next element, these two ranges will get merged). */
    add(ranges: ElementRanges, from: ElementIndex, to: ElementIndex): ElementRanges;
    /** Apply function `func` to each range in `ranges` */
    foreach(ranges: ElementRanges, func: (from: ElementIndex, to: ElementIndex) => any): void;
    /** Apply function `func` to each range in `ranges` and return an array with results */
    map<T>(ranges: ElementRanges, func: (from: ElementIndex, to: ElementIndex) => T): T[];
    /** Compute the set union of multiple `ElementRanges` objects (as sets of elements) */
    union(ranges: (ElementRanges | undefined)[]): ElementRanges;
    /** Turn a bag of ranges (in any order, possibly overlapping or touching) into a newly allocated `ElementRanges`
     * of disjoint ranges sorted by start (touching ranges are merged). `bag` is not modified.
     *
     * Instead of sorting ranges (which needs an index array and a comparator), the starts and the ends are sorted
     * independently as typed arrays (native, allocation-free numeric sort) and swept like interval-open/close events:
     * a merged range starts when the depth goes 0 -> 1 and ends when it goes 1 -> 0 (at equal coordinates a start is
     * processed before an end, so that touching ranges merge). */
    normalize(bag: ElementRangesBuffer): ElementRanges;
    /** Return a sorted subset of `elements` which lie in any of `ranges` (i.e. set intersection of `elements` and `ranges`).
     * If `out` is provided, use it to store the result (clear any old contents).
     * If `outFirstElementIndex` is provided, fill `outFirstElementIndex.value` with the index of the first selected element (if any). */
    selectElementsInRanges(elements: SortedArray<ElementIndex>, ranges: ElementRanges, out?: ElementIndex[], outFirstElementIndex?: {
        value?: number;
    }): ElementIndex[];
};
//# sourceMappingURL=element-ranges.d.ts.map