/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { OrderedSet } from '@molstar/core/data/int';
import { MolScriptBuilder as MS } from '@molstar/query-language/language/builder';
import { Structure } from '../structure.js';
import { Unit } from '../unit.js';
import type { Expression } from '@molstar/query-language/language/expression';
import type { UnitIndex } from './element.js';
import { Location } from './location.js';
import { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import type { NumberArray } from '@molstar/core/util/type-helpers';
import type { Boundary } from '@molstar/core/math/geometry/boundary';
import { Sphere3D } from '@molstar/core/math/geometry';
import { QueryContext, type QueryFn } from '../../query.js';
import { Schema } from './schema.js';
/** Represents multiple structure element index locations */
export interface Loci {
    readonly kind: 'element-loci';
    readonly structure: Structure;
    /** Access i-th element as unit.elements[indices[i]] */
    readonly elements: ReadonlyArray<{
        unit: Unit;
        /**
         * Indices into the unit.elements array.
         * Can use OrderedSet.forEach to iterate (or OrderedSet.size + OrderedSet.getAt)
         */
        indices: OrderedSet<UnitIndex>;
    }>;
}
export declare function Loci(structure: Structure, elements: ArrayLike<{
    unit: Unit;
    indices: OrderedSet<UnitIndex>;
}>): Loci;
export declare namespace Loci {
    type Element = Loci['elements'][0];
    function is(x: any): x is Loci;
    function areEqual(a: Loci, b: Loci): boolean;
    function isEmpty(loci: Loci): boolean;
    function isWholeStructure(loci: Loci): boolean;
    function size(loci: Loci): number;
    function all(structure: Structure): Loci;
    function none(structure: Structure): Loci;
    function fromExpression(structure: Structure, expression: Expression | ((builder: typeof MS) => Expression), queryContext?: QueryContext): Loci;
    function fromQuery(structure: Structure, query: QueryFn, queryContext?: QueryContext): Loci;
    function fromSchema(structure: Structure, schema: Schema): Loci;
    function getFirstLocation(loci: Loci, e?: Location): Location | undefined;
    function firstElement(loci: Loci): Loci;
    function firstResidue(loci: Loci): Loci;
    function firstChain(loci: Loci): Loci;
    function toStructure(loci: Loci): Structure;
    /**
     * Iterates over all locations.
     * The loc argument of the callback is mutable, use Location.clone() if you intend to keep
     * the value around.
     */
    function forEachLocation(loci: Loci, f: (loc: Location) => void, location?: Location): void;
    function remap(loci: Loci, structure: Structure): Loci;
    /** Create union of `xs` and `ys` */
    function union(xs: Loci, ys: Loci): Loci;
    /** Subtract `ys` from `xs` */
    function subtract(xs: Loci, ys: Loci): Loci;
    /** Intersect `xs` and `ys` */
    function intersect(xs: Loci, ys: Loci): Loci;
    function areIntersecting(xs: Loci, ys: Loci): boolean;
    /** Check if second loci is a subset of the first */
    function isSubset(xs: Loci, ys: Loci): boolean;
    function extendToWholeResidues(loci: Loci, restrictToConformation?: boolean): Loci;
    function extendToWholeChains(loci: Loci): Loci;
    function extendToWholeEntities(loci: Loci): Loci;
    function extendToWholeModels(loci: Loci): Loci;
    function extendToAllInstances(loci: Loci): Loci;
    function extendToWholeOperators(loci: Loci): Loci;
    function extendToRadius(loci: Loci, radius: number): Loci;
    function getBoundingSphere(loci: Loci, boundingSphere?: Sphere3D): Sphere3D;
    function getBoundary(loci: Loci, boundary?: Boundary): Boundary;
    function toPositionsArray(loci: Loci, positions: NumberArray, offset?: number): NumberArray;
    function getPrincipalAxes(loci: Loci): PrincipalAxes;
    function getPrincipalAxesMany(locis: Loci[]): PrincipalAxes;
    function toExpression(loci: Loci): Expression;
}
//# sourceMappingURL=loci.d.ts.map