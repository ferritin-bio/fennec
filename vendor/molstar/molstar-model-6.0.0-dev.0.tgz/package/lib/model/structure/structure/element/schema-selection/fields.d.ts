/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { SchemaItem } from '../schema.js';
export declare const SchemaItemFields: readonly (keyof SchemaItem)[];
/** Is `value` there? `undefined`, `null` and `NaN` (what a number which is missing is in an array of numbers) are not: they are not a criterion. */
export declare function hasValue<T>(value: T | undefined | null): value is T;
/** Does `row` have a value of another type than its field (a number given as text, an identifier given as a number, ...)? Values are matched
 * as they are, so such a row cannot select anything. */
export declare function hasWrongTypes(row: SchemaItem): boolean;
export declare function isSchemaItemField(name: string): name is keyof SchemaItem;
/** A value which an item can have: a missing value (`undefined`, `null`, `NaN`) is not a criterion. */
export declare function isFieldValue(value: unknown): value is string | number | boolean;
/** A copy of the item with the values it has (without the fields which are missing) */
export declare function itemWithValues(item: SchemaItem): SchemaItem;
/** Are these the rows which `schemaItemsFromFields` made (an argument of `element-schema` has to be)? */
export declare function isRowsOfSchemaItem(value: unknown): value is SchemaItem[];
/** The items of a table given by its fields: a field which is an array is a column of the table (a missing value is a hole in it),
 * any other field has the same value in every row. Without any column, there is one row. All the columns have the same length. */
export declare function schemaItemsFromFields(fields?: {
    readonly [name: string]: unknown;
}): SchemaItem[];
//# sourceMappingURL=fields.d.ts.map