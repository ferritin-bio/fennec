/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { Structure } from '../../structure.js';
import { Unit } from '../../unit.js';
import { ElementRanges } from './element-ranges.js';
import type { SchemaItem } from '../schema.js';
/** Helper for caching element ranges qualifying to a group of annotation rows, per `Unit`
 * (units of the same model and kind share the ranges, unless some row refers to a specific `instance_id` or `operator_name`). */
export declare class ElementRangesCache {
    private readonly rows;
    private readonly cache;
    private readonly hasOperators;
    constructor(rows: readonly SchemaItem[]);
    get(unit: Unit): ElementRanges;
    private compute;
}
/** Return the substructure of `structure` consisting of all elements which satisfy at least one of `rows`,
 * found through the indices of each model, so the cost does not grow with the number of atoms times the number of rows.
 *
 * This is what the generator `element-schema` (`Schema.toExpression({ items: rows })`) runs. Rows select what their criteria say: a residue
 * without `label_seq_id` never satisfies a `label_seq_id` criterion (not even 0), criteria which only exist for atoms select nothing on coarse
 * elements (with a warning), a range with `beg > end` selects nothing, and a range with insertion codes is a range of residues in file order.
 * When every element is selected, it returns `structure` itself. */
export declare function substructureFromRows(structure: Structure, rows: readonly SchemaItem[]): Structure;
//# sourceMappingURL=row-structure.d.ts.map