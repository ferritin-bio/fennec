/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Unit, type ElementIndex } from '../../../structure.js';
import { SortedArray } from '@molstar/core/data/int';
export declare function getAtomicPolymerElements(unit: Unit.Atomic): SortedArray<ElementIndex>;
export declare function getCoarsePolymerElements(unit: Unit.Spheres | Unit.Gaussians): SortedArray<ElementIndex>;
export declare function getAtomicGapElements(unit: Unit.Atomic): SortedArray<ElementIndex>;
export declare function getCoarseGapElements(unit: Unit.Spheres | Unit.Gaussians): SortedArray<ElementIndex>;
export declare function getNucleotideElements(unit: Unit.Atomic): SortedArray<ElementIndex>;
export declare function getProteinElements(unit: Unit.Atomic): SortedArray<ElementIndex>;
//# sourceMappingURL=polymer.d.ts.map