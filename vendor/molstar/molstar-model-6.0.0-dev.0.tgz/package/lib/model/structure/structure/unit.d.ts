/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { SymmetryOperator } from '@molstar/core/math/geometry/symmetry-operator';
import { Model } from '../model.js';
import { type Lookup3D } from '@molstar/core/math/geometry';
import { type IntraUnitBonds } from './unit/bonds.js';
import type { CoarseElements, CoarseSphereConformation, CoarseGaussianConformation } from '../model/properties/coarse.js';
import { BitFlags } from '@molstar/core/util';
import { UnitRings } from './unit/rings.js';
import type { StructureElement } from './element.js';
import type { ChainIndex, ResidueIndex, ElementIndex } from '../model/indexing.js';
import { IntMap, SortedArray } from '@molstar/core/data/int';
import type { mmCIF_Schema } from '@molstar/io/reader/cif/schema/mmcif';
import type { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import { type Boundary } from '@molstar/core/math/geometry/boundary';
import { type UnitResonance } from './unit/resonance.js';
/**
 * A building block of a structure that corresponds to an atomic or
 * a coarse grained representation 'conveniently grouped together'.
 */
type Unit = Unit.Atomic | Unit.Spheres | Unit.Gaussians;
declare namespace Unit {
    export const enum Kind {
        Atomic = 0,
        Spheres = 1,
        Gaussians = 2
    }
    export enum Kinds {
        Atomic = 0,
        Spheres = 1,
        Gaussians = 2
    }
    export function isAtomic(u: Unit): u is Atomic;
    export function isCoarse(u: Unit): u is Spheres | Gaussians;
    export function isSpheres(u: Unit): u is Spheres;
    export function isGaussians(u: Unit): u is Gaussians;
    export function create<K extends Kind>(id: number, invariantId: number, chainGroupId: number, traits: Traits, kind: Kind, model: Model, operator: SymmetryOperator, elements: StructureElement.Set, props?: K extends Kind.Atomic ? AtomicProperties : CoarseProperties): Unit;
    /** A group of units that differ only by symmetry operators. */
    export type SymmetryGroup = {
        readonly elements: StructureElement.Set;
        readonly units: ReadonlyArray<Unit>;
        /** Maps unit.id to index of unit in units array */
        readonly unitIndexMap: IntMap<number>;
        /** Hash based on unit.invariantId which is the same for all units in the group */
        readonly hashCode: number;
        /** Hash based on all unit.id values in the group, reflecting the units transformation*/
        readonly transformHash: number;
    };
    export function SymmetryGroup(units: Unit[]): {
        elements: StructureElement.Set;
        units: Unit[];
        readonly unitIndexMap: IntMap<number>;
        hashCode: number;
        transformHash: number;
    };
    export namespace SymmetryGroup {
        function areInvariantElementsEqual(a: SymmetryGroup, b: SymmetryGroup): boolean;
        function getUnitSymmetryGroupsIndexMap(symmetryGroups: ReadonlyArray<Unit.SymmetryGroup>): IntMap<number>;
    }
    export function conformationId(unit: Unit): import("@molstar/core/util").UUID;
    export function hashUnit(u: Unit): number;
    export type Traits = BitFlags<Trait>;
    export enum Trait {
        None = 0,
        MultiChain = 1,
        Partitioned = 2,
        FastBoundary = 4,
        Water = 8,
        CoarseGrained = 16
    }
    export namespace Traits {
        const is: (t: Traits, f: Trait) => boolean;
        const create: (f: Trait) => Traits;
    }
    export interface Base {
        readonly id: number;
        /** invariant ID stays the same even if the Operator/conformation changes. */
        readonly invariantId: number;
        readonly chainGroupId: number;
        readonly traits: Traits;
        readonly elements: StructureElement.Set;
        readonly model: Model;
        readonly conformation: SymmetryOperator.ArrayMapping<ElementIndex>;
        /**
         * The unit `getChild` made this one from, flattened to the root as `Structure.parent` is: same kind and model,
         * a superset of the elements, possibly another operator. Only its static props may be used (unit.md §2).
         */
        readonly parent: Unit | undefined;
        /** Static props: shared by every unit with these elements and model (symmetry copies), read-only (unit.md §1). */
        readonly props: Readonly<BaseProperties>;
        /** Dynamic data of this unit instance, never inherited by children (unit.md §1). */
        readonly transientCache: Map<any, any>;
        getChild(elements: StructureElement.Set): Unit;
        getCopy(id: number, invariantId: number, chainGroupId: number, options?: GetCopyOptions): Unit;
        applyOperator(id: number, operator: SymmetryOperator, dontCompose?: boolean): Unit;
        remapModel(model: Model, dynamicBonds: boolean): Unit;
        readonly boundary: Boundary;
        readonly lookup3d: Lookup3D<StructureElement.UnitIndex>;
        readonly polymerElements: SortedArray<ElementIndex>;
        readonly gapElements: SortedArray<ElementIndex>;
        /**
         * From mmCIF/IHM schema: `_ihm_model_representation_details.model_object_primitive`.
         */
        readonly objectPrimitive: mmCIF_Schema['ihm_model_representation_details']['model_object_primitive']['T'];
    }
    export interface GetCopyOptions {
        propagateTransientCache?: boolean;
    }
    interface BaseProperties {
        boundary?: Boundary;
        lookup3d?: Lookup3D<StructureElement.UnitIndex>;
        principalAxes?: PrincipalAxes;
        polymerElements?: SortedArray<ElementIndex>;
        gapElements?: SortedArray<ElementIndex>;
    }
    function BaseProperties(): BaseProperties;
    /**
     * A bulding block of a structure that corresponds
     * to a "natural group of atoms" (most often a "chain")
     * together with a transformation (rotation and translation)
     * that is dynamically applied to the underlying atom set.
     *
     * An atom set can be referenced by multiple different units which
     * makes construction of assemblies and spacegroups very efficient.
     */
    export class Atomic implements Base {
        readonly kind = Kind.Atomic;
        readonly objectPrimitive = "atomistic";
        readonly id: number;
        readonly invariantId: number;
        /** Used to identify a single chain split into multiple units. */
        readonly chainGroupId: number;
        readonly traits: Traits;
        readonly elements: StructureElement.Set;
        readonly model: Model;
        readonly conformation: SymmetryOperator.ArrayMapping<ElementIndex>;
        /** Reference `residueIndex` from `model` for faster access. */
        readonly residueIndex: ArrayLike<ResidueIndex>;
        /** Reference `chainIndex` from `model` for faster access. */
        readonly chainIndex: ArrayLike<ChainIndex>;
        readonly parent: Atomic | undefined;
        private readonly _props;
        get props(): Readonly<AtomicProperties>;
        private _transientCache;
        get transientCache(): Map<any, any>;
        getChild(elements: StructureElement.Set): Unit;
        getCopy(id: number, invariantId: number, chainGroupId: number, options?: GetCopyOptions): Unit;
        applyOperator(id: number, operator: SymmetryOperator, dontCompose?: boolean): Unit;
        remapModel(model: Model, dynamicBonds: boolean, props?: AtomicProperties): Atomic;
        get boundary(): Boundary;
        get lookup3d(): Lookup3D<StructureElement.UnitIndex>;
        get principalAxes(): PrincipalAxes;
        get bonds(): IntraUnitBonds;
        get rings(): UnitRings;
        get resonance(): UnitResonance;
        get polymerElements(): SortedArray<ElementIndex>;
        get gapElements(): SortedArray<ElementIndex>;
        get nucleotideElements(): SortedArray<ElementIndex>;
        get proteinElements(): SortedArray<ElementIndex>;
        get residueCount(): number;
        getResidueIndex(elementIndex: StructureElement.UnitIndex): ResidueIndex;
        /** Check if any element of the unit belongs to the given residue. */
        hasResidueIndex(residueIndex: ResidueIndex): boolean;
        constructor(id: number, invariantId: number, chainGroupId: number, traits: Traits, model: Model, elements: StructureElement.Set, conformation: SymmetryOperator.ArrayMapping<ElementIndex>, props: AtomicProperties, parent?: Atomic);
    }
    interface AtomicProperties extends BaseProperties {
        bonds?: IntraUnitBonds;
        rings?: UnitRings;
        resonance?: UnitResonance;
        nucleotideElements?: SortedArray<ElementIndex>;
        proteinElements?: SortedArray<ElementIndex>;
        residueCount?: number;
    }
    function AtomicProperties(): AtomicProperties;
    class Coarse<K extends Kind.Gaussians | Kind.Spheres, C extends CoarseSphereConformation | CoarseGaussianConformation> implements Base {
        readonly kind: K;
        readonly objectPrimitive: 'sphere' | 'gaussian';
        readonly id: number;
        readonly invariantId: number;
        readonly chainGroupId: number;
        readonly traits: Traits;
        readonly elements: StructureElement.Set;
        readonly model: Model;
        readonly conformation: SymmetryOperator.ArrayMapping<ElementIndex>;
        readonly coarseElements: CoarseElements;
        readonly coarseConformation: C;
        readonly parent: Unit.Spheres | Unit.Gaussians | undefined;
        private readonly _props;
        get props(): Readonly<CoarseProperties>;
        private _transientCache;
        get transientCache(): Map<any, any>;
        getChild(elements: StructureElement.Set): Unit;
        getCopy(id: number, invariantId: number, chainGroupId: number, options?: GetCopyOptions): Unit;
        applyOperator(id: number, operator: SymmetryOperator, dontCompose?: boolean): Unit;
        remapModel(model: Model, dynamicBonds: boolean, props?: CoarseProperties): Unit.Spheres | Unit.Gaussians;
        get boundary(): Boundary;
        get lookup3d(): Lookup3D<StructureElement.UnitIndex>;
        get principalAxes(): PrincipalAxes;
        get polymerElements(): SortedArray<ElementIndex>;
        get gapElements(): SortedArray<ElementIndex>;
        private getCoarseConformation;
        private getCoarseRadii;
        constructor(id: number, invariantId: number, chainGroupId: number, traits: Traits, model: Model, kind: K, elements: StructureElement.Set, conformation: SymmetryOperator.ArrayMapping<ElementIndex>, props: CoarseProperties, parent?: Unit.Spheres | Unit.Gaussians);
    }
    interface CoarseProperties extends BaseProperties {
    }
    function CoarseProperties(): CoarseProperties;
    export class Spheres extends Coarse<Kind.Spheres, CoarseSphereConformation> {
    }
    export class Gaussians extends Coarse<Kind.Gaussians, CoarseGaussianConformation> {
    }
    export function areSameChainOperatorGroup(a: Unit, b: Unit): boolean;
    export function areOperatorsEqual(a: Unit, b: Unit): boolean;
    export function areConformationsEqual(a: Unit, b: Unit): boolean;
    export function isSameConformation(u: Unit, model: Model): boolean;
    export function getModelConformationOfKind(kind: Unit.Kind, model: Model): import("../model/properties/atomic.js").AtomicConformation | CoarseGaussianConformation | CoarseSphereConformation;
    export function getConformation(u: Unit): import("../model/properties/atomic.js").AtomicConformation | CoarseGaussianConformation | CoarseSphereConformation;
    export function getModelHierarchyOfKind(kind: Unit.Kind, model: Model): import("../model/properties/atomic.js").AtomicHierarchy | CoarseElements;
    export function getHierarchy(u: Unit): import("../model/properties/atomic.js").AtomicHierarchy | CoarseElements;
    export {};
}
export { Unit };
//# sourceMappingURL=unit.d.ts.map