/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StructureQuery } from '../query.js';
export declare function merge(queries: ArrayLike<StructureQuery>): StructureQuery;
export declare function intersect(queries: ArrayLike<StructureQuery>): StructureQuery;
//# sourceMappingURL=combinators.d.ts.map