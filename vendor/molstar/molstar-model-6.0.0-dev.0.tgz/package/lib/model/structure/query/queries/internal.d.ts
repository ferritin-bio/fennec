/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StructureQuery } from '../query.js';
import type { QueryContext } from '../context.js';
import { type BundleElement } from '../../structure/element/bundle.js';
export declare function defaultBondTest(ctx: QueryContext): boolean;
export declare function atomicSequence(): StructureQuery;
export declare function water(): StructureQuery;
export declare function atomicHet(): StructureQuery;
export declare function spheres(): StructureQuery;
export declare function bundleElementImpl(groupedUnits: number[][], ranges: number[], set: number[]): BundleElement;
export declare function bundleGenerator(elements: BundleElement[]): StructureQuery;
//# sourceMappingURL=internal.d.ts.map