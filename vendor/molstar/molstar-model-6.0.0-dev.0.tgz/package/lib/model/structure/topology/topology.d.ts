/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { UUID } from '@molstar/core/util';
import type { Column } from '@molstar/core/data/db';
import type { BasicData } from '@molstar/model/formats/structure/basic/schema';
import type { ModelFormat } from '@molstar/model/formats/format';
export { Topology };
interface Topology {
    readonly id: UUID;
    readonly label: string;
    readonly basic: BasicData;
    readonly sourceData: ModelFormat;
    readonly bonds: {
        readonly indexA: Column<number>;
        readonly indexB: Column<number>;
        readonly order: Column<number>;
    };
}
declare namespace Topology {
    function create(label: string, basic: BasicData, bonds: Topology['bonds'], format: ModelFormat): Topology;
}
//# sourceMappingURL=topology.d.ts.map