/**
 * Copyright (c) 2017-2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Entities } from '../common.js';
import type { CoarseElementData, CoarsedElementKeys } from '../coarse.js';
export declare function getCoarseKeys(data: CoarseElementData, entities: Entities): CoarsedElementKeys;
//# sourceMappingURL=coarse-keys.d.ts.map