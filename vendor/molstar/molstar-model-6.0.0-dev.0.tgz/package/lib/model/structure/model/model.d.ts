/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { UUID } from '@molstar/core/util/uuid';
import type { StructureSequence } from './properties/sequence.js';
import { type AtomicHierarchy, type AtomicConformation, type AtomicRanges } from './properties/atomic.js';
import type { CoarseHierarchy, CoarseConformation } from './properties/coarse.js';
import type { Entities, ChemicalComponentMap, MissingResidues, StructAsymMap } from './properties/common.js';
import type { CustomProperties } from '../../custom-property.js';
import type { SaccharideComponentMap } from '../structure/carbohydrates/constants.js';
import type { ModelFormat } from '@molstar/model/formats/format';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { Coordinates, type Frame } from '../coordinates.js';
import type { Topology } from '../topology.js';
import { Task } from '@molstar/core/task';
import type { ChainIndex, ElementIndex } from './indexing.js';
import type { SymmetryOperator } from '@molstar/core/math/geometry';
import { type Trajectory } from '../trajectory.js';
import type { Unit } from '../structure.js';
import type { SortedArray } from '@molstar/core/data/int/sorted-array';
/**
 * Interface to the "source data" of the molecule.
 *
 * "Atoms" are integers in the range [0, atomCount).
 */
export interface Model extends Readonly<{
    id: UUID;
    entryId: string;
    label: string;
    /** the name of the entry/file/collection the model is part of */
    entry: string;
    /**
     * corresponds to
     * - for IHM: `ihm_model_list.model_id`
     * - for standard mmCIF: `atom_site.pdbx_PDB_model_num`
     * - for models from coordinates: frame index
     */
    modelNum: number;
    sourceData: ModelFormat;
    parent: Model | undefined;
    entities: Entities;
    sequence: StructureSequence;
    atomicHierarchy: AtomicHierarchy;
    atomicConformation: AtomicConformation;
    atomicRanges: AtomicRanges;
    atomicChainOperatorMappinng: Map<ChainIndex, SymmetryOperator>;
    properties: {
        /** map that holds details about unobserved or zero occurrence residues */
        readonly missingResidues: MissingResidues;
        /** maps residue name to `ChemicalComponent` data */
        readonly chemicalComponentMap: ChemicalComponentMap;
        /** maps residue name to `SaccharideComponent` data */
        readonly saccharideComponentMap: SaccharideComponentMap;
        /** maps label_asym_id name to `StructAsym` data */
        readonly structAsymMap: StructAsymMap;
    };
    customProperties: CustomProperties;
    /**
     * Properties independent of coordinates or other dynamic aspects.
     *
     * Not to be accessed directly, each custom property descriptor
     * defines property accessors that use this field to store the data.
     */
    _staticPropertyData: {
        [name: string]: any;
    };
    /**
     * Properties that depend on coordinates or other dynamic aspects.
     *
     * Not to be accessed directly, each custom property descriptor
     * defines property accessors that use this field to store the data.
     */
    _dynamicPropertyData: {
        [name: string]: any;
    };
    coarseHierarchy: CoarseHierarchy;
    coarseConformation: CoarseConformation;
}> {
}
export declare namespace Model {
    function trajectoryFromModelAndCoordinates(model: Model, coordinates: Coordinates): Trajectory;
    function trajectoryFromTopologyAndCoordinates(topology: Topology, coordinates: Coordinates): Task<Trajectory>;
    function getAtomicConformationFromFrame(model: Model, frame: Frame): AtomicConformation;
    function getCenter(model: Model): Vec3;
    /** Get array of atomic radii for all atoms in the model (cached). */
    function getAtomicRadii(model: Model): Float32Array;
    function getInvertedAtomSourceIndex(model: Model): {
        isIdentity: boolean;
        invertedIndex: ArrayLike<ElementIndex>;
    };
    type TrajectoryInfo = {
        readonly index: number;
        readonly size: number;
    };
    const TrajectoryInfo: {
        get(model: Model): TrajectoryInfo;
        set(model: Model, trajectoryInfo: TrajectoryInfo): TrajectoryInfo;
    };
    type AsymIdCount = {
        readonly auth: number;
        readonly label: number;
    };
    const AsymIdCount: {
        get(model: Model): AsymIdCount;
    };
    type AsymIdOffset = {
        auth: number;
        label: number;
    };
    const AsymIdOffset: import("../../../props/common/custom-property.js").CustomProperty.Provider<Model, {
        value: import("@molstar/core/util/param-definition").ParamDefinition.Value<AsymIdOffset | undefined>;
    }, AsymIdOffset | undefined>;
    type Index = number;
    const Index: import("../../../props/common/custom-property.js").CustomProperty.Provider<Model, {
        value: import("@molstar/core/util/param-definition").ParamDefinition.Value<number | undefined>;
    }, number | undefined>;
    type MaxIndex = number;
    const MaxIndex: import("../../../props/common/custom-property.js").CustomProperty.Provider<Model, {
        value: import("@molstar/core/util/param-definition").ParamDefinition.Value<number | undefined>;
    }, number | undefined>;
    function getRoot(model: Model): Model;
    function areHierarchiesEqual(a: Model, b: Model): boolean;
    type CoordinatesHistory = {
        areEqual(elements: SortedArray<ElementIndex>, kind: Unit.Kind, model: Model): boolean;
    };
    const CoordinatesHistory: {
        get(model: Model): CoordinatesHistory | undefined;
        set(model: Model, coordinatesHistory: CoordinatesHistory): CoordinatesHistory;
    };
    const CoarseGrained: {
        get(model: Model): boolean | undefined;
        set(model: Model, coarseGrained: boolean): boolean;
    };
    /**
     * Mark as coarse grained if any of the following conditions are met:
     * - has typical coarse grained atom names (BB, SC1)
     * - has less than three times as many atoms as polymer residues (C-alpha only models)
     * - has no standard sidechain atoms
     */
    function isCoarseGrained(model: Model): boolean;
    function hasCarbohydrate(model: Model): boolean;
    function hasProtein(model: Model): boolean;
    function hasNucleic(model: Model): boolean;
    function isFromPdbArchive(model: Model): boolean;
    function hasPdbId(model: Model): boolean;
    function hasSecondaryStructure(model: Model): boolean;
    function hasCrystalSymmetry(model: Model): boolean;
    function isFromXray(model: Model): boolean;
    function isFromEm(model: Model): boolean;
    function isFromNmr(model: Model): boolean;
    function isExperimental(model: Model): boolean;
    function isIntegrative(model: Model): boolean;
    function isComputational(model: Model): boolean;
    function hasXrayMap(model: Model): boolean;
    /**
     * Also checks for `content_type` of 'associated EM volume' to exclude cases
     * like 6TEK which are solved with 'X-RAY DIFFRACTION' but have an related
     * EMDB entry of type 'other EM volume'.
     */
    function hasEmMap(model: Model): boolean;
    function hasDensityMap(model: Model): boolean;
    function probablyHasDensityMap(model: Model): boolean;
}
//# sourceMappingURL=model.d.ts.map