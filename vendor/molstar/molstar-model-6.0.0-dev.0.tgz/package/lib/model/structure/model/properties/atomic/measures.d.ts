/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Himanshu Raj <himanshuraj6771@gmail.com>
 */
import type { ElementSymbol } from '../../types.js';
export declare const AtomicNumbers: {
    [e: string]: number | undefined;
};
export declare const ElementVdwRadii: {
    [e: number]: number | undefined;
};
export declare const ElementAtomWeights: {
    [e: number]: number | undefined;
};
export declare const DefaultVdwRadius = 1.7;
export declare const DefaultAtomWeight = 12.011;
export declare const DefaultAtomNumber = 0;
export declare function VdwRadius(element: ElementSymbol): number;
export declare function AtomWeight(element: ElementSymbol): number;
export declare function AtomNumber(element: ElementSymbol): number;
//# sourceMappingURL=measures.d.ts.map