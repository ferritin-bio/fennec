/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * Code-generated ion names params file. Names extracted from CCD components.
 *
 * @author molstar/chem-comp-dict/create-ions cli
 */
export declare const IonNames: Set<string>;
//# sourceMappingURL=ions.d.ts.map