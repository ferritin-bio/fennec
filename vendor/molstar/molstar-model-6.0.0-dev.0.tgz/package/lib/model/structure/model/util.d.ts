/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { AtomicConformation } from './properties/atomic.js';
import type { CoarseConformation } from './properties/coarse.js';
import type { Model } from './model.js';
export declare function calcModelCenter(atomicConformation: AtomicConformation, coarseConformation?: CoarseConformation): Vec3;
export declare function getAsymIdCount(model: Model): {
    auth: number;
    label: number;
};
//# sourceMappingURL=util.d.ts.map