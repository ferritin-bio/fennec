/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * Code-generated lipid params file. Names from Martini FF and Amber.
 *
 * @author molstar/lipid-params cli
 */
export declare const LipidNames: Set<string>;
//# sourceMappingURL=lipids.d.ts.map