/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { CoarseRanges, CoarseElementData } from '../coarse/hierarchy.js';
import type { ChemicalComponent } from '../common.js';
export declare function getCoarseRanges(data: CoarseElementData, chemicalComponentMap: ReadonlyMap<string, ChemicalComponent>): CoarseRanges;
//# sourceMappingURL=coarse-ranges.d.ts.map