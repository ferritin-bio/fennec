/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Mat4 } from '@molstar/core/math/linear-algebra';
import { FormatPropertyProvider } from '@molstar/model/formats/structure/common/property';
import type { CifExportContext } from '../../structure.js';
import type { Model } from '../model.js';
import { Column } from '@molstar/core/data/db';
import { CifWriter } from '@molstar/io/writer/cif';
export declare namespace GlobalModelTransformInfo {
    const Schema: {
        molstar_global_model_transform_info: {
            matrix: Column.Schema.Tensor;
        };
    };
    type Schema = typeof Schema;
    const Descriptor: {
        name: "molstar_global_model_transform_info";
        cifExport: {
            categories: {
                name: "molstar_global_model_transform_info";
                instance(ctx: CifExportContext): CifWriter.Category.Instance<any, any>;
            }[];
            prefix: string;
        };
    };
    const Provider: FormatPropertyProvider<Mat4>;
    function attach(model: Model, matrix: Mat4): void;
    function get(model: Model): Mat4 | undefined;
    function fromMmCif(model: Model): Mat4 | undefined;
    function hasData(model: Model): boolean;
    function writeMmCif(encoder: CifWriter.Encoder, matrix: Mat4): void;
}
//# sourceMappingURL=global-transform.d.ts.map