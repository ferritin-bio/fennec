/**
 * Copyright (c) 2017-2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { CifWriter } from '@molstar/io/writer/cif';
import type { CifExportContext } from '../mmcif.js';
import CifCategory = CifWriter.Category;
export declare const _struct_asym: CifCategory<CifExportContext>;
export declare const _entity_poly: CifCategory<CifExportContext>;
export declare const _entity_poly_seq: CifCategory<CifExportContext>;
//# sourceMappingURL=sequence.d.ts.map