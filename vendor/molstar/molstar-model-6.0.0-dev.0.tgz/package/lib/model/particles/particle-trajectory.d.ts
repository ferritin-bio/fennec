/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Task } from '@molstar/core/task/task';
import type { ParticleList } from './particle-list.js';
/**
 * A generic interface for representing (partial) particle trajectories.
 * Mirrors `Trajectory` from `mol-model/structure/trajectory.ts` but for `ParticleList` frames.
 */
export interface ParticleTrajectory {
    readonly frameCount: number;
    /** Statically available representative frame. Required for example by certain UI actions. */
    readonly representative: ParticleList;
    /** Return the particle list for the given frame index (0-based). */
    getFrameAtIndex(i: number): ParticleList | Task<ParticleList>;
}
export declare class ArrayParticleTrajectory implements ParticleTrajectory {
    private frames;
    readonly frameCount: number;
    readonly representative: ParticleList;
    getFrameAtIndex(i: number): ParticleList;
    constructor(frames: ParticleList[]);
}
//# sourceMappingURL=particle-trajectory.d.ts.map