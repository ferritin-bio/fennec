/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { OrderedSet } from '@molstar/core/data/int';
import type { Column } from '@molstar/core/data/db';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { Sphere3D } from '@molstar/core/math/geometry';
import type { ModelFormat } from '@molstar/model/formats/format';
import { type CustomProperties, CustomPropertyDescriptor } from '../custom-property.js';
import type { Boundary } from '@molstar/core/math/geometry/boundary';
import type { Cell } from '@molstar/core/math/geometry/spacegroup/cell';
/**
 * A single named per-particle scalar attribute (e.g. `'cc'`, `'class'`, `'score'`).
 *
 * `column` provides the per-particle values (indexed by particle position, length = `count`).
 * Formats should reuse an existing `Column` (e.g. via `Column.view`) or provide a lambda-based
 * accessor instead of copying data whenever possible.
 */
export interface ParticleAttribute {
    readonly column: Column<any>;
    readonly label: string;
    readonly min: number;
    readonly max: number;
}
export interface ParticleCompartmentInfo {
    /** Compartment name/path (e.g. `"root.mge.surface.proteins"`). */
    readonly name: string;
}
export interface ParticleEntityInfo {
    /** Entity name (e.g. `"MG_191_192_NAP"`). */
    readonly name: string;
    /** Optional functional annotation of the entity (e.g. `"Lipid"`). */
    readonly function?: string;
}
/** Lightweight metadata for a single target id, always available (unlike `targetMapping`). */
export interface ParticleTargetInfo {
    /** Optional display name for this target (e.g. chain id, tomogram id, agent type name). */
    readonly name?: string;
    /** Index into `entityInfo`; states/enforces that every particle of this target shares this entity. */
    readonly entity?: number;
}
export interface ParticleList {
    readonly entryId?: string;
    readonly label?: string;
    readonly count: number;
    /**
     * Optional periodic/bounding cell for the particle system (e.g. the simulation box
     * size of a Simularium trajectory).
     */
    readonly cell?: Cell;
    /** Unique keys for each particle for mapping to source data. */
    readonly keys: Int32Array;
    /**
     * Per-particle target index (length = `count`). Each value identifies which
     * target structure/volume/shape this particle belongs to. Use 0 for
     * single-target data. The distinct values in this array correspond to the
     * keys of `targetMapping` when present.
     */
    readonly targets: Int32Array;
    /**
     * Metadata for each unique target ID in `targets`. Always present (unlike `targetMapping`),
     * so target ids can be enumerated cheaply without scanning `targets`.
     */
    readonly targetInfo: ReadonlyMap<number, ParticleTargetInfo>;
    /**
     * Optional mapping from each unique target ID in `targets` to the reference object
     * instanced at every particle with that target ID. The objects are owned by the
     * particle list itself and are not part of the plugin state tree.
     */
    readonly targetMapping?: ReadonlyMap<number, ParticleTarget>;
    /**
     * Optional per-particle compartment index (length = `count`). Each value identifies
     * which compartment this particle belongs to. A value of -1 means "no compartment".
     * The distinct non-negative values correspond to keys of `compartmentInfo`.
     */
    readonly compartments?: Int32Array;
    /**
     * Optional mapping from each unique compartment index in `compartments` to the
     * compartment info.
     */
    readonly compartmentInfo?: ReadonlyMap<number, ParticleCompartmentInfo>;
    /**
     * Optional per-particle entity index (length = `count`). Each value identifies
     * which entity (molecule type) this particle belongs to. A value of -1 means "no entity".
     * The distinct non-negative values correspond to keys of `entityInfo`.
     */
    readonly entities?: Int32Array;
    /**
     * Optional mapping from each unique entity index in `entities` to the entity info.
     */
    readonly entityInfo?: ReadonlyMap<number, ParticleEntityInfo>;
    /** Particle positions in angstrom, packed as `[x0, y0, z0, x1, y1, z1, ...]`. */
    readonly coordinates: Float32Array;
    /** Optional per-particle orientations as unit quaternions, packed as `[x0, y0, z0, w0, ...]`. */
    readonly rotations?: Float32Array;
    /** Optional per-particle bounding sphere radii in angstrom (length = `count`). */
    readonly radii?: Float32Array;
    /**
     * Optional polyline (fiber) connectivity over particles, stored in compressed-sparse-row
     * form. Fiber `f` (for `0 <= f < count`) is the ordered polyline through the particles
     * `indices[offsets[f]]` .. `indices[offsets[f + 1]) - 1]`. Used by formats such as
     * Simularium where an agent expands into a chain of particles.
     */
    readonly fibers?: {
        readonly count: number;
        readonly offsets: Int32Array;
        readonly indices: Int32Array;
    };
    /**
     * Named per-particle scalar attributes, indexed by particle position (length = count).
     * Keys are short identifiers (e.g. 'cc', 'class', 'score').
     */
    readonly attributes?: ReadonlyMap<string, ParticleAttribute>;
    readonly getParticleLabel: (index: number) => string;
    readonly sourceData: ModelFormat;
    customProperties: CustomProperties;
    _propertyData: {
        [name: string]: any;
    };
}
/**
 * A reference object instanced at each particle of a given target id. Each particle has
 * exactly one target id (see `ParticleList.targets`); the distinct target ids map to these
 * targets via `ParticleList.targetMapping`.
 */
export type ParticleTarget = {
    readonly kind: 'structure';
    readonly structure: import('../structure/structure.js').Structure;
} | {
    readonly kind: 'shape';
    readonly shape: import('../shape/shape.js').Shape;
} | {
    readonly kind: 'volume';
    readonly volume: import('../volume/volume.js').Volume;
};
export declare namespace ParticleTarget {
    function data(target: ParticleTarget): import("../shape/shape.js").Shape<import("../shape/shape.js").ShapeGeometry> | import("../structure/structure.js").Structure | import("../volume/volume.js").Volume;
}
/**
 * Per-particle transforms as a flat array, 16 consecutive floats (column-major mat4) per
 * particle. Computed once and cached on the `ParticleList`.
 */
export declare function getParticleTransforms(data: ParticleList): Float32Array;
/** The particles of a `ParticleList` grouped by their target id. */
export interface ParticleTargetGroups {
    /** The distinct target ids, ascending. */
    readonly targetIds: Int32Array;
    /** The particles of group `g`, as indices into the unfiltered `ParticleList`. */
    readonly sets: ReadonlyArray<OrderedSet<number>>;
    readonly groupOfTarget: ReadonlyMap<number, number>;
}
/**
 * Group the particles by target id. Computed once and cached on the `ParticleList`.
 *
 * When `targets` is already non-decreasing - the usual case, since formats emit particles
 * grouped by target - each group is a contiguous range and is returned as an `Interval`,
 * which needs no per-group storage and makes `OrderedSet.getAt`/`indexOf` arithmetic rather
 * than a binary search. Otherwise the groups are built with a counting sort.
 */
export declare function getParticleTargetGroups(data: ParticleList): ParticleTargetGroups;
/**
 * Per-particle mask (length = `count`) marking fiber particles, i.e. particles referenced
 * by `fibers.indices`. Returns `undefined` if the particle list has no `fibers` data.
 * Computed once and cached on the `ParticleList`.
 */
export declare function getFiberParticleMask(data: ParticleList): Uint8Array | undefined;
export declare namespace Particle {
    function is(x: any): x is ParticleList;
    /** A single particle within a `ParticleList`. */
    interface Location {
        readonly kind: 'particle-location';
        particles: ParticleList;
        /** Particle index in the list. */
        index: number;
    }
    function Location(particles?: ParticleList, index?: number): Location;
    function isLocation(x: any): x is Location;
    /** Write the particle's position into `out`. */
    function position(out: Vec3, location: Location): Vec3;
    /** A loci over one or more particles in a `ParticleList`. */
    interface Loci {
        readonly kind: 'particle-loci';
        readonly particles: ParticleList;
        readonly indices: OrderedSet<number>;
    }
    function Loci(particles: ParticleList, indices: OrderedSet<number>): Loci;
    function isLoci(x: any): x is Loci;
    function areLociEqual(a: Loci, b: Loci): boolean;
    function isLociEmpty(loci: Loci): boolean;
    function lociSize(loci: Loci): number;
    /** Remap a loci to a new `ParticleList`; indices outside the new range are dropped. */
    function remapLoci(loci: Loci, particles: ParticleList): Loci;
    function getBoundingSphere(loci: Loci, boundingSphere?: Sphere3D): Sphere3D;
    function getLabel(loci: Loci): string;
    /** Return a copy of `particles` with the given per-target reference objects attached. */
    function withTargets(particles: ParticleList, targetMapping: ReadonlyMap<number, ParticleTarget>): ParticleList;
    const BoundaryDescriptor: CustomPropertyDescriptor<Boundary>;
    function setBoundary(particles: ParticleList, boundary: Boundary): void;
    function getBoundary(particles: ParticleList): Boundary;
}
//# sourceMappingURL=particle-list.d.ts.map