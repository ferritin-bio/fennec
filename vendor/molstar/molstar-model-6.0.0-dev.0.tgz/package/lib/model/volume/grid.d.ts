/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type SpacegroupCell, Box3D, Sphere3D } from '@molstar/core/math/geometry';
import { Tensor, Mat4, Vec3 } from '@molstar/core/math/linear-algebra';
import { type Histogram, type HistogramRobustStats } from '@molstar/core/math/histogram';
/** The basic unit cell that contains the grid data. */
interface Grid {
    readonly transform: Grid.Transform;
    readonly cells: Tensor;
    readonly stats: Readonly<{
        min: number;
        max: number;
        mean: number;
        sigma: number;
    }>;
    readonly periodicity?: 'none' | 'xyz';
}
declare namespace Grid {
    export const One: Grid;
    export type Transform = {
        kind: 'spacegroup';
        cell: SpacegroupCell;
        fractionalBox: Box3D;
    } | {
        kind: 'matrix';
        matrix: Mat4;
    };
    export function getGridToCartesianTransform(grid: Grid): Mat4;
    export function areEquivalent(gridA: Grid, gridB: Grid): boolean;
    export function isEmpty(grid: Grid): boolean;
    export function getBoundingSphere(grid: Grid, boundingSphere?: Sphere3D): Sphere3D;
    export function getIsosurfaceBoundingSphere(grid: Grid, isoValue: number, boundingSphere?: Sphere3D): Sphere3D;
    /**
     * Compute histogram with given bin count.
     * Cached on the Grid object.
     */
    export function getHistogram(grid: Grid, binCount: number): Histogram;
    /** Default bin count for histogram-derived robust statistics. */
    export const RobustStatsBinCount = 1024;
    /**
     * Compute robust summary statistics (percentiles, mean, sigma) from the
     * cached histogram. Set `ignoreZero` to skip the histogram bin that
     * contains exact zero values (typical for masked/padded density maps).
     * Cached on the Grid object.
     */
    export function getRobustStats(grid: Grid, opts?: {
        ignoreZero?: boolean;
        binCount?: number;
    }): HistogramRobustStats;
    export function makeGetTrilinearlyInterpolated(grid: Grid, transform: 'none' | 'relative'): (position: Vec3) => number;
    /**
     * Core trilinear interpolation function.
     * @param gridCoords - Position in grid coordinates (fractional indices)
     * @param mi, mj, mk - Grid dimensions
     * @param getValue - Function to get value at integer grid coordinates
     * @returns Interpolated value or NaN if out of bounds
     */
    export function trilinearlyInterpolate(gridCoords: Vec3, mi: number, mj: number, mk: number, isPeriodic: boolean, getValue: (i: number, j: number, k: number) => number): number;
    /**
     * Core trilinear interpolation function for Vec3 values.
     * More efficient for interleaved data like gradients since getValue is called once per grid point.
     * @param gridCoords - Position in grid coordinates (fractional indices)
     * @param mi, mj, mk - Grid dimensions
     * @param getValue - Function to get Vec3 value at integer grid coordinates
     * @param out - Output Vec3
     * @returns true if interpolation succeeded, false if out of bounds
     */
    export function trilinearlyInterpolateVec3(gridCoords: Vec3, mi: number, mj: number, mk: number, getValue: (i: number, j: number, k: number, out: Vec3) => void, out: Vec3): boolean;
    type Gradients = {
        values: Float32Array;
        magnitude: {
            min: number;
            max: number;
            mean: number;
            sigma: number;
        };
    };
    /**
     * Pre-compute gradients at each grid cell using central differences.
     * Returns a single Float32Array with interleaved xyz components (x1, y1, z1, x2, y2, z2, ...).
     * Cached on the Grid object.
     */
    export function getGradients(grid: Grid): Gradients;
    /**
     * Create a function that returns trilinearly interpolated gradient at a grid position.
     * The gradient is pre-computed at grid cells and interpolated for smooth results.
     */
    export function makeGetInterpolatedGradient(grid: Grid): (gridCoords: Vec3, out: Vec3) => boolean;
    export {};
}
export { Grid };
//# sourceMappingURL=grid.d.ts.map