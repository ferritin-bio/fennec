/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Color } from '@molstar/core/util/color';
import { UUID } from '@molstar/core/util';
import { OrderedSet } from '@molstar/core/data/int';
import { Mat4 } from '@molstar/core/math/linear-algebra';
import type { Sphere3D } from '@molstar/core/math/geometry/primitives/sphere3d';
/** Data shared by a shape and its graphics integrations. `G` is deliberately
 * structural so the model package does not need to own graphics geometry. */
export interface ShapeGeometry {
    readonly kind: string;
    readonly boundingSphere: Sphere3D;
}
export interface Shape<G extends ShapeGeometry = ShapeGeometry> {
    readonly id: UUID;
    readonly name: string;
    readonly sourceData: unknown;
    readonly geometry: G;
    readonly transforms: Mat4[];
    readonly groupCount: number;
    getGroupBoundingSphere?: (groups: ShapeGroup.Loci['groups'], out?: Sphere3D) => Sphere3D;
    getColor(groupId: number, instanceId: number): Color;
    getSize(groupId: number, instanceId: number): number;
    getLabel(groupId: number, instanceId: number): string;
}
export declare namespace Shape {
    /** Create model-side shape data; rendering consumers should use the graphics Shape.create factory. */
    function create<G extends ShapeGeometry>(name: string, sourceData: unknown, geometry: G, getColor: Shape['getColor'], getSize: Shape['getSize'], getLabel: Shape['getLabel'], groupCount: number, transforms?: Mat4[]): Shape<G>;
    interface Loci {
        readonly kind: 'shape-loci';
        readonly shape: Shape;
    }
    function Loci(shape: Shape): Loci;
    function isLoci(x: any): x is Loci;
    function areLociEqual(a: Loci, b: Loci): boolean;
    function isLociEmpty(loci: Loci): boolean;
}
export declare namespace ShapeGroup {
    interface Location {
        readonly kind: 'group-location';
        shape: Shape;
        group: number;
        instance: number;
    }
    function Location(shape?: Shape, group?: number, instance?: number): Location;
    function isLocation(x: any): x is Location;
    interface Loci {
        readonly kind: 'group-loci';
        readonly shape: Shape;
        readonly groups: ReadonlyArray<{
            readonly ids: OrderedSet<number>;
            readonly instance: number;
        }>;
    }
    function Loci(shape: Shape, groups: Loci['groups']): Loci;
    function isLoci(x: any): x is Loci;
    function areLociEqual(a: Loci, b: Loci): boolean;
    function isLociEmpty(loci: Loci): boolean;
    function size(loci: Loci): number;
}
//# sourceMappingURL=shape.d.ts.map