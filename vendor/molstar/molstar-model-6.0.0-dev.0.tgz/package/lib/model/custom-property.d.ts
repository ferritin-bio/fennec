/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { CifWriter } from '@molstar/io/writer/cif';
import type { CifExportContext } from './structure/export/mmcif.js';
import type { QuerySymbolRuntime } from '@molstar/model/script/runtime/query/compiler';
import { UUID } from '@molstar/core/util';
export { CustomPropertyDescriptor, CustomProperties };
interface CustomPropertyDescriptor<ExportCtx = CifExportContext, Symbols extends {
    [name: string]: QuerySymbolRuntime;
} = {}> {
    readonly name: string;
    cifExport?: {
        prefix: string;
        context?: (ctx: CifExportContext) => ExportCtx | undefined;
        categories: CifWriter.Category<ExportCtx>[];
    };
    symbols?: Symbols;
}
declare function CustomPropertyDescriptor<Ctx, Desc extends CustomPropertyDescriptor<Ctx>>(desc: Desc): Desc;
declare namespace CustomPropertyDescriptor {
    function getUUID(prop: CustomPropertyDescriptor): UUID;
}
/**
 * Anything with a dispose method, used to despose of data assets or webgl resources
 */
type Asset = {
    dispose: () => void;
};
declare class CustomProperties {
    private _list;
    private _set;
    private _refs;
    /** desc → owner → assets; the owner is `undefined` unless the objects sharing these properties own them apart */
    private _assets;
    get all(): ReadonlyArray<CustomPropertyDescriptor>;
    add(desc: CustomPropertyDescriptor<any>): void;
    reference(desc: CustomPropertyDescriptor<any>, add: boolean): void;
    hasReference(desc: CustomPropertyDescriptor<any>): boolean;
    has(desc: CustomPropertyDescriptor<any>): boolean;
    /**
     * Sets assets for a prop, disposes of existing assets for that prop. `owner` keeps the assets of one of the objects
     * sharing these properties apart, e.g. the model id for dynamic data: models with the same topology share
     * `customProperties` but not their dynamic property data.
     */
    assets(desc: CustomPropertyDescriptor<any>, assets?: Asset[], owner?: string): void;
    /** Disposes of all assets of all props (and forgets them, so a later `assets()` does not dispose them again) */
    dispose(): void;
}
//# sourceMappingURL=custom-property.d.ts.map