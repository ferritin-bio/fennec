/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Expression } from '@molstar/query-language/language/expression';
import { type StructureElement, StructureSelection, type Structure, type QueryFn, type QueryContextOptions } from '@molstar/model/model/structure';
import { MolScriptBuilder } from '@molstar/query-language/language/builder';
import type { Script } from '@molstar/core/util/script';
export { ScriptImpl as Script };
type ScriptImpl = Script;
declare function ScriptImpl(expression: string, language: Script['language']): Script;
declare namespace ScriptImpl {
    const Info: {
        [k in Script['language']]: string;
    };
    type Language = Script['language'];
    function is(x: any): x is Script;
    function areEqual(a: Script, b: Script): boolean;
    /** `mol-script` plus the languages enabled by importing a `transpilers/<lang>` module */
    function getAvailableLanguages(): Language[];
    function toExpression(script: Script): Expression;
    function toQuery(script: Script): QueryFn<StructureSelection>;
    function toLoci(script: Script, structure: Structure): StructureElement.Loci;
    function getStructureSelection(expr: Expression | ((builder: typeof MolScriptBuilder) => Expression), structure: Structure, options?: QueryContextOptions): StructureSelection;
}
//# sourceMappingURL=script.d.ts.map