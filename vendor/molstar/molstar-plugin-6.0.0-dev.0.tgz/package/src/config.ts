/**
 * Copyright (c) 2020-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { Structure, Model } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { PdbDownloadProvider } from '@molstar/plugin/state/actions/structure';
import type { EmdbDownloadProvider } from '@molstar/plugin/state/actions/volume';
import type { StructureRepresentationPresetProvider } from '@molstar/plugin/state/builder/structure/representation-presets/types';
import { PluginFeatureDetection } from '@molstar/plugin/features';
import type { SaccharideCompIdMapType } from '@molstar/model/model/structure/structure/carbohydrates/constants';
import type { BackgroundProps } from '@molstar/graphics/canvas3d/passes/background';
import type { GraphicsBackendDescriptor } from '@molstar/graphics/gl/backend';

export class PluginConfigItem<T = any> {
  toString() {
    return this.key;
  }
  valueOf() {
    return this.key;
  }
  constructor(
    public key: string,
    public defaultValue?: T,
  ) {}
}

function item<T>(key: string, defaultValue?: T) {
  return new PluginConfigItem(key, defaultValue);
}

export const PluginConfig = {
  item,
  General: {
    IsBusyTimeoutMs: item('plugin-config.is-busy-timeout', 750),
    DisableAntialiasing: item('plugin-config.disable-antialiasing', false),
    DisablePreserveDrawingBuffer: item('plugin-config.disable-preserve-drawing-buffer', false),
    PixelScale: item('plugin-config.pixel-scale', 1),
    PickScale: item('plugin-config.pick-scale', 0.25),
    Transparency: item<'blended' | 'wboit' | 'dpoit'>(
      'plugin-config.transparency',
      PluginFeatureDetection.defaultTransparency,
    ),
    /**
     * Graphics backends tried in order, e.g. `[WebGPUBackend, WebGL2Backend, WebGLBackend]`; by default those of
     * `@molstar/graphics/gl/backends/default` (WebGL, WebGL1 only with `PreferWebGl1`; builds may alias the module)
     */
    GraphicsBackends: item<readonly GraphicsBackendDescriptor[] | undefined>(
      'plugin-config.graphics-backends',
      undefined,
    ),
    // as of Oct 1 2021, WebGL 2 doesn't work on iOS 15.
    // TODO: check back in a few weeks to see if it was fixed
    PreferWebGl1: item('plugin-config.prefer-webgl1', false),
    AllowMajorPerformanceCaveat: item('plugin-config.allow-major-performance-caveat', false),
    PowerPreference: item<WebGLContextAttributes['powerPreference']>(
      'plugin-config.power-preference',
      'high-performance',
    ),
    ResolutionMode: item<'auto' | 'scaled' | 'native'>('plugin-config.resolution-mode', 'auto'),
    /**
     * The animation loop stops asking for frames while the canvas is idle (`Canvas3D.isIdle`) and starts again on its
     * `wake` or a state animation. Off by default: code that changes the scene or the camera past Canvas3D's API without
     * `requestDraw` would not be drawn.
     */
    PauseLoopWhenIdle: item('plugin-config.pause-loop-when-idle', false),
  },
  State: {
    DefaultServer: item('plugin-state.server', 'https://webchem.ncbr.muni.cz/molstar-state'),
    CurrentServer: item('plugin-state.server', 'https://webchem.ncbr.muni.cz/molstar-state'),
    HistoryCapacity: item('history-capacity.server', 5),
  },
  VolumeStreaming: {
    Enabled: item('volume-streaming.enabled', true),
    DefaultServer: item('volume-streaming.server', 'https://ds.litemol.org'),
    CanStream: item('volume-streaming.can-stream', (s: Structure, plugin: PluginContext) => {
      return s.models.length === 1 && Model.probablyHasDensityMap(s.models[0]);
    }),
    EmdbHeaderServer: item('volume-streaming.emdb-header-server', 'https://files.wwpdb.org/pub/emdb/structures'),
  },
  Viewport: {
    ShowReset: item('viewer.show-reset-button', true),
    ShowExpand: item('viewer.show-expand-button', true),
    ShowToggleFullscreen: item('viewer.show-toggle-fullscreen-button', true),
    ShowControls: item('viewer.show-controls-button', true),
    ShowSettings: item('viewer.show-settings-button', true),
    ShowSelectionMode: item('viewer.show-selection-model-button', true),
    ShowAnimation: item('viewer.show-animation-button', true),
    ShowTrajectoryControls: item('viewer.show-trajectory-controls', true),
    ShowScreenshotControls: item('viewer.show-screenshot-controls', true),
    ShowIllumination: item('viewer.show-illumination-button', true),
    ShowXR: item<'auto' | 'always' | 'never'>('viewer.show-xr', 'always'),
  },
  Download: {
    DefaultPdbProvider: item<PdbDownloadProvider>('download.default-pdb-provider', 'pdbe'),
    DefaultEmdbProvider: item<EmdbDownloadProvider>('download.default-emdb-provider', 'pdbe'),
  },
  Structure: {
    SizeThresholds: item('structure.size-thresholds', Structure.DefaultSizeThresholds),
    DefaultHierarchyPreset: item<string>('structure.default-hierarchy-preset', 'preset-trajectory-default'),
    DefaultRepresentationPreset: item<string>(
      'structure.default-representation-preset',
      'preset-structure-representation-auto',
    ),
    DefaultRepresentationPresetParams: item<StructureRepresentationPresetProvider.CommonParams>(
      'structure.default-representation-preset-params',
      {},
    ),
    SaccharideCompIdMapType: item<SaccharideCompIdMapType>('structure.saccharide-comp-id-map-type', 'default'),
  },
  Background: {
    Styles: item<[BackgroundProps, string][]>('background.styles', []),
  },
};

export class PluginConfigManager {
  private _config = new Map<PluginConfigItem<any>, unknown>();

  get<T>(key: PluginConfigItem<T>) {
    if (!this._config.has(key)) return key.defaultValue;
    return this._config.get(key) as T;
  }

  set<T>(key: PluginConfigItem<T>, value: T) {
    this._config.set(key, value);
  }

  delete<T>(key: PluginConfigItem<T>) {
    this._config.delete(key);
  }

  constructor(initial?: [PluginConfigItem, unknown][]) {
    if (!initial) return;
    initial.forEach(([k, v]) => this._config.set(k, v));
  }
}
