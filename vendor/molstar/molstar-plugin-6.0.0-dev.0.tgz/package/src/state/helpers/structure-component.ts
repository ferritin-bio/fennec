/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */

import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Expression } from '@molstar/query-language/language/expression';
import { MolScriptBuilder } from '@molstar/query-language/language/builder';
import {
  StructureElement,
  Structure,
  StructureSelection as Sel,
  StructureQuery,
  Queries,
  QueryContext,
  Model,
} from '@molstar/model/model/structure';
import { StructureQueryHelper } from './structure-query.js';
import { PluginStateObject as SO } from '../objects.js';
import { all } from '@molstar/plugin/state/queries/structure/basic';
import {
  ion,
  lipid,
  nucleic,
  polymer,
  protein,
  branchedPlusConnected,
  ligandPlusConnected,
  coarse,
} from '@molstar/plugin/state/queries/structure/type';
import { nonStandardPolymer } from '@molstar/plugin/state/queries/structure/residue';
import { StateTransformer, StateObject } from '@molstar/core/state';
import { Script } from '@molstar/model/script/script';
import { assertUnreachable } from '@molstar/core/util/type-helpers';

export const StaticStructureComponentTypes = [
  'all',

  'polymer',

  'protein',
  'nucleic',
  'water',
  'ion',
  'lipid',

  'branched',
  'ligand',
  'non-standard',

  'coarse',
] as const;

export type StaticStructureComponentType = (typeof StaticStructureComponentTypes)[number];

export const StructureComponentParams = () => ({
  type: PD.MappedStatic(
    'static',
    {
      static: PD.Text<StaticStructureComponentType>('polymer'),
      expression: PD.Value<Expression>(MolScriptBuilder.struct.generator.all),
      bundle: PD.Value<StructureElement.Bundle>(StructureElement.Bundle.Empty),
      script: PD.Script({ language: 'mol-script', expression: '(sel.atom.all)' }),
    },
    { isHidden: true },
  ),
  nullIfEmpty: PD.Optional(PD.Boolean(true, { isHidden: true })),
  label: PD.Text('', { isHidden: true }),
});
export type StructureComponentParams = PD.ValuesFor<ReturnType<typeof StructureComponentParams>>;

/** What `StructureComponent` keeps between its calls */
export interface StructureComponentCache {
  /** The structure which the component was made from */
  source: Structure;
  entry?: StructureQueryHelper.CacheEntry;
  /** The component is the source structure itself (e.g. every element is selected), so its properties are not its own and it must not dispose them */
  isSource?: boolean;
}

export function createStructureComponent(
  a: Structure,
  params: StructureComponentParams,
  cache: StructureComponentCache,
) {
  cache.source = a;

  let component: Structure = Structure.Empty;
  let label: string | undefined = void 0;
  switch (params.type.name) {
    case 'static': {
      let query: StructureQuery;
      switch (params.type.params) {
        case 'all':
          query = all.query;
          label = 'All';
          break;

        case 'polymer':
          query = polymer.query;
          label = 'Polymer';
          break;

        case 'protein':
          query = protein.query;
          label = 'Protein';
          break;
        case 'nucleic':
          query = nucleic.query;
          label = 'Nucleic';
          break;
        case 'water':
          query = Queries.internal.water();
          label = 'Water';
          break;
        case 'ion':
          query = ion.query;
          label = 'Ion';
          break;
        case 'lipid':
          query = lipid.query;
          label = 'Lipid';
          break;

        case 'branched':
          query = branchedPlusConnected.query;
          label = 'Branched';
          break;
        case 'ligand':
          query = ligandPlusConnected.query;
          label = 'Ligand';
          break;

        case 'non-standard':
          query = nonStandardPolymer.query;
          label = 'Non-standard';
          break;

        case 'coarse':
          query = coarse.query;
          label = 'Coarse';
          break;

        default:
          assertUnreachable(params.type);
      }
      const result = query(new QueryContext(a));
      component = Sel.unionStructure(result);
      break;
    }
    case 'script':
    case 'expression': {
      const { selection, entry } = StructureQueryHelper.createAndRun(a, params.type.params);
      cache.entry = entry;
      component = Sel.unionStructure(selection);
      break;
    }
    case 'bundle': {
      if (params.type.params.hash !== a.hashCode) break;
      component = StructureElement.Bundle.toStructure(params.type.params, a);
      break;
    }
  }

  if (params.nullIfEmpty && component.elementCount === 0) return StateObject.Null;

  const props = {
    label: `${params.label || label || 'Component'}`,
    description: Structure.elementDescription(component),
  };
  cache.isSource = component === a;
  return new SO.Molecule.Structure(component, props);
}

export function updateStructureComponent(
  a: Structure,
  b: SO.Molecule.Structure,
  oldParams: StructureComponentParams,
  newParams: StructureComponentParams,
  cache: StructureComponentCache,
) {
  if (oldParams.type.name !== newParams.type.name) return StateTransformer.UpdateResult.Recreate;

  let updated = false;

  switch (newParams.type.name) {
    case 'static': {
      if (oldParams.type.params !== newParams.type.params) {
        return StateTransformer.UpdateResult.Recreate;
      }
      if (!Structure.areEquivalent(a, cache.source)) {
        return StateTransformer.UpdateResult.Recreate;
      }
      // The same model, or none (an empty substructure): nothing to remap, but the label may have changed (below).
      if (b.data.model === a.model || !b.data.model) break;
      if (!Model.areHierarchiesEqual(a.model, b.data.model)) return StateTransformer.UpdateResult.Recreate;

      b.data = b.data.remapModel(a.model);
      cache.isSource = false; // (a copy)
      updated = true;
      break;
    }
    case 'script':
      if (!Script.areEqual(oldParams.type.params as Script, newParams.type.params)) {
        return StateTransformer.UpdateResult.Recreate;
      }
    case 'expression': {
      if ((oldParams.type.params as Expression) !== newParams.type.params) {
        return StateTransformer.UpdateResult.Recreate;
      }

      if (a === cache.source) break;

      const entry = (cache as { entry: StructureQueryHelper.CacheEntry }).entry;

      const selection = StructureQueryHelper.updateStructure(entry, a);
      cache.source = a;
      b.data = Sel.unionStructure(selection);
      cache.isSource = b.data === a;
      StructureQueryHelper.updateStructureObject(b, selection, newParams.label);
      updated = true;
      break;
    }
    case 'bundle': {
      if (
        a === cache.source &&
        StructureElement.Bundle.areEqual(oldParams.type.params as StructureElement.Bundle, newParams.type.params)
      ) {
        break;
      }

      cache.source = a;
      if (newParams.type.params.hash !== a.hashCode) {
        updated = b.data.elementCount !== 0;
        b.data = b.data.elementCount === 0 ? b.data : Structure.Empty;
      } else {
        updated = true;
        b.data = StructureElement.Bundle.toStructure(newParams.type.params, a);
      }
      cache.isSource = b.data === a;
      break;
    }
  }

  if (updated) {
    if (newParams.nullIfEmpty && b.data.elementCount === 0) return StateTransformer.UpdateResult.Null;

    b.description = Structure.elementDescription(b.data);
  }

  if (oldParams.label !== newParams.label) {
    updated = true;
    b.label = `${newParams.label || b.label}`;
  }

  return updated ? StateTransformer.UpdateResult.Updated : StateTransformer.UpdateResult.Unchanged;
}
