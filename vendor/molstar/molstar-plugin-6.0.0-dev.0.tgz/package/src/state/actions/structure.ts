/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */

import type { PluginContext } from '@molstar/plugin/context';
import { StateAction, StateSelection, StateTransformer } from '@molstar/core/state';
import { Task } from '@molstar/core/task';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StructureRepresentationPresetProvider } from '../builder/structure/representation-presets/types.js';
import { TrajectoryFormatCategory } from '@molstar/plugin/state/formats/trajectory/category';
import { RootStructureDefinition } from '../helpers/root-structure.js';
import { PluginStateObject } from '../objects.js';
import type { Download } from '@molstar/plugin/state/transforms/data/fetch';
import {
  CustomModelProperties,
  CustomStructureProperties,
  ModelFromTrajectory,
  TrajectoryFromModelAndCoordinates,
} from '@molstar/plugin/state/transforms/structure/hierarchy';
import { Asset } from '@molstar/core/util/assets';
import { PluginConfig } from '@molstar/plugin/config';
import { getFileNameInfo } from '@molstar/core/util/file-info';
import { assertUnreachable } from '@molstar/core/util/type-helpers';
import { TopologyFormatCategory } from '@molstar/plugin/state/formats/topology/category';
import { CoordinatesFormatCategory } from '@molstar/plugin/state/formats/coordinates/category';

/** The id of the empty representation preset, which also turns off the unit cell. */
const EmptyRepresentationPresetId = 'preset-structure-representation-empty';

/** The format of every source that loads an mmCIF file, and of the multi-source blob. */
const MmcifFormat = 'mmcif';

const DownloadModelRepresentationOptions = (plugin: PluginContext) => {
  const representationDefault = plugin.config.get(PluginConfig.Structure.DefaultRepresentationPreset) ?? '';
  return PD.Group(
    {
      type: RootStructureDefinition.getParams(void 0, 'auto').type,
      representation: PD.Select(
        representationDefault,
        plugin.builders.structure.representation
          .getPresets()
          .map((p) => [p.id, p.display.name, p.display.group] as any),
        { description: 'Which representation preset to use.' },
      ),
      representationParams: PD.Group(StructureRepresentationPresetProvider.CommonParams, { isHidden: true }),
      // loading a blob is implemented by the mmCIF format
      asTrajectory: PD.Optional(
        PD.Boolean(false, {
          description: 'Load all entries into a single trajectory.',
          isHidden: !plugin.dataFormats.has(MmcifFormat),
        }),
      ),
    },
    { isExpanded: false },
  );
};

export const PdbDownloadProvider = {
  rcsb: PD.Group(
    {
      encoding: PD.Select('bcif', PD.arrayToOptions(['cif', 'bcif'] as const)),
    },
    { label: 'RCSB PDB', isFlat: true },
  ),
  pdbe: PD.Group(
    {
      variant: PD.Select('updated-bcif', [
        ['updated-bcif', 'Updated (bcif)'],
        ['updated', 'Updated'],
        ['archival', 'Archival'],
      ] as ['updated' | 'updated-bcif' | 'archival', string][]),
    },
    { label: 'PDBe', isFlat: true },
  ),
  pdbj: PD.EmptyGroup({ label: 'PDBj' }),
};
export type PdbDownloadProvider = keyof typeof PdbDownloadProvider;

/**
 * Offers only the sources whose formats are registered: every PDB-like source loads mmCIF, SWISS-MODEL loads PDB,
 * PubChem loads MOL, and the URL source needs at least one trajectory format.
 */
function availableSources<S extends PD.Params>(plugin: PluginContext, sources: S, hasTrajectoryFormats: boolean) {
  const formats: Record<string, string> = {
    pdb: MmcifFormat,
    'pdb-ihm': MmcifFormat,
    swissmodel: 'pdb',
    alphafolddb: MmcifFormat,
    modelarchive: MmcifFormat,
    pubchem: 'mol',
  };
  const available = Object.keys(sources).filter((k) => {
    const format = formats[k];
    return format ? plugin.dataFormats.has(format) : hasTrajectoryFormats;
  });
  const map: PD.Params = {};
  for (const k of available) map[k] = sources[k];
  // without a registered source the action has nothing to offer: its only option is an empty one
  if (available.length === 0) map[''] = PD.EmptyGroup();
  return PD.MappedStatic((available.includes('pdb') ? 'pdb' : (available[0] ?? '')) as keyof S, map as S);
}

export { DownloadStructure };
type DownloadStructure = typeof DownloadStructure;
const DownloadStructure = StateAction.build({
  from: PluginStateObject.Root,
  display: {
    name: 'Download Structure',
    description: 'Load a structure from the provided source and create its representation.',
    triggerLabel: 'Download',
  },
  params: (_, plugin: PluginContext) => {
    const options = DownloadModelRepresentationOptions(plugin);
    const defaultPdbProvider = plugin.config.get(PluginConfig.Download.DefaultPdbProvider) || 'pdbe';
    const trajectoryFormats = plugin.dataFormats.options
      .filter((o) => o[2] === TrajectoryFormatCategory)
      .map((o) => o[0]);
    const sources = {
      pdb: PD.Group(
        {
          provider: PD.Group(
            {
              id: PD.Text('1tqn', { label: 'PDB Id(s)', description: 'One or more comma/space separated PDB ids.' }),
              server: PD.MappedStatic(defaultPdbProvider, PdbDownloadProvider),
            },
            { pivot: 'id' },
          ),
          options,
        },
        { isFlat: true, label: 'PDB' },
      ),
      'pdb-ihm': PD.Group(
        {
          provider: PD.Group(
            {
              id: PD.Text('8zzc', { label: 'PDB-IHM Id(s)', description: 'One or more comma/space separated ids.' }),
              encoding: PD.Select('bcif', PD.arrayToOptions(['cif', 'bcif'] as const)),
            },
            { pivot: 'id' },
          ),
          options,
        },
        { isFlat: true, label: 'PDB-IHM' },
      ),
      swissmodel: PD.Group(
        {
          id: PD.Text('Q9Y2I8', { label: 'UniProtKB AC(s)', description: 'One or more comma/space separated ACs.' }),
          options,
        },
        {
          isFlat: true,
          label: 'SWISS-MODEL',
          description: 'Loads the best homology model or experimental structure',
        },
      ),
      alphafolddb: PD.Group(
        {
          provider: PD.Group(
            {
              id: PD.Text('Q8W3K0', {
                label: 'ID(s)',
                description:
                  'One or more comma/space separated IDs. Each ID can be either UniProt accession (e.g. Q14676, Q14676-2) or AlphaFoldDB model entity ID (e.g. AF-Q14676-F1, AF-Q14676-2-F1, AF-0000000066074510). Version suffixes (e.g. -v1) will be ignored and the newest model version will be downloaded.',
              }),
              encoding: PD.Select('bcif', PD.arrayToOptions(['cif', 'bcif'] as const)),
            },
            { pivot: 'id' },
          ),
          options,
        },
        { isFlat: true, label: 'AlphaFold DB', description: 'Loads the predicted model if available' },
      ),
      modelarchive: PD.Group(
        {
          id: PD.Text('ma-bak-cepc-0003', {
            label: 'Accession Code(s)',
            description: 'One or more comma/space separated ACs.',
          }),
          options,
        },
        { isFlat: true, label: 'Model Archive' },
      ),
      pubchem: PD.Group(
        {
          id: PD.Text('2244,2245', { label: 'PubChem ID', description: 'One or more comma/space separated IDs.' }),
          options,
        },
        { isFlat: true, label: 'PubChem', description: 'Loads 3D conformer from PubChem.' },
      ),
      url: PD.Group(
        {
          url: PD.Url(''),
          format: PD.Select<string>(
            trajectoryFormats.includes(MmcifFormat) ? MmcifFormat : (trajectoryFormats[0] ?? MmcifFormat),
            PD.arrayToOptions(trajectoryFormats, (f) => f),
          ),
          isBinary: PD.Boolean(false),
          label: PD.Optional(PD.Text('')),
          options,
        },
        { isFlat: true, label: 'URL' },
      ),
    };
    return { source: availableSources(plugin, sources, trajectoryFormats.length > 0) };
  },
})(({ params, state }, plugin: PluginContext) =>
  Task.create('Download Structure', async (ctx) => {
    plugin.behaviors.layout.leftPanelTabName.next('data');

    const src = params.source;
    let downloadParams: StateTransformer.Params<Download>[];
    let asTrajectory = false;
    let format: string = MmcifFormat;

    switch (src.name) {
      case 'url':
        downloadParams = [{ url: src.params.url, isBinary: src.params.isBinary, label: src.params.label || undefined }];
        format = src.params.format;
        break;
      case 'pdb':
        downloadParams = await (src.params.provider.server.name === 'pdbe'
          ? getPdbeDownloadParams(src)
          : src.params.provider.server.name === 'pdbj'
            ? getPdbjDownloadParams(src)
            : src.params.provider.server.name === 'rcsb'
              ? getRcsbDownloadParams(src)
              : assertUnreachable(src as never));
        asTrajectory = !!src.params.options.asTrajectory;
        break;
      case 'pdb-ihm':
        const map = (id: string) => (id.startsWith('PDBDEV_') ? id : `PDBDEV_${id.padStart(8, '0')}`);
        downloadParams = await getDownloadParams(
          src.params.provider.id,
          (id) => {
            // 4 character PDB id, TODO: support extended PDB ID
            if (id.match(/^[1-9][A-Z0-9]{3}$/i) !== null) {
              return src.params.provider.encoding === 'bcif'
                ? `https://pdb-ihm.org/bcif/${id.toLowerCase()}.bcif`
                : `https://pdb-ihm.org/cif/${id.toLowerCase()}.cif`;
            }
            const nId = map(id.toUpperCase());
            return src.params.provider.encoding === 'bcif'
              ? `https://pdb-ihm.org/bcif/${nId}.bcif`
              : `https://pdb-ihm.org/cif/${nId}.cif`;
          },
          (id) => {
            const nId = id.toUpperCase();
            return nId.match(/^[1-9][A-Z0-9]{3}$/) ? `PDB-IHM: ${nId}` : map(nId);
          },
          src.params.provider.encoding === 'bcif',
        );
        asTrajectory = !!src.params.options.asTrajectory;
        break;
      case 'swissmodel':
        downloadParams = await getDownloadParams(
          src.params.id,
          (id) => `https://swissmodel.expasy.org/repository/uniprot/${id.toUpperCase()}.pdb`,
          (id) => `SWISS-MODEL: ${id}`,
          false,
        );
        asTrajectory = !!src.params.options.asTrajectory;
        format = 'pdb';
        break;
      case 'alphafolddb':
        downloadParams = await getDownloadParams(
          src.params.provider.id,
          async (id) => {
            // id = UniProt accession: Q14676, Q14676-4
            // id = model entity ID: AF-Q14676-F1, AF-Q14676-4-F1, AF-0000000066074510
            // id = model entity ID + version to be ignored: AF-Q14676-4-F1-v6, AF-0000000066074510-v1
            const cleanId = id.replace(/-v\d+$/i, '').toUpperCase(); // Ignore version suffix (e.g. "-v6") because it is not a part of the ID, but displayed on AFDB page and people often copy-paste it
            const url = `https://www.alphafold.ebi.ac.uk/api/prediction/${cleanId}`;
            const info = await plugin.runTask(plugin.fetch({ url, type: 'json' }));
            if (Array.isArray(info) && info.length > 0) {
              const prop = src.params.provider.encoding === 'bcif' ? 'bcifUrl' : 'cifUrl';
              return info[0][prop];
            }
            throw new Error(`No AlphaFold DB entry for '${id}'`);
          },
          (id) => `AlphaFold DB: ${id}`,
          src.params.provider.encoding === 'bcif',
        );
        asTrajectory = !!src.params.options.asTrajectory;
        format = MmcifFormat;
        break;
      case 'modelarchive':
        downloadParams = await getDownloadParams(
          src.params.id,
          // Without `www.`: that host does not answer a browser's cross-origin request (the plain one does).
          (id) => `https://modelarchive.org/doi/10.5452/${id.toLowerCase()}.cif`,
          (id) => `Model Archive: ${id}`,
          false,
        );
        asTrajectory = !!src.params.options.asTrajectory;
        format = MmcifFormat;
        break;
      case 'pubchem':
        downloadParams = await getDownloadParams(
          src.params.id,
          (id) => `https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/CID/${id.trim()}/record/SDF/?record_type=3d`,
          (id) => `PubChem: ${id}`,
          false,
        );
        asTrajectory = !!src.params.options.asTrajectory;
        format = 'mol';
        break;
      default:
        assertUnreachable(src);
    }

    const representationPreset: any =
      (params.source.params.options.representation ||
        plugin.config.get(PluginConfig.Structure.DefaultRepresentationPreset)) ??
      '';
    const showUnitcell = representationPreset !== EmptyRepresentationPresetId;
    const hierarchyPreset = plugin.config.get(PluginConfig.Structure.DefaultHierarchyPreset) ?? '';

    const structure = src.params.options.type.name === 'auto' ? void 0 : src.params.options.type;
    await state
      .transaction(async () => {
        if (downloadParams.length > 0 && asTrajectory) {
          const blob = await plugin.builders.data.downloadBlob(
            {
              sources: downloadParams.map((src, i) => ({ id: '' + i, url: src.url, isBinary: src.isBinary })),
              maxConcurrency: 6,
            },
            { state: { isGhost: true } },
          );
          const trajectory = await plugin.builders.structure.parseTrajectory(blob, {
            formats: downloadParams.map((_, i) => ({ id: '' + i, format: 'cif' as const })),
          });

          await plugin.builders.structure.hierarchy.applyPreset(trajectory, hierarchyPreset, {
            structure,
            showUnitcell,
            representationPreset,
            representationPresetParams: params.source.params.options.representationParams,
          });
        } else {
          for (const download of downloadParams) {
            const data = await plugin.builders.data.download(download, { state: { isGhost: true } });
            if (!plugin.dataFormats.has(format)) throw new Error('unknown file format');
            const provider = plugin.dataFormats.get(format)!;
            const trajectory = await plugin.builders.structure.parseTrajectory(data, provider);

            await plugin.builders.structure.hierarchy.applyPreset(trajectory, hierarchyPreset, {
              structure,
              showUnitcell,
              representationPreset,
              representationPresetParams: params.source.params.options.representationParams,
            });
          }
        }
      })
      .runInContext(ctx);
  }),
);

async function getDownloadParams(
  src: string,
  url: (id: string) => string | Promise<string>,
  label: (id: string) => string,
  isBinary: boolean,
): Promise<StateTransformer.Params<Download>[]> {
  const ids = src
    .split(/[,\s]/)
    .map((id) => id.trim())
    .filter((id) => !!id && (id.length >= 4 || /^[1-9][0-9]*$/.test(id)));
  const ret: StateTransformer.Params<Download>[] = [];
  for (const id of ids) {
    ret.push({ url: Asset.Url(await url(id)), isBinary, label: label(id) });
  }
  return ret;
}

async function getPdbeDownloadParams(src: ReturnType<DownloadStructure['createDefaultParams']>['source']) {
  if (src.name !== 'pdb' || src.params.provider.server.name !== 'pdbe') throw new Error('expected pdbe');
  return src.params.provider.server.params.variant === 'updated'
    ? getDownloadParams(
        src.params.provider.id,
        (id) => `https://www.ebi.ac.uk/pdbe/static/entry/${id.toLowerCase()}_updated.cif`,
        (id) => `PDBe: ${id} (updated cif)`,
        false,
      )
    : src.params.provider.server.params.variant === 'updated-bcif'
      ? getDownloadParams(
          src.params.provider.id,
          (id) => `https://www.ebi.ac.uk/pdbe/entry-files/download/${id.toLowerCase()}.bcif`,
          (id) => `PDBe: ${id} (updated cif)`,
          true,
        )
      : getDownloadParams(
          src.params.provider.id,
          (id) => `https://www.ebi.ac.uk/pdbe/static/entry/${id.toLowerCase()}.cif`,
          (id) => `PDBe: ${id} (cif)`,
          false,
        );
}

async function getPdbjDownloadParams(src: ReturnType<DownloadStructure['createDefaultParams']>['source']) {
  if (src.name !== 'pdb' || src.params.provider.server.name !== 'pdbj') throw new Error('expected pdbj');
  return getDownloadParams(
    src.params.provider.id,
    (id) =>
      `https://data.pdbjlc1.pdbj.org/pub/pdb/data/structures/divided/mmCIF/${id.toLowerCase().substring(1, 3)}/${id.toLowerCase()}.cif`,
    (id) => `PDBj: ${id} (cif)`,
    false,
  );
}

async function getRcsbDownloadParams(src: ReturnType<DownloadStructure['createDefaultParams']>['source']) {
  if (src.name !== 'pdb' || src.params.provider.server.name !== 'rcsb') throw new Error('expected rcsb');
  return src.params.provider.server.params.encoding === 'cif'
    ? getDownloadParams(
        src.params.provider.id,
        (id) => `https://files.rcsb.org/download/${id.toUpperCase()}.cif`,
        (id) => `RCSB PDB: ${id} (cif)`,
        false,
      )
    : getDownloadParams(
        src.params.provider.id,
        (id) => `https://models.rcsb.org/${id.toUpperCase()}.bcif`,
        (id) => `RCSB PDB: ${id} (bcif)`,
        true,
      );
}

export const UpdateTrajectory = StateAction.build({
  display: { name: 'Update Trajectory' },
  params: {
    action: PD.Select('advance', PD.arrayToOptions(['advance', 'reset'] as const)),
    by: PD.Optional(PD.Numeric(1, { min: -1, max: 1, step: 1 })),
  },
})(({ params, state }) => {
  const models = state.selectQ((q) => q.ofTransformer(ModelFromTrajectory));

  const update = state.build();

  if (params.action === 'reset') {
    for (const m of models) {
      update.to(m).update({ modelIndex: 0 });
    }
  } else {
    for (const m of models) {
      const parent = StateSelection.findAncestorOfType(
        state.tree,
        state.cells,
        m.transform.ref,
        PluginStateObject.Molecule.Trajectory,
      );
      if (!parent || !parent.obj) continue;
      const traj = parent.obj;
      update.to(m).update((old) => {
        let modelIndex = (old.modelIndex + params.by!) % traj.data.frameCount;
        if (modelIndex < 0) modelIndex += traj.data.frameCount;
        return { modelIndex };
      });
    }
  }

  return state.updateTree(update);
});

export const EnableModelCustomProps = StateAction.build({
  display: { name: 'Custom Model Properties', description: 'Enable parameters for custom properties of the model.' },
  from: PluginStateObject.Molecule.Model,
  params(a, ctx: PluginContext) {
    return ctx.customModelProperties.getParams(a?.data);
  },
  isApplicable(a, t, ctx: PluginContext) {
    return t.transformer !== CustomModelProperties;
  },
})(({ ref, params }, ctx: PluginContext) => ctx.builders.structure.insertModelProperties(ref, params));

export const EnableStructureCustomProps = StateAction.build({
  display: {
    name: 'Custom Structure Properties',
    description: 'Enable parameters for custom properties of the structure.',
  },
  from: PluginStateObject.Molecule.Structure,
  params(a, ctx: PluginContext) {
    return ctx.customStructureProperties.getParams(a?.data);
  },
  isApplicable(a, t, ctx: PluginContext) {
    return t.transformer !== CustomStructureProperties;
  },
})(({ ref, params }, ctx: PluginContext) => ctx.builders.structure.insertStructureProperties(ref, params));

export const AddTrajectory = StateAction.build({
  display: {
    name: 'Add Trajectory',
    description: 'Add trajectory from existing model/topology and coordinates.',
    triggerLabel: 'Add',
  },
  from: PluginStateObject.Root,
  params(a, ctx: PluginContext) {
    const state = ctx.state.data;
    const models = [
      ...state.selectQ((q) => q.rootsOfType(PluginStateObject.Molecule.Model)),
      ...state.selectQ((q) => q.rootsOfType(PluginStateObject.Molecule.Topology)),
    ];
    const modelOptions = models.map((t) => [t.transform.ref, t.obj!.label]) as [string, string][];
    const coords = state.selectQ((q) => q.rootsOfType(PluginStateObject.Molecule.Coordinates));
    const coordOptions = coords.map((c) => [c.transform.ref, c.obj!.label]) as [string, string][];
    return {
      model: PD.Select(modelOptions.length ? modelOptions[0][0] : '', modelOptions),
      coordinates: PD.Select(coordOptions.length ? coordOptions[0][0] : '', coordOptions),
    };
  },
})(({ params, state }, ctx: PluginContext) =>
  Task.create('Add Trajectory', (taskCtx) => {
    return state
      .transaction(async () => {
        const dependsOn = [params.model, params.coordinates];
        const model = state
          .build()
          .toRoot()
          .apply(
            TrajectoryFromModelAndCoordinates,
            {
              modelRef: params.model,
              coordinatesRef: params.coordinates,
            },
            { dependsOn },
          )
          .apply(ModelFromTrajectory, { modelIndex: 0 });

        await state.updateTree(model).runInContext(taskCtx);
        const structure = await ctx.builders.structure.createStructure(model.selector);
        await ctx.builders.structure.representation.applyPreset(
          structure,
          ctx.config.get(PluginConfig.Structure.DefaultRepresentationPreset) ?? '',
        );
      })
      .runInContext(taskCtx);
  }),
);

export const LoadTrajectory = StateAction.build({
  display: {
    name: 'Load Trajectory',
    description: 'Load trajectory of model/topology and coordinates from URL or file.',
    triggerLabel: 'Load',
  },
  from: PluginStateObject.Root,
  params(a, ctx: PluginContext) {
    const { options } = ctx.dataFormats;
    const modelOptions = options.filter((o) => o[2] === TrajectoryFormatCategory || o[2] === TopologyFormatCategory);
    const coordinatesOptions = options.filter((o) => o[2] === CoordinatesFormatCategory);

    const modelExts: string[] = [];
    const coordinatesExts: string[] = [];
    for (const { provider } of ctx.dataFormats.list) {
      if (provider.category === TrajectoryFormatCategory || provider.category === TopologyFormatCategory) {
        if (provider.binaryExtensions) modelExts.push(...provider.binaryExtensions);
        if (provider.stringExtensions) modelExts.push(...provider.stringExtensions);
      } else if (provider.category === CoordinatesFormatCategory) {
        if (provider.binaryExtensions) coordinatesExts.push(...provider.binaryExtensions);
        if (provider.stringExtensions) coordinatesExts.push(...provider.stringExtensions);
      }
    }

    return {
      source: PD.MappedStatic(
        'file',
        {
          url: PD.Group(
            {
              model: PD.Group(
                {
                  url: PD.Url(''),
                  format: PD.Select(modelOptions[0][0], modelOptions),
                  isBinary: PD.Boolean(false),
                },
                { isExpanded: true },
              ),
              coordinates: PD.Group(
                {
                  url: PD.Url(''),
                  format: PD.Select(coordinatesOptions[0][0], coordinatesOptions),
                },
                { isExpanded: true },
              ),
            },
            { isFlat: true },
          ),
          file: PD.Group(
            {
              model: PD.File({ accept: modelExts.map((e) => `.${e}`).join(','), label: 'Model' }),
              coordinates: PD.File({ accept: coordinatesExts.map((e) => `.${e}`).join(','), label: 'Coordinates' }),
            },
            { isFlat: true },
          ),
        },
        {
          options: [
            ['url', 'URL'],
            ['file', 'File'],
          ],
        },
      ),
    };
  },
})(({ params, state }, ctx: PluginContext) =>
  Task.create('Load Trajectory', (taskCtx) => {
    return state
      .transaction(async () => {
        const s = params.source;

        if (s.name === 'file' && (s.params.model === null || s.params.coordinates === null)) {
          ctx.log.error('No file(s) selected');
          return;
        }

        if (s.name === 'url' && (!s.params.model || !s.params.coordinates)) {
          ctx.log.error('No URL(s) given');
          return;
        }

        const processUrl = async (url: string | Asset.Url, format: string, isBinary: boolean) => {
          const data = await ctx.builders.data.download({ url, isBinary });

          if (!ctx.dataFormats.has(format)) {
            ctx.log.warn(`LoadTrajectory: could not find data provider for '${format}'`);
            return;
          }

          return ctx.dataFormats.get(format)!.parse(ctx, data);
        };

        const processFile = async (file: Asset.File | null) => {
          if (!file) throw new Error('No file selected');

          const info = getFileNameInfo(file.file?.name ?? '');
          const isBinary = ctx.dataFormats.binaryExtensions.has(info.ext);
          const { data } = await ctx.builders.data.readFile({ file, isBinary });
          const provider = ctx.dataFormats.auto(info, data.cell?.obj!);

          if (!provider) {
            ctx.log.warn(`LoadTrajectory: could not find data provider for '${info.ext}'`);
            await ctx.state.data.build().delete(data).commit();
            return;
          }

          return provider.parse(ctx, data);
        };

        try {
          const modelParsed =
            s.name === 'url'
              ? await processUrl(s.params.model.url, s.params.model.format, s.params.model.isBinary)
              : await processFile(s.params.model);

          let model;
          if ('trajectory' in modelParsed) {
            model = await state
              .build()
              .to(modelParsed.trajectory)
              .apply(ModelFromTrajectory, { modelIndex: 0 })
              .commit();
          } else {
            model = modelParsed.topology;
          }

          //

          const coordinates =
            s.name === 'url'
              ? await processUrl(s.params.coordinates.url, s.params.coordinates.format, true)
              : await processFile(s.params.coordinates);

          //

          // dependsOn is auto-derived from the `getDependencies` hook on TrajectoryFromModelAndCoordinates
          const traj = state
            .build()
            .toRoot()
            .apply(TrajectoryFromModelAndCoordinates, {
              modelRef: model.ref,
              coordinatesRef: coordinates.ref,
            })
            .apply(ModelFromTrajectory, { modelIndex: 0 });

          await state.updateTree(traj).runInContext(taskCtx);
          const structure = await ctx.builders.structure.createStructure(traj.selector);
          await ctx.builders.structure.representation.applyPreset(
            structure,
            ctx.config.get(PluginConfig.Structure.DefaultRepresentationPreset) ?? '',
          );
        } catch (e) {
          console.error(e);
          ctx.log.error(`Error loading trajectory`);
        }
      })
      .runInContext(taskCtx);
  }),
);
