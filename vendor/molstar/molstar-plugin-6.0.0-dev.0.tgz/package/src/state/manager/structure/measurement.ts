/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */

import { StructureElement } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import { StateSelection, StateTransform, StateTransformer, StateObject, StateObjectCell } from '@molstar/core/state';
import { CreateGroup } from '@molstar/plugin/state/transforms/misc/group';
import {
  StructureSelectionsAngle3D,
  StructureSelectionsDihedral3D,
  StructureSelectionsDistance3D,
  StructureSelectionsLabel3D,
  StructureSelectionsOrientation3D,
  StructureSelectionsPlane3D,
} from '@molstar/plugin/state/transforms/structure/measurement';
import { MultiStructureSelectionFromBundle } from '@molstar/plugin/state/transforms/structure/selection';
import { PluginCommands } from '@molstar/plugin/commands';
import { arraySetAdd } from '@molstar/core/util/array';
import { PluginStateObject } from '../../objects.js';
import { StatefulPluginComponent } from '../../component.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import {
  MeasurementRepresentationCommonTextParams,
  LociLabelTextParams,
} from '@molstar/graphics/repr/shape/loci/common';
import type { LineParams } from '@molstar/graphics/repr/structure/representation/line';
import { Color } from '@molstar/core/util/color';

export { StructureMeasurementManager };

export const MeasurementGroupTag = 'measurement-group';
export const MeasurementOrderLabelTag = 'measurement-order-label';

export type StructureMeasurementCell = StateObjectCell<
  PluginStateObject.Shape.Representation3D,
  StateTransform<
    StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, any>
  >
>;

export const StructureMeasurementParams = {
  distanceUnitLabel: PD.Text('\u212B', { isEssential: true }),
  textColor: MeasurementRepresentationCommonTextParams.textColor,
};
const DefaultStructureMeasurementOptions = PD.getDefaultValues(StructureMeasurementParams);
export type StructureMeasurementOptions = PD.ValuesFor<typeof StructureMeasurementParams>;

export interface StructureMeasurementManagerState {
  labels: StructureMeasurementCell[];
  distances: StructureMeasurementCell[];
  angles: StructureMeasurementCell[];
  dihedrals: StructureMeasurementCell[];
  orientations: StructureMeasurementCell[];
  planes: StructureMeasurementCell[];
  options: StructureMeasurementOptions;
}

type StructureMeasurementManagerAddOptions = {
  customText?: string;
  selectionTags?: string | string[];
  reprTags?: string | string[];
  lineParams?: Partial<PD.Values<LineParams>>;
  labelParams?: Partial<PD.Values<LociLabelTextParams>>;
};

function serializeLoci(loci: StructureElement.Loci) {
  return { bundle: StructureElement.Bundle.fromLoci(loci) };
}

class StructureMeasurementManager extends StatefulPluginComponent<StructureMeasurementManagerState> {
  readonly behaviors = {
    state: this.ev.behavior(this.state),
  };

  private stateUpdated() {
    this.behaviors.state.next(this.state);
  }

  private getGroup() {
    const state = this.plugin.state.data;
    const groupRef = StateSelection.findTagInSubtree(state.tree, StateTransform.RootRef, MeasurementGroupTag);
    const builder = this.plugin.state.data.build();

    if (groupRef) return builder.to(groupRef);
    return builder.toRoot().group(CreateGroup, { label: `Measurements` }, { tags: MeasurementGroupTag });
  }

  async setOptions(options: StructureMeasurementOptions) {
    if (this.updateState({ options })) this.stateUpdated();

    const update = this.plugin.state.data.build();
    for (const cell of this.state.distances) {
      update.to(cell).update((old: any) => {
        old.unitLabel = options.distanceUnitLabel;
        old.textColor = options.textColor;
      });
    }
    for (const cell of this.state.labels) {
      update.to(cell).update((old: any) => {
        old.textColor = options.textColor;
      });
    }
    for (const cell of this.state.angles) {
      update.to(cell).update((old: any) => {
        old.textColor = options.textColor;
      });
    }
    for (const cell of this.state.dihedrals) {
      update.to(cell).update((old: any) => {
        old.textColor = options.textColor;
      });
    }

    if (update.editInfo.count === 0) return;

    await PluginCommands.State.Update(this.plugin, {
      state: this.plugin.state.data,
      tree: update,
      options: { doNotLogTiming: true },
    });
  }

  async addDistance(
    a: StructureElement.Loci,
    b: StructureElement.Loci,
    options?: StructureMeasurementManagerAddOptions & {
      visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsDistance3D>>;
    },
  ) {
    const cellA = this.plugin.helpers.substructureParent.get(a.structure);
    const cellB = this.plugin.helpers.substructureParent.get(b.structure);

    if (!cellA || !cellB) return;

    const dependsOn = [cellA.transform.ref];
    arraySetAdd(dependsOn, cellB.transform.ref);

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections: [
          { key: 'a', groupId: 'a', ref: cellA.transform.ref, ...serializeLoci(a) },
          { key: 'b', groupId: 'b', ref: cellB.transform.ref, ...serializeLoci(b) },
        ],
        isTransitive: true,
        label: 'Distance',
      },
      { dependsOn, tags: options?.selectionTags },
    );
    const representation = selection.apply(
      StructureSelectionsDistance3D,
      {
        customText: options?.customText || '',
        unitLabel: this.state.options.distanceUnitLabel,
        textColor: this.state.options.textColor,
        ...(options?.lineParams as any),
        ...options?.labelParams,
        ...options?.visualParams,
      },
      { tags: options?.reprTags },
    );

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: representation, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addAngle(
    a: StructureElement.Loci,
    b: StructureElement.Loci,
    c: StructureElement.Loci,
    options?: StructureMeasurementManagerAddOptions & {
      visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsAngle3D>>;
    },
  ) {
    const cellA = this.plugin.helpers.substructureParent.get(a.structure);
    const cellB = this.plugin.helpers.substructureParent.get(b.structure);
    const cellC = this.plugin.helpers.substructureParent.get(c.structure);

    if (!cellA || !cellB || !cellC) return;

    const dependsOn = [cellA.transform.ref];
    arraySetAdd(dependsOn, cellB.transform.ref);
    arraySetAdd(dependsOn, cellC.transform.ref);

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections: [
          { key: 'a', ref: cellA.transform.ref, ...serializeLoci(a) },
          { key: 'b', ref: cellB.transform.ref, ...serializeLoci(b) },
          { key: 'c', ref: cellC.transform.ref, ...serializeLoci(c) },
        ],
        isTransitive: true,
        label: 'Angle',
      },
      { dependsOn, tags: options?.selectionTags },
    );
    const representation = selection.apply(
      StructureSelectionsAngle3D,
      {
        customText: options?.customText || '',
        textColor: this.state.options.textColor,
        ...(options?.lineParams as any),
        ...options?.labelParams,
        ...options?.visualParams,
      },
      { tags: options?.reprTags },
    );

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: representation, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addDihedral(
    a: StructureElement.Loci,
    b: StructureElement.Loci,
    c: StructureElement.Loci,
    d: StructureElement.Loci,
    options?: StructureMeasurementManagerAddOptions & {
      visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsDihedral3D>>;
    },
  ) {
    const cellA = this.plugin.helpers.substructureParent.get(a.structure);
    const cellB = this.plugin.helpers.substructureParent.get(b.structure);
    const cellC = this.plugin.helpers.substructureParent.get(c.structure);
    const cellD = this.plugin.helpers.substructureParent.get(d.structure);

    if (!cellA || !cellB || !cellC || !cellD) return;

    const dependsOn = [cellA.transform.ref];
    arraySetAdd(dependsOn, cellB.transform.ref);
    arraySetAdd(dependsOn, cellC.transform.ref);
    arraySetAdd(dependsOn, cellD.transform.ref);

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections: [
          { key: 'a', ref: cellA.transform.ref, ...serializeLoci(a) },
          { key: 'b', ref: cellB.transform.ref, ...serializeLoci(b) },
          { key: 'c', ref: cellC.transform.ref, ...serializeLoci(c) },
          { key: 'd', ref: cellD.transform.ref, ...serializeLoci(d) },
        ],
        isTransitive: true,
        label: 'Dihedral',
      },
      { dependsOn, tags: options?.selectionTags },
    );
    const representation = selection.apply(
      StructureSelectionsDihedral3D,
      {
        customText: options?.customText || '',
        textColor: this.state.options.textColor,
        ...(options?.lineParams as any),
        ...options?.labelParams,
        ...options?.visualParams,
      },
      { tags: options?.reprTags },
    );

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: representation, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addLabel(
    a: StructureElement.Loci,
    options?: Omit<StructureMeasurementManagerAddOptions, 'customText' | 'lineParams'> & {
      visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsLabel3D>>;
    },
  ) {
    const cellA = this.plugin.helpers.substructureParent.get(a.structure);

    if (!cellA) return;

    const dependsOn = [cellA.transform.ref];

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections: [{ key: 'a', ref: cellA.transform.ref, ...serializeLoci(a) }],
        isTransitive: true,
        label: 'Label',
      },
      { dependsOn, tags: options?.selectionTags },
    );
    const representation = selection.apply(
      StructureSelectionsLabel3D,
      {
        textColor: this.state.options.textColor,
        ...options?.labelParams,
        ...options?.visualParams,
      },
      { tags: options?.reprTags },
    );
    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: representation, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addOrientation(locis: StructureElement.Loci[]) {
    const selections: { key: string; ref: string; groupId?: string; bundle: StructureElement.Bundle }[] = [];
    const dependsOn: string[] = [];

    for (let i = 0, il = locis.length; i < il; ++i) {
      const l = locis[i];
      const cell = this.plugin.helpers.substructureParent.get(l.structure);
      if (!cell) continue;

      arraySetAdd(dependsOn, cell.transform.ref);
      selections.push({ key: `l${i}`, ref: cell.transform.ref, ...serializeLoci(l) });
    }

    if (selections.length === 0) return;

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections,
        isTransitive: true,
        label: 'Orientation',
      },
      { dependsOn },
    );
    const representation = selection.apply(StructureSelectionsOrientation3D);

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: representation, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addPlane(locis: StructureElement.Loci[]) {
    const selections: { key: string; ref: string; groupId?: string; bundle: StructureElement.Bundle }[] = [];
    const dependsOn: string[] = [];

    for (let i = 0, il = locis.length; i < il; ++i) {
      const l = locis[i];
      const cell = this.plugin.helpers.substructureParent.get(l.structure);
      if (!cell) continue;

      arraySetAdd(dependsOn, cell.transform.ref);
      selections.push({ key: `l${i}`, ref: cell.transform.ref, ...serializeLoci(l) });
    }

    if (selections.length === 0) return;

    const update = this.getGroup();
    const selection = update.apply(
      MultiStructureSelectionFromBundle,
      {
        selections,
        isTransitive: true,
        label: 'Plane',
      },
      { dependsOn },
    );
    const representation = selection.apply(StructureSelectionsPlane3D);

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: update, options: { doNotLogTiming: true } });
    return { selection: selection.selector, representation: representation.selector };
  }

  async addOrderLabels(locis: StructureElement.Loci[]) {
    const update = this.getGroup();

    const current = this.plugin.state.data.select(
      StateSelection.Generators.ofType(PluginStateObject.Molecule.Structure.Selections).withTag(
        MeasurementOrderLabelTag,
      ),
    );
    for (const obj of current) update.delete(obj);

    let order = 1;
    for (const loci of locis) {
      const cell = this.plugin.helpers.substructureParent.get(loci.structure);
      if (!cell) continue;

      const dependsOn = [cell.transform.ref];

      update
        .apply(
          MultiStructureSelectionFromBundle,
          {
            selections: [{ key: 'a', ref: cell.transform.ref, ...serializeLoci(loci) }],
            isTransitive: true,
            label: 'Order',
          },
          { dependsOn, tags: MeasurementOrderLabelTag },
        )
        .apply(
          StructureSelectionsLabel3D,
          {
            textColor: Color.fromRgb(255, 255, 255),
            borderColor: Color.fromRgb(0, 0, 0),
            textSize: 0.33,
            borderWidth: 0.3,
            offsetZ: 0.75,
            customText: `${order++}`,
          },
          { tags: MeasurementOrderLabelTag },
        );
    }

    const state = this.plugin.state.data;
    await PluginCommands.State.Update(this.plugin, { state, tree: update, options: { doNotLogTiming: true } });
    return { representation: update.selector };
  }

  private _empty: any[] = [];
  private getTransforms<
    T extends StateTransformer<A, B, any>,
    A extends PluginStateObject.Molecule.Structure.Selections,
    B extends StateObject,
  >(transformer: T) {
    const state = this.plugin.state.data;
    const groupRef = StateSelection.findTagInSubtree(state.tree, StateTransform.RootRef, MeasurementGroupTag);
    const ret = groupRef ? state.select(StateSelection.Generators.ofTransformer(transformer, groupRef)) : this._empty;
    if (ret.length === 0) return this._empty;
    return ret;
  }

  private sync() {
    const labels = [];
    for (const cell of this.getTransforms(StructureSelectionsLabel3D) as StructureMeasurementCell[]) {
      const tags = (cell.obj as any)['tags'] as string[];
      if (!tags || !tags.includes(MeasurementOrderLabelTag)) labels.push(cell);
    }

    const updated = this.updateState({
      labels,
      distances: this.getTransforms(StructureSelectionsDistance3D),
      angles: this.getTransforms(StructureSelectionsAngle3D),
      dihedrals: this.getTransforms(StructureSelectionsDihedral3D),
      orientations: this.getTransforms(StructureSelectionsOrientation3D),
      planes: this.getTransforms(StructureSelectionsPlane3D),
    });
    if (updated) this.stateUpdated();
  }

  constructor(private plugin: PluginContext) {
    super({
      labels: [],
      distances: [],
      angles: [],
      dihedrals: [],
      orientations: [],
      planes: [],
      options: DefaultStructureMeasurementOptions,
    });

    plugin.state.data.events.changed.subscribe((e) => {
      if (e.inTransaction || plugin.behaviors.state.isAnimating.value) return;
      this.sync();
    });

    plugin.behaviors.state.isAnimating.subscribe((isAnimating) => {
      if (!isAnimating && !plugin.behaviors.state.isUpdating.value) this.sync();
    });
  }
}
