/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { List } from 'immutable';
import { UUID } from '@molstar/core/util';
import { PluginState } from '@molstar/plugin/state';
import { precompileSnapshots } from '@molstar/plugin/state/precompile';
import { StatefulPluginComponent } from '../component.js';
import type { PluginContext } from '@molstar/plugin/context';
import { utf8ByteCount, utf8Write } from '@molstar/core/util/utf8';
import type { Asset } from '@molstar/core/util/assets';
import { Zip } from '@molstar/core/util/zip/zip';
import { readFromFile } from '@molstar/core/util/data-source';
import { objectForEach } from '@molstar/core/util/object';
import { PLUGIN_VERSION } from '@molstar/plugin/version';
import { canvasToBlob } from '@molstar/graphics/canvas3d/util';
import { Task } from '@molstar/core/task';
import { StringLike } from '@molstar/core/util/string-like';
import { SingleTaskQueue } from '@molstar/core/util/single-task-queue';

export { PluginStateSnapshotManager };

interface StateManagerState {
  current?: UUID;
  currentAnimationTimeMs?: number;
  entries: List<PluginStateSnapshotManager.Entry>;
  isPlaying: boolean;
  nextSnapshotDelayInMs: number;
}

class PluginStateSnapshotManager extends StatefulPluginComponent<StateManagerState> {
  static DefaultNextSnapshotDelayInMs = 1500;

  private entryMap = new Map<string, PluginStateSnapshotManager.Entry>();
  private defaultSnapshotId: UUID | undefined = undefined;

  protected updateState(state: Partial<StateManagerState>) {
    if ('current' in state && !('currentAnimationTimeMs' in state)) {
      return super.updateState({ ...state, currentAnimationTimeMs: 0 });
    } else {
      return super.updateState(state);
    }
  }

  readonly events = {
    changed: this.ev(),
    opened: this.ev(),
  };

  get current() {
    const id = this.state.current;
    return this.state.entries.find((e) => e.snapshot.id === id);
  }

  getIndex(e: PluginStateSnapshotManager.Entry) {
    return this.state.entries.indexOf(e);
  }

  getEntry(id: string | undefined) {
    if (!id) return;
    return this.entryMap.get(id);
  }

  remove(id: string) {
    const e = this.entryMap.get(id);
    if (!e) return;

    if (e?.image) this.plugin.managers.asset.delete(e.image);
    this.entryMap.delete(id);
    this.updateState({
      current: this.state.current === id ? void 0 : this.state.current,
      entries: this.state.entries.delete(this.getIndex(e)),
    });
    this.events.changed.next(void 0);
  }

  add(e: PluginStateSnapshotManager.Entry) {
    this.entryMap.set(e.snapshot.id, e);
    this.updateState({ current: e.snapshot.id, entries: this.state.entries.push(e) });
    this.events.changed.next(void 0);
  }

  replace(id: string, snapshot: PluginState.Snapshot, params?: PluginStateSnapshotManager.EntryParams) {
    const old = this.getEntry(id);
    if (!old) return;

    this.defaultSnapshotId = undefined;

    if (old?.image) this.plugin.managers.asset.delete(old.image);
    const idx = this.getIndex(old);
    // The id changes here!
    const e = PluginStateSnapshotManager.Entry(snapshot, {
      key: params?.key ?? old.key,
      name: params?.name ?? old.name,
      description: params?.description ?? old.description,
      descriptionFormat: params?.descriptionFormat ?? old.descriptionFormat,
      image: params?.image,
    });
    this.entryMap.set(snapshot.id, e);
    this.updateState({ current: e.snapshot.id, entries: this.state.entries.set(idx, e) });
    this.events.changed.next(void 0);
  }

  move(id: string, dir: -1 | 1) {
    const len = this.state.entries.size;
    if (len < 2) return;

    const e = this.getEntry(id);
    if (!e) return;
    const from = this.getIndex(e);
    let to = (from + dir) % len;
    if (to < 0) to += len;
    const f = this.state.entries.get(to)!;

    const entries = this.state.entries.asMutable();
    entries.set(to, e);
    entries.set(from, f);

    this.updateState({ current: e.snapshot.id, entries: entries.asImmutable() });
    this.events.changed.next(void 0);
  }

  update(
    e: PluginStateSnapshotManager.Entry,
    options: {
      key?: string;
      name?: string;
      description?: string;
      descriptionFormat?: PluginStateSnapshotManager.DescriptionFormat;
    },
  ) {
    const idx = this.getIndex(e);
    if (idx < 0) return;
    const entries = this.state.entries.set(idx, {
      ...e,
      key: options.key?.trim() || undefined,
      name: options.name?.trim() || undefined,
      description: options.description?.trim() || undefined,
      descriptionFormat: options.descriptionFormat,
    });
    this.updateState({ entries });
    this.entryMap.set(e.snapshot.id, this.state.entries.get(idx)!);
    this.events.changed.next(void 0);
  }

  clear() {
    if (this.state.entries.size === 0) return;

    this.entryMap.forEach((e) => {
      if (e?.image) this.plugin.managers.asset.delete(e.image);
    });
    this.entryMap.clear();
    this.updateState({ current: void 0, entries: List<PluginStateSnapshotManager.Entry>() });
    this.events.changed.next(void 0);
  }

  applyKey(key: string) {
    const e = this.state.entries.find((e) => e.key === key);
    if (!e) return;

    this.updateState({ current: e.snapshot.id as UUID });
    this.events.changed.next(void 0);
    this.plugin.state.setSnapshot(e.snapshot);
  }

  setCurrent(id: string) {
    const e = this.getEntry(id);
    if (e) {
      this.updateState({ current: id as UUID });
      this.events.changed.next(void 0);
    }
    return e && e.snapshot;
  }

  private animationFrameQueue = new SingleTaskQueue();
  setSnapshotAnimationFrame(currentAnimationTimeMs: number, load = false) {
    const entry = this.getEntry(this.state.current);
    if (!entry) return;

    const frameIndex = PluginState.getStateTransitionFrameIndex(entry.snapshot, currentAnimationTimeMs) ?? 0;

    if (this.updateState({ currentAnimationTimeMs })) {
      this.events.changed.next(void 0);
    }

    if (load) {
      this.animationFrameQueue.run(() => {
        return this.plugin.state.setAnimationSnapshot(entry.snapshot, frameIndex ?? 0);
      });
    }

    return frameIndex;
  }

  getNextId(id: string | undefined, dir: -1 | 1) {
    const len = this.state.entries.size;
    if (!id) {
      if (len === 0) return void 0;
      const idx = dir === -1 ? len - 1 : 0;
      return this.state.entries.get(idx)!.snapshot.id;
    }

    const e = this.getEntry(id);
    if (!e) return;
    let idx = this.getIndex(e);
    if (idx < 0) return;

    idx = (idx + dir) % len;
    if (idx < 0) idx += len;

    return this.state.entries.get(idx)!.snapshot.id;
  }

  applyNext(dir: -1 | 1) {
    const next = this.getNextId(this.state.current, dir);
    if (next) {
      const snapshot = this.setCurrent(next);
      if (snapshot) return this.plugin.state.setSnapshot(snapshot);
    }
  }

  async setStateSnapshot(
    snapshot: PluginStateSnapshotManager.StateSnapshot,
  ): Promise<PluginState.Snapshot | undefined> {
    // Validate every entry before clearing so a failing state leaves the manager unchanged
    for (const e of snapshot.entries) PluginState.validateSnapshotTransformers(e.snapshot);

    this.clear();
    const entries = List<PluginStateSnapshotManager.Entry>().asMutable();
    for (const e of snapshot.entries) {
      this.entryMap.set(e.snapshot.id, e);
      entries.push(e);
    }
    const current = snapshot.current
      ? snapshot.current
      : snapshot.entries.length > 0
        ? snapshot.entries[0].snapshot.id
        : void 0;
    this.updateState({
      current,
      entries: entries.asImmutable(),
      isPlaying: false,
      nextSnapshotDelayInMs: snapshot.playback
        ? snapshot.playback.nextSnapshotDelayInMs
        : PluginStateSnapshotManager.DefaultNextSnapshotDelayInMs,
    });
    this.events.changed.next(void 0);
    // what the other snapshots draw, prepared in the background so that playing them compiles nothing
    precompileSnapshots(
      this.plugin,
      snapshot.entries.map((e) => e.snapshot),
    );
    if (!current) return;
    const entry = this.getEntry(current);
    const next = entry && entry.snapshot;
    if (!next) return;
    await this.plugin.state.setSnapshot(next);
    if (snapshot.playback?.isPlaying) this.play({ delayFirst: true });
    return next;
  }

  private async syncCurrent(options?: {
    name?: string;
    description?: string;
    descriptionFormat?: PluginStateSnapshotManager.DescriptionFormat;
    params?: PluginState.SnapshotParams;
  }) {
    const isEmpty = this.state.entries.size === 0;
    const canReplace =
      this.state.entries.size === 1 &&
      this.state.current &&
      (!this.defaultSnapshotId || this.state.current === this.defaultSnapshotId);
    if (!isEmpty && !canReplace) return;

    const snapshot = this.plugin.state.getSnapshot(options?.params);
    const image =
      (options?.params?.image ?? this.plugin.state.snapshotParams.value.image)
        ? await PluginStateSnapshotManager.getCanvasImageAsset(this.plugin, `${snapshot.id}-image.png`)
        : undefined;

    if (isEmpty) {
      this.add(
        PluginStateSnapshotManager.Entry(snapshot, {
          name: options?.name,
          description: options?.description,
          descriptionFormat: options?.descriptionFormat,
          image,
        }),
      );
    } else if (canReplace) {
      // Replace the current state only if there is a single snapshot that has been created automatically
      const current = this.getEntry(this.state.current);
      if (current?.image) this.plugin.managers.asset.delete(current.image);
      this.replace(this.state.current!, snapshot, { image });
    }

    this.defaultSnapshotId = snapshot.id;
  }

  /** What `syncCurrent` would make the list, on a copy (the manager's entries untouched; `keepList`). */
  private async syncedCopy(options?: {
    name?: string;
    description?: string;
    descriptionFormat?: PluginStateSnapshotManager.DescriptionFormat;
    params?: PluginState.SnapshotParams;
  }): Promise<{ entries: PluginStateSnapshotManager.Entry[]; current: UUID | undefined }> {
    const entries = this.state.entries.valueSeq().toArray();
    const isEmpty = entries.length === 0;
    const canReplace =
      entries.length === 1 &&
      this.state.current &&
      this.defaultSnapshotId !== undefined &&
      this.state.current === this.defaultSnapshotId;
    if (!isEmpty && !canReplace) return { entries, current: this.state.current };
    const snapshot = this.plugin.state.getSnapshot(options?.params);
    const entry = PluginStateSnapshotManager.Entry(snapshot, {
      name: options?.name,
      description: options?.description,
      descriptionFormat: options?.descriptionFormat,
    });
    return { entries: [entry], current: entry.snapshot.id };
  }

  async getStateSnapshot(options?: {
    name?: string;
    description?: string;
    playOnLoad?: boolean;
    params?: PluginState.SnapshotParams;
    /**
     * Leaves the list as it is: the current scene is added to (or replaces the automatic entry of) the returned
     * snapshot only, not the manager's entries (a host whose list is the person's own).
     */
    keepList?: boolean;
  }): Promise<PluginStateSnapshotManager.StateSnapshot> {
    let entries: PluginStateSnapshotManager.Entry[];
    let current = this.state.current;
    if (options?.keepList) {
      ({ entries, current } = await this.syncedCopy(options));
    } else {
      await this.syncCurrent(options);
      entries = this.state.entries.valueSeq().toArray();
      current = this.state.current;
    }
    for (let i = 0; i < entries.length; i++) {
      if (!entries[i]._transientData) continue;

      // Clone the entry to avoid modifying the original
      entries[i] = { ...entries[i] };
      // Remove any transient data before serialization
      delete entries[i]._transientData;
    }

    return {
      timestamp: +new Date(),
      version: PLUGIN_VERSION,
      name: options && options.name,
      description: options && options.description,
      current,
      playback: {
        isPlaying: !!(options && options.playOnLoad),
        nextSnapshotDelayInMs: this.state.nextSnapshotDelayInMs,
      },
      entries,
    };
  }

  async serialize(options?: {
    type: 'json' | 'molj' | 'zip' | 'molx';
    params?: PluginState.SnapshotParams;
    /** See `getStateSnapshot`. */
    keepList?: boolean;
    /**
     * What a host keeps beside the state: files in a zip (`.molx`, beside `state.json`), top-level fields in a JSON
     * state (`.molj`). `open` hands them back.
     */
    extra?: PluginStateSnapshotManager.Extra;
  }) {
    const snapshot = await this.getStateSnapshot({ params: options?.params, keepList: options?.keepList });
    const isJson = !options?.type || options.type === 'json' || options.type === 'molj';
    const json = JSON.stringify(
      isJson && options?.extra?.fields ? { ...options.extra.fields, ...snapshot } : snapshot,
      null,
      2,
    );

    if (!options?.type || options.type === 'json' || options.type === 'molj') {
      return new Blob([json], { type: 'application/json;charset=utf-8' });
    } else {
      const state = new Uint8Array(utf8ByteCount(json));
      utf8Write(state, 0, json);

      const zipDataObj: { [k: string]: Uint8Array<ArrayBuffer> } = {
        'state.json': state,
      };

      const assets: [UUID, Asset][] = [];

      // TODO: there can be duplicate entries: check for this?
      for (const { asset, file } of this.plugin.managers.asset.assets) {
        assets.push([asset.id, asset]);
        zipDataObj[`assets/${asset.id}`] = new Uint8Array(await file.arrayBuffer());
      }

      if (assets.length > 0) {
        const index = JSON.stringify(assets, null, 2);
        const data = new Uint8Array(utf8ByteCount(index));
        utf8Write(data, 0, index);
        zipDataObj['assets.json'] = data;
      }

      for (const [name, data] of Object.entries(options?.extra?.files ?? {})) {
        if (name === 'state.json' || name === 'assets.json' || name.startsWith('assets/')) continue;
        zipDataObj[name] = data as Uint8Array<ArrayBuffer>;
      }

      const zipFile = await this.plugin.runTask(Zip(zipDataObj));
      return new Blob([zipFile], { type: 'application/zip' });
    }
  }

  /** Opens a state or a session file; what a host kept beside the state (`serialize`'s `extra`) comes back. */
  async open(file: File): Promise<PluginStateSnapshotManager.Extra | undefined> {
    let extra: PluginStateSnapshotManager.Extra | undefined;
    try {
      const fn = file.name.toLowerCase();
      if (fn.endsWith('json') || fn.endsWith('molj')) {
        const data = await this.plugin.runTask(readFromFile(file, 'string'));
        const snapshot = JSON.parse(StringLike.toString(data));
        if (snapshot && typeof snapshot === 'object') extra = { fields: snapshot };

        if (PluginStateSnapshotManager.isStateSnapshot(snapshot)) {
          await this.setStateSnapshot(snapshot);
        } else if (PluginStateSnapshotManager.isStateSnapshot(snapshot.data)) {
          await this.setStateSnapshot(snapshot.data);
        } else {
          await this.plugin.state.setSnapshot(snapshot);
        }
      } else {
        const data = await this.plugin.runTask(readFromFile(file, 'zip'));
        const assetData = Object.create(null);

        const files: { [name: string]: Uint8Array } = {};
        objectForEach(data, (v, k) => {
          if (k === 'state.json' || k === 'assets.json') return;
          if (!k.startsWith('assets/')) files[k] = v;
          const name = k.substring(k.indexOf('/') + 1);
          assetData[name] = v;
        });
        if (Object.keys(files).length) extra = { files };
        const stateFile = new File([data['state.json']], 'state.json');
        const snapshot = await this.plugin.runTask(readFromFile(stateFile, 'json'));

        if (data['assets.json']) {
          const file = new File([data['assets.json']], 'assets.json');
          const json = await this.plugin.runTask(readFromFile(file, 'json'));

          for (const [id, asset] of json) {
            this.plugin.managers.asset.set(asset, new File([assetData[id]], asset.name));
          }
        }

        await this.setStateSnapshot(snapshot);
      }
      this.events.opened.next(void 0);
      return extra;
    } catch (e) {
      console.error(e);
      this.plugin.log.error('Error reading state');
      return undefined;
    }
  }

  private timeoutHandle: any = void 0;
  private next = async () => {
    this.timeoutHandle = void 0;
    const next = this.getNextId(this.state.current, 1);
    if (!next || next === this.state.current) {
      this.stop();
      return;
    }
    const snapshot = this.setCurrent(next)!;
    await this.plugin.state.setSnapshot(snapshot);
    const delay =
      typeof snapshot.durationInMs !== 'undefined' ? snapshot.durationInMs : this.state.nextSnapshotDelayInMs;
    if (this.state.isPlaying) this.timeoutHandle = setTimeout(this.next, delay);
  };

  private async startPlayback() {
    const { current } = this;
    if (!current) return;

    // If there is a transition associated with the current snapshot, replay it
    if (current.snapshot.transition) {
      const snapshot = this.setCurrent(this.state.current!)!;
      await this.plugin.state.setSnapshot(snapshot);
      const delay =
        typeof snapshot.durationInMs !== 'undefined' ? snapshot.durationInMs : this.state.nextSnapshotDelayInMs;
      if (this.state.isPlaying) this.timeoutHandle = setTimeout(this.next, delay);
    } else {
      return this.next();
    }
  }

  async play(options?: { delayFirst?: boolean; restart?: boolean }) {
    if (this.state.isPlaying && !options?.delayFirst) {
      if (options?.restart) {
        await this.stop();
      } else {
        return;
      }
    }

    this.updateState({ isPlaying: true });

    if (options?.delayFirst) {
      const e = this.getEntry(this.state.current);
      if (!e) {
        this.next();
        return;
      }
      this.events.changed.next(void 0);
      const snapshot = e.snapshot;
      const delay =
        typeof snapshot.durationInMs !== 'undefined' ? snapshot.durationInMs : this.state.nextSnapshotDelayInMs;
      this.timeoutHandle = setTimeout(this.next, delay);
    } else {
      this.startPlayback();
    }
  }

  async stop() {
    await this.plugin.managers.animation.stop();
    this.updateState({ isPlaying: false });
    if (typeof this.timeoutHandle !== 'undefined') clearTimeout(this.timeoutHandle);
    this.timeoutHandle = void 0;
    this.events.changed.next(void 0);
  }

  async togglePlay() {
    if (this.state.isPlaying) {
      await this.stop();
      this.plugin.managers.markdownExtensions.audio.pause();
    } else {
      await this.play();
    }
  }

  dispose() {
    super.dispose();
    this.entryMap.clear();
  }

  constructor(private plugin: PluginContext) {
    super({
      current: void 0,
      entries: List(),
      isPlaying: false,
      nextSnapshotDelayInMs: PluginStateSnapshotManager.DefaultNextSnapshotDelayInMs,
    });
    // TODO make nextSnapshotDelayInMs editable
  }
}

namespace PluginStateSnapshotManager {
  export type DescriptionFormat = 'markdown' | 'plaintext';

  /** What a host keeps in a state or session file beside the state (`serialize`'s `extra`, `open`'s result). */
  export interface Extra {
    /** Files in a session's zip, beside `state.json` (not `assets/`). */
    files?: { [name: string]: Uint8Array };
    /** A JSON state's top-level fields (all of them, on open). */
    fields?: { [name: string]: unknown };
  }

  export interface EntryParams {
    key?: string;
    name?: string;
    /** Information about the snapshot, to be shown in the UI when the snapshot is loaded. */
    description?: string;
    /** Toggle between markdown and plaintext interpretation of `description`. Default is markdown. */
    descriptionFormat?: DescriptionFormat;
    image?: Asset;
  }

  export interface Entry extends EntryParams {
    timestamp: number;
    snapshot: PluginState.Snapshot;
    /** Extra data that is not serialized */
    _transientData?: any;
  }

  export function Entry(snapshot: PluginState.Snapshot, params: EntryParams): Entry {
    return { timestamp: +new Date(), snapshot, ...params };
  }

  export function isStateSnapshot(x?: any): x is StateSnapshot {
    const s = x as StateSnapshot;
    return !!s && !!s.timestamp && !!s.entries;
  }

  export interface StateSnapshot {
    timestamp: number;
    version: string;
    name?: string;
    description?: string;
    current: UUID | undefined;
    playback: {
      isPlaying: boolean;
      nextSnapshotDelayInMs: number;
    };
    entries: Entry[];
  }

  export async function getCanvasImageAsset(ctx: PluginContext, name: string): Promise<Asset | undefined> {
    const task = Task.create('Render Screenshot', async (runtime) => {
      if (!ctx.helpers.viewportScreenshot) return;
      const p = await ctx.helpers.viewportScreenshot.getPreview(runtime, 512);
      if (!p) return;

      const blob = await canvasToBlob(p.canvas, 'png');
      const file = new File([blob], name);
      const image: Asset = { kind: 'file', id: UUID.create22(), name };
      ctx.managers.asset.set(image, file);
      return image;
    });
    return ctx.runTask(task);
  }
}
