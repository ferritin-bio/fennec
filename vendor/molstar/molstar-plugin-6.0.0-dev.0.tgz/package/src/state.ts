/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */

import { merge } from 'rxjs';
import type { Camera } from '@molstar/graphics/canvas3d/camera';
import {
  type TransitionTrajectory,
  TransitionTrajectoryParamDefinition,
} from '@molstar/graphics/canvas3d/camera/transition-functions';
import { Canvas3DContext, Canvas3DParams, type Canvas3DProps } from '@molstar/graphics/canvas3d/canvas3d';
import { type EasingKind, EasingParamDefinition } from '@molstar/core/math/easing';
import type { Vec3 } from '@molstar/core/math/linear-algebra';
import { AnimateStateSnapshotTransition } from '@molstar/plugin/state/animation/built-in/state-snapshots';
import { PluginComponent } from '@molstar/plugin/state/component';
import {
  type ProviderKind,
  type RepresentationScope,
  warnIfUnregistered,
} from '@molstar/plugin/state/helpers/representation-registry';
import type { PluginAnimationManager } from '@molstar/plugin/state/manager/animation';
import type { InteractivityManager } from '@molstar/plugin/state/manager/interactivity';
import type { StructureComponentManager } from '@molstar/plugin/state/manager/structure/component';
import type { StructureFocusSnapshot } from '@molstar/plugin/state/manager/structure/focus';
import type { StructureSelectionSnapshot } from '@molstar/plugin/state/manager/structure/selection';
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { State, StateTransform, StateTransformer } from '@molstar/core/state';
import { Scheduler } from '@molstar/core/task';
import { UUID } from '@molstar/core/util';
import { memoizeLatest } from '@molstar/core/util/memoize';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { produce } from '@molstar/core/util/produce';
import { PluginBehavior } from '@molstar/plugin/behavior/behavior';
import { PluginCommands } from '@molstar/plugin/commands';
import { PluginConfig } from '@molstar/plugin/config';
import type { PluginContext } from '@molstar/plugin/context';

export { PluginState };

/**
 * Representation transformer ids by scope (ids only, so this module does not import the transformers):
 * `StructureRepresentation3D`, `VolumeRepresentation3D`, and `ParticlesRepresentation3D`.
 */
const RepresentationTransformerScopes: { [id: string]: RepresentationScope | undefined } = {
  'ms-plugin.structure-representation-3d': 'structure',
  'ms-plugin.volume-representation-3d': 'volume',
  'ms-plugin.particles-representation-3d': 'particles',
};

/** How long a scrubbed transition (`setAnimationSnapshot`) rests before it emits `canvas3d.settingsUpdated`. */
const SettingsUpdatedDebounceMs = 100;

class PluginState extends PluginComponent {
  private get animation() {
    return this.plugin.managers.animation;
  }

  readonly data = State.create(new SO.Root({}), {
    runTask: this.plugin.runTask,
    globalContext: this.plugin,
    historyCapacity: this.plugin.config.get(PluginConfig.State.HistoryCapacity),
  });
  readonly behaviors = State.create(new PluginBehavior.Root({}), {
    runTask: this.plugin.runTask,
    globalContext: this.plugin,
    rootState: { isLocked: true },
  });

  readonly events = {
    cell: {
      stateUpdated: merge(this.data.events.cell.stateUpdated, this.behaviors.events.cell.stateUpdated),
      created: merge(this.data.events.cell.created, this.behaviors.events.cell.created),
      removed: merge(this.data.events.cell.removed, this.behaviors.events.cell.removed),
    },
    object: {
      created: merge(this.data.events.object.created, this.behaviors.events.object.created),
      removed: merge(this.data.events.object.removed, this.behaviors.events.object.removed),
      updated: merge(this.data.events.object.updated, this.behaviors.events.object.updated),
    },
  } as const;

  readonly snapshotParams = this.ev.behavior<PluginState.SnapshotParams>(PluginState.DefaultSnapshotParams);

  setSnapshotParams = (params?: PluginState.SnapshotParams) => {
    this.snapshotParams.next({ ...PluginState.DefaultSnapshotParams, ...params });
  };

  private readonly customState = new Map<string, PluginState.CustomStateEntry>();

  /**
   * Registers state owned by a component outside the plugin's own state (for example the sequence viewer of Prism,
   * `'prism-viewer.sequence'`). `getSnapshot` writes `get()` of every registered key into `snapshot.custom`;
   * `setSnapshot` calls `set` after the data tree is applied, with `undefined` when the snapshot has no value for the
   * key (reset to defaults). Transition frames do not apply it. Returns the unregister function; registering a key
   * twice throws.
   */
  registerCustomState(key: string, entry: PluginState.CustomStateEntry): () => void {
    if (this.customState.has(key)) throw new Error(`Custom state '${key}' is already registered`);
    this.customState.set(key, entry);
    return () => {
      if (this.customState.get(key) === entry) this.customState.delete(key);
    };
  }

  getSnapshot(params?: PluginState.SnapshotParams): PluginState.Snapshot {
    const p = { ...this.snapshotParams.value, ...params };
    // A camera reset waits for the next frame (after a load, `camera.reset`): committed now, so the snapshot keeps the
    // framed view rather than the camera before it.
    if (p.camera) this.plugin.canvas3d?.commit(true);
    let custom: { [key: string]: unknown } | undefined;
    if (this.customState.size > 0) {
      custom = {};
      this.customState.forEach((entry, key) => {
        custom![key] = entry.get();
      });
    }
    return {
      id: UUID.create22(),
      data: p.data ? this.data.getSnapshot() : void 0,
      behaviour: p.behavior ? this.behaviors.getSnapshot() : void 0,
      animation: p.animation ? this.animation.getSnapshot() : void 0,
      startAnimation: p.startAnimation ? !!p.startAnimation : void 0,
      camera: p.camera
        ? {
            // Where an animating camera is going (a focus that just started), not a frame of the way there.
            current: this.plugin.canvas3d!.camera.getSettledSnapshot(),
            transitionStyle: p.cameraTransition!.name,
            transitionDurationInMs:
              p?.cameraTransition?.name === 'animate' ? p.cameraTransition.params.durationInMs : void 0,
            transitionEasing: p?.cameraTransition?.name === 'animate' ? p.cameraTransition.params.easing : void 0,
            transitionTrajectory:
              p?.cameraTransition?.name === 'animate' ? p.cameraTransition.params.trajectory : void 0,
          }
        : void 0,
      canvas3dContext: p.canvas3dContext ? { props: this.plugin.canvas3dContext?.props } : void 0,
      canvas3d: p.canvas3d ? { props: this.plugin.canvas3d?.props } : void 0,
      interactivity: p.interactivity ? { props: this.plugin.managers.interactivity.props } : void 0,
      structureFocus: this.plugin.managers.structure.focus.getSnapshot(),
      structureSelection: p.structureSelection ? this.plugin.managers.structure.selection.getSnapshot() : void 0,
      structureComponentManager: p.componentManager
        ? {
            options: this.plugin.managers.structure.component.state.options,
          }
        : void 0,
      durationInMs: p?.durationInMs,
      custom,
    };
  }

  /**
   * Throws one error listing every transformer id used by the snapshot (behavior tree, data tree, and
   * transition frame data trees) that is not registered. Reads ids only; resolves and imports nothing.
   * Call before applying a snapshot so a failing snapshot leaves the plugin unchanged.
   */
  static validateSnapshotTransformers(snapshot: PluginState.Snapshot) {
    const missing = new Set<string>();
    const visit = (tree: State.Snapshot | undefined) => {
      for (const t of tree?.tree?.transforms ?? []) {
        if (!StateTransformer.has(t.transformer)) missing.add(t.transformer);
      }
    };
    visit(snapshot.behaviour);
    visit(snapshot.data);
    for (const frame of snapshot.transition?.frames ?? []) visit(frame.data);
    if (missing.size === 0) return;
    throw new Error(
      `Snapshot uses transformers that are not available in this plugin: ${Array.from(missing).join(', ')}. Import the modules that define them.`,
    );
  }

  /**
   * Warns for each representation type, color theme, and size theme name used by the snapshot's data tree and
   * transition frames that is not registered in the matching scope; the registry default replaces it when the data
   * tree is normalized. Reads names only and never throws for a missing name.
   * Call after the behavior tree is applied, since behaviors may register providers.
   */
  reportUnregisteredNames(snapshot: PluginState.Snapshot) {
    const reported = new Set<string>();
    const check = (
      scopeName: RepresentationScope,
      kind: ProviderKind,
      registry: Parameters<typeof warnIfUnregistered>[3],
      name: unknown,
    ) => {
      if (typeof name !== 'string') return;
      const key = `${scopeName}|${kind}|${name}`;
      if (reported.has(key)) return;
      reported.add(key);
      warnIfUnregistered(this.plugin, scopeName, kind, registry, name);
    };
    const visit = (tree: State.Snapshot | undefined) => {
      for (const t of tree?.tree?.transforms ?? []) {
        const scopeName = RepresentationTransformerScopes[t.transformer];
        if (!scopeName || !t.params) continue;
        const { registry, themes } = this.plugin.representation[scopeName];
        check(scopeName, 'representation', registry, t.params.type?.name);
        check(scopeName, 'color theme', themes.colorThemeRegistry, t.params.colorTheme?.name);
        check(scopeName, 'size theme', themes.sizeThemeRegistry, t.params.sizeTheme?.name);
      }
    };
    visit(snapshot.data);
    for (const frame of snapshot.transition?.frames ?? []) visit(frame.data);
  }

  async setSnapshot(snapshot: PluginState.Snapshot) {
    PluginState.validateSnapshotTransformers(snapshot);
    await this.animation.stop();

    // this needs to go 1st since these changes are already baked into the behavior and data state
    if (snapshot.structureComponentManager?.options)
      this.plugin.managers.structure.component._setSnapshotState(snapshot.structureComponentManager?.options);
    if (snapshot.behaviour) await this.plugin.runTask(this.behaviors.setSnapshot(snapshot.behaviour));
    // behaviors have registered their providers by now
    this.reportUnregisteredNames(snapshot);
    if (snapshot.data) await this.plugin.runTask(this.data.setSnapshot(snapshot.data));
    await this.setCustomState(snapshot);
    if (snapshot.canvas3d?.props) {
      const settings: Partial<Canvas3DProps> = PD.normalizeParams(Canvas3DParams, snapshot.canvas3d.props, 'children');
      if (snapshot.camera?.current || snapshot.camera?.focus) {
        // Avoid multiple camera transitions (creates ugly cases when camera in old and new snapshot is the same)
        settings.camera = undefined;
        settings.cameraClipping = undefined;
        settings.cameraFog = undefined;
      }
      await PluginCommands.Canvas3D.SetSettings(this.plugin, { settings });
    }
    if (snapshot.canvas3dContext?.props) {
      const props = PD.normalizeParams(Canvas3DContext.Params, snapshot.canvas3dContext.props, 'children');
      this.plugin.setCanvas3DContextProps(props);
    }
    if (snapshot.interactivity) {
      if (snapshot.interactivity.props) this.plugin.managers.interactivity.setProps(snapshot.interactivity.props);
    }
    if (snapshot.structureFocus) {
      this.plugin.managers.structure.focus.setSnapshot(snapshot.structureFocus);
    }
    if (snapshot.structureSelection) {
      this.plugin.managers.structure.selection.setSnapshot(snapshot.structureSelection);
    }
    if (snapshot.animation) {
      this.animation.setSnapshot(snapshot.animation);
    }
    if (snapshot.camera?.current) {
      PluginCommands.Camera.Reset(this.plugin, {
        snapshot: snapshot.camera.current,
        durationMs: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionDurationInMs : undefined,
        easing: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionEasing : undefined,
        trajectory: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionTrajectory : undefined,
      });
    } else if (snapshot.camera?.focus) {
      PluginCommands.Camera.FocusObject(this.plugin, {
        ...snapshot.camera.focus,
        durationMs: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionDurationInMs : undefined,
        easing: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionEasing : undefined,
        trajectory: snapshot.camera.transitionStyle === 'animate' ? snapshot.camera.transitionTrajectory : undefined,
      });
    }

    if (
      typeof snapshot?.onLoadMarkdownCommands === 'object' &&
      Object.keys(snapshot.onLoadMarkdownCommands).length > 0
    ) {
      this.plugin.managers.markdownExtensions.tryExecute('click', snapshot.onLoadMarkdownCommands);
    }

    if (snapshot.startAnimation) {
      this.animation.start();
      return;
    }

    if (snapshot.transition?.autoplay) {
      await Scheduler.immediatePromise();
      this.animation.play(AnimateStateSnapshotTransition, {});
    }
  }

  /** Calls `set` of every registered custom state with the snapshot's value, or `undefined`; other keys are ignored. */
  private async setCustomState(snapshot: PluginState.Snapshot) {
    for (const [key, entry] of Array.from(this.customState)) {
      try {
        await entry.set(snapshot.custom?.[key]);
      } catch (e) {
        this.plugin.log.error(`Failed to restore custom state '${key}': ${e instanceof Error ? e.message : e}`);
      }
    }
  }

  private settingsUpdatedTimer: ReturnType<typeof setTimeout> | undefined = undefined;
  private emitSettingsUpdated = () => {
    this.settingsUpdatedTimer = undefined;
    this.plugin.events.canvas3d.settingsUpdated.next(void 0);
  };

  async setAnimationSnapshot(snapshot: PluginState.Snapshot, frameIndex: number) {
    await this.animation.stopStateTransitionAnimation();

    const { transition } = snapshot;
    if (!transition) return;
    const finalIndex = Math.min(frameIndex, transition.frames.length - 1);
    const frame = transition.frames[finalIndex] ?? snapshot.data;
    if (frame.data) await this.plugin.runTask(this.data.setSnapshot(frame.data));
    if (frame.canvas3d?.props && this.plugin.canvas3d) {
      // A scrubbed transition sets every frame's props silently and says so once the scrubbing settles: emitting per
      // frame would wake every settings reader at the scrub's rate.
      const settings = PD.normalizeParams(Canvas3DParams, frame.canvas3d.props, 'children');
      this.plugin.canvas3d.setProps(settings);
      clearTimeout(this.settingsUpdatedTimer);
      this.settingsUpdatedTimer = setTimeout(this.emitSettingsUpdated, SettingsUpdatedDebounceMs);
    }
    if (frame.camera?.current) {
      PluginCommands.Camera.Reset(this.plugin, {
        snapshot: frame.camera.current,
        durationMs: frame.camera.transitionStyle === 'animate' ? frame.camera.transitionDurationInMs : undefined,
        easing: frame.camera.transitionStyle === 'animate' ? frame.camera.transitionEasing : undefined,
        trajectory: frame.camera.transitionStyle === 'animate' ? frame.camera.transitionTrajectory : undefined,
      });
    }

    if (
      !frameIndex &&
      typeof snapshot?.onLoadMarkdownCommands === 'object' &&
      Object.keys(snapshot.onLoadMarkdownCommands).length > 0
    ) {
      this.plugin.managers.markdownExtensions.tryExecute('click', snapshot.onLoadMarkdownCommands);
    }
  }

  updateTransform(state: State, a: StateTransform.Ref, params: any, canUndo?: string | boolean) {
    const tree = state.build().to(a).update(params);
    return PluginCommands.State.Update(this.plugin, { state, tree, options: { canUndo } });
  }

  hasBehavior(behavior: StateTransformer | string) {
    const behaviorId = typeof behavior === 'string' ? behavior : behavior.id;
    return this.behaviors.tree.transforms.has(behaviorId);
  }

  /**
   * Updates the params of a behavior. With a transformer, the behavior is inserted with default params when it is
   * absent. With a transformer id, only a behavior that is present is updated (use `hasBehavior` to check) and
   * nothing is inserted; `P` is the params type, usually an `import type` of the behavior module.
   */
  updateBehavior<T extends StateTransformer>(
    behavior: T,
    params: (old: StateTransformer.Params<T>) => void | StateTransformer.Params<T>,
  ): Promise<void>;
  updateBehavior<P = any>(behaviorId: string, params: (old: P) => void | P): Promise<void>;
  updateBehavior(behavior: StateTransformer | string, params: (old: any) => any): Promise<void> {
    const tree = this.behaviors.build();
    if (typeof behavior === 'string') {
      if (!this.behaviors.tree.transforms.has(behavior)) return Promise.resolve();
      tree.to(behavior).update(params);
    } else if (!this.behaviors.tree.transforms.has(behavior.id)) {
      const defaultParams = behavior.createDefaultParams(void 0 as any, this.plugin);
      tree
        .to(PluginBehavior.getCategoryId(behavior))
        .apply(behavior, produce(defaultParams, params) as any, { ref: behavior.id });
    } else {
      tree.to(behavior.id).update(params);
    }
    return this.plugin.runTask(this.behaviors.updateTree(tree));
  }

  dispose() {
    clearTimeout(this.settingsUpdatedTimer);
    this.behaviors.cells.forEach((cell) => {
      if (PluginBehavior.Behavior.is(cell.obj)) {
        cell.obj.data.unregister?.();
        cell.obj.data.dispose?.();
      }
    });

    super.dispose();
    this.data.dispose();
    this.behaviors.dispose();
    this.animation.dispose();
  }

  constructor(private plugin: PluginContext) {
    super();
  }
}

namespace PluginState {
  export type CameraTransitionStyle = 'instant' | 'animate';
  export const SnapshotParams = {
    durationInMs: PD.Numeric(1500, { min: 100, max: 15000, step: 100 }, { label: 'Duration in ms' }),
    data: PD.Boolean(true),
    behavior: PD.Boolean(false),
    structureSelection: PD.Boolean(false),
    componentManager: PD.Boolean(true),
    animation: PD.Boolean(true),
    startAnimation: PD.Boolean(false),
    canvas3d: PD.Boolean(true),
    canvas3dContext: PD.Boolean(true),
    interactivity: PD.Boolean(true),
    camera: PD.Boolean(true),
    cameraTransition: PD.MappedStatic(
      'animate',
      {
        animate: PD.Group({
          durationInMs: PD.Numeric(250, { min: 100, max: 5000, step: 500 }, { label: 'Duration in ms' }),
          easing: EasingParamDefinition('linear'),
          trajectory: TransitionTrajectoryParamDefinition('linear'),
        }),
        instant: PD.Group({}),
      },
      {
        options: [
          ['animate', 'Animate'],
          ['instant', 'Instant'],
        ],
      },
    ),
    image: PD.Boolean(false),
  };
  export type SnapshotParams = Partial<PD.Values<typeof SnapshotParams>>;
  export const DefaultSnapshotParams = PD.getDefaultValues(SnapshotParams);

  export interface Snapshot {
    id: UUID;
    data?: State.Snapshot;
    behaviour?: State.Snapshot;
    animation?: PluginAnimationManager.Snapshot;
    startAnimation?: boolean;
    camera?: {
      current?: Camera.Snapshot;
      focus?: SnapshotFocusInfo;
      transitionStyle: CameraTransitionStyle;
      transitionDurationInMs?: number;
      transitionEasing?: EasingKind;
      transitionTrajectory?: TransitionTrajectory;
    };
    canvas3d?: {
      props?: Canvas3DProps;
    };
    canvas3dContext?: {
      props?: Canvas3DContext.Props;
    };
    interactivity?: {
      props?: InteractivityManager.Props;
    };
    structureFocus?: StructureFocusSnapshot;
    structureSelection?: StructureSelectionSnapshot;
    structureComponentManager?: {
      options?: StructureComponentManager.Options;
    };
    durationInMs?: number;
    transition?: StateTransition;
    onLoadMarkdownCommands?: Record<string, any>;
    /**
     * Owner-keyed state registered with `PluginState.registerCustomState` (for example Prism's sequence viewer,
     * `'prism-viewer.sequence'`). Keys nobody registered are kept as they are and ignored on restore.
     */
    custom?: { [key: string]: unknown };
  }

  export interface CustomStateEntry {
    get(): unknown;
    set(value: unknown | undefined): void | Promise<void>;
  }

  export interface StateTransition {
    autoplay?: boolean;
    loop?: boolean;
    frames: {
      durationInMs: number;
      data: State.Snapshot;
      camera?: Snapshot['camera'];
      canvas3d?: { props?: Canvas3DProps };
    }[];
  }

  export const getMinFrameDuration = memoizeLatest((snapshot: Snapshot | undefined): number => {
    if (!snapshot) return 1000 / 60;
    const { transition } = snapshot;
    if (!transition) return 1000 / 60;

    let minDuration = Infinity;
    for (const frame of transition.frames) {
      if (frame.durationInMs > 0 && frame.durationInMs < minDuration) {
        minDuration = frame.durationInMs;
      }
    }
    if (!Number.isFinite(minDuration)) return 1000 / 60;
    return minDuration;
  });

  export const getStateTransitionDuration = memoizeLatest((snapshot: Snapshot | undefined): number | undefined => {
    if (!snapshot) return undefined;
    const { transition } = snapshot;
    if (!transition) return undefined;
    let totalDuration = 0;
    for (let i = 0; i < transition.frames.length; i++) {
      const frame = transition.frames[i];
      totalDuration += frame.durationInMs;
    }
    return totalDuration;
  });

  export const getStateTransitionFrameTime = memoizeLatest(
    (snapshot: Snapshot | undefined, frameIndex: number | undefined): number => {
      if (!snapshot || frameIndex === undefined) return 0;
      const { transition } = snapshot;
      if (!transition) return 0;
      let currentDuration = 0;
      for (let i = 0; i < frameIndex; i++) {
        if (transition.frames.length <= i) break;
        const frame = transition.frames[i];
        currentDuration += frame.durationInMs;
      }
      return currentDuration;
    },
  );

  export function getStateTransitionFrameIndex(snapshot: Snapshot, timestamp: number): number | undefined {
    const { transition } = snapshot;
    if (!transition?.frames.length) return undefined;

    let t = timestamp;
    if (transition.loop) {
      t %= getStateTransitionDuration(snapshot) ?? 1;
    }

    let currentDuration = 0;
    if (t <= transition.frames[0].durationInMs) return 0;
    for (let i = 0; i < transition.frames.length; i++) {
      if (currentDuration >= t) return i;
      const frame = transition.frames[i];
      currentDuration += frame.durationInMs;
    }
    return transition.frames.length - 1;
  }

  export type SnapshotType = 'json' | 'molj' | 'zip' | 'molx';

  export interface SnapshotFocusInfo {
    targets?: SnapshotFocusTargetInfo[];
    direction?: Vec3;
    up?: Vec3;
  }
  /** Final radius to be computed as `radius ?? targetBoundingRadius * radiusFactor + extraRadius` */
  export interface SnapshotFocusTargetInfo {
    /** Reference to plugin state node to focus (undefined means focus whole scene) */
    targetRef?: StateTransform.Ref;
    /** Overrides focus center defined by `targetRef` */
    center?: Vec3;
    /** Overrides focus radius defined by `targetRef` */
    radius?: number;
    /** Multiplies focus radius defined by `targetRef` */
    radiusFactor?: number;
    /** Adds to focus radius defined by `targetRef` */
    extraRadius?: number;
  }
}
