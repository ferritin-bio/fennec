/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginSpec } from '@molstar/plugin/spec';
export declare const DefaultPluginSpec: () => PluginSpec;
//# sourceMappingURL=default-spec.d.ts.map