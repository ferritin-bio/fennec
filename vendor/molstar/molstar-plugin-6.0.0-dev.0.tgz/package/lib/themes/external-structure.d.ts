/**
 * Copyright (c) 2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Color } from '@molstar/core/util/color';
import type { ColorTheme } from '@molstar/graphics/theme/color';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '@molstar/graphics/theme/theme';
import { Structure } from '@molstar/model/model/structure';
export declare const ExternalStructureColorThemeParams: {
    structure: PD.ValueRef<Structure>;
    style: PD.Mapped<PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        asymId: "auth" | "label";
    }>, "chain-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
        overrideWater: boolean;
        waterColor: Color;
    }>, "entity-id"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "entity-source"> | PD.NamedParams<PD.Normalize<{
        saturation: number;
        lightness: number;
        colors: PD.NamedParams<PD.Normalize<unknown>, "default"> | PD.NamedParams<PD.Normalize<{
            water: Color;
            ion: Color;
            protein: Color;
            RNA: Color;
            DNA: Color;
            PNA: Color;
            saccharide: Color;
        }>, "custom">;
    }>, "molecule-type"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "model-index"> | PD.NamedParams<PD.Normalize<{
        palette: PD.NamedParams<PD.Normalize<{
            list: {
                kind: 'interpolate' | 'set';
                colors: import("@molstar/core/util/color/color").ColorListEntry[];
            };
        }>, "colors"> | PD.NamedParams<PD.Normalize<{
            hue: [number, number];
            chroma: [number, number];
            luminance: [number, number];
            sort: "contrast" | "none";
            clusteringStepCount: number;
            minSampleCount: number;
            sampleCountFactor: number;
            maxCount: number;
        }>, "generate">;
    }>, "structure-index">>;
    defaultColor: PD.Color;
    maxDistance: PD.Numeric;
    approxMaxDistance: PD.Numeric;
    normalOffset: PD.Numeric;
    backboneOnly: PD.BooleanParam;
};
export type ExternalStructureColorThemeParams = typeof ExternalStructureColorThemeParams;
export declare function ExternalStructureColorTheme(ctx: ThemeDataContext, props: PD.Values<ExternalStructureColorThemeParams>): ColorTheme<ExternalStructureColorThemeParams>;
export declare const ExternalStructureColorThemeProvider: ColorTheme.Provider<ExternalStructureColorThemeParams, 'external-structure'>;
//# sourceMappingURL=external-structure.d.ts.map