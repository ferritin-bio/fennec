/**
 * Copyright (c) 2024-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Cai Huiyu <szmun.caihy@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ColorTheme } from '@molstar/graphics/theme/color';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeDataContext } from '@molstar/graphics/theme/theme';
import { Volume } from '@molstar/model/model/volume';
export declare const ExternalVolumeColorThemeParams: {
    volume: PD.ValueRef<Volume>;
    coloring: PD.Mapped<PD.NamedParams<PD.Normalize<{
        domain: PD.NamedParams<[number, number], "custom"> | PD.NamedParams<PD.Normalize<{
            symmetric: /*elided*/ any;
        }>, "auto">;
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "absolute-value"> | PD.NamedParams<PD.Normalize<{
        domain: PD.NamedParams<[number, number], "custom"> | PD.NamedParams<PD.Normalize<{
            symmetric: /*elided*/ any;
        }>, "auto">;
        list: {
            kind: 'interpolate' | 'set';
            colors: import("@molstar/core/util/color/color").ColorListEntry[];
        };
    }>, "relative-value">>;
    defaultColor: PD.Color;
    normalOffset: PD.Numeric;
    usePalette: PD.BooleanParam;
};
export type ExternalVolumeColorThemeParams = typeof ExternalVolumeColorThemeParams;
export declare function ExternalVolumeColorTheme(ctx: ThemeDataContext, props: PD.Values<ExternalVolumeColorThemeParams>): ColorTheme<ExternalVolumeColorThemeParams>;
export declare const ExternalVolumeColorThemeProvider: ColorTheme.Provider<ExternalVolumeColorThemeParams, 'external-volume'>;
//# sourceMappingURL=external-volume.d.ts.map