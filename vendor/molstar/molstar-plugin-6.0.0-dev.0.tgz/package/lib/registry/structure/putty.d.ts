/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The putty structure representation with the providers of its default color (chain-id) and size (uncertainty) themes. */
export declare const Putty: PluginRegistryEntry;
//# sourceMappingURL=putty.d.ts.map