/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The blob-surface structure representation with the providers of its default color (chain-id) and size (physical) themes. */
export declare const BlobSurface: PluginRegistryEntry;
//# sourceMappingURL=blob-surface.d.ts.map