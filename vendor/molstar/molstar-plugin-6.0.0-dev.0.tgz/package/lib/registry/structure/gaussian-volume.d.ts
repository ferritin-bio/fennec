/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The gaussian-volume structure representation with the providers of its default color (chain-id) and size (physical) themes. */
export declare const GaussianVolume: PluginRegistryEntry;
//# sourceMappingURL=gaussian-volume.d.ts.map