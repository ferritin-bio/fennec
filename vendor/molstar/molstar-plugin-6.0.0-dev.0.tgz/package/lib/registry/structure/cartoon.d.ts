/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The cartoon structure representation with the providers of its default color (chain-id) and size (uniform) themes. */
export declare const Cartoon: PluginRegistryEntry;
//# sourceMappingURL=cartoon.d.ts.map