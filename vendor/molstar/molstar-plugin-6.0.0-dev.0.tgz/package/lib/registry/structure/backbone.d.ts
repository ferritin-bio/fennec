/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The backbone structure representation with the providers of its default color (chain-id) and size (uniform) themes. */
export declare const Backbone: PluginRegistryEntry;
//# sourceMappingURL=backbone.d.ts.map