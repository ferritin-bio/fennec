/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The orientation structure representation with the providers of its default color (chain-id) and size (uniform) themes. */
export declare const Orientation: PluginRegistryEntry;
//# sourceMappingURL=orientation.d.ts.map