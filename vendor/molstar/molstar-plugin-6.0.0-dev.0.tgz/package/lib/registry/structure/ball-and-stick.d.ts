/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The ball-and-stick structure representation with the providers of its default color (element-symbol) and size (physical) themes. */
export declare const BallAndStick: PluginRegistryEntry;
//# sourceMappingURL=ball-and-stick.d.ts.map