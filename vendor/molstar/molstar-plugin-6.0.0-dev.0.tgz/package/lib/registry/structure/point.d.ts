/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The point structure representation with the providers of its default color (element-symbol) and size (uniform) themes. */
export declare const Point: PluginRegistryEntry;
//# sourceMappingURL=point.d.ts.map