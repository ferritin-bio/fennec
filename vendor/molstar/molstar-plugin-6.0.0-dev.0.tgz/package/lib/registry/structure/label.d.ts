/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The label structure representation with the providers of its default color (uniform) and size (physical) themes. */
export declare const Label: PluginRegistryEntry;
//# sourceMappingURL=label.d.ts.map