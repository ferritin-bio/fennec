/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/**
 * Combines entries into one entry, for modules whose entry includes the entries of what they use. Lists are
 * concatenated in order and a provider listed by several entries appears once, so the result registers each provider a
 * single time.
 */
export declare function mergeRegistryEntries(...entries: readonly PluginRegistryEntry[]): PluginRegistryEntry;
//# sourceMappingURL=merge.d.ts.map