/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The direct-volume volume representation with the providers of its default color (volume-value) and size (uniform) themes. */
export declare const DirectVolume: PluginRegistryEntry;
//# sourceMappingURL=direct-volume.d.ts.map