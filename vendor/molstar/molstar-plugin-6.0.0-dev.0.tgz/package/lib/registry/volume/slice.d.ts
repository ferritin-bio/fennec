/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The slice volume representation with the providers of its default color (uniform) and size (uniform) themes. */
export declare const Slice: PluginRegistryEntry;
//# sourceMappingURL=slice.d.ts.map