/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The isosurface volume representation with the providers of its default color (uniform) and size (uniform) themes. */
export declare const Isosurface: PluginRegistryEntry;
//# sourceMappingURL=isosurface.d.ts.map