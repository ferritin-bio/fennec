/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The segment volume representation with the providers of its default color (volume-segment) and size (uniform) themes. */
export declare const Segment: PluginRegistryEntry;
//# sourceMappingURL=segment.d.ts.map