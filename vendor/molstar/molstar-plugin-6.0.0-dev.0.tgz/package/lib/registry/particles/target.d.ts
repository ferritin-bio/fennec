/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The target particles representation with the providers of its default color (particle-entity) and size (uniform) themes. */
export declare const ParticleTarget: PluginRegistryEntry;
//# sourceMappingURL=target.d.ts.map