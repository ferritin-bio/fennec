/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** The spacefill particles representation with the providers of its default color (particle-index) and size (particle-size) themes. */
export declare const ParticleSpacefill: PluginRegistryEntry;
//# sourceMappingURL=spacefill.d.ts.map