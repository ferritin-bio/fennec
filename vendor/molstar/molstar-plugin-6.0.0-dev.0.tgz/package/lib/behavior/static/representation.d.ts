/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
export declare function registerDefault(ctx: PluginContext): void;
export declare function SyncRepresentationToCanvas(ctx: PluginContext): void;
export declare function SyncStructureRepresentation3DState(ctx: PluginContext): void;
export declare function UpdateRepresentationVisibility(ctx: PluginContext): void;
//# sourceMappingURL=representation.d.ts.map