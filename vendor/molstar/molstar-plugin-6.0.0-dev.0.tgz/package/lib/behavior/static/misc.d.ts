/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
export declare function registerDefault(ctx: PluginContext): void;
export declare function Canvas3DSetSettings(ctx: PluginContext): void;
//# sourceMappingURL=misc.d.ts.map