/**
 * Copyright (c) 2018-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
export declare function registerDefault(ctx: PluginContext): void;
export declare function Reset(ctx: PluginContext): void;
export declare function SetSnapshot(ctx: PluginContext): void;
export declare function Focus(ctx: PluginContext): void;
export declare function FocusObject(ctx: PluginContext): void;
export declare function OrientAxes(ctx: PluginContext): void;
export declare function ResetAxes(ctx: PluginContext): void;
//# sourceMappingURL=camera.d.ts.map