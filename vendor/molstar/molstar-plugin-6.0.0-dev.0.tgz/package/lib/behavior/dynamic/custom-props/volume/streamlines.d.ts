/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const Streamlines: import("@molstar/core/state/transformer").StateTransformer<any, any, any>;
//# sourceMappingURL=streamlines.d.ts.map