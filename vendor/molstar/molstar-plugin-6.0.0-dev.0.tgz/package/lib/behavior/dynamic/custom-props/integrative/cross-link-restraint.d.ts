/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const CrossLinkRestraint: import("@molstar/core/state/transformer").StateTransformer<any, any, any>;
//# sourceMappingURL=cross-link-restraint.d.ts.map