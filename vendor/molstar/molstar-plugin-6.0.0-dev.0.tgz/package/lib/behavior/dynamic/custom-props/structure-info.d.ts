/**
 * Copyright (c) 2020-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const StructureInfo: import("@molstar/core/state").StateTransformer<any, any, any>;
//# sourceMappingURL=structure-info.d.ts.map