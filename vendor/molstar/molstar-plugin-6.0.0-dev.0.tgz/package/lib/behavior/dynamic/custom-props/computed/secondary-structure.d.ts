/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const SecondaryStructure: import("@molstar/core/state/transformer").StateTransformer<any, any, any>;
//# sourceMappingURL=secondary-structure.d.ts.map