/**
 * Copyright (c) 2019-2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const Interactions: import("@molstar/core/state").StateTransformer<any, any, any>;
//# sourceMappingURL=interactions.d.ts.map