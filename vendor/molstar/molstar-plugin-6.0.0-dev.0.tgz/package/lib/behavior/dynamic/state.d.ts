/**
 * Copyright (c) 2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const SnapshotControls: import("@molstar/core/state/transformer").StateTransformer<any, any, any>;
//# sourceMappingURL=state.d.ts.map