/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginContext } from '@molstar/plugin/context';
import { Clip } from '@molstar/core/util/clip';
declare const StructureFocusRepresentationParams: (plugin: PluginContext) => {
    expandRadius: PD.Numeric;
    targetParams: PD.Group<PD.Normalize<{
        [x: string]: /*elided*/ any;
    }>>;
    surroundingsParams: PD.Group<PD.Normalize<{
        [x: string]: /*elided*/ any;
    }>>;
    nciParams: PD.Group<PD.Normalize<{
        [x: string]: /*elided*/ any;
    }>>;
    components: PD.MultiSelect<"interactions" | "surroundings" | "target">;
    excludeTargetFromSurroundings: PD.BooleanParam;
    ignoreHydrogens: PD.BooleanParam;
    ignoreHydrogensVariant: PD.Select<"all" | "non-polar">;
    ignoreLight: PD.BooleanParam;
    material: PD.Group<PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>>;
    clip: PD.Group<PD.Normalize<{
        variant: Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>>;
    interior: PD.Group<PD.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>>;
    animation: PD.Group<PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>>;
};
export type StructureFocusRepresentationProps = PD.ValuesFor<ReturnType<typeof StructureFocusRepresentationParams>>;
export declare enum StructureFocusRepresentationTags {
    TargetSel = "structure-focus-target-sel",
    TargetRepr = "structure-focus-target-repr",
    SurrSel = "structure-focus-surr-sel",
    SurrRepr = "structure-focus-surr-repr",
    SurrNciRepr = "structure-focus-surr-nci-repr"
}
export declare const StructureFocusRepresentation: import("@molstar/core/state").StateTransformer<any, any, any>;
export {};
//# sourceMappingURL=structure-focus-representation.d.ts.map