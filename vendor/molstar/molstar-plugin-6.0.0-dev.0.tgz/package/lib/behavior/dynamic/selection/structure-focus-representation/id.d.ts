/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
/** Name of the structure focus representation behavior transformer. */
export declare const StructureFocusRepresentationName = "create-structure-focus-representation";
/** Transformer id of the structure focus representation behavior (the `ms-plugin` namespace and the name). */
export declare const StructureFocusRepresentationId = "ms-plugin.create-structure-focus-representation";
//# sourceMappingURL=id.d.ts.map