/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { PluginStateObject } from '@molstar/plugin/state/objects';
import { Volume } from '@molstar/model/model/volume';
import type { VolumeServerInfo } from './model.js';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { Color } from '@molstar/core/util/color';
import { PluginBehavior } from '../../behavior.js';
import { Structure } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
declare const VolumeStreaming_base: {
    new (data: VolumeStreaming.Behavior, props?: {
        label: string;
        description?: string;
    } | undefined): {
        id: import("@molstar/core/util/uuid").UUID;
        type: PluginStateObject.TypeInfo;
        label: string;
        description?: string;
        data: VolumeStreaming.Behavior;
    };
    type: PluginStateObject.TypeInfo;
    is(obj?: import("@molstar/core/state").StateObject): obj is import("@molstar/core/state").StateObject<VolumeStreaming.Behavior, PluginStateObject.TypeInfo>;
};
export declare class VolumeStreaming extends VolumeStreaming_base {
}
export declare namespace VolumeStreaming {
    const RootTag = "volume-streaming-info";
    interface ChannelParams {
        isoValue: Volume.IsoValue;
        color: Color;
        wireframe: boolean;
        opacity: number;
    }
    function createParams(options?: {
        data?: VolumeServerInfo.Data;
        defaultView?: ViewTypes;
        channelParams?: DefaultChannelParams;
    }): {
        entry: PD.Mapped<PD.NamedParams<PD.Values<{
            view: PD.Mapped<PD.NamedParams<PD.Normalize<{}>, "cell"> | PD.NamedParams<PD.Normalize<{}>, "off"> | PD.NamedParams<PD.Normalize<{
                bottomLeft: Vec3;
                topRight: Vec3;
            }>, "box"> | PD.NamedParams<PD.Normalize<{
                radius: number;
                bottomLeft: Vec3;
                topRight: Vec3;
            }>, "selection-box"> | PD.NamedParams<PD.Normalize<{
                radius: number;
                dynamicDetailLevel: number;
                bottomLeft: Vec3;
                topRight: Vec3;
            }>, "camera-target"> | PD.NamedParams<PD.Normalize<{
                radius: number;
                selectionDetailLevel: number;
                isSelection: boolean;
                bottomLeft: Vec3;
                topRight: Vec3;
            }>, "auto">>;
            detailLevel: PD.Select<number>;
            channels: PD.Group<PD.Normalize<{
                em: PD.Normalize<ChannelParams>;
            }>> | PD.Group<PD.Normalize<{
                '2fo-fc': PD.Normalize<ChannelParams>;
                'fo-fc(+ve)': PD.Normalize<ChannelParams>;
                'fo-fc(-ve)': PD.Normalize<ChannelParams>;
            }>>;
        }>, string>>;
    };
    type EntryParamDefinition = ReturnType<typeof createEntryParams>;
    type EntryParams = PD.Values<EntryParamDefinition>;
    function createEntryParams(options: {
        entryData?: VolumeServerInfo.EntryData;
        defaultView?: ViewTypes;
        structure?: Structure;
        channelParams?: DefaultChannelParams;
    }): {
        view: PD.Mapped<PD.NamedParams<PD.Normalize<{}>, "cell"> | PD.NamedParams<PD.Normalize<{}>, "off"> | PD.NamedParams<PD.Normalize<{
            bottomLeft: Vec3;
            topRight: Vec3;
        }>, "box"> | PD.NamedParams<PD.Normalize<{
            radius: number;
            bottomLeft: Vec3;
            topRight: Vec3;
        }>, "selection-box"> | PD.NamedParams<PD.Normalize<{
            radius: number;
            dynamicDetailLevel: number;
            bottomLeft: Vec3;
            topRight: Vec3;
        }>, "camera-target"> | PD.NamedParams<PD.Normalize<{
            radius: number;
            selectionDetailLevel: number;
            isSelection: boolean;
            bottomLeft: Vec3;
            topRight: Vec3;
        }>, "auto">>;
        detailLevel: PD.Select<number>;
        channels: PD.Group<PD.Normalize<{
            em: PD.Normalize<ChannelParams>;
        }>> | PD.Group<PD.Normalize<{
            '2fo-fc': PD.Normalize<ChannelParams>;
            'fo-fc(+ve)': PD.Normalize<ChannelParams>;
            'fo-fc(-ve)': PD.Normalize<ChannelParams>;
        }>>;
    };
    function copyParams(origParams: Params): Params;
    const ViewTypeOptions: [ViewTypes, string][];
    type ViewTypes = 'off' | 'box' | 'selection-box' | 'camera-target' | 'cell' | 'auto';
    type ParamDefinition = ReturnType<typeof createParams>;
    type Params = PD.Values<ParamDefinition>;
    type ChannelType = 'em' | '2fo-fc' | 'fo-fc(+ve)' | 'fo-fc(-ve)';
    const ChannelTypeOptions: [ChannelType, string][];
    interface ChannelInfo {
        data: Volume;
        color: Color;
        wireframe: boolean;
        isoValue: Volume.IsoValue.Relative;
        opacity: number;
    }
    type Channels = {
        [name in ChannelType]?: ChannelInfo;
    };
    type DefaultChannelParams = {
        [name in ChannelType]?: Partial<ChannelParams>;
    };
    class Behavior extends PluginBehavior.WithSubscribers<Params> {
        plugin: PluginContext;
        data: VolumeServerInfo.Data;
        private cache;
        params: Params;
        private lastLoci;
        private ref;
        infoMap: Map<string, VolumeServerInfo.EntryData>;
        private updateQueue;
        private cameraTargetObservable;
        private cameraTargetSubscription?;
        channels: Channels;
        get info(): VolumeServerInfo.EntryData;
        private queryData;
        private parseCif;
        private updateParams;
        private getStructureRoot;
        register(ref: string): void;
        unregister(): void;
        private isCameraTargetSame;
        private cameraTargetDistance;
        private _invTransform;
        private getBoxFromLoci;
        private updateAuto;
        private updateSelectionBox;
        private updateCameraTarget;
        private boxFromCameraTarget;
        private decideDetail;
        update(params: Params): Promise<boolean>;
        private createChannel;
        getDescription(): "" | "Camera" | "Cell" | "Selection" | "Static Box";
        constructor(plugin: PluginContext, data: VolumeServerInfo.Data);
    }
}
export {};
//# sourceMappingURL=behavior.d.ts.map