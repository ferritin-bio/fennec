/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/**
 * Per-kind plumbing of `PluginContext.register`: turns entries into registrations, checks them all for conflicts
 * before changing anything, applies them in the fixed order, and builds the undo.
 *
 * This module must not value-import catalogs; it only drives the registries and managers of the context.
 */
export { registerEntries };
/**
 * Registers `entry` with `plugin` and returns an idempotent undo. Checks every provider for conflicts before changing
 * anything; on a conflict throws one error listing all of them and leaves the plugin unchanged.
 */
declare function registerEntries(plugin: PluginContext, entry: PluginRegistryEntry | readonly PluginRegistryEntry[]): () => void;
//# sourceMappingURL=registry-entry.d.ts.map