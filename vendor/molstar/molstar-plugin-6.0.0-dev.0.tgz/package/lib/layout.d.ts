/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Lukáš Polák <admin@lukaspolak.cz>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StatefulPluginComponent } from '@molstar/plugin/state/component';
import type { PluginContext } from '@molstar/plugin/context';
export type PluginLayoutControlsDisplay = 'outside' | 'portrait' | 'landscape' | 'reactive';
export declare const PluginLayoutStateParams: {
    isExpanded: PD.BooleanParam;
    showControls: PD.BooleanParam;
    regionState: PD.Group<PD.Normalize<{
        left: "collapsed" | "full" | "hidden";
        top: "full" | "hidden";
        right: "full" | "hidden";
        bottom: "full" | "hidden";
    }>>;
    controlsDisplay: PD.Value<PluginLayoutControlsDisplay>;
    expandToFullscreen: PD.BooleanParam;
};
export type PluginLayoutStateProps = PD.Values<typeof PluginLayoutStateParams>;
export type LeftPanelTabName = 'none' | 'root' | 'data' | 'states' | 'settings' | 'help';
export declare class PluginLayout extends StatefulPluginComponent<PluginLayoutStateProps> {
    private context;
    readonly events: {
        updated: import("rxjs").Subject<unknown>;
    };
    private updateProps;
    root: HTMLElement | undefined;
    private rootState;
    private expandedViewport;
    setProps(props: Partial<PluginLayoutStateProps>): void;
    setRoot(root: HTMLElement): void;
    private getScrollElement;
    private tryRequestFullscreen;
    private tryExitFullscreen;
    private handleExpand;
    private fullscreenChangeHandler;
    dispose(): void;
    constructor(context: PluginContext);
}
//# sourceMappingURL=layout.d.ts.map