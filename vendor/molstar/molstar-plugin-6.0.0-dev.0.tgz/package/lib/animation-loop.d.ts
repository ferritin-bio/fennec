/**
 * Copyright (c) 2020-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import type { PluginAnimationManager } from '@molstar/plugin/state/manager/animation';
export declare class PluginAnimationLoop {
    private plugin;
    private lastTickT;
    private properTimeT;
    private currentFrame;
    private _isAnimating;
    private pausesWhenIdle;
    /** Started, but asking for no frames while the canvas is idle: the next `wake` asks again. */
    private sleeping;
    private idleSince;
    private wakeSubs;
    /** Started and not stopped: also while it sleeps (`isSleeping`). */
    get isAnimating(): boolean;
    /** Started, but asking for no frames: the canvas is idle (`PluginConfig.General.PauseLoopWhenIdle`). */
    get isSleeping(): boolean;
    tick(t: number, options?: {
        isSynchronous?: boolean;
        manualDraw?: boolean;
        animation?: PluginAnimationManager.AnimationInfo;
        updateControls?: boolean;
        xrFrame?: XRFrame;
    }): Promise<void>;
    private frame;
    /** How long the canvas has been idle with nothing animating (ms), when the loop may sleep; else 0. */
    private idleFor;
    /** Something gave the canvas work (or a state animation started): a sleeping loop asks for frames again. */
    private wake;
    private followWake;
    resetTime(t: number): void;
    start(options?: {
        immediate?: boolean;
    }): void;
    stop(options?: {
        noDraw?: boolean;
    }): void;
    dispose(): void;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=animation-loop.d.ts.map