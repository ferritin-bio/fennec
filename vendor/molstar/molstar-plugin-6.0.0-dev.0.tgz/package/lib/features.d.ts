/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const PluginFeatureDetection: {
    readonly defaultTransparency: 'blended' | 'wboit' | 'dpoit';
};
//# sourceMappingURL=features.d.ts.map