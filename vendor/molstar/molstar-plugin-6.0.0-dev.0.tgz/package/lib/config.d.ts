/**
 * Copyright (c) 2020-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Structure } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { EmdbDownloadProvider } from '@molstar/plugin/state/actions/volume';
import type { StructureRepresentationPresetProvider } from '@molstar/plugin/state/builder/structure/representation-presets/types';
import type { SaccharideCompIdMapType } from '@molstar/model/model/structure/structure/carbohydrates/constants';
import type { GraphicsBackendDescriptor } from '@molstar/graphics/gl/backend';
export declare class PluginConfigItem<T = any> {
    key: string;
    defaultValue?: T | undefined;
    toString(): string;
    valueOf(): string;
    constructor(key: string, defaultValue?: T | undefined);
}
declare function item<T>(key: string, defaultValue?: T): PluginConfigItem<T>;
export declare const PluginConfig: {
    item: typeof item;
    General: {
        IsBusyTimeoutMs: PluginConfigItem<number>;
        DisableAntialiasing: PluginConfigItem<boolean>;
        DisablePreserveDrawingBuffer: PluginConfigItem<boolean>;
        PixelScale: PluginConfigItem<number>;
        PickScale: PluginConfigItem<number>;
        Transparency: PluginConfigItem<"blended" | "dpoit" | "wboit">;
        /**
         * Graphics backends tried in order, e.g. `[WebGPUBackend, WebGL2Backend, WebGLBackend]`; by default those of
         * `@molstar/graphics/gl/backends/default` (WebGL, WebGL1 only with `PreferWebGl1`; builds may alias the module)
         */
        GraphicsBackends: PluginConfigItem<readonly GraphicsBackendDescriptor[] | undefined>;
        PreferWebGl1: PluginConfigItem<boolean>;
        AllowMajorPerformanceCaveat: PluginConfigItem<boolean>;
        PowerPreference: PluginConfigItem<WebGLPowerPreference | undefined>;
        ResolutionMode: PluginConfigItem<"auto" | "native" | "scaled">;
        /**
         * The animation loop stops asking for frames while the canvas is idle (`Canvas3D.isIdle`) and starts again on its
         * `wake` or a state animation. Off by default: code that changes the scene or the camera past Canvas3D's API without
         * `requestDraw` would not be drawn.
         */
        PauseLoopWhenIdle: PluginConfigItem<boolean>;
    };
    State: {
        DefaultServer: PluginConfigItem<string>;
        CurrentServer: PluginConfigItem<string>;
        HistoryCapacity: PluginConfigItem<number>;
    };
    VolumeStreaming: {
        Enabled: PluginConfigItem<boolean>;
        DefaultServer: PluginConfigItem<string>;
        CanStream: PluginConfigItem<(s: Structure, plugin: PluginContext) => boolean>;
        EmdbHeaderServer: PluginConfigItem<string>;
    };
    Viewport: {
        ShowReset: PluginConfigItem<boolean>;
        ShowExpand: PluginConfigItem<boolean>;
        ShowToggleFullscreen: PluginConfigItem<boolean>;
        ShowControls: PluginConfigItem<boolean>;
        ShowSettings: PluginConfigItem<boolean>;
        ShowSelectionMode: PluginConfigItem<boolean>;
        ShowAnimation: PluginConfigItem<boolean>;
        ShowTrajectoryControls: PluginConfigItem<boolean>;
        ShowScreenshotControls: PluginConfigItem<boolean>;
        ShowIllumination: PluginConfigItem<boolean>;
        ShowXR: PluginConfigItem<"always" | "auto" | "never">;
    };
    Download: {
        DefaultPdbProvider: PluginConfigItem<"pdbe" | "pdbj" | "rcsb">;
        DefaultEmdbProvider: PluginConfigItem<EmdbDownloadProvider>;
    };
    Structure: {
        SizeThresholds: PluginConfigItem<{
            smallResidueCount: number;
            mediumResidueCount: number;
            largeResidueCount: number;
            highSymmetryUnitCount: number;
            fiberResidueCount: number;
        }>;
        DefaultHierarchyPreset: PluginConfigItem<string>;
        DefaultRepresentationPreset: PluginConfigItem<string>;
        DefaultRepresentationPresetParams: PluginConfigItem<StructureRepresentationPresetProvider.CommonParams>;
        SaccharideCompIdMapType: PluginConfigItem<SaccharideCompIdMapType>;
    };
    Background: {
        Styles: PluginConfigItem<[import("@molstar/core/util/param-definition").ParamDefinition.Values<{
            variant: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "off"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                opacity: number;
                saturation: number;
                lightness: number;
                faces: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    nx: any;
                    ny: any;
                    nz: any;
                    px: any;
                    py: any;
                    pz: any;
                }>, "urls"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    nx: any;
                    ny: any;
                    nz: any;
                    px: any;
                    py: any;
                    pz: any;
                }>, "files">;
                blur: number;
                rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    x: any;
                    y: any;
                    z: any;
                }>;
            }>, "skybox"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                opacity: number;
                saturation: number;
                lightness: number;
                source: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<any, "url"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/assets").Asset.File | null, "file">;
                blur: number;
                coverage: "canvas" | "viewport";
            }>, "image"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                topColor: import("@molstar/core/util/color/color").Color;
                bottomColor: import("@molstar/core/util/color/color").Color;
                ratio: number;
                coverage: "canvas" | "viewport";
            }>, "horizontalGradient"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                centerColor: import("@molstar/core/util/color/color").Color;
                edgeColor: import("@molstar/core/util/color/color").Color;
                ratio: number;
                coverage: "canvas" | "viewport";
            }>, "radialGradient">>;
        }>, string][]>;
    };
};
export declare class PluginConfigManager {
    private _config;
    get<T>(key: PluginConfigItem<T>): T | undefined;
    set<T>(key: PluginConfigItem<T>, value: T): void;
    delete<T>(key: PluginConfigItem<T>): void;
    constructor(initial?: [PluginConfigItem, unknown][]);
}
export {};
//# sourceMappingURL=config.d.ts.map