/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { GraphicsBackendDescriptor } from '@molstar/graphics/gl/backend';
/**
 * `auto`: WebGPU where it has the features of WebGL2 (blending into float32 targets, missing in older browsers), else
 * WebGL2, then WebGL1; `webgpu`: WebGPU, else WebGL; `webgl`: WebGL2, else WebGL1 (WebGL1 only with
 * `PluginConfig.General.PreferWebGl1`); `webgl2` and `webgl1`: only that version
 */
export type GraphicsBackendChoice = 'auto' | 'webgpu' | 'webgl' | 'webgl2' | 'webgl1';
/**
 * The backends of `choice` for `PluginConfig.General.GraphicsBackends`, undefined for the plugin's default (`webgl`);
 * from the backend sets (not the backends), so that builds with one backend alias the others away (see
 * `molstar.variants` in the Viewer's manifest)
 */
export declare function getGraphicsBackends(choice: GraphicsBackendChoice): readonly GraphicsBackendDescriptor[] | undefined;
//# sourceMappingURL=graphics-backends.d.ts.map