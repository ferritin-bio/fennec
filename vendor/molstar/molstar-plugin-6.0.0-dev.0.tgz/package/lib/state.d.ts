/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { Camera } from '@molstar/graphics/canvas3d/camera';
import { type TransitionTrajectory } from '@molstar/graphics/canvas3d/camera/transition-functions';
import { Canvas3DContext, type Canvas3DProps } from '@molstar/graphics/canvas3d/canvas3d';
import { type EasingKind } from '@molstar/core/math/easing';
import type { Vec3 } from '@molstar/core/math/linear-algebra';
import { PluginComponent } from '@molstar/plugin/state/component';
import type { PluginAnimationManager } from '@molstar/plugin/state/manager/animation';
import type { InteractivityManager } from '@molstar/plugin/state/manager/interactivity';
import type { StructureComponentManager } from '@molstar/plugin/state/manager/structure/component';
import type { StructureFocusSnapshot } from '@molstar/plugin/state/manager/structure/focus';
import type { StructureSelectionSnapshot } from '@molstar/plugin/state/manager/structure/selection';
import { State, StateTransform, StateTransformer } from '@molstar/core/state';
import { UUID } from '@molstar/core/util';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginContext } from '@molstar/plugin/context';
export { PluginState };
declare class PluginState extends PluginComponent {
    private plugin;
    private get animation();
    readonly data: State;
    readonly behaviors: State;
    readonly events: {
        readonly cell: {
            readonly stateUpdated: import("rxjs").Observable<State.ObjectEvent & {
                cell: import("@molstar/core/state").StateObjectCell;
            }>;
            readonly created: import("rxjs").Observable<State.ObjectEvent & {
                cell: import("@molstar/core/state").StateObjectCell;
            }>;
            readonly removed: import("rxjs").Observable<State.ObjectEvent & {
                parent: StateTransform.Ref;
            }>;
        };
        readonly object: {
            readonly created: import("rxjs").Observable<State.ObjectEvent & {
                obj: import("@molstar/core/state").StateObject;
            }>;
            readonly removed: import("rxjs").Observable<State.ObjectEvent & {
                obj?: import("@molstar/core/state").StateObject;
            }>;
            readonly updated: import("rxjs").Observable<State.ObjectEvent & {
                action: 'in-place' | 'recreate';
                obj: import("@molstar/core/state").StateObject;
                oldObj?: import("@molstar/core/state").StateObject;
                oldData?: any;
            }>;
        };
    };
    readonly snapshotParams: import("rxjs").BehaviorSubject<Partial<PD.Values<{
        durationInMs: PD.Numeric;
        data: PD.BooleanParam;
        behavior: PD.BooleanParam;
        structureSelection: PD.BooleanParam;
        componentManager: PD.BooleanParam;
        animation: PD.BooleanParam;
        startAnimation: PD.BooleanParam;
        canvas3d: PD.BooleanParam;
        canvas3dContext: PD.BooleanParam;
        interactivity: PD.BooleanParam;
        camera: PD.BooleanParam;
        cameraTransition: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "instant"> | PD.NamedParams<PD.Normalize<{
            durationInMs: number;
            easing: "bounce-in" | "bounce-in-out" | "bounce-out" | "circle-in" | "circle-in-out" | "circle-out" | "cubic-in" | "cubic-in-out" | "cubic-out" | "exp-in" | "exp-in-out" | "exp-out" | "linear" | "quad-in" | "quad-in-out" | "quad-out" | "sin-in" | "sin-in-out" | "sin-out";
            trajectory: "leap" | "leap-relative" | "linear" | "linear-relative";
        }>, "animate">>;
        image: PD.BooleanParam;
    }>>>;
    setSnapshotParams: (params?: PluginState.SnapshotParams) => void;
    private readonly customState;
    /**
     * Registers state owned by a component outside the plugin's own state (for example the sequence viewer of Prism,
     * `'prism-viewer.sequence'`). `getSnapshot` writes `get()` of every registered key into `snapshot.custom`;
     * `setSnapshot` calls `set` after the data tree is applied, with `undefined` when the snapshot has no value for the
     * key (reset to defaults). Transition frames do not apply it. Returns the unregister function; registering a key
     * twice throws.
     */
    registerCustomState(key: string, entry: PluginState.CustomStateEntry): () => void;
    getSnapshot(params?: PluginState.SnapshotParams): PluginState.Snapshot;
    /**
     * Throws one error listing every transformer id used by the snapshot (behavior tree, data tree, and
     * transition frame data trees) that is not registered. Reads ids only; resolves and imports nothing.
     * Call before applying a snapshot so a failing snapshot leaves the plugin unchanged.
     */
    static validateSnapshotTransformers(snapshot: PluginState.Snapshot): void;
    /**
     * Warns for each representation type, color theme, and size theme name used by the snapshot's data tree and
     * transition frames that is not registered in the matching scope; the registry default replaces it when the data
     * tree is normalized. Reads names only and never throws for a missing name.
     * Call after the behavior tree is applied, since behaviors may register providers.
     */
    reportUnregisteredNames(snapshot: PluginState.Snapshot): void;
    setSnapshot(snapshot: PluginState.Snapshot): Promise<void>;
    /** Calls `set` of every registered custom state with the snapshot's value, or `undefined`; other keys are ignored. */
    private setCustomState;
    private settingsUpdatedTimer;
    private emitSettingsUpdated;
    setAnimationSnapshot(snapshot: PluginState.Snapshot, frameIndex: number): Promise<void>;
    updateTransform(state: State, a: StateTransform.Ref, params: any, canUndo?: string | boolean): Promise<void>;
    hasBehavior(behavior: StateTransformer | string): boolean;
    /**
     * Updates the params of a behavior. With a transformer, the behavior is inserted with default params when it is
     * absent. With a transformer id, only a behavior that is present is updated (use `hasBehavior` to check) and
     * nothing is inserted; `P` is the params type, usually an `import type` of the behavior module.
     */
    updateBehavior<T extends StateTransformer>(behavior: T, params: (old: StateTransformer.Params<T>) => void | StateTransformer.Params<T>): Promise<void>;
    updateBehavior<P = any>(behaviorId: string, params: (old: P) => void | P): Promise<void>;
    dispose(): void;
    constructor(plugin: PluginContext);
}
declare namespace PluginState {
    type CameraTransitionStyle = 'instant' | 'animate';
    const SnapshotParams: {
        durationInMs: PD.Numeric;
        data: PD.BooleanParam;
        behavior: PD.BooleanParam;
        structureSelection: PD.BooleanParam;
        componentManager: PD.BooleanParam;
        animation: PD.BooleanParam;
        startAnimation: PD.BooleanParam;
        canvas3d: PD.BooleanParam;
        canvas3dContext: PD.BooleanParam;
        interactivity: PD.BooleanParam;
        camera: PD.BooleanParam;
        cameraTransition: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "instant"> | PD.NamedParams<PD.Normalize<{
            durationInMs: number;
            easing: "bounce-in" | "bounce-in-out" | "bounce-out" | "circle-in" | "circle-in-out" | "circle-out" | "cubic-in" | "cubic-in-out" | "cubic-out" | "exp-in" | "exp-in-out" | "exp-out" | "linear" | "quad-in" | "quad-in-out" | "quad-out" | "sin-in" | "sin-in-out" | "sin-out";
            trajectory: "leap" | "leap-relative" | "linear" | "linear-relative";
        }>, "animate">>;
        image: PD.BooleanParam;
    };
    type SnapshotParams = Partial<PD.Values<typeof SnapshotParams>>;
    const DefaultSnapshotParams: PD.Values<{
        durationInMs: PD.Numeric;
        data: PD.BooleanParam;
        behavior: PD.BooleanParam;
        structureSelection: PD.BooleanParam;
        componentManager: PD.BooleanParam;
        animation: PD.BooleanParam;
        startAnimation: PD.BooleanParam;
        canvas3d: PD.BooleanParam;
        canvas3dContext: PD.BooleanParam;
        interactivity: PD.BooleanParam;
        camera: PD.BooleanParam;
        cameraTransition: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "instant"> | PD.NamedParams<PD.Normalize<{
            durationInMs: number;
            easing: "bounce-in" | "bounce-in-out" | "bounce-out" | "circle-in" | "circle-in-out" | "circle-out" | "cubic-in" | "cubic-in-out" | "cubic-out" | "exp-in" | "exp-in-out" | "exp-out" | "linear" | "quad-in" | "quad-in-out" | "quad-out" | "sin-in" | "sin-in-out" | "sin-out";
            trajectory: "leap" | "leap-relative" | "linear" | "linear-relative";
        }>, "animate">>;
        image: PD.BooleanParam;
    }>;
    interface Snapshot {
        id: UUID;
        data?: State.Snapshot;
        behaviour?: State.Snapshot;
        animation?: PluginAnimationManager.Snapshot;
        startAnimation?: boolean;
        camera?: {
            current?: Camera.Snapshot;
            focus?: SnapshotFocusInfo;
            transitionStyle: CameraTransitionStyle;
            transitionDurationInMs?: number;
            transitionEasing?: EasingKind;
            transitionTrajectory?: TransitionTrajectory;
        };
        canvas3d?: {
            props?: Canvas3DProps;
        };
        canvas3dContext?: {
            props?: Canvas3DContext.Props;
        };
        interactivity?: {
            props?: InteractivityManager.Props;
        };
        structureFocus?: StructureFocusSnapshot;
        structureSelection?: StructureSelectionSnapshot;
        structureComponentManager?: {
            options?: StructureComponentManager.Options;
        };
        durationInMs?: number;
        transition?: StateTransition;
        onLoadMarkdownCommands?: Record<string, any>;
        /**
         * Owner-keyed state registered with `PluginState.registerCustomState` (for example Prism's sequence viewer,
         * `'prism-viewer.sequence'`). Keys nobody registered are kept as they are and ignored on restore.
         */
        custom?: {
            [key: string]: unknown;
        };
    }
    interface CustomStateEntry {
        get(): unknown;
        set(value: unknown | undefined): void | Promise<void>;
    }
    interface StateTransition {
        autoplay?: boolean;
        loop?: boolean;
        frames: {
            durationInMs: number;
            data: State.Snapshot;
            camera?: Snapshot['camera'];
            canvas3d?: {
                props?: Canvas3DProps;
            };
        }[];
    }
    const getMinFrameDuration: (snapshot: Snapshot | undefined) => number;
    const getStateTransitionDuration: (snapshot: Snapshot | undefined) => number | undefined;
    const getStateTransitionFrameTime: (snapshot: Snapshot | undefined, frameIndex: number | undefined) => number;
    function getStateTransitionFrameIndex(snapshot: Snapshot, timestamp: number): number | undefined;
    type SnapshotType = 'json' | 'molj' | 'zip' | 'molx';
    interface SnapshotFocusInfo {
        targets?: SnapshotFocusTargetInfo[];
        direction?: Vec3;
        up?: Vec3;
    }
    /** Final radius to be computed as `radius ?? targetBoundingRadius * radiusFactor + extraRadius` */
    interface SnapshotFocusTargetInfo {
        /** Reference to plugin state node to focus (undefined means focus whole scene) */
        targetRef?: StateTransform.Ref;
        /** Overrides focus center defined by `targetRef` */
        center?: Vec3;
        /** Overrides focus radius defined by `targetRef` */
        radius?: number;
        /** Multiplies focus radius defined by `targetRef` */
        radiusFactor?: number;
        /** Adds to focus radius defined by `targetRef` */
        extraRadius?: number;
    }
}
//# sourceMappingURL=state.d.ts.map