/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
/**
 * Development-mode check that every registered representation has its default color and size themes registered in
 * its scope. It warns through `plugin.log.warn` and never throws, registers, or resolves anything; this module must
 * not value-import catalogs.
 */
export { checkDefaultThemes };
/**
 * Warns once per (scope, representation, theme kind, theme name) for the lifetime of `warned` (one set per plugin).
 * Returns the messages it logged.
 */
declare function checkDefaultThemes(plugin: PluginContext, warned: Set<string>): string[];
//# sourceMappingURL=registry-check.d.ts.map