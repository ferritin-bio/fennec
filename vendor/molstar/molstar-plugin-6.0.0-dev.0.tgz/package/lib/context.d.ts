/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { List } from 'immutable';
import { Subscription } from 'rxjs';
import { Canvas3D, Canvas3DContext, type PartialCanvas3DProps } from '@molstar/graphics/canvas3d/canvas3d';
import type { GraphicsBackendDescriptor } from '@molstar/graphics/gl/backend';
import { CustomProperty } from '@molstar/model/props/common/custom-property';
import type { Model, Structure } from '@molstar/model/model/structure';
import { DataBuilder } from '@molstar/plugin/state/builder/data';
import { StructureBuilder } from '@molstar/plugin/state/builder/structure';
import { DataFormatRegistry } from '@molstar/plugin/state/formats/registry';
import { StructureSelectionQueryRegistry } from '@molstar/plugin/state/queries/structure/registry';
import { PluginAnimationManager } from '@molstar/plugin/state/manager/animation';
import { CameraManager } from '@molstar/plugin/state/manager/camera';
import { InteractivityManager } from '@molstar/plugin/state/manager/interactivity';
import { type LociLabel, LociLabelManager } from '@molstar/plugin/state/manager/loci-label';
import { PluginStateSnapshotManager } from '@molstar/plugin/state/manager/snapshots';
import { StructureComponentManager } from '@molstar/plugin/state/manager/structure/component';
import { StructureFocusManager } from '@molstar/plugin/state/manager/structure/focus';
import { StructureHierarchyManager } from '@molstar/plugin/state/manager/structure/hierarchy';
import type { StructureHierarchyRef } from '@molstar/plugin/state/manager/structure/hierarchy-state';
import { StructureMeasurementManager } from '@molstar/plugin/state/manager/structure/measurement';
import { StructureSelectionManager } from '@molstar/plugin/state/manager/structure/selection';
import { ParticleHierarchyManager } from '@molstar/plugin/state/manager/particles/hierarchy';
import { VolumeHierarchyManager } from '@molstar/plugin/state/manager/volume/hierarchy';
import { MarkdownExtensionManager } from '@molstar/plugin/state/manager/markdown-extensions';
import { type LeftPanelTabName, PluginLayout } from '@molstar/plugin/layout';
import { ParticleRepresentationRegistry } from '@molstar/graphics/repr/particles/registry';
import { StructureRepresentationRegistry } from '@molstar/graphics/repr/structure/registry';
import { VolumeRepresentationRegistry } from '@molstar/graphics/repr/volume/registry';
import { RuntimeContext, Task } from '@molstar/core/task';
import type { ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import { AssetManager } from '@molstar/core/util/assets';
import { ajaxGet } from '@molstar/core/util/data-source';
import { type KeyInput } from '@molstar/core/util/input/input-observer';
import { LogEntry } from '@molstar/core/util/log-entry';
import { PluginAnimationLoop } from '@molstar/plugin/animation-loop';
import { PluginCommandManager } from '@molstar/plugin/command';
import { PluginConfigManager } from '@molstar/plugin/config';
import type { PluginRegistryEntry, PluginSpec } from '@molstar/plugin/spec';
import { PluginState } from '@molstar/plugin/state';
import { SubstructureParentHelper } from '@molstar/plugin/util/substructure-parent-helper';
import { TaskManager } from '@molstar/plugin/util/task-manager';
import { PluginToastManager } from '@molstar/plugin/util/toast';
import { ViewportScreenshotHelper } from '@molstar/plugin/util/viewport-screenshot';
import { DragAndDropManager } from '@molstar/plugin/state/manager/drag-and-drop';
import { ErrorContext } from '@molstar/core/util/error-context';
import type { Volume } from '@molstar/model/model/volume';
export type PluginInitializedState = {
    kind: 'no';
} | {
    kind: 'yes';
} | {
    kind: 'error';
    error: any;
};
export declare class PluginContext {
    spec: PluginSpec;
    runTask: <T>(task: Task<T>, params?: {
        useOverlay?: boolean;
    }) => Promise<T>;
    resolveTask: <T>(object: Task<T> | T | undefined) => Promise<T> | NonNullable<T> | undefined;
    protected subs: Subscription[];
    private initCanvas3dPromiseCallbacks;
    private _isInitialized;
    private initializedPromiseCallbacks;
    private disposed;
    private container;
    private ev;
    readonly config: PluginConfigManager;
    readonly state: PluginState;
    readonly commands: PluginCommandManager;
    private canvas3dInit;
    readonly behaviors: {
        readonly state: {
            readonly isAnimating: import("rxjs").BehaviorSubject<boolean>;
            readonly isUpdating: import("rxjs").BehaviorSubject<boolean>;
            readonly isBusy: import("rxjs").BehaviorSubject<boolean>;
        };
        readonly interaction: {
            readonly hover: import("rxjs").BehaviorSubject<InteractivityManager.HoverEvent>;
            readonly click: import("rxjs").BehaviorSubject<InteractivityManager.ClickEvent>;
            readonly drag: import("rxjs").BehaviorSubject<InteractivityManager.DragEvent>;
            readonly key: import("rxjs").BehaviorSubject<KeyInput>;
            readonly keyReleased: import("rxjs").BehaviorSubject<KeyInput>;
            readonly selectionMode: import("rxjs").BehaviorSubject<boolean>;
        };
        readonly labels: {
            readonly highlight: import("rxjs").BehaviorSubject<{
                labels: ReadonlyArray<LociLabel>;
            }>;
        };
        readonly layout: {
            readonly leftPanelTabName: import("rxjs").BehaviorSubject<LeftPanelTabName>;
        };
        readonly canvas3d: {
            readonly initialized: import("rxjs").Observable<boolean>;
        };
    };
    readonly canvas3dInitialized: Promise<void>;
    readonly initialized: Promise<void>;
    get isInitialized(): boolean;
    readonly canvas3dContext: Canvas3DContext | undefined;
    readonly canvas3d: Canvas3D | undefined;
    readonly layout: PluginLayout;
    readonly animationLoop: PluginAnimationLoop;
    readonly representation: {
        readonly structure: {
            readonly registry: StructureRepresentationRegistry;
            readonly themes: ThemeRegistryContext;
        };
        readonly volume: {
            readonly registry: VolumeRepresentationRegistry;
            readonly themes: ThemeRegistryContext;
        };
        readonly particles: {
            readonly registry: ParticleRepresentationRegistry;
            readonly themes: ThemeRegistryContext;
        };
    };
    readonly query: {
        readonly structure: {
            readonly registry: StructureSelectionQueryRegistry;
        };
    };
    readonly dataFormats: DataFormatRegistry;
    readonly builders: {
        data: DataBuilder;
        structure: StructureBuilder;
    };
    build(): import("@molstar/core/state").StateBuilder.Root;
    readonly helpers: {
        readonly substructureParent: SubstructureParentHelper;
        readonly viewportScreenshot: ViewportScreenshotHelper | undefined;
    };
    readonly managers: {
        readonly structure: {
            readonly hierarchy: StructureHierarchyManager;
            readonly component: StructureComponentManager;
            readonly measurement: StructureMeasurementManager;
            readonly selection: StructureSelectionManager;
            readonly focus: StructureFocusManager;
        };
        readonly volume: {
            readonly hierarchy: VolumeHierarchyManager;
        };
        readonly particles: {
            readonly hierarchy: ParticleHierarchyManager;
        };
        readonly interactivity: InteractivityManager;
        readonly camera: CameraManager;
        readonly animation: PluginAnimationManager;
        readonly snapshot: PluginStateSnapshotManager;
        readonly lociLabels: LociLabelManager;
        readonly toast: PluginToastManager;
        readonly asset: AssetManager;
        readonly task: TaskManager;
        readonly markdownExtensions: MarkdownExtensionManager;
        readonly dragAndDrop: DragAndDropManager;
    };
    readonly events: {
        readonly log: import("rxjs").Subject<LogEntry>;
        readonly task: {
            progress: import("rxjs").Subject<TaskManager.ProgressEvent>;
            finished: import("rxjs").Subject<{
                id: number;
            }>;
        };
        readonly canvas3d: {
            readonly settingsUpdated: import("rxjs").Subject<unknown>;
            /** after the graphics backend changed (`setGraphicsBackends`, or a fallback after a context was lost for good) */
            readonly backendChanged: import("rxjs").Subject<unknown>;
        };
    };
    readonly customModelProperties: CustomProperty.Registry<Model>;
    readonly customStructureProperties: CustomProperty.Registry<Structure>;
    readonly customVolumeProperties: CustomProperty.Registry<Volume>;
    readonly customStructureControls: Map<string, new () => any>;
    readonly customImportControls: Map<string, new () => any>;
    readonly genericRepresentationControls: Map<string, (selection: StructureHierarchyManager['selection']) => [StructureHierarchyRef[], string]>;
    /**
     * A helper for collecting and notifying errors
     * in async contexts such as custom properties.
     *
     * Individual extensions are responsible for using this
     * context and displaying the errors in appropriate ways.
     */
    readonly errorContext: ErrorContext;
    /**
     * Used to store application specific custom state which is then available
     * to State Actions and similar constructs via the PluginContext.
     */
    readonly customState: unknown;
    /**
     * Sets the canvas props and emits `events.canvas3d.settingsUpdated`, so a reader of `canvas3d.props` can follow.
     * Prefer this (or `PluginCommands.Canvas3D.SetSettings`) over `canvas3d.setProps`, which emits nothing. Not for
     * per-frame use: it emits on every call.
     */
    setCanvas3DProps(props: PartialCanvas3DProps): void;
    /** Sets the canvas context props (transparency, resolution, ...) and emits `events.canvas3d.settingsUpdated`. */
    setCanvas3DContextProps(props: Partial<Canvas3DContext.Props>): void;
    initViewerAsync(canvas: HTMLCanvasElement, container: HTMLDivElement, canvas3dContext?: Canvas3DContext): Promise<boolean>;
    initContainerAsync(options?: {
        canvas3dContext?: Canvas3DContext;
        checkeredCanvasBackground?: boolean;
    }): Promise<boolean>;
    mountAsync(target: HTMLElement, initOptions?: {
        canvas3dContext?: Canvas3DContext;
        checkeredCanvasBackground?: boolean;
    }): Promise<boolean>;
    /** The container being made: mounts while it is made (e.g. a component mounted twice) wait for the same one. */
    private containerInit?;
    private _initContainer;
    private _createContainer;
    /**
     * Mount the plugin into the target element (assumes the target has "relative"-like positioninig).
     * If initContainer wasn't called separately before, initOptions will be passed to it.
     */
    private _mount;
    unmount(): void;
    private _initViewer;
    private _graphicsBackends;
    /** The backends the context was created from (none when the context was passed in), see `setGraphicsBackends` */
    get graphicsBackends(): readonly GraphicsBackendDescriptor[];
    /**
     * Switches the graphics backend to the first of `backends` that can be created (e.g. a subset of
     * `graphicsBackends`), keeping the scene (see `Canvas3DContext.setBackend`); false, keeping the current backend, if
     * none can be created
     */
    setGraphicsBackends(backends: readonly GraphicsBackendDescriptor[]): Promise<boolean>;
    handleResize: () => void;
    readonly log: {
        entries: List<LogEntry>;
        entry: (e: LogEntry) => void;
        error: (msg: string) => void;
        message: (msg: string) => void;
        info: (msg: string) => void;
        warn: (msg: string) => void;
    };
    /**
     * This should be used in all transform related request so that it could be "spoofed" to allow
     * "static" access to resources.
     */
    readonly fetch: typeof ajaxGet;
    /** return true is animating or updating */
    get isBusy(): boolean;
    get selectionMode(): boolean;
    set selectionMode(mode: boolean);
    dataTransaction(f: (ctx: RuntimeContext) => Promise<void> | void, options?: {
        canUndo?: string | boolean;
        rethrowErrors?: boolean;
    }): Promise<void>;
    clear(resetViewportSettings?: boolean): Promise<void>;
    dispose(options?: {
        doNotForceWebGLContextLoss?: boolean;
        doNotDisposeCanvas3DContext?: boolean;
    }): void;
    private initBehaviorEvents;
    private initBuiltInBehavior;
    private initBehaviors;
    /**
     * Registers the providers of one or more entries, in the fixed order of the registry contract, and returns an
     * idempotent function that removes exactly what this call registered.
     *
     * Checks every provider against existing registrations and against each other first; on a conflict it throws one
     * error listing all of them and changes nothing. Must be called after `init()` has created the managers, which is
     * the case for `spec.registry`, behaviors, and everything that runs later.
     */
    register(entry: PluginRegistryEntry | readonly PluginRegistryEntry[]): () => void;
    private readonly warnedDefaultThemes;
    /** Development mode only: warns for registered representations whose default themes are not registered. */
    private checkDefaultThemes;
    init(): Promise<void>;
    constructor(spec: PluginSpec);
}
//# sourceMappingURL=context.d.ts.map