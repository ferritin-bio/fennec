/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import '@molstar/query-language/transpilers/all';
import '@molstar/plugin/state/transforms/catalog';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
/** Every built-in color and size theme in all three scopes, plus the external structure and volume color themes. */
export declare const DefaultThemes: PluginRegistryEntry;
export declare const DefaultStructureRepresentations: PluginRegistryEntry;
export declare const DefaultVolumeRepresentations: PluginRegistryEntry;
export declare const DefaultParticleRepresentations: PluginRegistryEntry;
export declare const DefaultActions: PluginRegistryEntry;
export declare const DefaultFormats: PluginRegistryEntry;
export declare const DefaultPresets: PluginRegistryEntry;
export declare const DefaultSelectionQueries: PluginRegistryEntry;
export declare const DefaultMarkdownExtensions: PluginRegistryEntry;
/** The open-anything handler: runs after session handling and every other handler, whatever the entry order. */
export declare const DefaultDragAndDrop: PluginRegistryEntry;
export declare const DefaultAnimations: PluginRegistryEntry;
/** The default plugin: every entry above, in registration order. */
export declare const DefaultRegistry: readonly PluginRegistryEntry[];
//# sourceMappingURL=default-registry.d.ts.map