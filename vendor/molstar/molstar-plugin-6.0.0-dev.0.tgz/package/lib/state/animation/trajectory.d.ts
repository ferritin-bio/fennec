/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { StateObject, StateTransformer } from '@molstar/core/state';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { PluginStateAnimation } from './model.js';
export declare const TrajectoryAnimationParams: {
    mode: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "palindrome"> | PD.NamedParams<PD.Normalize<{
        direction: string;
    }>, "loop"> | PD.NamedParams<PD.Normalize<{
        direction: string;
    }>, "once">>;
    duration: PD.Mapped<PD.NamedParams<PD.Normalize<{
        durationInS: number;
    }>, "fixed"> | PD.NamedParams<PD.Normalize<{
        targetFps: number;
    }>, "computed"> | PD.NamedParams<PD.Normalize<{
        maxFps: number;
    }>, "sequential">>;
    /** The refs of the frame-holding cells (`transformer`'s) to step; empty: all of them. */
    refs: PD.Base<string[] | undefined>;
};
export type TrajectoryAnimationParams = PD.ValuesFor<typeof TrajectoryAnimationParams>;
export interface TrajectoryAnimationState {
    palindromeDirections?: {
        [id: string]: -1 | 1 | undefined;
    };
}
export interface TrajectoryAnimationOptions<A extends StateTransformer, TTraj extends StateObject.Ctor> {
    name: string;
    display: {
        name: string;
    };
    /** Transformer of the state cells that hold the current per-frame index (e.g. `ModelFromTrajectory`) */
    transformer: A;
    /** Ancestor state object type that holds the trajectory data (e.g. `PluginStateObject.Molecule.Trajectory`) */
    trajectoryType: TTraj;
    /** Reason shown when there is no trajectory with more than one frame to animate */
    noTrajectoryReason: string;
    /** Number of frames available in the trajectory data */
    getFrameCount: (data: StateObject.From<TTraj>['data']) => number;
    /** Reads the current frame index from the params of a `transformer` cell */
    getFrameIndex: (params: StateTransformer.Params<A>) => number;
    /** Builds the params patch that sets a new frame index on a `transformer` cell */
    setFrameIndex: (frameIndex: number) => Partial<StateTransformer.Params<A>>;
}
/**
 * Creates an animation that steps through the frames of one or more trajectories
 * (e.g. structure models or particle lists) according to the shared
 * `TrajectoryAnimationParams` (mode + duration).
 */
export declare function createTrajectoryAnimation<A extends StateTransformer, TTraj extends StateObject.Ctor>(options: TrajectoryAnimationOptions<A, TTraj>): PluginStateAnimation<TrajectoryAnimationParams, TrajectoryAnimationState>;
//# sourceMappingURL=trajectory.d.ts.map