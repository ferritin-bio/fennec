/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateAnimation } from '../model.js';
export declare const AnimateTime: PluginStateAnimation<{
    durationInMs: number;
}, {}>;
//# sourceMappingURL=time.d.ts.map