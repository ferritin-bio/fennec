/**
 * Copyright (c) 2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateAnimation } from '../model.js';
export declare const AnimateStructureSpin: PluginStateAnimation<{
    durationInMs: number;
}, {
    t: number;
}>;
//# sourceMappingURL=spin-structure.d.ts.map