/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Camera } from '@molstar/graphics/canvas3d/camera';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { PluginStateAnimation } from '../model.js';
type State = {
    snapshot: Camera.Snapshot;
};
export declare const AnimateCameraSpin: PluginStateAnimation<{
    durationInMs: number;
    speed: number;
    axis: Vec3;
}, State | undefined>;
export {};
//# sourceMappingURL=camera-spin.d.ts.map