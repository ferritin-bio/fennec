/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export declare const AnimateModelIndex: import("../model.js").PluginStateAnimation<import("../trajectory.js").TrajectoryAnimationParams, import("../trajectory.js").TrajectoryAnimationState>;
//# sourceMappingURL=model-index.d.ts.map