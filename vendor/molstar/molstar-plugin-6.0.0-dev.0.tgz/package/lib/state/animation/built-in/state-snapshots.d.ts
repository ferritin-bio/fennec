/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { PluginStateAnimation } from '../model.js';
export declare const AnimateStateSnapshots: PluginStateAnimation<unknown, unknown>;
export declare const AnimateStateSnapshotTransition: PluginStateAnimation<unknown, unknown>;
//# sourceMappingURL=state-snapshots.d.ts.map