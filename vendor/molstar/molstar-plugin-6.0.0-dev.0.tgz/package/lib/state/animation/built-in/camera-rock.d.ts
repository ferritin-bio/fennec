/**
 * Copyright (c) 2022-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Camera } from '@molstar/graphics/canvas3d/camera';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { PluginStateAnimation } from '../model.js';
type State = {
    snapshot: Camera.Snapshot;
};
export declare const AnimateCameraRock: PluginStateAnimation<{
    durationInMs: number;
    speed: number;
    angle: number;
    axis: Vec3;
}, State | undefined>;
export {};
//# sourceMappingURL=camera-rock.d.ts.map