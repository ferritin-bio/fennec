/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const AnimateParticleTrajectory: import("../model.js").PluginStateAnimation<import("../trajectory.js").TrajectoryAnimationParams, import("../trajectory.js").TrajectoryAnimationState>;
//# sourceMappingURL=particles.d.ts.map