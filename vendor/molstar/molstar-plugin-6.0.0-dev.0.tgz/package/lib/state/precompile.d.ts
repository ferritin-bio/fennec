/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type StateTransform, type StateTransformer, StateTree } from '@molstar/core/state';
import type { Canvas3DPrecompileProps } from '@molstar/graphics/canvas3d/canvas3d';
import type { GraphicsContext } from '@molstar/graphics/gl/context';
import type { ObjectSignature, PrecompileList } from '@molstar/graphics/gl/precompile';
import type { GeometryUtils } from '@molstar/graphics/geo/geometry/geometry';
import { type SignatureContext } from '@molstar/graphics/repr/signatures';
import type { Representation, RepresentationContext, RepresentationProvider } from '@molstar/graphics/repr/representation';
import type { ThemeRegistryContext } from '@molstar/graphics/theme/theme';
import type { PluginContext } from '../context.js';
import type { PluginState } from '../state.js';
/** What a transform's signatures are derived in: the plugin (registries), the context and the transform's place */
export interface TransformSignatureContext {
    readonly plugin: PluginContext;
    readonly graphics?: GraphicsContext;
    /** the layers set on the transform's representation by its children (overpaint, transparency, ...) */
    readonly layers: SignatureContext['layers'];
    readonly tree: StateTree;
    readonly transform: StateTransform;
}
/** The signatures of the objects a transform with `params` may create, without its data, see `getGeometrySignatures` */
export type TransformSignatures = (params: any, ctx: TransformSignatureContext) => ObjectSignature[];
type Layer = keyof SignatureContext['layers'];
/** Registers how the signatures of `transformer`'s objects are derived from its params */
export declare function registerTransformSignatures(transformer: StateTransformer, signatures: TransformSignatures): void;
/** Registers `transformer` as one that sets `layer` on its parent representation */
export declare function registerTransformLayer(transformer: StateTransformer, layer: Layer): void;
/**
 * The signatures of the objects the representations of `tree` may create, from their params alone (no data, nothing
 * built): what `Canvas3D.precompile` prepares before the tree is applied. Transforms without registered signatures
 * (`registerTransformSignatures`) are left out; their objects compile when first drawn
 */
export declare function getTreePrecompileList(plugin: PluginContext, tree: StateTree, cache?: Map<string, ObjectSignature[]>): PrecompileList;
/**
 * The list of `snapshots` (`getTreePrecompileList` of each state tree, and of the frames of their transitions, e.g. an
 * opacity animated) and the props their frames draw with, for `Canvas3D.precompile`
 */
export declare function getSnapshotsPrecompileList(plugin: PluginContext, snapshots: readonly PluginState.Snapshot[]): {
    list: PrecompileList;
    props: Canvas3DPrecompileProps[];
};
/**
 * Prepares what playing `snapshots` draws (`getSnapshotsPrecompileList`, `Canvas3D.precompile`), e.g. when a state or a
 * story is loaded; meant to run in the background (pending work), resolves when ready
 */
export declare function precompileSnapshots(plugin: PluginContext, snapshots: readonly PluginState.Snapshot[]): Promise<void>;
/**
 * The signatures of a representation from a registry with `params` (type, color and size themes, as the representation
 * transforms take them), created without data
 */
export declare function getRepresentationSignatures(provider: RepresentationProvider<any, any, any> | undefined, themes: ThemeRegistryContext, params: {
    type: {
        name: string;
        params?: any;
    };
    colorTheme?: {
        name: string;
        params: any;
    };
    sizeTheme?: any;
}, ctx: TransformSignatureContext): ObjectSignature[];
/** The geometries of the shapes a transform provides (`SO.Shape.Provider`) with `params` */
export type ShapeGeometries = (params: any) => GeometryUtils<any>[];
/** Registers the geometries of the shapes `transformer` provides, for the signatures of their representations */
export declare function registerShapeGeometry(transformer: StateTransformer, geometries: ShapeGeometries): void;
/**
 * The signatures of a shape representation with `params` of the shapes `provider` (its parent transform) gives, colored
 * and sized by shape group (see `ShapeRepresentation`)
 */
export declare function getShapeSignatures(provider: StateTransform | undefined, params: any, ctx: TransformSignatureContext): ObjectSignature[];
/**
 * The signatures of a representation of shapes (e.g. a measurement's) that `create` makes, with `params`, created
 * without data
 */
export declare function getShapeRepresentationSignatures(create: (ctx: RepresentationContext) => Representation<any, any>, params: any, ctx: TransformSignatureContext): ObjectSignature[];
export {};
//# sourceMappingURL=precompile.d.ts.map