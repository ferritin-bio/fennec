/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { PluginComponent } from '../../component.js';
import { ParticleHierarchy, type ParticleHierarchyRef, type ParticleListRef } from './hierarchy-state.js';
export declare class ParticleHierarchyManager extends PluginComponent {
    private plugin;
    private state;
    readonly behaviors: {
        selection: import("rxjs").BehaviorSubject<{
            hierarchy: ParticleHierarchy;
            list: ParticleListRef | undefined;
        }>;
    };
    private get dataState();
    get current(): ParticleHierarchy;
    get selection(): ParticleListRef | undefined;
    private sync;
    setCurrent(list?: ParticleListRef): void;
    remove(refs: (ParticleHierarchyRef | string)[], canUndo?: boolean): Promise<void> | undefined;
    toggleVisibility(refs: ReadonlyArray<ParticleHierarchyRef>, action?: 'show' | 'hide'): void;
    addRepresentation(ref: ParticleListRef, type: string): Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
    constructor(plugin: PluginContext);
}
export declare namespace ParticleHierarchyManager {
    function getRepresentationTypes(plugin: PluginContext, pivot: ParticleListRef | undefined): [string, string][];
}
//# sourceMappingURL=hierarchy.d.ts.map