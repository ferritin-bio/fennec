/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '../../objects.js';
import type { ParticlesRepresentation3D } from '@molstar/plugin/state/transforms/particles/representation';
import { StateObject, StateTransform, State, StateObjectCell, StateTransformer } from '@molstar/core/state';
export declare function buildParticleHierarchy(state: State, previous?: ParticleHierarchy): {
    hierarchy: ParticleHierarchy;
    added: Set<string>;
    changed: boolean;
};
export interface ParticleHierarchy {
    lists: ParticleListRef[];
    refs: Map<StateTransform.Ref, ParticleHierarchyRef>;
}
export declare function ParticleHierarchy(): ParticleHierarchy;
interface RefBase<K extends string = string, O extends StateObject = StateObject, T extends StateTransformer = StateTransformer> {
    kind: K;
    cell: StateObjectCell<O, StateTransform<T>>;
    version: StateTransform['version'];
}
export type ParticleHierarchyRef = ParticleListRef | ParticleRepresentationRef;
export interface ParticleListRef extends RefBase<'particle-list', SO.Particle.List> {
    representations: ParticleRepresentationRef[];
}
export interface ParticleRepresentationRef extends RefBase<'particle-representation', SO.Particle.Representation3D, typeof ParticlesRepresentation3D> {
    list: ParticleListRef;
}
export {};
//# sourceMappingURL=hierarchy-state.d.ts.map