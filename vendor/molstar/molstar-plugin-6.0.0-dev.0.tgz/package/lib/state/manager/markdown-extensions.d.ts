/**
 * Copyright (c) 2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StateObjectCell } from '@molstar/core/state';
import type { PluginContext } from '@molstar/plugin/context';
import { BehaviorSubject } from 'rxjs';
export type MarkdownExtensionEvent = 'click' | 'mouse-enter' | 'mouse-leave';
export interface MarkdownExtension {
    name: string;
    execute?: (options: {
        event: MarkdownExtensionEvent;
        args: Record<string, string>;
        manager: MarkdownExtensionManager;
    }) => void;
    reactRenderFn?: (options: {
        args: Record<string, string>;
        manager: MarkdownExtensionManager;
    }) => any;
}
export declare class MarkdownExtensionManager {
    plugin: PluginContext;
    state: {
        audioPlayer: BehaviorSubject<HTMLAudioElement | null>;
    };
    private extension;
    /** Registration counts by extension name */
    private extensionCounts;
    private refResolvers;
    private uriResolvers;
    private argsParsers;
    /**
     * Default parser has priority 100, parsers with higher priority
     * will be called first.
     */
    registerArgsParser(name: string, priority: number, parser: (input: string | undefined) => Record<string, string> | undefined): void;
    removeArgsParser(name: string): void;
    parseArgs(input: string | undefined): Record<string, string> | undefined;
    registerRefResolver(name: string, resolver: (plugin: PluginContext, refs: string[]) => StateObjectCell[]): void;
    removeRefResolver(name: string): void;
    registerUriResolver(name: string, resolver: (plugin: PluginContext, uri: string) => Promise<string> | string | undefined): void;
    removeUriResolver(name: string): void;
    /** Returns the message `registerExtension` would throw for `command`, without changing anything. */
    findConflict(command: MarkdownExtension): string | undefined;
    /**
     * Extensions are keyed by `name`. Registering the same object again increments a count,
     * a different object under an existing name throws.
     */
    registerExtension(command: MarkdownExtension): void;
    /**
     * Decrements the count of the extension (given by name or object) and removes it at zero.
     * No-op for an unknown name, or for an object that is not the one registered under its name.
     */
    removeExtension(nameOrExtension: string | MarkdownExtension): void;
    private _tryRender;
    /**
     * Render a markdown extension with the given arguments.
     * Default renderers are defined separately because we
     * don't want to include `react` outside of mol-plugin-ui.
     */
    tryRender(args: Record<string, string>, defaultRenderers: MarkdownExtension[]): any;
    tryExecute(event: MarkdownExtensionEvent, args: Record<string, string>): void;
    tryResolveUri(uri: string): Promise<string> | string | undefined;
    findCells(refs: string[]): StateObjectCell[];
    private resolveAudioPlayer;
    get audioPlayer(): HTMLAudioElement | null;
    audio: {
        play: (src: string, options?: {
            toggle?: boolean;
        }) => Promise<void>;
        pause: () => void;
        stop: () => void;
        dispose: () => void;
    };
    constructor(plugin: PluginContext);
}
export declare function defaultParseMarkdownCommandArgs(input: string | undefined): Record<string, string> | undefined;
//# sourceMappingURL=markdown-extensions.d.ts.map