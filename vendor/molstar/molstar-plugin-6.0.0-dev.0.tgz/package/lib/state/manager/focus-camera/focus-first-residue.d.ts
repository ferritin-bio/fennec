import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import type { PluginContext } from '@molstar/plugin/context';
import { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import type { StructureComponentRef } from '../structure/hierarchy-state.js';
import { Camera } from '@molstar/graphics/canvas3d/camera';
export declare function pcaFocus(plugin: PluginContext, radius: number, options: {
    principalAxes: PrincipalAxes;
    positionToFlip?: Vec3;
}): Partial<Camera.Snapshot> | undefined;
interface PcaTransformData {
    principalAxes: PrincipalAxes;
    positionToFlip: Vec3;
}
export declare function getPcaTransform(group: StructureComponentRef[]): PcaTransformData | undefined;
export {};
//# sourceMappingURL=focus-first-residue.d.ts.map