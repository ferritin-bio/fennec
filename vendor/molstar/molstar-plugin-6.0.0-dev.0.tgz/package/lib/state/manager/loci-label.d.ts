/**
 * Copyright (c) 2018-2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { Loci } from '@molstar/model/model/loci';
import { Representation } from '@molstar/graphics/repr/representation';
export type LociLabel = string | any;
export type LociLabelProvider = {
    label: (loci: Loci, repr?: Representation<any>) => LociLabel | undefined;
    group?: (entry: LociLabel) => string;
    /** Labels from providers with higher priority are shown first */
    priority?: number;
};
export declare class LociLabelManager {
    ctx: PluginContext;
    providers: LociLabelProvider[];
    /** Registration counts by provider identity */
    private counts;
    /** Drops all providers and their counts. */
    clearProviders(): void;
    /** Providers have no key, so registration never conflicts. */
    findConflict(_provider: LociLabelProvider): string | undefined;
    /** Registering the same provider again increments its count. */
    addProvider(provider: LociLabelProvider): void;
    /** Decrements the count and removes the provider at zero; no-op for an unknown provider. */
    removeProvider(provider: LociLabelProvider): void;
    /**
     * Labels the current highlights again: for a provider whose label depends on more than the loci (what a linked view
     * hovers over the same residue) when that changed and the highlight did not. Nothing highlighted: nothing sent.
     */
    refresh(): void;
    private locis;
    private mark;
    private isDirty;
    private labels;
    private groupedLabels;
    private showLabels;
    private getLabels;
    constructor(ctx: PluginContext);
}
//# sourceMappingURL=loci-label.d.ts.map