/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { StatefulPluginComponent } from '../component.js';
import type { PluginContext } from '@molstar/plugin/context';
import type { PluginStateAnimation } from '../animation/model.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export { PluginAnimationManager };
declare class PluginAnimationManager extends StatefulPluginComponent<PluginAnimationManager.State> {
    private context;
    private map;
    private _animations;
    /** Registration counts by name; 0 for an animation `play` added on demand */
    private counts;
    private currentTime;
    private _current;
    private _params?;
    readonly events: {
        updated: import("rxjs").Subject<unknown>;
        applied: import("rxjs").Subject<unknown>;
    };
    get isEmpty(): boolean;
    /** The selected animation, or `undefined` when none is registered. */
    get current(): PluginAnimationManager.Current | undefined;
    get animations(): PluginStateAnimation<any, any>[];
    get isAnimatingStateTransition(): boolean;
    private triggerUpdate;
    private triggerApply;
    getParams(): PD.Params;
    updateParams(newParams: Partial<PluginAnimationManager.State['params']>): void;
    updateCurrentParams(values: any): void;
    /** Returns the message `register` would throw for `animation`, without changing anything. */
    findConflict(animation: PluginStateAnimation): string | undefined;
    /**
     * Animations are keyed by `name`. Registering the same object again increments a count,
     * a different object under an existing name throws.
     */
    register(animation: PluginStateAnimation): void;
    /**
     * Decrements the count and removes the animation at zero. No-op for an unknown animation
     * and for one that `play` added on demand. Removing the current animation selects the first remaining one,
     * or none, and resets the cached params.
     */
    unregister(animation: PluginStateAnimation): void;
    private add;
    private remove;
    play<P>(animation: PluginStateAnimation<P>, params: P): Promise<void>;
    tick(t: number, isSynchronous?: boolean, animation?: PluginAnimationManager.AnimationInfo): Promise<void>;
    private isStopped;
    private isApplying;
    /** The frame being applied (`applyAsync`): `stop` waits for it, so what comes after (a snapshot) is not overwritten. */
    private applying;
    start(): Promise<void>;
    stop(): Promise<void>;
    stopStateTransitionAnimation(): Promise<void> | undefined;
    get isAnimating(): boolean;
    private applyAsync;
    private applyFrame;
    getSnapshot(): PluginAnimationManager.Snapshot;
    setSnapshot(snapshot: PluginAnimationManager.Snapshot): void;
    private resume;
    constructor(context: PluginContext);
}
declare namespace PluginAnimationManager {
    interface AnimationInfo {
        currentFrame: number;
        frameCount: number;
    }
    interface Current {
        anim: PluginStateAnimation;
        params: PD.Params;
        paramValues: any;
        state: any;
        startedTime: number;
        lastTime: number;
    }
    interface State {
        params: {
            current: string;
        };
        animationState: 'stopped' | 'playing';
    }
    interface Snapshot {
        state: State;
        current?: {
            paramValues: any;
            state: any;
        };
    }
}
//# sourceMappingURL=animation.d.ts.map