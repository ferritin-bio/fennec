/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { Loci } from '@molstar/model/model/loci';
import type { PluginContext } from '@molstar/plugin/context';
import { Representation } from '@molstar/graphics/repr/representation';
import type { ButtonsType, ModifiersKeys } from '@molstar/core/util/input/input-observer';
import { MarkerAction } from '@molstar/core/util/marker-action';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StatefulPluginComponent } from '../component.js';
import type { StructureSelectionManager } from './structure/selection.js';
import type { Vec2, Vec3 } from '@molstar/core/math/linear-algebra';
export { InteractivityManager };
interface InteractivityManagerState {
    props: PD.ValuesFor<InteractivityManager.Params>;
}
declare const DefaultInteractivityFocusOptions: {
    minRadius: number;
    extraRadius: number;
    durationMs: number;
};
export type InteractivityFocusLociOptions = typeof DefaultInteractivityFocusOptions;
declare class InteractivityManager extends StatefulPluginComponent<InteractivityManagerState> {
    readonly plugin: PluginContext;
    readonly lociSelects: InteractivityManager.LociSelectManager;
    readonly lociHighlights: InteractivityManager.LociHighlightManager;
    private _props;
    readonly events: {
        propsUpdated: import("rxjs").Subject<unknown>;
    };
    get props(): Readonly<InteractivityManagerState['props']>;
    setProps(props: Partial<InteractivityManager.Props>): void;
    dispose(): void;
    constructor(plugin: PluginContext, props?: Partial<InteractivityManager.Props>);
}
declare namespace InteractivityManager {
    const Params: {
        granularity: PD.Select<"chain" | "chainInstances" | "element" | "elementInstances" | "entity" | "model" | "operator" | "residue" | "residueInstances" | "structure">;
    };
    type Params = typeof Params;
    type Props = PD.Values<Params>;
    interface HoverEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        page?: Vec2;
        position?: Vec3;
    }
    interface DragEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        pageStart: Vec2;
        pageEnd: Vec2;
    }
    interface ClickEvent {
        current: Representation.Loci;
        buttons: ButtonsType;
        button: ButtonsType.Flag;
        modifiers: ModifiersKeys;
        page?: Vec2;
        position?: Vec3;
    }
    /**
     * The `noRender` argument indicates that the action should only update the internal
     * data structure but not render anything user visible. For example, no ui update of
     * loci labels.
     *
     * This is useful because some actions require clearing any markings before
     * they can be applied.
     */
    type LociMarkProvider = (loci: Representation.Loci, action: MarkerAction, noRender?: boolean) => void;
    abstract class LociMarkManager {
        readonly ctx: PluginContext;
        protected providers: LociMarkProvider[];
        protected sel: StructureSelectionManager;
        readonly props: Readonly<Props>;
        setProps(props: Partial<Props>): void;
        addProvider(provider: LociMarkProvider): void;
        removeProvider(provider: LociMarkProvider): void;
        protected normalizedLoci(reprLoci: Representation.Loci, applyGranularity: boolean, alwaysConvertBonds?: boolean): {
            loci: Loci;
            repr: Representation.Any<PD.Params, Representation.State> | undefined;
        };
        protected mark(current: Representation.Loci, action: MarkerAction, noRender?: boolean): void;
        dispose(): void;
        constructor(ctx: PluginContext, props?: Partial<Props>);
    }
    class LociHighlightManager extends LociMarkManager {
        private prev;
        private isHighlighted;
        private addHighlight;
        clearHighlights: (noRender?: boolean) => void;
        highlight(current: Representation.Loci, applyGranularity?: boolean): void;
        highlightOnly(current: Representation.Loci, applyGranularity?: boolean): void;
        highlightOnlyExtend(current: Representation.Loci, applyGranularity?: boolean): void;
        dispose(): void;
    }
    class LociSelectManager extends LociMarkManager {
        toggle(current: Representation.Loci, applyGranularity?: boolean): void;
        toggleExtend(current: Representation.Loci, applyGranularity?: boolean): void;
        select(current: Representation.Loci, applyGranularity?: boolean): void;
        selectJoin(current: Representation.Loci, applyGranularity?: boolean): void;
        selectOnly(current: Representation.Loci, applyGranularity?: boolean): void;
        deselect(current: Representation.Loci, applyGranularity?: boolean): void;
        deselectAll(): void;
        deselectAllOnEmpty(current: Representation.Loci): void;
        protected mark(current: Representation.Loci, action: MarkerAction.Select | MarkerAction.Deselect): void;
        private toggleSel;
    }
}
//# sourceMappingURL=interactivity.d.ts.map