/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { PluginComponent } from '../../component.js';
import { VolumeHierarchy, type VolumeHierarchyRef, type VolumeRef } from './hierarchy-state.js';
export declare class VolumeHierarchyManager extends PluginComponent {
    private plugin;
    private state;
    readonly behaviors: {
        selection: import("rxjs").BehaviorSubject<{
            hierarchy: VolumeHierarchy;
            volume: VolumeRef | undefined;
        }>;
    };
    private get dataState();
    get current(): VolumeHierarchy;
    get selection(): VolumeRef | undefined;
    private sync;
    setCurrent(volume?: VolumeRef): void;
    remove(refs: (VolumeHierarchyRef | string)[], canUndo?: boolean): Promise<void> | undefined;
    toggleVisibility(refs: ReadonlyArray<VolumeHierarchyRef>, action?: 'show' | 'hide'): void;
    addRepresentation(ref: VolumeRef, type: string): Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
    constructor(plugin: PluginContext);
}
export declare namespace VolumeHierarchyManager {
    function getRepresentationTypes(plugin: PluginContext, pivot: VolumeRef | undefined): [string, string][];
}
//# sourceMappingURL=hierarchy.d.ts.map