/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import { Loci } from '@molstar/model/model/loci';
import { Structure, StructureElement, StructureQuery } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import { StateObjectRef } from '@molstar/core/state';
import { StatefulPluginComponent } from '../../component.js';
import type { StructureSelectionQuery } from '@molstar/plugin/state/queries/structure/query';
import { PluginStateObject as PSO } from '../../objects.js';
import { UUID } from '@molstar/core/util';
import type { StructureRef } from './hierarchy-state.js';
interface StructureSelectionManagerState {
    entries: Map<string, SelectionEntry>;
    additionsHistory: StructureSelectionHistoryEntry[];
    stats?: SelectionStats;
}
export type StructureSelectionModifier = 'add' | 'remove' | 'intersect' | 'set';
export type StructureSelectionSnapshot = {
    entries: {
        ref: string;
        bundle: StructureElement.Bundle;
    }[];
};
export declare class StructureSelectionManager extends StatefulPluginComponent<StructureSelectionManagerState> {
    private plugin;
    readonly events: {
        changed: import("rxjs").Subject<undefined>;
        additionsHistoryUpdated: import("rxjs").Subject<undefined>;
        loci: {
            add: import("rxjs").Subject<StructureElement.Loci>;
            remove: import("rxjs").Subject<StructureElement.Loci>;
            clear: import("rxjs").Subject<undefined>;
        };
    };
    private referenceLoci;
    get entries(): Map<string, SelectionEntry>;
    get additionsHistory(): StructureSelectionHistoryEntry[];
    get stats(): SelectionStats;
    private getEntry;
    private calcStats;
    private add;
    private remove;
    private intersect;
    private set;
    modifyHistory(entry: StructureSelectionHistoryEntry, action: 'remove' | 'up' | 'down', modulus?: number, groupByStructure?: boolean): void;
    private tryAddHistory;
    private clearHistory;
    private clearHistoryForStructure;
    private onRemove;
    private onUpdate;
    /** Removes all selections and returns them */
    clear(): StructureElement.Loci[];
    getLoci(structure: Structure): StructureElement.Loci | {
        kind: 'empty-loci';
    };
    getStructure(structure: Structure): Structure | undefined;
    structureHasSelection(structure: StructureRef): boolean;
    has(loci: Loci): boolean;
    tryGetRange(loci: Loci): StructureElement.Loci | undefined;
    /** Count of all selected elements */
    elementCount(): number;
    getBoundary(): {
        box: {
            min: Vec3;
            max: Vec3;
        };
        sphere: import("@molstar/core/math/geometry").Sphere3D;
    };
    getPrincipalAxes(): PrincipalAxes;
    modify(modifier: StructureSelectionModifier, loci: Loci): void;
    private get applicableStructures();
    private triggerInteraction;
    fromLoci(modifier: StructureSelectionModifier, loci: Loci, applyGranularity?: boolean): void;
    fromCompiledQuery(modifier: StructureSelectionModifier, query: StructureQuery, applyGranularity?: boolean): void;
    fromSelectionQuery(modifier: StructureSelectionModifier, query: StructureSelectionQuery, applyGranularity?: boolean): void;
    fromSelections(ref: StateObjectRef<PSO.Molecule.Structure.Selections>): void;
    getSnapshot(): StructureSelectionSnapshot;
    setSnapshot(snapshot: StructureSelectionSnapshot): void;
    constructor(plugin: PluginContext);
}
interface SelectionStats {
    structureCount: number;
    elementCount: number;
    label: string;
}
declare function SelectionStats(): SelectionStats;
declare class SelectionEntry {
    private _selection;
    private _structure?;
    get selection(): StructureElement.Loci;
    set selection(value: StructureElement.Loci);
    get structure(): Structure | undefined;
    constructor(selection: StructureElement.Loci);
}
export interface StructureSelectionHistoryEntry {
    id: UUID;
    loci: StructureElement.Loci;
    label: string;
}
/** Return loci spanning the range between `fromLoci` and `toLoci` (including both) if they belong to the same unit in the same structure */
export declare function getLociRange(fromLoci: Loci | undefined, toLoci: Loci | undefined): StructureElement.Loci | undefined;
export {};
//# sourceMappingURL=selection.d.ts.map