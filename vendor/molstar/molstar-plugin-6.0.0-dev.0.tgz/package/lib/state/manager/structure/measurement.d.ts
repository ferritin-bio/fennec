/**
 * Copyright (c) 2019-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ryan DiRisio <rjdiris@gmail.com>
 */
import { StructureElement } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import { StateTransform, StateTransformer, StateObject, StateObjectCell } from '@molstar/core/state';
import { StructureSelectionsAngle3D, StructureSelectionsDihedral3D, StructureSelectionsDistance3D, StructureSelectionsLabel3D } from '@molstar/plugin/state/transforms/structure/measurement';
import { PluginStateObject } from '../../objects.js';
import { StatefulPluginComponent } from '../../component.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { LociLabelTextParams } from '@molstar/graphics/repr/shape/loci/common';
import type { LineParams } from '@molstar/graphics/repr/structure/representation/line';
import { Color } from '@molstar/core/util/color';
export { StructureMeasurementManager };
export declare const MeasurementGroupTag = "measurement-group";
export declare const MeasurementOrderLabelTag = "measurement-order-label";
export type StructureMeasurementCell = StateObjectCell<PluginStateObject.Shape.Representation3D, StateTransform<StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, any>>>;
export declare const StructureMeasurementParams: {
    distanceUnitLabel: PD.Text<string>;
    textColor: PD.Color;
};
export type StructureMeasurementOptions = PD.ValuesFor<typeof StructureMeasurementParams>;
export interface StructureMeasurementManagerState {
    labels: StructureMeasurementCell[];
    distances: StructureMeasurementCell[];
    angles: StructureMeasurementCell[];
    dihedrals: StructureMeasurementCell[];
    orientations: StructureMeasurementCell[];
    planes: StructureMeasurementCell[];
    options: StructureMeasurementOptions;
}
type StructureMeasurementManagerAddOptions = {
    customText?: string;
    selectionTags?: string | string[];
    reprTags?: string | string[];
    lineParams?: Partial<PD.Values<LineParams>>;
    labelParams?: Partial<PD.Values<LociLabelTextParams>>;
};
declare class StructureMeasurementManager extends StatefulPluginComponent<StructureMeasurementManagerState> {
    private plugin;
    readonly behaviors: {
        state: import("rxjs").BehaviorSubject<StructureMeasurementManagerState>;
    };
    private stateUpdated;
    private getGroup;
    setOptions(options: StructureMeasurementOptions): Promise<void>;
    addDistance(a: StructureElement.Loci, b: StructureElement.Loci, options?: StructureMeasurementManagerAddOptions & {
        visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsDistance3D>>;
    }): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
            fontQuality: number;
            fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
            fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
            fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
            sizeFactor: number;
            borderColor: Color;
            offsetX: number;
            offsetY: number;
            offsetZ: number;
            background: boolean;
            backgroundMargin: number;
            backgroundColor: Color;
            backgroundOpacity: number;
            tether: boolean;
            tetherLength: number;
            tetherBaseWidth: number;
            attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
            animation: PD.Normalize<{
                wiggleMode: "group" | "position";
                wiggleSpeed: number;
                wiggleAmplitude: number;
                wiggleFrequency: number;
                tumbleSpeed: number;
                tumbleAmplitude: number;
                tumbleFrequency: number;
            }>;
            customText: string;
            textColor: Color;
            textSize: number;
            borderWidth: number;
            unitLabel: string;
            lineSizeAttenuation: boolean;
            linesColor: Color;
            linesSize: number;
            dashLength: number;
            visuals: ("lines" | "text")[];
        }>>>;
    } | undefined>;
    addAngle(a: StructureElement.Loci, b: StructureElement.Loci, c: StructureElement.Loci, options?: StructureMeasurementManagerAddOptions & {
        visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsAngle3D>>;
    }): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            doubleSided: boolean;
            flipSided: boolean;
            flatShaded: boolean;
            celShaded: boolean;
            xrayShaded: "inverted" | boolean;
            transparentBackfaces: "off" | "on" | "opaque";
            solidInterior: boolean;
            bumpFrequency: number;
            bumpAmplitude: number;
            interior: PD.Normalize<{
                color: import("@molstar/core/util/color/color").Color;
                colorStrength: number;
                substance: PD.Normalize<{
                    metalness: number;
                    roughness: number;
                    bumpiness: number;
                }>;
                substanceStrength: number;
            }>;
            animation: PD.Normalize<{
                wiggleMode: "group" | "position";
                wiggleSpeed: number;
                wiggleAmplitude: number;
                wiggleFrequency: number;
                tumbleSpeed: number;
                tumbleAmplitude: number;
                tumbleFrequency: number;
            }>;
            fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
            fontQuality: number;
            fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
            fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
            fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
            sizeFactor: number;
            borderColor: Color;
            offsetX: number;
            offsetY: number;
            offsetZ: number;
            background: boolean;
            backgroundMargin: number;
            backgroundColor: Color;
            backgroundOpacity: number;
            tether: boolean;
            tetherLength: number;
            tetherBaseWidth: number;
            attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
            customText: string;
            textColor: Color;
            textSize: number;
            borderWidth: number;
            color: Color;
            arcScale: number;
            lineSizeAttenuation: boolean;
            linesSize: number;
            dashLength: number;
            ignoreLight: boolean;
            sectorOpacity: number;
            visuals: ("arc" | "sector" | "text" | "vectors")[];
        }>>>;
    } | undefined>;
    addDihedral(a: StructureElement.Loci, b: StructureElement.Loci, c: StructureElement.Loci, d: StructureElement.Loci, options?: StructureMeasurementManagerAddOptions & {
        visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsDihedral3D>>;
    }): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            doubleSided: boolean;
            flipSided: boolean;
            flatShaded: boolean;
            celShaded: boolean;
            xrayShaded: "inverted" | boolean;
            transparentBackfaces: "off" | "on" | "opaque";
            solidInterior: boolean;
            bumpFrequency: number;
            bumpAmplitude: number;
            interior: PD.Normalize<{
                color: import("@molstar/core/util/color/color").Color;
                colorStrength: number;
                substance: PD.Normalize<{
                    metalness: number;
                    roughness: number;
                    bumpiness: number;
                }>;
                substanceStrength: number;
            }>;
            animation: PD.Normalize<{
                wiggleMode: "group" | "position";
                wiggleSpeed: number;
                wiggleAmplitude: number;
                wiggleFrequency: number;
                tumbleSpeed: number;
                tumbleAmplitude: number;
                tumbleFrequency: number;
            }>;
            fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
            fontQuality: number;
            fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
            fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
            fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
            sizeFactor: number;
            borderColor: Color;
            offsetX: number;
            offsetY: number;
            offsetZ: number;
            background: boolean;
            backgroundMargin: number;
            backgroundColor: Color;
            backgroundOpacity: number;
            tether: boolean;
            tetherLength: number;
            tetherBaseWidth: number;
            attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
            customText: string;
            textColor: Color;
            textSize: number;
            borderWidth: number;
            color: Color;
            arcScale: number;
            lineSizeAttenuation: boolean;
            linesSize: number;
            dashLength: number;
            ignoreLight: boolean;
            sectorOpacity: number;
            visuals: ("arc" | "arms" | "connector" | "extenders" | "sector" | "text" | "vectors")[];
        }>>>;
    } | undefined>;
    addLabel(a: StructureElement.Loci, options?: Omit<StructureMeasurementManagerAddOptions, 'customText' | 'lineParams'> & {
        visualParams?: Partial<StateTransformer.Params<typeof StructureSelectionsLabel3D>>;
    }): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
            fontQuality: number;
            fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
            fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
            fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
            sizeFactor: number;
            borderColor: Color;
            offsetX: number;
            offsetY: number;
            offsetZ: number;
            background: boolean;
            backgroundMargin: number;
            backgroundColor: Color;
            backgroundOpacity: number;
            tether: boolean;
            tetherLength: number;
            tetherBaseWidth: number;
            attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
            customText: string;
            textColor: Color;
            textSize: number;
            borderWidth: number;
            scaleByRadius: boolean;
            visuals: "text"[];
            snapshotKey: string;
            tooltip: string;
        }>>>;
    } | undefined>;
    addOrientation(locis: StructureElement.Loci[]): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            doubleSided: boolean;
            flipSided: boolean;
            flatShaded: boolean;
            ignoreLight: boolean;
            celShaded: boolean;
            xrayShaded: "inverted" | boolean;
            transparentBackfaces: "off" | "on" | "opaque";
            solidInterior: boolean;
            bumpFrequency: number;
            bumpAmplitude: number;
            interior: PD.Normalize<{
                color: import("@molstar/core/util/color/color").Color;
                colorStrength: number;
                substance: PD.Normalize<{
                    metalness: number;
                    roughness: number;
                    bumpiness: number;
                }>;
                substanceStrength: number;
            }>;
            animation: PD.Normalize<{
                wiggleMode: "group" | "position";
                wiggleSpeed: number;
                wiggleAmplitude: number;
                wiggleFrequency: number;
                tumbleSpeed: number;
                tumbleAmplitude: number;
                tumbleFrequency: number;
            }>;
            color: Color;
            scaleFactor: number;
            radiusScale: number;
            visuals: ("axes" | "box" | "ellipsoid")[];
        }>>>;
    } | undefined>;
    addPlane(locis: StructureElement.Loci[]): Promise<{
        selection: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure.Selections, StateTransformer<PluginStateObject.Root, PluginStateObject.Molecule.Structure.Selections, PD.Normalize<{
            selections: PD.Normalize<{
                key: /*elided*/ any;
                ref: /*elided*/ any;
                groupId: /*elided*/ any;
                bundle: /*elided*/ any;
            }>[];
            isTransitive: boolean | undefined;
            label: string | undefined;
        }>>>;
        representation: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<PluginStateObject.Molecule.Structure.Selections, PluginStateObject.Shape.Representation3D, PD.Normalize<{
            alpha: number;
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            clip: PD.Normalize<{
                variant: import("@molstar/core/util/clip").Clip.Variant;
                objects: PD.Normalize<{
                    type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                    invert: boolean;
                    position: import("@molstar/core/math/linear-algebra").Vec3;
                    rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
                    scale: import("@molstar/core/math/linear-algebra").Vec3;
                    transform: import("@molstar/core/math/linear-algebra").Mat4;
                }>[];
            }>;
            emissive: number;
            density: number;
            instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
            renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
            lod: import("@molstar/core/math/linear-algebra").Vec3;
            cellSize: number;
            batchSize: number;
            doubleSided: boolean;
            flipSided: boolean;
            flatShaded: boolean;
            ignoreLight: boolean;
            celShaded: boolean;
            xrayShaded: "inverted" | boolean;
            transparentBackfaces: "off" | "on" | "opaque";
            solidInterior: boolean;
            bumpFrequency: number;
            bumpAmplitude: number;
            interior: PD.Normalize<{
                color: import("@molstar/core/util/color/color").Color;
                colorStrength: number;
                substance: PD.Normalize<{
                    metalness: number;
                    roughness: number;
                    bumpiness: number;
                }>;
                substanceStrength: number;
            }>;
            animation: PD.Normalize<{
                wiggleMode: "group" | "position";
                wiggleSpeed: number;
                wiggleAmplitude: number;
                wiggleFrequency: number;
                tumbleSpeed: number;
                tumbleAmplitude: number;
                tumbleFrequency: number;
            }>;
            color: Color;
            scaleFactor: number;
            variant: "circle" | "rectangle";
            radialSegments: number;
            visuals: "plane"[];
        }>>>;
    } | undefined>;
    addOrderLabels(locis: StructureElement.Loci[]): Promise<{
        representation: import("@molstar/core/state").StateObjectSelector<StateObject<any, StateObject.Type<any>>, StateTransformer<never, PluginStateObject.Group, PD.Normalize<{
            label: string;
            description: string | undefined;
        }>>> | import("@molstar/core/state").StateObjectSelector<StateObject<any, StateObject.Type<any>>, StateTransformer<StateObject<any, StateObject.Type<any>>, StateObject<any, StateObject.Type<any>>, any>>;
    }>;
    private _empty;
    private getTransforms;
    private sync;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=measurement.d.ts.map