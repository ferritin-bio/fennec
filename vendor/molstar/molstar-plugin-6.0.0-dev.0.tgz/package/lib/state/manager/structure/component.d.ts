/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Himanshu Raj <himanshuraj6771@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import type { StateTransformer } from '@molstar/core/state';
import type { ColorTheme } from '@molstar/graphics/theme/color';
import type { SizeTheme } from '@molstar/graphics/theme/size';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { StructureRepresentationPresetProvider } from '../../builder/structure/representation-presets/types.js';
import { StatefulPluginComponent } from '../../component.js';
import { StructureSelectionQuery } from '@molstar/plugin/state/queries/structure/query';
import { StructureRepresentation3D } from '@molstar/plugin/state/transforms/structure/representation';
import type { StructureHierarchyRef, StructureComponentRef, StructureRef, StructureRepresentationRef } from './hierarchy-state.js';
import { Clip } from '@molstar/core/util/clip';
export { StructureComponentManager };
interface StructureComponentManagerState {
    options: StructureComponentManager.Options;
}
declare class StructureComponentManager extends StatefulPluginComponent<StructureComponentManagerState> {
    plugin: PluginContext;
    readonly events: {
        optionsUpdated: import("rxjs").Subject<undefined>;
    };
    get currentStructures(): readonly StructureRef[];
    get pivotStructure(): StructureRef | undefined;
    _setSnapshotState(options: StructureComponentManager.Options): void;
    setOptions(options: StructureComponentManager.Options): Promise<void>;
    private optionHandlers;
    /**
     * Registers a handler that applies an option owned by an optional behavior, for example `interactions`. The option
     * slot always exists and round-trips through snapshots; without a handler a changed value is preserved but ignored.
     * The handler runs from `setOptions` after the options are updated, when the value of its option changed.
     * Returns a function that removes the handler.
     */
    registerOptionHandler<K extends StructureComponentManager.OptionKey>(key: K, handler: StructureComponentManager.OptionHandler<K>): () => void;
    private updateReprParams;
    applyPreset<P extends StructureRepresentationPresetProvider>(structures: ReadonlyArray<StructureRef>, provider: P, params?: StructureRepresentationPresetProvider.Params<P>): Promise<any>;
    private syncPreset;
    clear(structures: ReadonlyArray<StructureRef>): Promise<void>;
    selectThis(components: ReadonlyArray<StructureComponentRef>): void;
    canBeModified(ref: StructureHierarchyRef): boolean;
    modifyByCurrentSelection(components: ReadonlyArray<StructureComponentRef>, action: StructureComponentManager.ModifyAction): Promise<void>;
    toggleVisibility(components: ReadonlyArray<StructureComponentRef>, reprPivot?: StructureRepresentationRef): void;
    removeRepresentations(components: ReadonlyArray<StructureComponentRef>, pivot?: StructureRepresentationRef): Promise<void> | undefined;
    updateRepresentations(components: ReadonlyArray<StructureComponentRef>, pivot: StructureRepresentationRef, params: StateTransformer.Params<StructureRepresentation3D>): Promise<void>;
    /**
     * To update theme for all selected structures, use
     *   plugin.dataTransaction(async () => {
     *      for (const s of structure.hierarchy.selection.structures) await updateRepresentationsTheme(s.componets, ...);
     *   }, { canUndo: 'Update Theme' });
     */
    updateRepresentationsTheme<C extends ColorTheme.BuiltIn, S extends SizeTheme.BuiltIn>(components: ReadonlyArray<StructureComponentRef>, params: StructureComponentManager.UpdateThemeParams<C, S>): Promise<any> | undefined;
    updateRepresentationsTheme<C extends ColorTheme.BuiltIn, S extends SizeTheme.BuiltIn>(components: ReadonlyArray<StructureComponentRef>, params: (c: StructureComponentRef, r: StructureRepresentationRef) => StructureComponentManager.UpdateThemeParams<C, S>): Promise<any> | undefined;
    addRepresentation(components: ReadonlyArray<StructureComponentRef>, type: string): Promise<void> | undefined;
    private tryFindComponent;
    add(params: StructureComponentManager.AddParams, structures?: ReadonlyArray<StructureRef>): Promise<void>;
    applyTheme(params: StructureComponentManager.ThemeParams, structures?: ReadonlyArray<StructureRef>): Promise<void>;
    private modifyComponent;
    updateLabel(component: StructureComponentRef, label: string): void;
    private get dataState();
    private clearComponents;
    constructor(plugin: PluginContext);
}
declare namespace StructureComponentManager {
    const OptionsParams: {
        hydrogens: PD.Select<"all" | "hide-all" | "only-polar">;
        visualQuality: PD.Select<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium">;
        ignoreLight: PD.BooleanParam;
        solidSurface: PD.BooleanParam;
        materialStyle: PD.Group<PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>>;
        clipObjects: PD.Group<PD.Normalize<{
            variant: Clip.Variant;
            objects: PD.Normalize<{
                type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
                invert: boolean;
                position: import("@molstar/core/math/linear-algebra").Vec3;
                rotation: PD.Normalize<Clip.Rotation>;
                scale: import("@molstar/core/math/linear-algebra").Vec3;
                transform: import("@molstar/core/math/linear-algebra").Mat4;
            }>[];
        }>>;
        interactions: PD.Group<PD.Normalize<{
            providers: PD.Normalize<{
                ionic: PD.NamedParams<{
                    distanceMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'pi-stacking': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                    offsetMax: PD.Numeric;
                    angleDevMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'cation-pi': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                    offsetMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'halogen-bonds': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                    angleMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'hydrogen-bonds': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                    backbone: PD.BooleanParam;
                    accAngleDevMax: PD.Numeric;
                    ignoreHydrogens: PD.BooleanParam;
                    donAngleDevMax: PD.Numeric;
                    accOutOfPlaneAngleMax: PD.Numeric;
                    donOutOfPlaneAngleMax: PD.Numeric;
                    water: PD.BooleanParam;
                    sulfurDistanceMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'weak-hydrogen-bonds': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                    backbone: PD.BooleanParam;
                    accAngleDevMax: PD.Numeric;
                    ignoreHydrogens: PD.BooleanParam;
                    donAngleDevMax: PD.Numeric;
                    accOutOfPlaneAngleMax: PD.Numeric;
                    donOutOfPlaneAngleMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                hydrophobic: PD.NamedParams<{
                    distanceMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
                'metal-coordination': PD.NamedParams<{
                    distanceMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
            }>;
            bridges: PD.Normalize<{
                'water-bridges': PD.NamedParams<{
                    backbone: PD.BooleanParam;
                    ignoreHydrogens: PD.BooleanParam;
                    legDistMin: PD.Numeric;
                    legDistMax: PD.Numeric;
                    donAngleDevMax: PD.Numeric;
                    accAngleDevMax: PD.Numeric;
                    donOutOfPlaneAngleMax: PD.Numeric;
                    accOutOfPlaneAngleMax: PD.Numeric;
                    omegaMin: PD.Numeric;
                    omegaMax: PD.Numeric;
                }, "on"> | PD.NamedParams<{}, "off">;
            }>;
            contacts: PD.Normalize<{
                lineOfSightDistFactor: number;
            }>;
        }>>;
        interior: PD.Group<PD.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
            colorStrength: number;
            substance: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
            substanceStrength: number;
        }>>;
        animation: PD.Group<PD.Normalize<{
            wiggleMode: "group" | "position";
            wiggleSpeed: number;
            wiggleAmplitude: number;
            wiggleFrequency: number;
            tumbleSpeed: number;
            tumbleAmplitude: number;
            tumbleFrequency: number;
        }>>;
    };
    type Options = PD.Values<typeof OptionsParams>;
    type OptionKey = keyof Options;
    /** Applies a changed option value, see `registerOptionHandler`. */
    type OptionHandler<K extends OptionKey> = (value: Options[K], manager: StructureComponentManager) => void | Promise<void>;
    /** The default selection: `current` when it is registered, otherwise the first option. */
    function getDefaultSelectionQuery(options: ReadonlyArray<[StructureSelectionQuery, string, string]>): StructureSelectionQuery | undefined;
    function getAddParams(plugin: PluginContext, params?: {
        pivot?: StructureRef;
        allowNone: boolean;
        hideSelection?: boolean;
        checkExisting?: boolean;
    }): {
        selection: PD.Select<StructureSelectionQuery>;
        representation: PD.Select<string>;
        options: PD.Group<PD.Normalize<{
            label: string;
            checkExisting: boolean;
        }>>;
    };
    type AddParams = {
        selection: StructureSelectionQuery;
        options: {
            checkExisting: boolean;
            label: string;
        };
        representation: string;
    };
    function getThemeParams(plugin: PluginContext, pivot: StructureRef | StructureComponentRef | undefined): {
        selection: PD.Select<StructureSelectionQuery>;
        action: PD.Mapped<PD.NamedParams<PD.Normalize<unknown>, "resetColor"> | PD.NamedParams<PD.Normalize<unknown>, "resetMaterial"> | PD.NamedParams<PD.Normalize<{
            color: import("@molstar/core/util/color/color").Color;
        }>, "color"> | PD.NamedParams<PD.Normalize<{
            value: number;
        }>, "transparency"> | PD.NamedParams<PD.Normalize<{
            value: number;
        }>, "emissive"> | PD.NamedParams<PD.Normalize<{
            material: PD.Normalize<{
                metalness: number;
                roughness: number;
                bumpiness: number;
            }>;
        }>, "material"> | PD.NamedParams<PD.Normalize<{
            excludeGroups: ("five" | "four" | "one" | "six" | "three" | "two")[];
        }>, "clipping"> | PD.NamedParams<PD.Normalize<{
            value: number;
        }>, "wiggle">>;
        representations: PD.MultiSelect<string>;
    };
    type ThemeParams = PD.Values<ReturnType<typeof getThemeParams>>;
    function getRepresentationTypes(plugin: PluginContext, pivot: StructureRef | StructureComponentRef | undefined): [string, string][];
    type ModifyAction = 'union' | 'subtract' | 'intersect';
    interface UpdateThemeParams<C extends ColorTheme.BuiltIn, S extends SizeTheme.BuiltIn> {
        /**
         * this works for any theme name (use 'name as any'), but code completion will break
         */
        color?: C | 'default';
        colorParams?: ColorTheme.BuiltInParams<C>;
        size?: S | 'default';
        sizeParams?: SizeTheme.BuiltInParams<S>;
    }
}
//# sourceMappingURL=component.d.ts.map