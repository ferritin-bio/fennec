/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { List } from 'immutable';
import { UUID } from '@molstar/core/util';
import { PluginState } from '@molstar/plugin/state';
import { StatefulPluginComponent } from '../component.js';
import type { PluginContext } from '@molstar/plugin/context';
import type { Asset } from '@molstar/core/util/assets';
export { PluginStateSnapshotManager };
interface StateManagerState {
    current?: UUID;
    currentAnimationTimeMs?: number;
    entries: List<PluginStateSnapshotManager.Entry>;
    isPlaying: boolean;
    nextSnapshotDelayInMs: number;
}
declare class PluginStateSnapshotManager extends StatefulPluginComponent<StateManagerState> {
    private plugin;
    static DefaultNextSnapshotDelayInMs: number;
    private entryMap;
    private defaultSnapshotId;
    protected updateState(state: Partial<StateManagerState>): boolean;
    readonly events: {
        changed: import("rxjs").Subject<unknown>;
        opened: import("rxjs").Subject<unknown>;
    };
    get current(): PluginStateSnapshotManager.Entry | undefined;
    getIndex(e: PluginStateSnapshotManager.Entry): number;
    getEntry(id: string | undefined): PluginStateSnapshotManager.Entry | undefined;
    remove(id: string): void;
    add(e: PluginStateSnapshotManager.Entry): void;
    replace(id: string, snapshot: PluginState.Snapshot, params?: PluginStateSnapshotManager.EntryParams): void;
    move(id: string, dir: -1 | 1): void;
    update(e: PluginStateSnapshotManager.Entry, options: {
        key?: string;
        name?: string;
        description?: string;
        descriptionFormat?: PluginStateSnapshotManager.DescriptionFormat;
    }): void;
    clear(): void;
    applyKey(key: string): void;
    setCurrent(id: string): PluginState.Snapshot | undefined;
    private animationFrameQueue;
    setSnapshotAnimationFrame(currentAnimationTimeMs: number, load?: boolean): number | undefined;
    getNextId(id: string | undefined, dir: -1 | 1): UUID | undefined;
    applyNext(dir: -1 | 1): Promise<void> | undefined;
    setStateSnapshot(snapshot: PluginStateSnapshotManager.StateSnapshot): Promise<PluginState.Snapshot | undefined>;
    private syncCurrent;
    /** What `syncCurrent` would make the list, on a copy (the manager's entries untouched; `keepList`). */
    private syncedCopy;
    getStateSnapshot(options?: {
        name?: string;
        description?: string;
        playOnLoad?: boolean;
        params?: PluginState.SnapshotParams;
        /**
         * Leaves the list as it is: the current scene is added to (or replaces the automatic entry of) the returned
         * snapshot only, not the manager's entries (a host whose list is the person's own).
         */
        keepList?: boolean;
    }): Promise<PluginStateSnapshotManager.StateSnapshot>;
    serialize(options?: {
        type: 'json' | 'molj' | 'zip' | 'molx';
        params?: PluginState.SnapshotParams;
        /** See `getStateSnapshot`. */
        keepList?: boolean;
        /**
         * What a host keeps beside the state: files in a zip (`.molx`, beside `state.json`), top-level fields in a JSON
         * state (`.molj`). `open` hands them back.
         */
        extra?: PluginStateSnapshotManager.Extra;
    }): Promise<Blob>;
    /** Opens a state or a session file; what a host kept beside the state (`serialize`'s `extra`) comes back. */
    open(file: File): Promise<PluginStateSnapshotManager.Extra | undefined>;
    private timeoutHandle;
    private next;
    private startPlayback;
    play(options?: {
        delayFirst?: boolean;
        restart?: boolean;
    }): Promise<void>;
    stop(): Promise<void>;
    togglePlay(): Promise<void>;
    dispose(): void;
    constructor(plugin: PluginContext);
}
declare namespace PluginStateSnapshotManager {
    type DescriptionFormat = 'markdown' | 'plaintext';
    /** What a host keeps in a state or session file beside the state (`serialize`'s `extra`, `open`'s result). */
    interface Extra {
        /** Files in a session's zip, beside `state.json` (not `assets/`). */
        files?: {
            [name: string]: Uint8Array;
        };
        /** A JSON state's top-level fields (all of them, on open). */
        fields?: {
            [name: string]: unknown;
        };
    }
    interface EntryParams {
        key?: string;
        name?: string;
        /** Information about the snapshot, to be shown in the UI when the snapshot is loaded. */
        description?: string;
        /** Toggle between markdown and plaintext interpretation of `description`. Default is markdown. */
        descriptionFormat?: DescriptionFormat;
        image?: Asset;
    }
    interface Entry extends EntryParams {
        timestamp: number;
        snapshot: PluginState.Snapshot;
        /** Extra data that is not serialized */
        _transientData?: any;
    }
    function Entry(snapshot: PluginState.Snapshot, params: EntryParams): Entry;
    function isStateSnapshot(x?: any): x is StateSnapshot;
    interface StateSnapshot {
        timestamp: number;
        version: string;
        name?: string;
        description?: string;
        current: UUID | undefined;
        playback: {
            isPlaying: boolean;
            nextSnapshotDelayInMs: number;
        };
        entries: Entry[];
    }
    function getCanvasImageAsset(ctx: PluginContext, name: string): Promise<Asset | undefined>;
}
//# sourceMappingURL=snapshots.d.ts.map