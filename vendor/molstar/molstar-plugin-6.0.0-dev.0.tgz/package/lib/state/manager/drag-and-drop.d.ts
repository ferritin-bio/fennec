/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
export type PluginDragAndDropHandler = (files: File[], plugin: PluginContext) => Promise<boolean> | boolean;
export interface PluginDragAndDropEntry {
    readonly name: string;
    readonly handle: PluginDragAndDropHandler;
    /** Fallback handlers run after the built-in session handling, so they only get files no other handler took. */
    readonly fallback?: boolean;
}
/**
 * Handlers are keyed by `name`; a provider's identity is its `handle` function.
 * Registering the same name and handle again increments a count, a different handle
 * under an existing name throws.
 */
export declare class DragAndDropManager {
    plugin: PluginContext;
    private entries;
    /** Returns the message `addEntry` would throw for `entry`, without changing anything. */
    findConflict(entry: PluginDragAndDropEntry): string | undefined;
    addEntry(entry: PluginDragAndDropEntry): void;
    /** Decrements the provider registered with the same name and handle, no-op when there is none. */
    removeEntry(entry: PluginDragAndDropEntry): void;
    addHandler(name: string, handler: PluginDragAndDropHandler, options?: {
        fallback?: boolean;
    }): void;
    /** Decrements the provider registered under `name`, no-op for an unknown name. */
    removeHandler(name: string): void;
    /** The registered entries in registration order. */
    list(): readonly PluginDragAndDropEntry[];
    private decrement;
    /**
     * Tries non-fallback handlers, then the built-in session handling, then fallback handlers;
     * each group in reverse registration order.
     */
    handle(files: File[]): Promise<void>;
    private tryHandlers;
    dispose(): void;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=drag-and-drop.d.ts.map