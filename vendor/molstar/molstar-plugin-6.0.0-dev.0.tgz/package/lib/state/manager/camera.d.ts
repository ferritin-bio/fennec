/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ke Ma <mark.ma@rcsb.org>
 * @author Adam Midlik <midlik@gmail.com>
 */
import type { Camera } from '@molstar/graphics/canvas3d/camera';
import type { TransitionTrajectory } from '@molstar/graphics/canvas3d/camera/transition-functions';
import type { Canvas3DCameraResetOptions } from '@molstar/graphics/canvas3d/canvas3d';
import type { GraphicsRenderObject } from '@molstar/graphics/gl/render-object';
import type { EasingFunction } from '@molstar/core/math/easing';
import type { Sphere3D } from '@molstar/core/math/geometry';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import type { PrincipalAxes } from '@molstar/core/math/linear-algebra/matrix/principal-axes';
import { Loci } from '@molstar/model/model/loci';
import { Structure } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { PluginState } from '@molstar/plugin/state';
export declare const DefaultCameraFocusOptions: {
    minRadius: number;
    extraRadius: number;
    durationMs: number;
    zoomOut: boolean;
    zoomOutOptions: {
        durationFactor: number;
    };
    easing: EasingFunction;
    trajectory: TransitionTrajectory;
};
export declare const DefaultCameraFocusLociOptions: {
    minRadius: number;
    extraRadius: number;
    durationMs: number;
    zoomOut: boolean;
    zoomOutOptions: {
        durationFactor: number;
    };
    easing: EasingFunction;
    trajectory: TransitionTrajectory;
    optimizeDirection: boolean;
    optimizeDirectionUp: 'current' | 'default' | Vec3;
};
export type CameraFocusOptions = typeof DefaultCameraFocusOptions;
export type CameraFocusLociOptions = typeof DefaultCameraFocusLociOptions;
export type TransitionOptions = Pick<Canvas3DCameraResetOptions, 'easing' | 'trajectory'>;
export declare class CameraManager {
    readonly plugin: PluginContext;
    private boundaryHelper;
    private transformedLoci;
    focusRenderObjects(objects?: ReadonlyArray<GraphicsRenderObject>, options?: Partial<CameraFocusOptions>): void;
    private getFocusSphere;
    private getFocusLociOptimized;
    private getFocusLociBase;
    focusLoci(loci: Loci | Loci[], options?: Partial<CameraFocusLociOptions>): void;
    focusSpheres<T>(xs: ReadonlyArray<T>, sphere: (t: T) => Sphere3D | undefined, options?: Partial<CameraFocusOptions> & {
        principalAxes?: PrincipalAxes;
        positionToFlip?: Vec3;
    }): void;
    private getFocusSphereSnapshot;
    private focusSnapshot;
    focusSphere(sphere: Sphere3D, options?: Partial<CameraFocusOptions> & {
        principalAxes?: PrincipalAxes;
        positionToFlip?: Vec3;
    }): void;
    /** Focus on a set of plugin state object cells (if `options.targets` is non-empty) or on the whole scene (if `options.targets` is empty). */
    focusObject(options: PluginState.SnapshotFocusInfo & {
        minRadius?: number;
        durationMs?: number;
    } & TransitionOptions): void;
    /** Align PCA axes of `structures` (default: all loaded structures) to the screen axes. */
    orientAxes(structures?: Structure[], durationMs?: number, transitionOptions?: TransitionOptions): void;
    /** Align Cartesian axes to the screen axes (X right, Y up). */
    resetAxes(durationMs?: number, transitionOptions?: TransitionOptions): void;
    setSnapshot(snapshot: Partial<Camera.Snapshot>, durationMs?: number, transitionOptions?: TransitionOptions): void;
    reset(snapshot?: Partial<Camera.Snapshot>, durationMs?: number, transitionOptions?: TransitionOptions): void;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=camera.d.ts.map