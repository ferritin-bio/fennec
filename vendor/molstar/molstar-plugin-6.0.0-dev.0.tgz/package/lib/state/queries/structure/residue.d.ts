/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const nonStandardPolymer: StructureSelectionQuery;
export declare const ring: StructureSelectionQuery;
export declare const aromaticRing: StructureSelectionQuery;
export declare const AminoAcidSelectionQueries: StructureSelectionQuery[];
export declare const NucleicBaseSelectionQueries: StructureSelectionQuery[];
export declare const ResidueSelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=residue.d.ts.map