/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export declare const StructureSelectionQueries: {
    all: import("./query.js").StructureSelectionQuery;
    current: import("./query.js").StructureSelectionQuery;
    polymer: import("./query.js").StructureSelectionQuery;
    trace: import("./query.js").StructureSelectionQuery;
    backbone: import("./query.js").StructureSelectionQuery;
    sidechain: import("./query.js").StructureSelectionQuery;
    sidechainWithTrace: import("./query.js").StructureSelectionQuery;
    protein: import("./query.js").StructureSelectionQuery;
    nucleic: import("./query.js").StructureSelectionQuery;
    helix: import("./query.js").StructureSelectionQuery;
    beta: import("./query.js").StructureSelectionQuery;
    water: import("./query.js").StructureSelectionQuery;
    ion: import("./query.js").StructureSelectionQuery;
    lipid: import("./query.js").StructureSelectionQuery;
    branched: import("./query.js").StructureSelectionQuery;
    branchedPlusConnected: import("./query.js").StructureSelectionQuery;
    branchedConnectedOnly: import("./query.js").StructureSelectionQuery;
    ligand: import("./query.js").StructureSelectionQuery;
    ligandPlusConnected: import("./query.js").StructureSelectionQuery;
    ligandConnectedOnly: import("./query.js").StructureSelectionQuery;
    connectedOnly: import("./query.js").StructureSelectionQuery;
    disulfideBridges: import("./query.js").StructureSelectionQuery;
    nosBridges: import("./query.js").StructureSelectionQuery;
    nonStandardPolymer: import("./query.js").StructureSelectionQuery;
    coarse: import("./query.js").StructureSelectionQuery;
    ring: import("./query.js").StructureSelectionQuery;
    aromaticRing: import("./query.js").StructureSelectionQuery;
    surroundings: import("./query.js").StructureSelectionQuery;
    surroundingLigands: import("./query.js").StructureSelectionQuery;
    surroundingAtoms: import("./query.js").StructureSelectionQuery;
    complement: import("./query.js").StructureSelectionQuery;
    covalentlyBonded: import("./query.js").StructureSelectionQuery;
    covalentlyOrMetallicBonded: import("./query.js").StructureSelectionQuery;
    covalentlyBondedComponent: import("./query.js").StructureSelectionQuery;
    wholeResidues: import("./query.js").StructureSelectionQuery;
};
//# sourceMappingURL=catalog.d.ts.map