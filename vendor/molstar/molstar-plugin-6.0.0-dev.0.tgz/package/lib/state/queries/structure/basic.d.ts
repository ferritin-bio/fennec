/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const all: StructureSelectionQuery;
export declare const current: StructureSelectionQuery;
export declare const BasicSelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=basic.d.ts.map