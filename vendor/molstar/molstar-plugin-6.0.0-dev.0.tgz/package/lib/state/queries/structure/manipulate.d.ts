/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const surroundings: StructureSelectionQuery;
export declare const surroundingLigands: StructureSelectionQuery;
export declare const surroundingAtoms: StructureSelectionQuery;
export declare const complement: StructureSelectionQuery;
export declare const covalentlyBonded: StructureSelectionQuery;
export declare const covalentlyBondedComponent: StructureSelectionQuery;
export declare const covalentlyOrMetallicBonded: StructureSelectionQuery;
export declare const wholeResidues: StructureSelectionQuery;
export declare const ManipulateSelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=manipulate.d.ts.map