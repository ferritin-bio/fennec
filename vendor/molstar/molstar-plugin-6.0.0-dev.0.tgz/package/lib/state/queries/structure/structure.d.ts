/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const trace: StructureSelectionQuery;
export declare const backbone: StructureSelectionQuery;
export declare const sidechain: StructureSelectionQuery;
export declare const sidechainWithTrace: StructureSelectionQuery;
export declare const helix: StructureSelectionQuery;
export declare const beta: StructureSelectionQuery;
export declare const StructurePropertySelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=structure.d.ts.map