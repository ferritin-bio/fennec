/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { CustomProperty } from '@molstar/model/props/common/custom-property';
import { StructureSelection } from '@molstar/model/model/structure';
import type { Structure, StructureQuery } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { Expression } from '@molstar/query-language/language/expression';
import type { RuntimeContext } from '@molstar/core/task';
export declare enum StructureSelectionCategory {
    Type = "Type",
    Structure = "Structure Property",
    Atom = "Atom Property",
    Bond = "Bond Property",
    Residue = "Residue Property",
    AminoAcid = "Amino Acid",
    NucleicBase = "Nucleic Base",
    Manipulate = "Manipulate Selection",
    Validation = "Validation",
    Misc = "Miscellaneous",
    Internal = "Internal"
}
export { StructureSelectionQuery };
interface StructureSelectionQuery {
    readonly label: string;
    readonly expression: Expression;
    readonly description: string;
    readonly category: string;
    readonly isHidden: boolean;
    readonly priority: number;
    readonly referencesCurrent: boolean;
    readonly query: StructureQuery;
    readonly ensureCustomProperties?: (ctx: CustomProperty.Context, structure: Structure) => Promise<void>;
    getSelection(plugin: PluginContext, runtime: RuntimeContext, structure: Structure): Promise<StructureSelection>;
}
interface StructureSelectionQueryProps {
    description?: string;
    category?: string;
    isHidden?: boolean;
    priority?: number;
    referencesCurrent?: boolean;
    ensureCustomProperties?: (ctx: CustomProperty.Context, structure: Structure) => Promise<void>;
}
declare function StructureSelectionQuery(label: string, expression: Expression, props?: StructureSelectionQueryProps): StructureSelectionQuery;
//# sourceMappingURL=query.d.ts.map