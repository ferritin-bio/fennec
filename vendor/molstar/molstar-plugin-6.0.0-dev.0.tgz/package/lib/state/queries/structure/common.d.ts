/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export declare const proteinEntityTest: import("@molstar/query-language/language/expression").Expression;
export declare const nucleiEntityTest: import("@molstar/query-language/language/expression").Expression;
/**
 * this is to get non-polymer and peptide terminus components in polymer entities,
 * - non-polymer, e.g. PXZ in 4HIV or generally ACE
 * - carboxy terminus, e.g. FC0 in 4BP9, or ETA in 6DDE
 * - amino terminus, e.g. ARF in 3K4V, or 4MM in 3EGV
 */
export declare const nonPolymerResidueTest: import("@molstar/query-language/language/expression").Expression;
//# sourceMappingURL=common.d.ts.map