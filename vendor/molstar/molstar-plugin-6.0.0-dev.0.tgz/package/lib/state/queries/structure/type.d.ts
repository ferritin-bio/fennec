/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const polymer: StructureSelectionQuery;
export declare const protein: StructureSelectionQuery;
export declare const nucleic: StructureSelectionQuery;
export declare const water: StructureSelectionQuery;
export declare const ion: StructureSelectionQuery;
export declare const lipid: StructureSelectionQuery;
export declare const branched: StructureSelectionQuery;
export declare const branchedPlusConnected: StructureSelectionQuery;
export declare const branchedConnectedOnly: StructureSelectionQuery;
export declare const ligand: StructureSelectionQuery;
export declare const ligandPlusConnected: StructureSelectionQuery;
export declare const ligandConnectedOnly: StructureSelectionQuery;
export declare const connectedOnly: StructureSelectionQuery;
export declare const coarse: StructureSelectionQuery;
export declare const TypeSelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=type.d.ts.map