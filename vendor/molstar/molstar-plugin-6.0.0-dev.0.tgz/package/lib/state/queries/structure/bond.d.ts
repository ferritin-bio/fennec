/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { StructureSelectionQuery } from './query.js';
export declare const disulfideBridges: StructureSelectionQuery;
export declare const nosBridges: StructureSelectionQuery;
export declare const BondSelectionQueries: StructureSelectionQuery[];
//# sourceMappingURL=bond.d.ts.map