/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { type Structure } from '@molstar/model/model/structure';
import { StructureSelectionQuery } from './query.js';
export declare function ResidueQuery([names, label]: [string[], string], category: string, priority?: number): StructureSelectionQuery;
export declare function ElementSymbolQuery([names, label]: [string[], string], category: string, priority: number): StructureSelectionQuery;
export declare function EntityDescriptionQuery([names, label]: [string[], string], category: string, priority: number): StructureSelectionQuery;
export declare function getElementQueries(structures: Structure[]): StructureSelectionQuery[];
export declare function getNonStandardResidueQueries(structures: Structure[]): StructureSelectionQuery[];
export declare function getPolymerAndBranchedEntityQueries(structures: Structure[]): StructureSelectionQuery[];
//# sourceMappingURL=dynamic.d.ts.map