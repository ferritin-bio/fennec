/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StructureSelectionQuery } from './query.js';
export declare class StructureSelectionQueryRegistry {
    list: StructureSelectionQuery[];
    options: [StructureSelectionQuery, string, string][];
    version: number;
    /** Registration counts by query identity */
    private counts;
    /** Queries have no key, so registration never conflicts. */
    findConflict(_q: StructureSelectionQuery): string | undefined;
    /** Registering the same query again increments its count. */
    add(q: StructureSelectionQuery): void;
    /** Decrements the count and removes the query at zero; no-op for an unknown query. */
    remove(q: StructureSelectionQuery): void;
}
//# sourceMappingURL=registry.d.ts.map