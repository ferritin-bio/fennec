/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Expression } from '@molstar/query-language/language/expression';
import { type QueryFn, Structure, StructureSelection as Sel } from '@molstar/model/model/structure';
import { Script } from '@molstar/model/script/script';
import type { PluginStateObject as SO } from '../objects.js';
export { StructureQueryHelper };
declare namespace StructureQueryHelper {
    interface CacheEntry {
        script?: Script;
        expression: Expression;
        compiled: QueryFn<Sel>;
        originalStructure: Structure;
        currentStructure: Structure;
    }
    function isUnchanged(entry: CacheEntry, query: Script | Expression, structure: Structure): boolean;
    function create(structure: Structure, query: Script | Expression): CacheEntry;
    function run(entry: CacheEntry, structure: Structure): Sel;
    function createAndRun(structure: Structure, query: Script | Expression): {
        entry: CacheEntry;
        selection: Sel;
    };
    function updateStructure(entry: CacheEntry, structure: Structure): Sel;
    function updateStructureObject(obj: SO.Molecule.Structure, selection: Sel, label?: string): void;
}
//# sourceMappingURL=structure-query.d.ts.map