/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import type { RuntimeContext } from '@molstar/core/task';
/**
 * EMDB/PDBe lookups shared by volume streaming and the volume format providers. Kept out of the volume streaming
 * behavior modules so base modules can use them without loading the behavior.
 */
export declare function getContourLevel(provider: 'emdb' | 'pdbe', plugin: PluginContext, taskCtx: RuntimeContext, emdbId: string): Promise<any>;
export declare function getContourLevelEmdb(plugin: PluginContext, taskCtx: RuntimeContext, emdbId: string): Promise<number>;
export declare function getContourLevelPdbe(plugin: PluginContext, taskCtx: RuntimeContext, emdbId: string): Promise<any>;
export declare function getEmdbIds(plugin: PluginContext, taskCtx: RuntimeContext, pdbId: string): Promise<string[]>;
//# sourceMappingURL=emdb.d.ts.map