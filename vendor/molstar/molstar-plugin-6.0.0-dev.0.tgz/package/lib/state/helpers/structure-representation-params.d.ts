/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Structure } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { RepresentationProvider } from '@molstar/graphics/repr/representation';
import type { StructureRepresentationRegistry } from '@molstar/graphics/repr/structure/registry';
import type { StateTransformer } from '@molstar/core/state';
import type { ColorTheme } from '@molstar/graphics/theme/color';
import type { SizeTheme } from '@molstar/graphics/theme/size';
import type { StructureRepresentation3D } from '@molstar/plugin/state/transforms/structure/representation';
export declare function isSurfaceRepresentationType(name: string): boolean;
/** A representation of the scope, given as a provider or as a registered name. */
export type StructureRepresentationRef = RepresentationProvider<Structure> | string;
/** A color theme, given as a provider or as a registered name. */
export type StructureColorThemeRef = ColorTheme.Provider | string;
/** A size theme, given as a provider or as a registered name. */
export type StructureSizeThemeRef = SizeTheme.Provider | string;
/** Params of a representation reference: a provider's params, the params of a built-in name, or `{}` for other names. */
export type StructureRepresentationParamsOf<R extends StructureRepresentationRef> = [R] extends [
    RepresentationProvider<Structure>
] ? Partial<RepresentationProvider.ParamValues<R>> : [R] extends [StructureRepresentationRegistry.BuiltIn] ? StructureRepresentationRegistry.BuiltInParams<R> : {};
/** Params of a color theme reference: a provider's params, the params of a built-in name, or `{}` for other names. */
export type StructureColorThemeParamsOf<C extends StructureColorThemeRef> = [C] extends [ColorTheme.Provider] ? Partial<ColorTheme.ParamValues<C>> : [C] extends [ColorTheme.BuiltIn] ? ColorTheme.BuiltInParams<C> : {};
/** Params of a size theme reference: a provider's params, the params of a built-in name, or `{}` for other names. */
export type StructureSizeThemeParamsOf<S extends StructureSizeThemeRef> = [S] extends [SizeTheme.Provider] ? Partial<SizeTheme.ParamValues<S>> : [S] extends [SizeTheme.BuiltIn] ? SizeTheme.BuiltInParams<S> : {};
/**
 * Each of `type`, `color`, and `size` is a provider or a name and is resolved independently, so a provider can be
 * combined with a theme name. The params types follow the field: a provider's params, the params of a built-in name, or
 * `{}` for any other name.
 */
export interface StructureRepresentationProps<R extends StructureRepresentationRef = StructureRepresentationRef, C extends StructureColorThemeRef = StructureColorThemeRef, S extends StructureSizeThemeRef = StructureSizeThemeRef> {
    type?: R;
    typeParams?: StructureRepresentationParamsOf<R>;
    color?: C;
    colorParams?: StructureColorThemeParamsOf<C>;
    size?: S;
    sizeParams?: StructureSizeThemeParamsOf<S>;
}
/** Props with representation, color theme, and size theme names. */
export type StructureRepresentationBuiltInProps<R extends StructureRepresentationRegistry.BuiltIn = StructureRepresentationRegistry.BuiltIn, C extends ColorTheme.BuiltIn = ColorTheme.BuiltIn, S extends SizeTheme.BuiltIn = SizeTheme.BuiltIn> = StructureRepresentationProps<R, C, S>;
export declare function createStructureRepresentationParams<R extends StructureRepresentationRef = StructureRepresentationRef, C extends StructureColorThemeRef = StructureColorThemeRef, S extends StructureSizeThemeRef = StructureSizeThemeRef>(ctx: PluginContext, structure?: Structure, props?: StructureRepresentationProps<R, C, S>): StateTransformer.Params<StructureRepresentation3D>;
export declare function getStructureThemeTypes(ctx: PluginContext, structure?: Structure): [string, string, string][];
export declare function createStructureColorThemeParams<T extends ColorTheme.BuiltIn>(ctx: PluginContext, structure: Structure | undefined, typeName: string | undefined, themeName: T, params?: ColorTheme.BuiltInParams<T>): StateTransformer.Params<StructureRepresentation3D>['colorTheme'];
export declare function createStructureColorThemeParams(ctx: PluginContext, structure: Structure | undefined, typeName: string | undefined, themeName?: string, params?: any): StateTransformer.Params<StructureRepresentation3D>['colorTheme'];
export declare function createStructureSizeThemeParams<T extends SizeTheme.BuiltIn>(ctx: PluginContext, structure: Structure | undefined, typeName: string | undefined, themeName: T, params?: SizeTheme.BuiltInParams<T>): StateTransformer.Params<StructureRepresentation3D>['sizeTheme'];
export declare function createStructureSizeThemeParams(ctx: PluginContext, structure: Structure | undefined, typeName: string | undefined, themeName?: string, params?: any): StateTransformer.Params<StructureRepresentation3D>['sizeTheme'];
//# sourceMappingURL=structure-representation-params.d.ts.map