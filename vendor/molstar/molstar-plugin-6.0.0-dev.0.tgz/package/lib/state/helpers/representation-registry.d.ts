/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ThemeRegistryContext } from '@molstar/graphics/theme/theme';
/** Scopes that have their own representation and theme registries. */
export type RepresentationScope = 'structure' | 'volume' | 'particles';
/** The registry surface needed to check names and emptiness (representation or theme registry). */
interface NameRegistry {
    readonly default: unknown;
    has(name: string): boolean;
}
interface ScopeRegistries {
    registry: NameRegistry;
    themes: ThemeRegistryContext;
}
/**
 * Params of a `PD.Mapped` without any option, used for transformer and helper params when the
 * scope has no registered provider to build them from. Applying them fails with `assertRepresentationScope`.
 */
export declare function emptyMappedParams(): PD.Mapped<any>;
/** Values of {@link emptyMappedParams}. */
export declare function emptyMappedValue(): {
    name: string;
    params: any;
};
export declare function hasRepresentations(scope: ScopeRegistries): boolean;
export declare function hasColorThemes(scope: ScopeRegistries): boolean;
export declare function hasSizeThemes(scope: ScopeRegistries): boolean;
/** True when the scope has a representation, a color theme, and a size theme to build params from. */
export declare function hasRepresentationScope(scope: ScopeRegistries): boolean;
export declare function assertRepresentations(scopeName: RepresentationScope, scope: ScopeRegistries): void;
export declare function assertColorThemes(scopeName: RepresentationScope, scope: ScopeRegistries): void;
export declare function assertSizeThemes(scopeName: RepresentationScope, scope: ScopeRegistries): void;
/** Throws when the scope has no representation, color theme, or size theme registered. */
export declare function assertRepresentationScope(scopeName: RepresentationScope, scope: ScopeRegistries): void;
export type ProviderKind = 'representation' | 'color theme' | 'size theme';
/** Warns when `name` (if given) is not registered; params are then built as usual and normalization substitutes. */
export declare function warnIfUnregistered(plugin: PluginContext, scopeName: RepresentationScope, kind: ProviderKind, registry: NameRegistry, name: string | undefined): void;
interface RepresentationLike {
    defaultColorTheme: {
        name: string;
    };
    defaultSizeTheme: {
        name: string;
    };
}
interface RepresentationScopeRegistries extends ScopeRegistries {
    registry: NameRegistry & {
        get(name: string): RepresentationLike;
        readonly default: {
            provider: RepresentationLike;
        } | undefined;
    };
}
export interface RequestedNames {
    /** Representation name or provider; the registry default when not given. */
    type?: string | RepresentationLike;
    /** Color theme name or provider; the representation's default color theme when not given. */
    color?: string | object;
    /** Size theme name or provider; the representation's default size theme when not given. */
    size?: string | object;
    /** Whether the call builds a color theme (so its name and the default color theme are checked). */
    checkColor: boolean;
    /** Whether the call builds a size theme (so its name and the default size theme are checked). */
    checkSize: boolean;
}
/**
 * Warns for each requested representation, color theme, and size theme name, and for the representation's default
 * theme names that are used, when it is not registered in the scope. Provider objects are used directly and not
 * checked. Params are built as usual afterwards; normalization substitutes the registry defaults.
 */
export declare function warnUnregisteredNames(plugin: PluginContext, scopeName: RepresentationScope, scope: RepresentationScopeRegistries, request: RequestedNames): void;
export {};
//# sourceMappingURL=representation-registry.d.ts.map