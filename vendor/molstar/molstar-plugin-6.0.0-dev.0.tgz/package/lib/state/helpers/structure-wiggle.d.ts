/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Structure, StructureElement } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { StructureComponentRef } from '../manager/structure/hierarchy-state.js';
import { EmptyLoci } from '@molstar/model/model/loci';
export declare function setStructureWiggle(plugin: PluginContext, components: StructureComponentRef[], value: number, lociGetter: (structure: Structure) => Promise<StructureElement.Loci | EmptyLoci>, types?: string[]): Promise<void>;
export declare function clearStructureWiggle(plugin: PluginContext, components: StructureComponentRef[], types?: string[]): Promise<void>;
/**
 * Set per-group wiggle based on B-factor/RMSF uncertainty data.
 * Values are normalized to [0, 1] within each structure's min-max range.
 * @param scale - maximum wiggle value (default 1.0, corresponds to Angstroms when combined with wiggleAmplitude)
 */
export declare function setStructureWiggleFromUncertainty(plugin: PluginContext, components: StructureComponentRef[], scale?: number, types?: string[]): Promise<void>;
//# sourceMappingURL=structure-wiggle.d.ts.map