/**
 * Copyright (c) 2019-2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Structure, StructureElement } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { StructureComponentRef } from '../manager/structure/hierarchy-state.js';
import { EmptyLoci } from '@molstar/model/model/loci';
export declare function setStructureTransparency(plugin: PluginContext, components: StructureComponentRef[], value: number, lociGetter: (structure: Structure) => Promise<StructureElement.Loci | EmptyLoci>, types?: string[]): Promise<void>;
export declare function clearStructureTransparency(plugin: PluginContext, components: StructureComponentRef[], types?: string[]): Promise<void>;
//# sourceMappingURL=structure-transparency.d.ts.map