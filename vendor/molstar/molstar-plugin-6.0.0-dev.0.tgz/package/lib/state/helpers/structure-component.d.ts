/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Expression } from '@molstar/query-language/language/expression';
import { StructureElement, Structure } from '@molstar/model/model/structure';
import { StructureQueryHelper } from './structure-query.js';
import { PluginStateObject as SO } from '../objects.js';
import { StateTransformer, StateObject } from '@molstar/core/state';
export declare const StaticStructureComponentTypes: readonly ['all', 'polymer', 'protein', 'nucleic', 'water', 'ion', 'lipid', 'branched', 'ligand', 'non-standard', 'coarse'];
export type StaticStructureComponentType = (typeof StaticStructureComponentTypes)[number];
export declare const StructureComponentParams: () => {
    type: PD.Mapped<PD.NamedParams<StructureElement.Bundle, "bundle"> | PD.NamedParams<import("@molstar/core/util/script").Script, "script"> | PD.NamedParams<Expression, "expression"> | PD.NamedParams<"all" | "branched" | "coarse" | "ion" | "ligand" | "lipid" | "non-standard" | "nucleic" | "polymer" | "protein" | "water", "static">>;
    nullIfEmpty: PD.Base<boolean | undefined>;
    label: PD.Text<string>;
};
export type StructureComponentParams = PD.ValuesFor<ReturnType<typeof StructureComponentParams>>;
/** What `StructureComponent` keeps between its calls */
export interface StructureComponentCache {
    /** The structure which the component was made from */
    source: Structure;
    entry?: StructureQueryHelper.CacheEntry;
    /** The component is the source structure itself (e.g. every element is selected), so its properties are not its own and it must not dispose them */
    isSource?: boolean;
}
export declare function createStructureComponent(a: Structure, params: StructureComponentParams, cache: StructureComponentCache): StateObject<any, any> | SO.Molecule.Structure;
export declare function updateStructureComponent(a: Structure, b: SO.Molecule.Structure, oldParams: StructureComponentParams, newParams: StructureComponentParams, cache: StructureComponentCache): StateTransformer.UpdateResult;
//# sourceMappingURL=structure-component.d.ts.map