/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Model } from '@molstar/model/model/structure';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import type { RuntimeContext } from '@molstar/core/task';
import type { PluginContext } from '@molstar/plugin/context';
import { PluginStateObject as SO } from '../objects.js';
export declare namespace RootStructureDefinition {
    function getParams(model?: Model, defaultValue?: 'auto' | 'model' | 'assembly' | 'symmetry' | 'symmetry-mates' | 'symmetry-assembly'): {
        type: PD.Mapped<PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
        }>, "auto"> | PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
        }>, "model"> | PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
            id: string | undefined;
        }>, "assembly"> | PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
            radius: number;
        }>, "symmetry-mates"> | PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
            ijkMin: Vec3;
            ijkMax: Vec3;
        }>, "symmetry"> | PD.NamedParams<PD.Normalize<{
            dynamicBonds: boolean | undefined;
            mergeBySymmetry: boolean | undefined;
            generators: PD.Normalize<{
                operators: {
                    index: number;
                    shift: Vec3;
                }[];
                asymIds: string[];
            }>[];
        }>, "symmetry-assembly">>;
    };
    type Params = PD.Values<ReturnType<typeof getParams>>['type'];
    function canAutoUpdate(oldParams: Params, newParams: Params): boolean;
    function create(plugin: PluginContext, ctx: RuntimeContext, model: Model, params?: Params): Promise<SO.Molecule.Structure>;
}
//# sourceMappingURL=root-structure.d.ts.map