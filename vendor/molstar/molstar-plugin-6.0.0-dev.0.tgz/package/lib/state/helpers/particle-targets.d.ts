/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { SimulariumGeometryResolver } from '@molstar/model/formats/particles/simularium';
import type { ParticleList, ParticleTarget } from '@molstar/model/model/particles/particle-list';
import type { PluginContext } from '@molstar/plugin/context';
import { RuntimeContext } from '@molstar/core/task';
import { Asset } from '@molstar/core/util/assets';
/** Options for a `PD.Select` of the supported target formats, including auto-detection. */
export declare function particleTargetFormatOptions(plugin: PluginContext): [string, string][];
/** Comma separated extension list for a `PD.File` accept attribute. */
export declare function particleTargetFileExtensions(plugin: PluginContext): string;
export type ParticleTargetSource = {
    readonly kind: 'url';
    readonly url: string | Asset.Url;
    readonly format?: string;
    readonly isBinary?: boolean;
} | {
    readonly kind: 'file';
    readonly file: Asset.File;
    readonly format?: string;
};
export interface ParticleTargetEntry {
    readonly targetId: number;
    readonly target: ParticleTarget;
}
export interface MatchedParticleTargetFile {
    readonly file: Asset.File;
    readonly targetIds: ReadonlyArray<number>;
}
export interface ParticleTargetFileMatches {
    readonly matches: ReadonlyArray<MatchedParticleTargetFile>;
    readonly warnings: ReadonlyArray<string>;
}
/** Match files by basename to the entity name associated with each particle target id. */
export declare function matchParticleTargetFiles(particles: ParticleList, files: ReadonlyArray<Asset.File>, excludedTargetIds?: ReadonlySet<number>): ParticleTargetFileMatches;
/**
 * Load a reference object (structure, shape, or volume) for a particle target from a URL or
 * a file using the registered data format providers. The object is meant to be attached to a
 * `ParticleList` via its `targetMapping`.
 *
 * The resolved asset is kept in the asset manager (so it is part of session snapshots) and
 * added to `assets`, whose owner must dispose the wrappers. Without `assets` it is released
 * again once parsed.
 */
export declare function loadParticleTarget(plugin: PluginContext, ctx: RuntimeContext, source: ParticleTargetSource, assets?: Asset.Wrapper[]): Promise<ParticleTarget>;
/** Load the reference objects of several targets, skipping the ones that fail with a warning. */
export declare function loadParticleTargets(plugin: PluginContext, ctx: RuntimeContext, sources: ReadonlyArray<{
    targetId: number;
    source: ParticleTargetSource;
}>, assets?: Asset.Wrapper[]): Promise<ParticleTargetEntry[]>;
/**
 * Resolve a value that is either a 4-character PDB id or a direct URL into a target source,
 * mirroring the `DownloadStructure` action: PDB ids are fetched from the default provider.
 */
export declare function particleTargetSourceFromPdbIdOrUrl(plugin: PluginContext, idOrUrl: string): ParticleTargetSource;
/** Resolves the geometries referenced by Simularium agent types into reference objects. */
export declare function createSimulariumGeometryResolver(plugin: PluginContext, ctx: RuntimeContext, assets?: Asset.Wrapper[]): SimulariumGeometryResolver;
//# sourceMappingURL=particle-targets.d.ts.map