/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
export declare const BuiltInTrajectoryFormats: readonly [{
    readonly name: "mmcif";
    readonly label: "mmCIF";
    readonly description: "mmCIF";
    readonly category: "Trajectory";
    readonly stringExtensions: ["cif", "mmcif", "mcif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Trajectory, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        trajectory: import("@molstar/model/model/structure").Trajectory;
    }>;
    readonly parseBlob: typeof import("./mmcif.js").parseMmcifBlob;
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly name: "cifCore";
    readonly label: "cifCore";
    readonly description: "CIF Core";
    readonly category: "Trajectory";
    readonly stringExtensions: ["cif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Trajectory, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        trajectory: import("@molstar/model/model/structure").Trajectory;
    }>;
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pdb";
    readonly label: "PDB";
    readonly description: "PDB";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pdb", "ent"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pdbqt";
    readonly label: "PDBQT";
    readonly description: "PDBQT";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pdbqt"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pqr";
    readonly label: "PQR";
    readonly description: "PQR";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pqr"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "gro";
    readonly label: "GRO";
    readonly description: "GRO";
    readonly category: "Trajectory";
    readonly stringExtensions: ["gro"];
    readonly binaryExtensions: [];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "xyz";
    readonly label: "XYZ";
    readonly description: "XYZ";
    readonly category: "Trajectory";
    readonly stringExtensions: ["xyz"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "lammps_data";
    readonly label: "Lammps Data";
    readonly description: "Lammps Data";
    readonly category: "Trajectory";
    readonly stringExtensions: ["data"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "lammps_traj_data";
    readonly label: "Lammps Trajectory Data";
    readonly description: "Lammps Trajectory Data";
    readonly category: "Trajectory";
    readonly stringExtensions: ["lammpstrj"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "mol";
    readonly label: "MOL";
    readonly description: "MOL";
    readonly category: "Trajectory";
    readonly stringExtensions: ["mol"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "sdf";
    readonly label: "SDF";
    readonly description: "SDF";
    readonly category: "Trajectory";
    readonly stringExtensions: ["sdf", "sd"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "mol2";
    readonly label: "MOL2";
    readonly description: "MOL2";
    readonly category: "Trajectory";
    readonly stringExtensions: ["mol2"];
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}];
export type BuiltInTrajectoryFormat = (typeof BuiltInTrajectoryFormats)[number]['name'];
//# sourceMappingURL=catalog.d.ts.map