/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { TrajectoryFromPDB };
type TrajectoryFromPDB = typeof TrajectoryFromPDB;
declare const TrajectoryFromPDB: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Molecule.Trajectory, PD.Normalize<{
    variant: "pdb" | "pdbqt" | "pqr";
}>>;
export declare const PdbProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pdb";
    readonly label: "PDB";
    readonly description: "PDB";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pdb", "ent"];
    readonly visuals: typeof defaultVisuals;
};
export declare const PdbqtProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pdbqt";
    readonly label: "PDBQT";
    readonly description: "PDBQT";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pdbqt"];
    readonly visuals: typeof defaultVisuals;
};
export declare const PqrProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "pqr";
    readonly label: "PQR";
    readonly description: "PQR";
    readonly category: "Trajectory";
    readonly stringExtensions: ["pqr"];
    readonly visuals: typeof defaultVisuals;
};
/** The Pdb data format with its actions. */
export declare const Pdb: PluginRegistryEntry;
/** The Pdbqt data format with its actions. */
export declare const Pdbqt: PluginRegistryEntry;
/** The Pqr data format with its actions. */
export declare const Pqr: PluginRegistryEntry;
//# sourceMappingURL=pdb.d.ts.map