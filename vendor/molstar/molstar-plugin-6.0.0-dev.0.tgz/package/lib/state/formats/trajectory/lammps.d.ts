/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { TrajectoryFromLammpsData };
type TrajectoryFromLammpsData = typeof TrajectoryFromLammpsData;
declare const TrajectoryFromLammpsData: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Molecule.Trajectory, PD.Normalize<{
    unitsStyle: "cgs" | "electron" | "lj" | "metal" | "micro" | "nano" | "real" | "si";
}>>;
export { TrajectoryFromLammpsTrajData };
type TrajectoryFromLammpsTrajData = typeof TrajectoryFromLammpsTrajData;
declare const TrajectoryFromLammpsTrajData: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Molecule.Trajectory, PD.Normalize<{
    unitsStyle: "cgs" | "electron" | "lj" | "metal" | "micro" | "nano" | "real" | "si";
}>>;
export declare const LammpsDataProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "lammps_data";
    readonly label: "Lammps Data";
    readonly description: "Lammps Data";
    readonly category: "Trajectory";
    readonly stringExtensions: ["data"];
    readonly visuals: typeof defaultVisuals;
};
export declare const LammpsTrajectoryDataProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "lammps_traj_data";
    readonly label: "Lammps Trajectory Data";
    readonly description: "Lammps Trajectory Data";
    readonly category: "Trajectory";
    readonly stringExtensions: ["lammpstrj"];
    readonly visuals: typeof defaultVisuals;
};
/** The LammpsData data format. */
export declare const LammpsData: PluginRegistryEntry;
/** The LammpsTrajectoryData data format. */
export declare const LammpsTrajectoryData: PluginRegistryEntry;
//# sourceMappingURL=lammps.d.ts.map