/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { type Trajectory } from '@molstar/model/model/structure';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { defaultVisuals } from './provider.js';
import { ParseBlob } from '@molstar/plugin/state/formats/cif';
import type { PluginContext } from '@molstar/plugin/context';
import type { StateObjectRef, StateTransformer } from '@molstar/core/state';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { TrajectoryFromBlob };
type TrajectoryFromBlob = typeof TrajectoryFromBlob;
declare const TrajectoryFromBlob: StateTransformer<SO.Format.Blob, SO.Molecule.Trajectory, PD.Normalize<{}>>;
/**
 * Parses a blob of several mmCIF entries into a single trajectory. `builders.structure.parseTrajectory(blob)` calls
 * this through the registered mmCIF format.
 */
export declare function parseMmcifBlob(plugin: PluginContext, data: StateObjectRef<SO.Data.Blob>, params: StateTransformer.Params<typeof ParseBlob>): Promise<import("@molstar/core/state").StateObjectSelector<SO.Molecule.Trajectory, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
export { TrajectoryFromMmCif };
type TrajectoryFromMmCif = typeof TrajectoryFromMmCif;
declare const TrajectoryFromMmCif: StateTransformer<SO.Format.Cif, SO.Molecule.Trajectory, PD.Normalize<{
    loadAllBlocks: boolean | undefined;
    blockHeader: string | undefined;
    blockIndex: number | undefined;
}>>;
export declare const MmcifProvider: {
    readonly name: "mmcif";
    readonly label: "mmCIF";
    readonly description: "mmCIF";
    readonly category: "Trajectory";
    readonly stringExtensions: ["cif", "mmcif", "mcif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: PluginContext, data: StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state").StateObjectSelector<SO.Molecule.Trajectory, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    }>;
    readonly parseRaw: (plugin: PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        trajectory: Trajectory;
    }>;
    readonly parseBlob: typeof parseMmcifBlob;
    readonly visuals: typeof defaultVisuals;
};
/** The Mmcif data format with its actions. */
export declare const Mmcif: PluginRegistryEntry;
//# sourceMappingURL=mmcif.d.ts.map