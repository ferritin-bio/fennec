/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { TrajectoryFromSDF };
type TrajectoryFromSDF = typeof TrajectoryFromSDF;
declare const TrajectoryFromSDF: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Molecule.Trajectory, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export declare const SdfProvider: {
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectRef<SO.Molecule.Trajectory>;
    }>;
    readonly parseRaw?: ((plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: import("@molstar/core/util/string-like").StringLike | Uint8Array, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<any>) | undefined;
    readonly name: "sdf";
    readonly label: "SDF";
    readonly description: "SDF";
    readonly category: "Trajectory";
    readonly stringExtensions: ["sdf", "sd"];
    readonly visuals: typeof defaultVisuals;
};
/** The Sdf data format. */
export declare const Sdf: PluginRegistryEntry;
//# sourceMappingURL=sdf.d.ts.map