/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import type { Trajectory } from '@molstar/model/model/structure';
export declare function trajectoryProps(trajectory: Trajectory): {
    label: string;
    description: string;
};
//# sourceMappingURL=helpers.d.ts.map