/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { TrajectoryFromCifCore };
type TrajectoryFromCifCore = typeof TrajectoryFromCifCore;
declare const TrajectoryFromCifCore: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Cif, SO.Molecule.Trajectory, PD.Normalize<{
    blockHeader: string | undefined;
}>>;
export declare const CifCoreProvider: {
    readonly name: "cifCore";
    readonly label: "cifCore";
    readonly description: "CIF Core";
    readonly category: "Trajectory";
    readonly stringExtensions: ["cif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        trajectoryTags?: string | string[];
    } | undefined) => Promise<{
        trajectory: import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Trajectory, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        trajectory: import("@molstar/model/model/structure").Trajectory;
    }>;
    readonly visuals: typeof defaultVisuals;
};
/** The CifCore data format with its actions. */
export declare const CifCore: PluginRegistryEntry;
//# sourceMappingURL=cif-core.d.ts.map