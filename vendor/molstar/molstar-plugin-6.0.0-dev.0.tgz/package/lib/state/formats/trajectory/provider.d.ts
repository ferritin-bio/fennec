/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import type { StateObjectRef, StateObjectSelector, StateTransformer } from '@molstar/core/state';
import type { PluginStateObject } from '@molstar/plugin/state/objects';
import type { ParseBlob } from '@molstar/plugin/state/formats/cif';
import { type DataFormatProvider } from '@molstar/plugin/state/formats/provider';
import type { PluginContext } from '@molstar/plugin/context';
export interface TrajectoryFormatProvider<P extends {
    trajectoryTags?: string | string[];
} = {
    trajectoryTags?: string | string[];
}, R extends {
    trajectory: StateObjectRef<PluginStateObject.Molecule.Trajectory>;
} = {
    trajectory: StateObjectRef<PluginStateObject.Molecule.Trajectory>;
}, Id extends string = string> extends DataFormatProvider<P, R, any, any, Id> {
    /**
     * Parses a blob of several data entries into a single trajectory. Used by `builders.structure.parseTrajectory(blob)`
     * and implemented by the mmCIF format only.
     */
    parseBlob?(plugin: PluginContext, blob: StateObjectRef<PluginStateObject.Data.Blob>, params: StateTransformer.Params<typeof ParseBlob>): Promise<StateObjectSelector<PluginStateObject.Molecule.Trajectory>>;
}
/** Identity helper that type checks a trajectory provider and keeps its `name` a literal type. */
export declare function TrajectoryFormatProvider<const T extends TrajectoryFormatProvider>(provider: T): T;
export declare function defaultVisuals(plugin: PluginContext, data: {
    trajectory: StateObjectRef<PluginStateObject.Molecule.Trajectory>;
}): Promise<any> | undefined;
export declare function directTrajectory<P extends {}>(transformer: StateTransformer<PluginStateObject.Data.String | PluginStateObject.Data.Binary, PluginStateObject.Molecule.Trajectory, P>, transformerParams?: P): Pick<TrajectoryFormatProvider, 'parse' | 'parseRaw'>;
//# sourceMappingURL=provider.d.ts.map