/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { CoordinatesFromLammpstraj };
type CoordinatesFromLammpstraj = typeof CoordinatesFromLammpstraj;
declare const CoordinatesFromLammpstraj: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Molecule.Coordinates, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { LammpsTrajectoryProvider };
declare const LammpsTrajectoryProvider: {
    readonly name: "lammpstrj";
    readonly label: "LAMMPSTRAJ";
    readonly description: "LAMMPSTRAJ";
    readonly category: "Coordinates";
    readonly stringExtensions: ["lammpstrj"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
};
type LammpsTrajectoryProvider = typeof LammpsTrajectoryProvider;
/** The LammpsTrajectory data format. */
export declare const LammpsTrajectory: PluginRegistryEntry;
//# sourceMappingURL=lammps.d.ts.map