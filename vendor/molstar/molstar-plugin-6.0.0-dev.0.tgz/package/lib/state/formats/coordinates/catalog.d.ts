/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
export declare const BuiltInCoordinatesFormats: readonly [{
    readonly name: "dcd";
    readonly label: "DCD";
    readonly description: "DCD";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["dcd"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "xtc";
    readonly label: "XTC";
    readonly description: "XTC";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["xtc"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "trr";
    readonly label: "TRR";
    readonly description: "TRR";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["trr"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "nctraj";
    readonly label: "NCTRAJ";
    readonly description: "NCTRAJ";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["nc", "nctraj"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "lammpstrj";
    readonly label: "LAMMPSTRAJ";
    readonly description: "LAMMPSTRAJ";
    readonly category: "Coordinates";
    readonly stringExtensions: ["lammpstrj"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}];
export type BuiltInCoordinatesFormat = (typeof BuiltInCoordinatesFormats)[number]['name'];
//# sourceMappingURL=catalog.d.ts.map