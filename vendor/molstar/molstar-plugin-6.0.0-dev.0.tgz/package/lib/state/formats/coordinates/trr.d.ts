/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { CoordinatesFromTrr };
type CoordinatesFromTrr = typeof CoordinatesFromTrr;
declare const CoordinatesFromTrr: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Molecule.Coordinates, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { TrrProvider };
declare const TrrProvider: {
    readonly name: "trr";
    readonly label: "TRR";
    readonly description: "TRR";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["trr"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
};
type TrrProvider = typeof TrrProvider;
/** The Trr data format. */
export declare const Trr: PluginRegistryEntry;
//# sourceMappingURL=trr.d.ts.map