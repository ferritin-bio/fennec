/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { CoordinatesFromDcd };
type CoordinatesFromDcd = typeof CoordinatesFromDcd;
declare const CoordinatesFromDcd: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Molecule.Coordinates, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { DcdProvider };
declare const DcdProvider: {
    readonly name: "dcd";
    readonly label: "DCD";
    readonly description: "DCD";
    readonly category: "Coordinates";
    readonly binaryExtensions: ["dcd"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Coordinates, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
};
type DcdProvider = typeof DcdProvider;
/** The Dcd data format. */
export declare const Dcd: PluginRegistryEntry;
//# sourceMappingURL=dcd.d.ts.map