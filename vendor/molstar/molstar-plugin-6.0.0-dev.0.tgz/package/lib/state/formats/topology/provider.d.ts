/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PsfProvider } from './psf.js';
export type TopologyProvider = PsfProvider;
//# sourceMappingURL=provider.d.ts.map