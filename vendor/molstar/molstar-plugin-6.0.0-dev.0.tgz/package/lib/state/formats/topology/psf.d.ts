/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParsePsf };
type ParsePsf = typeof ParsePsf;
declare const ParsePsf: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Psf, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { TopologyFromPsf };
type TopologyFromPsf = typeof TopologyFromPsf;
declare const TopologyFromPsf: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Psf, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { PsfProvider };
declare const PsfProvider: {
    readonly name: "psf";
    readonly label: "PSF";
    readonly description: "PSF";
    readonly category: "Topology";
    readonly stringExtensions: ["psf"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Psf, import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Psf, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Psf, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
};
type PsfProvider = typeof PsfProvider;
/** The Psf data format. */
export declare const Psf: PluginRegistryEntry;
//# sourceMappingURL=psf.d.ts.map