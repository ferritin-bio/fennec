/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParsePrmtop };
type ParsePrmtop = typeof ParsePrmtop;
declare const ParsePrmtop: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Prmtop, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { TopologyFromPrmtop };
type TopologyFromPrmtop = typeof TopologyFromPrmtop;
declare const TopologyFromPrmtop: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Prmtop, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { PrmtopProvider };
declare const PrmtopProvider: {
    readonly name: "prmtop";
    readonly label: "PRMTOP";
    readonly description: "PRMTOP";
    readonly category: "Topology";
    readonly stringExtensions: ["prmtop", "parm7"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Prmtop, import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Prmtop, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Prmtop, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
};
type PrmtopProvider = typeof PrmtopProvider;
/** The Prmtop data format. */
export declare const Prmtop: PluginRegistryEntry;
//# sourceMappingURL=prmtop.d.ts.map