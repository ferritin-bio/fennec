/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInTopologyFormats: readonly [{
    readonly name: "psf";
    readonly label: "PSF";
    readonly description: "PSF";
    readonly category: "Topology";
    readonly stringExtensions: ["psf"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Psf, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Psf, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Psf, import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
}, {
    readonly name: "prmtop";
    readonly label: "PRMTOP";
    readonly description: "PRMTOP";
    readonly category: "Topology";
    readonly stringExtensions: ["prmtop", "parm7"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Prmtop, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Prmtop, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Prmtop, import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
}, {
    readonly name: "top";
    readonly label: "TOP";
    readonly description: "TOP";
    readonly category: "Topology";
    readonly stringExtensions: ["top"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Top, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Top, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Top, import("../../objects.js").PluginStateObject.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
}];
export type BuiltInTopologyFormat = (typeof BuiltInTopologyFormats)[number]['name'];
//# sourceMappingURL=catalog.d.ts.map