/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseTop };
type ParseTop = typeof ParseTop;
declare const ParseTop: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Top, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { TopologyFromTop };
type TopologyFromTop = typeof TopologyFromTop;
declare const TopologyFromTop: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Top, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { TopProvider };
declare const TopProvider: {
    readonly name: "top";
    readonly label: "TOP";
    readonly description: "TOP";
    readonly category: "Topology";
    readonly stringExtensions: ["top"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Top, import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.Top, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        topology: import("@molstar/core/state/object").StateObjectSelector<SO.Molecule.Topology, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Top, SO.Molecule.Topology, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
    }>;
};
type TopProvider = typeof TopProvider;
/** The Top data format. */
export declare const Top: PluginRegistryEntry;
//# sourceMappingURL=top.d.ts.map