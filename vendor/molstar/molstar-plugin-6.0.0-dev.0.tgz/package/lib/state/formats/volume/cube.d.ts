/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO, type PluginStateObject } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type VolumeFormatParams, type VolumeData } from './provider.js';
import type { PluginContext } from '@molstar/plugin/context';
import type { StateObjectSelector } from '@molstar/core/state';
import { Volume } from '@molstar/model/model/volume';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseCube };
type ParseCube = typeof ParseCube;
declare const ParseCube: import("@molstar/core/state").StateTransformer<SO.Data.String, SO.Format.Cube, PD.Normalize<{}>>;
export { TrajectoryFromCube };
type TrajectoryFromCube = typeof TrajectoryFromCube;
declare const TrajectoryFromCube: import("@molstar/core/state").StateTransformer<SO.Format.Cube, SO.Molecule.Trajectory, PD.Normalize<{}>>;
export { VolumeFromCube };
type VolumeFromCube = typeof VolumeFromCube;
declare const VolumeFromCube: import("@molstar/core/state").StateTransformer<SO.Format.Cube, SO.Volume.Data, PD.Normalize<{
    dataIndex: number;
    entryId: string;
}>>;
export declare const CubeProvider: {
    readonly name: "cube";
    readonly label: "Cube";
    readonly description: "Cube";
    readonly category: "Volume";
    readonly stringExtensions: ["cub", "cube"];
    readonly parse: (plugin: PluginContext, data: import("@molstar/core/state").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: VolumeFormatParams) => Promise<{
        format: StateObjectSelector<SO.Format.Cube, import("@molstar/core/state").StateTransformer<SO.Data.String, SO.Format.Cube, PD.Normalize<{}>>>;
        volume: StateObjectSelector<SO.Volume.Data, import("@molstar/core/state").StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
        structure: StateObjectSelector<SO.Molecule.Structure, import("@molstar/core/state").StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: VolumeFormatParams) => Promise<{
        volume: Volume;
    }>;
    readonly visuals: (plugin: PluginContext, data: {
        volume: VolumeData;
        structure: StateObjectSelector<PluginStateObject.Molecule.Structure>;
    }) => Promise<(StateObjectSelector<SO.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | StateObjectSelector<SO.Volume.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>)[]>;
};
/** The Cube data format with its actions and the representations its visuals use. */
export declare const Cube: PluginRegistryEntry;
//# sourceMappingURL=cube.d.ts.map