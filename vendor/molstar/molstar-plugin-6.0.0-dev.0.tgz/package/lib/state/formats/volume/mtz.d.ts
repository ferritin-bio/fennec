/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { VolumeData } from './provider.js';
import { Volume } from '@molstar/model/model/volume';
import type { StateObjectSelector } from '@molstar/core/state';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseMtz };
type ParseMtz = typeof ParseMtz;
declare const ParseMtz: import("@molstar/core/state").StateTransformer<SO.Data.Binary, SO.Format.Mtz, PD.Normalize<{}>>;
export { VolumeFromMtz };
type VolumeFromMtz = typeof VolumeFromMtz;
declare const VolumeFromMtz: import("@molstar/core/state").StateTransformer<SO.Format.Mtz, SO.Volume.Data, PD.Normalize<{
    ampLabel: string;
    phiLabel: string;
    entryId: string;
}>>;
type MtzParams = {
    entryId?: string;
};
export declare const MtzProvider: {
    readonly name: "mtz";
    readonly label: "MTZ";
    readonly description: "CCP4 MTZ reflection data file with amplitude and phase columns";
    readonly category: "Volume";
    readonly binaryExtensions: ["mtz"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: MtzParams) => Promise<{
        volumes: {
            '2fofc': VolumeData[];
            fofc: VolumeData[];
        };
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: MtzParams) => Promise<{
        volumes: Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: {
            '2fofc': VolumeData[];
            fofc: VolumeData[];
        };
    }) => Promise<StateObjectSelector<SO.Volume.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[]>;
};
/** The Mtz data format and the representations its visuals use. */
export declare const Mtz: PluginRegistryEntry;
//# sourceMappingURL=mtz.d.ts.map