/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { type VolumeFormatParams, defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseCcp4 };
type ParseCcp4 = typeof ParseCcp4;
declare const ParseCcp4: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Ccp4, PD.Normalize<{}>>;
export { VolumeFromCcp4 };
type VolumeFromCcp4 = typeof VolumeFromCcp4;
declare const VolumeFromCcp4: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Ccp4, SO.Volume.Data, PD.Normalize<{
    voxelSize: Vec3;
    offset: Vec3;
    entryId: string;
}>>;
export declare const Ccp4Provider: {
    readonly name: "ccp4";
    readonly label: "CCP4/MRC/MAP";
    readonly description: "CCP4/MRC/MAP";
    readonly category: "Volume";
    readonly binaryExtensions: ["ccp4", "mrc", "map"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: VolumeFormatParams) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Ccp4, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Ccp4, PD.Normalize<{}>>>;
        volume: import("@molstar/core/state/object").StateObjectSelector<SO.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof defaultVisuals;
};
/** The Ccp4 data format with its actions and the representations its visuals use. */
export declare const Ccp4: PluginRegistryEntry;
//# sourceMappingURL=ccp4.d.ts.map