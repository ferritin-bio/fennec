/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
export declare const BuiltInVolumeFormats: readonly [{
    readonly name: "ccp4";
    readonly label: "CCP4/MRC/MAP";
    readonly description: "CCP4/MRC/MAP";
    readonly category: "Volume";
    readonly binaryExtensions: ["ccp4", "mrc", "map"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Ccp4, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary, import("../../objects.js").PluginStateObject.Format.Ccp4, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        volume: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Volume.Data, import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly name: "dsn6";
    readonly label: "DSN6/BRIX";
    readonly description: "DSN6/BRIX";
    readonly category: "Volume";
    readonly binaryExtensions: ["dsn6", "brix"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Dsn6, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary, import("../../objects.js").PluginStateObject.Format.Dsn6, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        volume: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Volume.Data, import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly name: "cube";
    readonly label: "Cube";
    readonly description: "Cube";
    readonly category: "Volume";
    readonly stringExtensions: ["cub", "cube"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Cube, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Cube, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        volume: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Volume.Data, import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Molecule.Structure, import("../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volume: import("./provider.js").VolumeData;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Structure>;
    }) => Promise<(import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>)[]>;
}, {
    readonly name: "dx";
    readonly label: "DX";
    readonly description: "DX";
    readonly category: "Volume";
    readonly stringExtensions: ["dx"];
    readonly binaryExtensions: ["dxbin"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        volume: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Volume.Data, import("../../objects.js").PluginStateObject.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: import("./provider.js").VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof import("./provider.js").defaultVisuals;
}, {
    readonly name: "dscif";
    readonly label: "DensityServer CIF";
    readonly description: "DensityServer CIF";
    readonly category: "Volume";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        entryId?: string | string[];
    }) => Promise<{
        volumes: import("./provider.js").VolumeData[];
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: {
        entryId?: string | string[];
    }) => Promise<{
        volumes: import("@molstar/model/model/volume").Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data>[];
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[]>;
}, {
    readonly name: "segcif";
    readonly label: "Segmentation CIF";
    readonly description: "Segmentation CIF";
    readonly category: "Volume";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        volumes: import("./provider.js").VolumeData[];
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        volumes: import("@molstar/model/model/volume").Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Data>[];
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[]>;
}, {
    readonly name: "sfcif";
    readonly label: "Structure Factors CIF";
    readonly description: "mmCIF structure factor file with reflection data (pdbx_FWT/pdbx_PHWT map coefficients)";
    readonly category: "Volume";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        entryId?: string;
    }) => Promise<{
        volumes: {
            '2fofc': import("./provider.js").VolumeData[];
            fofc: import("./provider.js").VolumeData[];
        };
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: {
        entryId?: string;
    }) => Promise<{
        volumes: import("@molstar/model/model/volume").Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: {
            '2fofc': import("./provider.js").VolumeData[];
            fofc: import("./provider.js").VolumeData[];
        };
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[]>;
}, {
    readonly name: "mtz";
    readonly label: "MTZ";
    readonly description: "CCP4 MTZ reflection data file with amplitude and phase columns";
    readonly category: "Volume";
    readonly binaryExtensions: ["mtz"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        entryId?: string;
    }) => Promise<{
        volumes: {
            '2fofc': import("./provider.js").VolumeData[];
            fofc: import("./provider.js").VolumeData[];
        };
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: {
        entryId?: string;
    }) => Promise<{
        volumes: import("@molstar/model/model/volume").Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: {
            '2fofc': import("./provider.js").VolumeData[];
            fofc: import("./provider.js").VolumeData[];
        };
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Volume.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[]>;
}];
export type BuiltInVolumeFormat = (typeof BuiltInVolumeFormats)[number]['name'];
/** @deprecated use BuiltInVolumeFormat */
export type BuildInVolumeFormat = BuiltInVolumeFormat;
//# sourceMappingURL=catalog.d.ts.map