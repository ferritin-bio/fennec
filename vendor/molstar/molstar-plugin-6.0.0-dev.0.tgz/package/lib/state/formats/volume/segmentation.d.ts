/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO, type PluginStateObject } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { VolumeData } from './provider.js';
import { Volume } from '@molstar/model/model/volume';
import type { StateObjectSelector } from '@molstar/core/state';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { VolumeFromSegmentationCif };
type VolumeFromSegmentationCif = typeof VolumeFromSegmentationCif;
declare const VolumeFromSegmentationCif: import("@molstar/core/state").StateTransformer<SO.Format.Cif, SO.Volume.Data, PD.Normalize<{
    blockHeader: string | undefined;
    segmentLabels: PD.Normalize<{
        id: /*elided*/ any;
        label: /*elided*/ any;
    }>[];
    ownerId: string;
}>>;
export declare const SegcifProvider: {
    readonly name: "segcif";
    readonly label: "Segmentation CIF";
    readonly description: "Segmentation CIF";
    readonly category: "Volume";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state").StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<{
        volumes: VolumeData[];
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        volumes: Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: StateObjectSelector<PluginStateObject.Volume.Data>[];
    }) => Promise<StateObjectSelector<SO.Volume.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[]>;
};
/** The Segcif data format and the representations its visuals use. */
export declare const Segcif: PluginRegistryEntry;
//# sourceMappingURL=segmentation.d.ts.map