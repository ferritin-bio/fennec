/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO, type PluginStateObject } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type VolumeData } from './provider.js';
import { Volume } from '@molstar/model/model/volume';
import type { StateObjectSelector } from '@molstar/core/state';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { VolumeFromDensityServerCif };
type VolumeFromDensityServerCif = typeof VolumeFromDensityServerCif;
declare const VolumeFromDensityServerCif: import("@molstar/core/state").StateTransformer<SO.Format.Cif, SO.Volume.Data, PD.Normalize<{
    blockHeader: string | undefined;
    entryId: string;
}>>;
type DsCifParams = {
    entryId?: string | string[];
};
export declare const DscifProvider: {
    readonly name: "dscif";
    readonly label: "DensityServer CIF";
    readonly description: "DensityServer CIF";
    readonly category: "Volume";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: DsCifParams) => Promise<{
        volumes: VolumeData[];
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: DsCifParams) => Promise<{
        volumes: Volume[];
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        volumes: StateObjectSelector<PluginStateObject.Volume.Data>[];
    }) => Promise<StateObjectSelector<SO.Volume.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[]>;
};
/** The Dscif data format and the representations its visuals use. */
export declare const Dscif: PluginRegistryEntry;
//# sourceMappingURL=density-server.d.ts.map