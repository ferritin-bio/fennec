/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { type VolumeFormatParams, defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseDx };
type ParseDx = typeof ParseDx;
declare const ParseDx: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Dx, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export { VolumeFromDx };
type VolumeFromDx = typeof VolumeFromDx;
declare const VolumeFromDx: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Dx, SO.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>;
export declare const DxProvider: {
    readonly name: "dx";
    readonly label: "DX";
    readonly description: "DX";
    readonly category: "Volume";
    readonly stringExtensions: ["dx"];
    readonly binaryExtensions: ["dxbin"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: VolumeFormatParams) => Promise<{
        volume: import("@molstar/core/state/object").StateObjectSelector<SO.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<SO.Volume.Data, SO.Volume.Data, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: string[];
            properties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof defaultVisuals;
};
/** The Dx data format with its actions and the representations its visuals use. */
export declare const Dx: PluginRegistryEntry;
//# sourceMappingURL=dx.d.ts.map