/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { Volume } from '@molstar/model/model/volume';
import type { StateObjectSelector } from '@molstar/core/state';
import type { PluginStateObject } from '@molstar/plugin/state/objects';
export type VolumeFormatParams = {
    entryId?: string;
};
export declare function tryObtainRecommendedIsoValue(plugin: PluginContext, volume?: Volume): Promise<void>;
export declare function tryGetRecomendedIsoValue(volume: Volume): Readonly<{
    kind: 'relative';
    relativeValue: number;
}> | Readonly<{
    kind: 'absolute';
    absoluteValue: number;
}> | undefined;
export type VolumeData = StateObjectSelector<PluginStateObject.Volume.Data>;
export declare function defaultVisuals(plugin: PluginContext, data: {
    volume: VolumeData;
}): Promise<StateObjectSelector<PluginStateObject.Volume.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[]>;
//# sourceMappingURL=provider.d.ts.map