/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 * @author Aliaksei Chareshneu <chareshneu.tech@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { type VolumeFormatParams, defaultVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseDsn6 };
type ParseDsn6 = typeof ParseDsn6;
declare const ParseDsn6: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Dsn6, PD.Normalize<{}>>;
export { VolumeFromDsn6 };
type VolumeFromDsn6 = typeof VolumeFromDsn6;
declare const VolumeFromDsn6: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Dsn6, SO.Volume.Data, PD.Normalize<{
    voxelSize: Vec3;
    entryId: string;
}>>;
export declare const Dsn6Provider: {
    readonly name: "dsn6";
    readonly label: "DSN6/BRIX";
    readonly description: "DSN6/BRIX";
    readonly category: "Volume";
    readonly binaryExtensions: ["dsn6", "brix"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: VolumeFormatParams) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Dsn6, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Dsn6, PD.Normalize<{}>>>;
        volume: import("@molstar/core/state/object").StateObjectSelector<SO.Volume.Data, import("@molstar/core/state/transformer").StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike, params?: VolumeFormatParams) => Promise<{
        volume: import("@molstar/model/model/volume").Volume;
    }>;
    readonly visuals: typeof defaultVisuals;
};
/** The Dsn6 data format with its actions and the representations its visuals use. */
export declare const Dsn6: PluginRegistryEntry;
//# sourceMappingURL=dsn6.d.ts.map