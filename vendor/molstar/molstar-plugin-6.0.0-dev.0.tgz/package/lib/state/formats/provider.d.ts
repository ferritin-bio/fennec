/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StringLike } from '@molstar/core/util/string-like';
import type { PluginContext } from '@molstar/plugin/context';
import type { StateObject, StateObjectRef, StateTransformer } from '@molstar/core/state';
import { RuntimeContext } from '@molstar/core/task';
import type { FileNameInfo } from '@molstar/core/util/file-info';
import { PluginStateObject } from '../objects.js';
export interface DataFormatProvider<P = any, R = any, V = any, D = any, Id extends string = string> {
    /** Registration name of the format, used in format params and `DownloadFile` options. */
    readonly name: Id;
    label: string;
    description: string;
    category?: string;
    stringExtensions?: string[];
    binaryExtensions?: string[];
    /**
     * Controls the order in which `DataFormatRegistry.auto` tries providers that share the
     * same extension, independent of registration order. Higher values are tried first.
     * Defaults to 0. Use a positive value for providers with a restrictive `isApplicable`
     * that should take precedence over more generic fallback providers (e.g. a specialized
     * variant of a shared file extension).
     */
    priority?: number;
    isApplicable?(info: FileNameInfo, data: StringLike | Uint8Array): boolean;
    parse(plugin: PluginContext, data: StateObjectRef<PluginStateObject.Data.Binary | PluginStateObject.Data.String>, params?: P): Promise<R>;
    /**
     * Parse the data into plain objects without creating state tree nodes. In contrast to `parse`
     * this can be called from within a state update, e.g. from a transformer.
     */
    parseRaw?(plugin: PluginContext, ctx: RuntimeContext, data: StringLike | Uint8Array, params?: P): Promise<D>;
    visuals?(plugin: PluginContext, data: R): Promise<V> | undefined;
    defaultData?: D;
}
/** Identity helper that type checks a provider and keeps its `name` a literal type. */
export declare function DataFormatProvider<const T extends DataFormatProvider>(provider: T): T;
export declare namespace DataFormatProvider {
    /** A provider that may lack a `name`, such as the user-supplied `customFormats` of the Viewer. */
    type Unnamed<P = any, R = any, V = any, D = any, Id extends string = string> = Omit<DataFormatProvider<P, R, V, D, Id>, 'name'> & {
        name?: Id;
    };
    /**
     * Returns `provider` when it is already called `name`, otherwise a copy that has `name`. Copies are
     * memoized, so repeated calls with the same arguments return the same object (the copy is a separate
     * identity from `provider`).
     */
    function withName<P = any, R = any, V = any, D = any>(provider: Unnamed<P, R, V, D>, name: string): DataFormatProvider<P, R, V, D>;
}
export declare function rawDataObject(data: StringLike | Uint8Array): PluginStateObject.Data.Binary | PluginStateObject.Data.String;
/** Applies a transformer directly, without adding nodes to the state tree. */
export declare function applyTransformerRaw<A extends StateObject, B extends StateObject, P extends {}>(plugin: PluginContext, ctx: RuntimeContext, transformer: StateTransformer<A, B, P>, a: A, params?: Partial<P>): Promise<B> | B;
type CifVariants = 'dscif' | 'segcif' | 'sfcif' | 'coreCif' | -1;
export declare function guessCifVariant(info: FileNameInfo, data: Uint8Array | StringLike): CifVariants;
export {};
//# sourceMappingURL=provider.d.ts.map