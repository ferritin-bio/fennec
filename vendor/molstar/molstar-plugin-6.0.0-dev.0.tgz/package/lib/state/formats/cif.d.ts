/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export { ParseBlob };
type ParseBlob = typeof ParseBlob;
declare const ParseBlob: import("@molstar/core/state").StateTransformer<SO.Data.Blob, SO.Format.Blob, PD.Normalize<{
    formats: PD.Normalize<{
        id: /*elided*/ any;
        format: /*elided*/ any;
    }>[];
}>>;
export { ParseCif };
type ParseCif = typeof ParseCif;
declare const ParseCif: import("@molstar/core/state").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Cif, PD.Normalize<{}>>;
//# sourceMappingURL=cif.d.ts.map