/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { simpleVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParticleListFromRelionStar };
type ParticleListFromRelionStar = typeof ParticleListFromRelionStar;
declare const ParticleListFromRelionStar: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Cif, SO.Particle.List, PD.Normalize<{
    tomograms: string[];
    micrographs: string[];
    pixelSize: number | undefined;
    particleRadius: number;
}>>;
export declare const RelionStarParticlesProvider: {
    readonly name: "relion_star_particles";
    readonly label: "RELION STAR Particles";
    readonly description: "RELION STAR Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["star"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        tomogram?: string;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Cif, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Cif, PD.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Cif, SO.Particle.List, PD.Normalize<{
            tomograms: string[];
            micrographs: string[];
            pixelSize: number | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof simpleVisuals;
};
/** The RelionStarParticles data format with its actions and the representations its visuals use. */
export declare const RelionStarParticles: PluginRegistryEntry;
//# sourceMappingURL=star.d.ts.map