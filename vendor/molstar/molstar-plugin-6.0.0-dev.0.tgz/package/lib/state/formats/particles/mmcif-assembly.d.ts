/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type MmcifVariant } from '@molstar/model/formats/particles/mmcif';
import type { PluginContext } from '@molstar/plugin/context';
import { type ParticleFormatData } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParticleListFromMmcifAssembly };
type ParticleListFromMmcifAssembly = typeof ParticleListFromMmcifAssembly;
declare const ParticleListFromMmcifAssembly: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Cif, SO.Particle.List, PD.Normalize<{
    assemblyId: string;
    asymIds: string[];
    variant: MmcifVariant;
    label: string | undefined;
    resolveTargets: boolean;
}>>;
export declare const MmcifParticlesProvider: {
    readonly name: "mmcif_particles";
    readonly label: "mmCIF Particles";
    readonly description: "mmCIF Particles (CellPack / PetWorld assemblies)";
    readonly category: "Particles";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    /**
     * Higher than the default (0) mmCIF/CifCore trajectory providers so that CellPack/PetWorld
     * assemblies are recognized ahead of them during auto-detection, regardless of registration order.
     */
    readonly priority: 10;
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        assemblyId?: string;
        asymIds?: string[];
        variant?: MmcifVariant;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Cif, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Cif, PD.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Cif, SO.Particle.List, PD.Normalize<{
            assemblyId: string;
            asymIds: string[];
            variant: MmcifVariant;
            label: string | undefined;
            resolveTargets: boolean;
        }>>>;
    }>;
    readonly visuals: (plugin: PluginContext, data: ParticleFormatData) => Promise<void>;
};
/** The MmcifParticles data format with its actions and the representations its visuals use. */
export declare const MmcifParticles: PluginRegistryEntry;
//# sourceMappingURL=mmcif-assembly.d.ts.map