/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { StateObjectRef } from '@molstar/core/state';
import type { PluginStateObject } from '@molstar/plugin/state/objects';
import type { PluginContext } from '@molstar/plugin/context';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export interface ParticleFormatData {
    format: StateObjectRef;
    list: StateObjectRef<PluginStateObject.Particle.List>;
}
export declare function complexVisuals(plugin: PluginContext, data: ParticleFormatData, targetProps?: {
    params?: {};
    colorTheme?: {
        name: string;
        params: {};
    };
    sizeTheme?: {
        name: string;
        params: {};
    };
}): Promise<void>;
export declare function simpleVisuals(plugin: PluginContext, data: ParticleFormatData): Promise<void>;
/** The particle representations and themes used by `simpleVisuals`. */
export declare const SimpleParticleVisuals: PluginRegistryEntry;
/**
 * The particle representations and themes used by `complexVisuals`: spacefill, fibers, and target with their default
 * themes, and the color themes chosen by what the particle list has (hierarchy, entity, compartment, or particle index).
 */
export declare const ComplexParticleVisuals: PluginRegistryEntry;
//# sourceMappingURL=provider.d.ts.map