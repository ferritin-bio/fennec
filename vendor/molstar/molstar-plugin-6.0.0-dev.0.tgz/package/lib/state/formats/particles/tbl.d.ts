/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { simpleVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseDynamoTbl };
type ParseDynamoTbl = typeof ParseDynamoTbl;
declare const ParseDynamoTbl: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.DynamoTbl, PD.Normalize<{}>>;
export { ParticleListFromDynamoTbl };
type ParticleListFromDynamoTbl = typeof ParticleListFromDynamoTbl;
declare const ParticleListFromDynamoTbl: import("@molstar/core/state/transformer").StateTransformer<SO.Format.DynamoTbl, SO.Particle.List, PD.Normalize<{
    tomos: string[];
    pixelSize: number | undefined;
    particleRadius: number;
}>>;
export declare const DynamoTblParticlesProvider: {
    readonly name: "dynamo_tbl_particles";
    readonly label: "Dynamo TBL Particles";
    readonly description: "Dynamo TBL Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["tbl"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        tomo?: number;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.DynamoTbl, import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.DynamoTbl, PD.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Format.DynamoTbl, SO.Particle.List, PD.Normalize<{
            tomos: string[];
            pixelSize: number | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof simpleVisuals;
};
/** The DynamoTblParticles data format with its actions and the representations its visuals use. */
export declare const DynamoTblParticles: PluginRegistryEntry;
//# sourceMappingURL=tbl.d.ts.map