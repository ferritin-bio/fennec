/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { simpleVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseCryoEtDataPortalNdjson };
type ParseCryoEtDataPortalNdjson = typeof ParseCryoEtDataPortalNdjson;
declare const ParseCryoEtDataPortalNdjson: import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.CryoEtDataPortalNdjson, PD.Normalize<{}>>;
export { ParticleListFromCryoEtDataPortalNdjson };
type ParticleListFromCryoEtDataPortalNdjson = typeof ParticleListFromCryoEtDataPortalNdjson;
declare const ParticleListFromCryoEtDataPortalNdjson: import("@molstar/core/state/transformer").StateTransformer<SO.Format.CryoEtDataPortalNdjson, SO.Particle.List, PD.Normalize<{
    pixelSize: number;
    type: string | undefined;
    particleRadius: number;
}>>;
export declare const CryoEtDataPortalNdjsonParticlesProvider: {
    readonly name: "cryoet_ndjson_particles";
    readonly label: "CryoET NDJSON Particles";
    readonly description: "CryoET NDJSON Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["ndjson"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        type?: string;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.CryoEtDataPortalNdjson, import("@molstar/core/state/transformer").StateTransformer<SO.Data.String, SO.Format.CryoEtDataPortalNdjson, PD.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Format.CryoEtDataPortalNdjson, SO.Particle.List, PD.Normalize<{
            pixelSize: number;
            type: string | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof simpleVisuals;
};
/** The CryoEtDataPortalNdjsonParticles data format with its actions and the representations its visuals use. */
export declare const CryoEtDataPortalNdjsonParticles: PluginRegistryEntry;
//# sourceMappingURL=ndjson.d.ts.map