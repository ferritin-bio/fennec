/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInParticlesFormats: readonly [{
    readonly name: "relion_star_particles";
    readonly label: "RELION STAR Particles";
    readonly description: "RELION STAR Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["star"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        tomogram?: string;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Cif, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Cif, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Cif, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            tomograms: string[];
            micrographs: string[];
            pixelSize: number | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof import("./provider.js").simpleVisuals;
}, {
    readonly name: "dynamo_tbl_particles";
    readonly label: "Dynamo TBL Particles";
    readonly description: "Dynamo TBL Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["tbl"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        tomo?: number;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.DynamoTbl, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.DynamoTbl, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.DynamoTbl, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            tomos: string[];
            pixelSize: number | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof import("./provider.js").simpleVisuals;
}, {
    readonly name: "cryoet_ndjson_particles";
    readonly label: "CryoET NDJSON Particles";
    readonly description: "CryoET NDJSON Particles";
    readonly category: "Particles";
    readonly stringExtensions: ["ndjson"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        type?: string;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.CryoEtDataPortalNdjson, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.CryoEtDataPortalNdjson, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.CryoEtDataPortalNdjson, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            pixelSize: number;
            type: string | undefined;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof import("./provider.js").simpleVisuals;
}, {
    readonly name: "artiatomi_em_particles";
    readonly label: "Artiatomi EM Particles";
    readonly description: "Artiatomi EM Particles";
    readonly category: "Particles";
    readonly binaryExtensions: ["em"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        tomo?: number;
        pixelSize?: number;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.ArtiatomiEm, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary, import("../../objects.js").PluginStateObject.Format.ArtiatomiEm, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.ArtiatomiEm, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            tomos: string[];
            pixelSize: number;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof import("./provider.js").simpleVisuals;
}, {
    readonly name: "mmcif_particles";
    readonly label: "mmCIF Particles";
    readonly description: "mmCIF Particles (CellPack / PetWorld assemblies)";
    readonly category: "Particles";
    readonly stringExtensions: ["cif"];
    readonly binaryExtensions: ["bcif"];
    readonly priority: 10;
    readonly isApplicable: (info: import("@molstar/core/util/file-info").FileNameInfo, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => boolean;
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        assemblyId?: string;
        asymIds?: string[];
        variant?: import("@molstar/model/formats/particles/mmcif").MmcifVariant;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Cif, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Cif, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Cif, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            assemblyId: string;
            asymIds: string[];
            variant: import("@molstar/model/formats/particles/mmcif").MmcifVariant;
            label: string | undefined;
            resolveTargets: boolean;
        }>>>;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: import("./provider.js").ParticleFormatData) => Promise<void>;
}, {
    readonly name: "simularium_particles";
    readonly label: "Simularium Particles";
    readonly description: "Simularium Particles";
    readonly category: "Particles";
    readonly binaryExtensions: ["simularium"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>, params?: {
        label?: string;
        frameIndex?: number;
        loadGeometries?: boolean;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Simularium, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary, import("../../objects.js").PluginStateObject.Format.Simularium, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        trajectory: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.Trajectory, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Simularium, import("../../objects.js").PluginStateObject.Particle.Trajectory, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            types: string[];
            scale: number;
            loadGeometries: boolean;
        }>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Particle.Trajectory, import("../../objects.js").PluginStateObject.Particle.List, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            frameIndex: number;
        }>>>;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: import("./provider.js").ParticleFormatData) => Promise<void>;
}];
export type BuiltInParticlesFormat = (typeof BuiltInParticlesFormats)[number]['name'];
//# sourceMappingURL=catalog.d.ts.map