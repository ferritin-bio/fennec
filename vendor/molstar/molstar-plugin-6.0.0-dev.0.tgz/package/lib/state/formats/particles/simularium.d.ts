/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginContext } from '@molstar/plugin/context';
import { type ParticleFormatData } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseSimularium };
type ParseSimularium = typeof ParseSimularium;
declare const ParseSimularium: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Simularium, PD.Normalize<{}>>;
export { ParticleTrajectoryFromSimularium };
type ParticleTrajectoryFromSimularium = typeof ParticleTrajectoryFromSimularium;
declare const ParticleTrajectoryFromSimularium: import("@molstar/core/state/transformer").StateTransformer<SO.Format.Simularium, SO.Particle.Trajectory, PD.Normalize<{
    types: string[];
    scale: number;
    loadGeometries: boolean;
}>>;
export declare const SimulariumParticlesProvider: {
    readonly name: "simularium_particles";
    readonly label: "Simularium Particles";
    readonly description: "Simularium Particles";
    readonly category: "Particles";
    readonly binaryExtensions: ["simularium"];
    readonly parse: (plugin: PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        frameIndex?: number;
        loadGeometries?: boolean;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.Simularium, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.Simularium, PD.Normalize<{}>>>;
        trajectory: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.Trajectory, import("@molstar/core/state/transformer").StateTransformer<SO.Format.Simularium, SO.Particle.Trajectory, PD.Normalize<{
            types: string[];
            scale: number;
            loadGeometries: boolean;
        }>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Particle.Trajectory, SO.Particle.List, PD.Normalize<{
            frameIndex: number;
        }>>>;
    }>;
    readonly visuals: (plugin: PluginContext, data: ParticleFormatData) => Promise<void>;
};
/** The SimulariumParticles data format with its actions and the representations its visuals use. */
export declare const SimulariumParticles: PluginRegistryEntry;
//# sourceMappingURL=simularium.d.ts.map