/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { simpleVisuals } from './provider.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParseArtiatomiEm };
type ParseArtiatomiEm = typeof ParseArtiatomiEm;
declare const ParseArtiatomiEm: import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.ArtiatomiEm, PD.Normalize<{}>>;
export { ParticleListFromArtiatomiEm };
type ParticleListFromArtiatomiEm = typeof ParticleListFromArtiatomiEm;
declare const ParticleListFromArtiatomiEm: import("@molstar/core/state/transformer").StateTransformer<SO.Format.ArtiatomiEm, SO.Particle.List, PD.Normalize<{
    tomos: string[];
    pixelSize: number;
    particleRadius: number;
}>>;
export declare const ArtiatomiEmParticlesProvider: {
    readonly name: "artiatomi_em_particles";
    readonly label: "Artiatomi EM Particles";
    readonly description: "Artiatomi EM Particles";
    readonly category: "Particles";
    readonly binaryExtensions: ["em"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<SO.Data.Binary | SO.Data.String>, params?: {
        label?: string;
        tomo?: number;
        pixelSize?: number;
    }) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<SO.Format.ArtiatomiEm, import("@molstar/core/state/transformer").StateTransformer<SO.Data.Binary, SO.Format.ArtiatomiEm, PD.Normalize<{}>>>;
        list: import("@molstar/core/state/object").StateObjectSelector<SO.Particle.List, import("@molstar/core/state/transformer").StateTransformer<SO.Format.ArtiatomiEm, SO.Particle.List, PD.Normalize<{
            tomos: string[];
            pixelSize: number;
            particleRadius: number;
        }>>>;
    }>;
    readonly visuals: typeof simpleVisuals;
};
/** The ArtiatomiEmParticles data format with its actions and the representations its visuals use. */
export declare const ArtiatomiEmParticles: PluginRegistryEntry;
//# sourceMappingURL=em.d.ts.map