/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const BuiltInShapeFormats: readonly [{
    readonly name: "ply";
    readonly label: "PLY";
    readonly description: "PLY";
    readonly category: "Shape";
    readonly stringExtensions: ["ply"];
    readonly binaryExtensions: ["ply"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Ply, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Ply, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        shape: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Ply, import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            transforms: import("@molstar/core/math/linear-algebra").Mat4[] | undefined;
            label: string | undefined;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        shape: import("@molstar/graphics/geo/shape/provider").ShapeProvider<any, any, any>;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        shape: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Shape.Provider>;
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "obj";
    readonly label: "OBJ";
    readonly description: "OBJ";
    readonly category: "Shape";
    readonly stringExtensions: ["obj"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Obj, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.String, import("../../objects.js").PluginStateObject.Format.Obj, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        shape: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Obj, import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            transforms: import("@molstar/core/math/linear-algebra").Mat4[] | undefined;
            label: string | undefined;
            mtlFile: import("@molstar/core/util/assets").Asset.File | null | undefined;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        shape: import("@molstar/graphics/geo/shape/provider").ShapeProvider<any, any, any>;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        shape: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Shape.Provider>;
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}, {
    readonly name: "vtp";
    readonly label: "VTP";
    readonly description: "VTK PolyData (VTP)";
    readonly category: "Shape";
    readonly binaryExtensions: ["vtp"];
    readonly parse: (plugin: import("../../../context.js").PluginContext, data: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Data.Binary | import("../../objects.js").PluginStateObject.Data.String>) => Promise<{
        format: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Format.Vtp, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Data.Binary, import("../../objects.js").PluginStateObject.Format.Vtp, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{}>>>;
        shape: import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/state/transformer").StateTransformer<import("../../objects.js").PluginStateObject.Format.Vtp, import("../../objects.js").PluginStateObject.Shape.Provider, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            transforms: import("@molstar/core/math/linear-algebra").Mat4[] | undefined;
            label: string | undefined;
        }>>>;
    }>;
    readonly parseRaw: (plugin: import("../../../context.js").PluginContext, ctx: import("@molstar/core/task/index").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        shape: import("@molstar/graphics/geo/shape/provider").ShapeProvider<any, any, any>;
    }>;
    readonly visuals: (plugin: import("../../../context.js").PluginContext, data: {
        shape: import("@molstar/core/state/object").StateObjectRef<import("../../objects.js").PluginStateObject.Shape.Provider>;
    }) => Promise<import("@molstar/core/state/object").StateObjectSelector<import("../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>>;
}];
export type BuiltInShapeFormat = (typeof BuiltInShapeFormats)[number]['name'];
/** @deprecated use BuiltInShapeFormat */
export type BuildInShapeFormat = BuiltInShapeFormat;
//# sourceMappingURL=catalog.d.ts.map