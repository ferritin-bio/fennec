/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO, type PluginStateObject } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Mat4 } from '@molstar/core/math/linear-algebra';
import type { PluginContext } from '@molstar/plugin/context';
import type { StateObjectRef } from '@molstar/core/state';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
export { ParsePly };
type ParsePly = typeof ParsePly;
declare const ParsePly: import("@molstar/core/state").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Ply, PD.Normalize<{}>>;
export { ShapeFromPly };
type ShapeFromPly = typeof ShapeFromPly;
declare const ShapeFromPly: import("@molstar/core/state").StateTransformer<SO.Format.Ply, SO.Shape.Provider, PD.Normalize<{
    transforms: Mat4[] | undefined;
    label: string | undefined;
}>>;
export declare const PlyProvider: {
    readonly name: "ply";
    readonly label: "PLY";
    readonly description: "PLY";
    readonly category: "Shape";
    readonly stringExtensions: ["ply"];
    readonly binaryExtensions: ["ply"];
    readonly parse: (plugin: PluginContext, data: StateObjectRef<SO.Data.Binary | SO.Data.String>) => Promise<{
        format: import("@molstar/core/state").StateObjectSelector<SO.Format.Ply, import("@molstar/core/state").StateTransformer<SO.Data.Binary | SO.Data.String, SO.Format.Ply, PD.Normalize<{}>>>;
        shape: import("@molstar/core/state").StateObjectSelector<SO.Shape.Provider, import("@molstar/core/state").StateTransformer<SO.Format.Ply, SO.Shape.Provider, PD.Normalize<{
            transforms: Mat4[] | undefined;
            label: string | undefined;
        }>>>;
    }>;
    readonly parseRaw: (plugin: PluginContext, ctx: import("@molstar/core/task").RuntimeContext, data: Uint8Array<ArrayBufferLike> | import("@molstar/core/util/string-like").StringLike) => Promise<{
        shape: import("@molstar/graphics/geo/shape/provider").ShapeProvider<any, any, any>;
    }>;
    readonly visuals: (plugin: PluginContext, data: {
        shape: StateObjectRef<PluginStateObject.Shape.Provider>;
    }) => Promise<import("@molstar/core/state").StateObjectSelector<SO.Shape.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
};
/** The Ply data format. */
export declare const Ply: PluginRegistryEntry;
//# sourceMappingURL=ply.d.ts.map