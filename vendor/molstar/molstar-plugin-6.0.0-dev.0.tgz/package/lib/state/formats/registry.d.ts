/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { FileNameInfo } from '@molstar/core/util/file-info';
import type { PluginStateObject } from '../objects.js';
import { DataFormatProvider } from './provider.js';
export declare class DataFormatRegistry {
    private _list;
    private _map;
    private _extensions;
    private _binaryExtensions;
    private _options;
    private _autoOrder;
    get types(): [name: string, label: string][];
    get extensions(): Set<string>;
    get binaryExtensions(): Set<string>;
    get options(): [name: string, label: string, category: string][];
    /**
     * Providers ordered for `auto()`: higher `priority` first, ties broken by registration
     * order (stable sort). Explicit priority makes auto-detection independent of the order
     * providers happen to be registered in.
     */
    get autoOrder(): {
        name: string;
        provider: DataFormatProvider;
    }[];
    private _invalidate;
    /**
     * Returns the message `add` would throw for `provider`, or `undefined` when it can be added.
     * Does not change the registry.
     */
    findConflict(provider: DataFormatProvider): string | undefined;
    /**
     * Registers a provider under `provider.name`. Adding the same object again increments its count,
     * a different object under an existing name throws.
     *
     * `add(name, provider)` is deprecated: when `name` differs from `provider.name` it registers
     * `DataFormatProvider.withName(provider, name)` instead.
     */
    add(provider: DataFormatProvider): void;
    /** @deprecated Use `add(provider)`, and `DataFormatProvider.withName` to register a provider under another name. */
    add(name: string, provider: DataFormatProvider.Unnamed): void;
    /** Decrements the count of a provider (given by identity or name) and removes it at zero. Unknown is a no-op. */
    remove(providerOrName: DataFormatProvider | string): void;
    /** Drops every provider and count. */
    clear(): void;
    has(name: string): boolean;
    auto(info: FileNameInfo, dataStateObject: PluginStateObject.Data.Binary | PluginStateObject.Data.String): DataFormatProvider<any, any, any, any, string> | undefined;
    get(name: string): DataFormatProvider | undefined;
    get list(): {
        name: string;
        provider: DataFormatProvider;
    }[];
}
/** The most common cause of an empty format registry is a 5.x-style spec without `registry`, so say how to fix it. */
export declare function unregisteredFormatMessage(name: string, registryIsEmpty: boolean): string;
//# sourceMappingURL=registry.d.ts.map