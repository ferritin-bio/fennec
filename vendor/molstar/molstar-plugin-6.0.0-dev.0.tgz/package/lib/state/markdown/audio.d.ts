/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { MarkdownExtension } from '../manager/markdown-extensions.js';
export declare const PlayAudioMarkdownExtension: MarkdownExtension;
export declare const ToggleAudioMarkdownExtension: MarkdownExtension;
export declare const PauseAudioMarkdownExtension: MarkdownExtension;
export declare const StopAudioMarkdownExtension: MarkdownExtension;
export declare const DisposeAudioMarkdownExtension: MarkdownExtension;
//# sourceMappingURL=audio.d.ts.map