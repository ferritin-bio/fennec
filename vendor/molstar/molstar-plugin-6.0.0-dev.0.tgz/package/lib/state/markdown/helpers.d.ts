/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StateObjectCell } from '@molstar/core/state';
import type { PluginContext } from '@molstar/plugin/context';
export declare function parseArray(input?: string): string[];
export declare function findRepresentations(plugin: PluginContext, cells: StateObjectCell[]): StateObjectCell[];
//# sourceMappingURL=helpers.d.ts.map