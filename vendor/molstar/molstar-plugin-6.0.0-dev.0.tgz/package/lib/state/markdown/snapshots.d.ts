/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { MarkdownExtension } from '../manager/markdown-extensions.js';
export declare const ApplySnapshotMarkdownExtension: MarkdownExtension;
export declare const NextSnapshotMarkdownExtension: MarkdownExtension;
export declare const PlayTransitionMarkdownExtension: MarkdownExtension;
export declare const PlaySnapshotsMarkdownExtension: MarkdownExtension;
export declare const StopAnimationMarkdownExtension: MarkdownExtension;
//# sourceMappingURL=snapshots.d.ts.map