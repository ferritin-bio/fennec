/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { MarkdownExtension } from '../manager/markdown-extensions.js';
export declare const QueryMarkdownExtension: MarkdownExtension;
//# sourceMappingURL=query.d.ts.map