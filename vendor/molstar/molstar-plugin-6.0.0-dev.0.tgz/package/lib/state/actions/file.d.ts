/**
 * Copyright (c) 2019-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { StateAction } from '@molstar/core/state';
import { Asset } from '@molstar/core/util/assets';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { PluginStateObject } from '../objects.js';
export declare const OpenFiles: StateAction<PluginStateObject.Root, void, PD.Normalize<{
    files: Asset.File[] | null;
    format: PD.NamedParams<string, "specific"> | PD.NamedParams<PD.Normalize<unknown>, "auto">;
    visuals: boolean;
}>>;
/**
 * Drag-and-drop handler of the `DefaultDragAndDrop` `open-files` entry: opens every dropped file
 * with the `OpenFiles` action (format detected from the file name, with default visuals).
 */
export declare function openDroppedFiles(files: File[], plugin: PluginContext): boolean;
export declare const DownloadFile: StateAction<PluginStateObject.Root, void, PD.Normalize<{
    url: string | Asset.Url;
    format: string;
    isBinary: boolean;
    visuals: boolean;
}>>;
//# sourceMappingURL=file.d.ts.map