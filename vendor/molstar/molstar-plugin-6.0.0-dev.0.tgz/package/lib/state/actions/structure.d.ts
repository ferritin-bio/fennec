/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
import { StateAction, StateTransformer } from '@molstar/core/state';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { PluginStateObject } from '../objects.js';
export declare const PdbDownloadProvider: {
    rcsb: PD.Group<PD.Normalize<{
        encoding: "bcif" | "cif";
    }>>;
    pdbe: PD.Group<PD.Normalize<{
        variant: "archival" | "updated" | "updated-bcif";
    }>>;
    pdbj: PD.Group<PD.Normalize<unknown>>;
};
export type PdbDownloadProvider = keyof typeof PdbDownloadProvider;
export { DownloadStructure };
type DownloadStructure = typeof DownloadStructure;
declare const DownloadStructure: StateAction<PluginStateObject.Root, void, PD.Normalize<{
    source: PD.NamedParams<PD.Normalize<{
        provider: /*elided*/ any;
        options: /*elided*/ any;
    }>, "pdb"> | PD.NamedParams<PD.Normalize<{
        provider: /*elided*/ any;
        options: /*elided*/ any;
    }>, "pdb-ihm"> | PD.NamedParams<PD.Normalize<{
        id: /*elided*/ any;
        options: /*elided*/ any;
    }>, "swissmodel"> | PD.NamedParams<PD.Normalize<{
        provider: /*elided*/ any;
        options: /*elided*/ any;
    }>, "alphafolddb"> | PD.NamedParams<PD.Normalize<{
        id: /*elided*/ any;
        options: /*elided*/ any;
    }>, "modelarchive"> | PD.NamedParams<PD.Normalize<{
        id: /*elided*/ any;
        options: /*elided*/ any;
    }>, "pubchem"> | PD.NamedParams<PD.Normalize<{
        url: /*elided*/ any;
        format: /*elided*/ any;
        isBinary: /*elided*/ any;
        label: /*elided*/ any;
        options: /*elided*/ any;
    }>, "url">;
}>>;
export declare const UpdateTrajectory: StateAction<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, void, PD.Normalize<{
    action: "advance" | "reset";
    by: number | undefined;
}>>;
export declare const EnableModelCustomProps: StateAction<PluginStateObject.Molecule.Model, Promise<import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>, PD.Normalize<{
    autoAttach: string[];
    properties: PD.Normalize<{
        [x: string]: any;
    }>;
}>>;
export declare const EnableStructureCustomProps: StateAction<PluginStateObject.Molecule.Structure, Promise<import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>, PD.Normalize<{
    autoAttach: string[];
    properties: PD.Normalize<{
        [x: string]: any;
    }>;
}>>;
export declare const AddTrajectory: StateAction<PluginStateObject.Root, void, PD.Normalize<{
    model: string;
    coordinates: string;
}>>;
export declare const LoadTrajectory: StateAction<PluginStateObject.Root, void, PD.Normalize<{
    source: PD.NamedParams<PD.Normalize<{
        model: /*elided*/ any;
        coordinates: /*elided*/ any;
    }>, "url"> | PD.NamedParams<PD.Normalize<{
        model: /*elided*/ any;
        coordinates: /*elided*/ any;
    }>, "file">;
}>>;
//# sourceMappingURL=structure.d.ts.map