/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Ccp4File } from '@molstar/io/reader/ccp4/schema';
import type { CifFile } from '@molstar/io/reader/cif';
import type { ArtiatomiEmFile } from '@molstar/io/reader/artiatomi/em';
import type { CryoEtDataPortalNdjsonFile } from '@molstar/io/reader/cryoet/ndjson';
import type { SimulariumFile } from '@molstar/io/reader/simularium/schema';
import type { MtzFile } from '@molstar/io/reader/mtz/schema';
import type { DcdFile } from '@molstar/io/reader/dcd/parser';
import type { DynamoTblFile } from '@molstar/io/reader/dynamo/tbl';
import type { Dsn6File } from '@molstar/io/reader/dsn6/schema';
import type { PlyFile } from '@molstar/io/reader/ply/schema';
import type { ObjFile } from '@molstar/io/reader/obj/schema';
import type { VtpFile } from '@molstar/io/reader/vtp/schema';
import type { PsfFile } from '@molstar/io/reader/psf/parser';
import type { ParticleList } from '@molstar/model/model/particles/particle-list';
import type { ParticleTrajectory } from '@molstar/model/model/particles/particle-trajectory';
import type { ShapeProvider } from '@molstar/graphics/geo/shape/provider';
import type { Coordinates as _Coordinates, Model as _Model, Structure as _Structure, Trajectory as _Trajectory, StructureElement, Topology as _Topology } from '@molstar/model/model/structure';
import type { Volume as _Volume } from '@molstar/model/model/volume';
import type { PluginBehavior } from '@molstar/plugin/behavior/behavior';
import type { Representation } from '@molstar/graphics/repr/representation';
import type { ShapeRepresentation } from '@molstar/graphics/repr/shape/representation';
import type { StructureRepresentation, StructureRepresentationState } from '@molstar/graphics/repr/structure/representation';
import type { VolumeRepresentation } from '@molstar/graphics/repr/volume/representation';
import type { ParticleRepresentation } from '@molstar/graphics/repr/particles/representation';
import { StateObject, StateTransformer } from '@molstar/core/state';
import type { CubeFile } from '@molstar/io/reader/cube/parser';
import type { DxFile } from '@molstar/io/reader/dx/parser';
import type { Color } from '@molstar/core/util/color/color';
import type { Asset } from '@molstar/core/util/assets';
import type { PrmtopFile } from '@molstar/io/reader/prmtop/parser';
import type { TopFile } from '@molstar/io/reader/top/parser';
import type { StringLike } from '@molstar/core/util/string-like';
export type TypeClass = 'root' | 'data' | 'prop';
export declare namespace PluginStateObject {
    export type Any = StateObject<any, TypeInfo>;
    export type TypeClass = 'Root' | 'Group' | 'Data' | 'Object' | 'Representation3D' | 'Behavior';
    export interface TypeInfo {
        name: string;
        typeClass: TypeClass;
    }
    export const Create: <D = {}>(type: TypeInfo) => {
        new (data: D, props?: {
            label: string;
            description?: string;
        } | undefined): {
            id: import("@molstar/core/util/uuid").UUID;
            type: TypeInfo;
            label: string;
            description?: string;
            data: D;
        };
        type: TypeInfo;
        is(obj?: StateObject): obj is StateObject<D, TypeInfo>;
    };
    export function isRepresentation3D(o?: Any): o is StateObject<Representation3DData<Representation.Any>, TypeInfo>;
    export function isBehavior(o?: Any): o is StateObject<PluginBehavior, TypeInfo>;
    export interface Representation3DData<T extends Representation.Any, S = any> {
        repr: T;
        sourceData: S;
    }
    export function CreateRepresentation3D<T extends Representation.Any, S = any>(type: {
        name: string;
    }): {
        new (data: Representation3DData<T, S>, props?: {
            label: string;
            description?: string;
        } | undefined): {
            id: import("@molstar/core/util/uuid").UUID;
            type: TypeInfo;
            label: string;
            description?: string;
            data: Representation3DData<T, S>;
        };
        type: TypeInfo;
        is(obj?: StateObject): obj is StateObject<Representation3DData<T, S>, TypeInfo>;
    };
    export function CreateBehavior<T extends PluginBehavior>(type: {
        name: string;
    }): {
        new (data: T, props?: {
            label: string;
            description?: string;
        } | undefined): {
            id: import("@molstar/core/util/uuid").UUID;
            type: TypeInfo;
            label: string;
            description?: string;
            data: T;
        };
        type: TypeInfo;
        is(obj?: StateObject): obj is StateObject<T, TypeInfo>;
    };
    const Root_base: {
        new (data: {}, props?: {
            label: string;
            description?: string;
        } | undefined): {
            id: import("@molstar/core/util/uuid").UUID;
            type: TypeInfo;
            label: string;
            description?: string;
            data: {};
        };
        type: TypeInfo;
        is(obj?: StateObject): obj is StateObject<{}, TypeInfo>;
    };
    export class Root extends Root_base {
    }
    const Group_base: {
        new (data: {}, props?: {
            label: string;
            description?: string;
        } | undefined): {
            id: import("@molstar/core/util/uuid").UUID;
            type: TypeInfo;
            label: string;
            description?: string;
            data: {};
        };
        type: TypeInfo;
        is(obj?: StateObject): obj is StateObject<{}, TypeInfo>;
    };
    export class Group extends Group_base {
    }
    export namespace Data {
        const String_base: {
            new (data: StringLike, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: StringLike;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<StringLike, TypeInfo>;
        };
        export class String extends String_base {
        }
        const Binary_base: {
            new (data: Uint8Array<ArrayBuffer>, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Uint8Array<ArrayBuffer>;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Uint8Array<ArrayBuffer>, TypeInfo>;
        };
        export class Binary extends Binary_base {
        }
        export type BlobEntry = {
            id: string;
        } & ({
            kind: 'string';
            data: string;
        } | {
            kind: 'binary';
            data: Uint8Array<ArrayBuffer>;
        });
        export type BlobData = BlobEntry[];
        const Blob_base: {
            new (data: BlobData, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: BlobData;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<BlobData, TypeInfo>;
        };
        export class Blob extends Blob_base {
        }
        export {};
    }
    export namespace Format {
        const Json_base: {
            new (data: any, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: any;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<any, TypeInfo>;
        };
        export class Json extends Json_base {
        }
        const Cif_base: {
            new (data: CifFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: CifFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<CifFile, TypeInfo>;
        };
        export class Cif extends Cif_base {
        }
        const ArtiatomiEm_base: {
            new (data: ArtiatomiEmFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: ArtiatomiEmFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<ArtiatomiEmFile, TypeInfo>;
        };
        export class ArtiatomiEm extends ArtiatomiEm_base {
        }
        const DynamoTbl_base: {
            new (data: DynamoTblFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: DynamoTblFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<DynamoTblFile, TypeInfo>;
        };
        export class DynamoTbl extends DynamoTbl_base {
        }
        const CryoEtDataPortalNdjson_base: {
            new (data: CryoEtDataPortalNdjsonFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: CryoEtDataPortalNdjsonFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<CryoEtDataPortalNdjsonFile, TypeInfo>;
        };
        export class CryoEtDataPortalNdjson extends CryoEtDataPortalNdjson_base {
        }
        const Simularium_base: {
            new (data: SimulariumFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: SimulariumFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<SimulariumFile, TypeInfo>;
        };
        export class Simularium extends Simularium_base {
        }
        const Cube_base: {
            new (data: CubeFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: CubeFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<CubeFile, TypeInfo>;
        };
        export class Cube extends Cube_base {
        }
        const Psf_base: {
            new (data: PsfFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: PsfFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<PsfFile, TypeInfo>;
        };
        export class Psf extends Psf_base {
        }
        const Prmtop_base: {
            new (data: PrmtopFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: PrmtopFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<PrmtopFile, TypeInfo>;
        };
        export class Prmtop extends Prmtop_base {
        }
        const Top_base: {
            new (data: TopFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: TopFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<TopFile, TypeInfo>;
        };
        export class Top extends Top_base {
        }
        const Ply_base: {
            new (data: PlyFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: PlyFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<PlyFile, TypeInfo>;
        };
        export class Ply extends Ply_base {
        }
        const Obj_base: {
            new (data: ObjFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: ObjFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<ObjFile, TypeInfo>;
        };
        export class Obj extends Obj_base {
        }
        const Vtp_base: {
            new (data: VtpFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: VtpFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<VtpFile, TypeInfo>;
        };
        export class Vtp extends Vtp_base {
        }
        const Ccp4_base: {
            new (data: Ccp4File, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Ccp4File;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Ccp4File, TypeInfo>;
        };
        export class Ccp4 extends Ccp4_base {
        }
        const Dsn6_base: {
            new (data: Dsn6File, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Dsn6File;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Dsn6File, TypeInfo>;
        };
        export class Dsn6 extends Dsn6_base {
        }
        const Dx_base: {
            new (data: DxFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: DxFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<DxFile, TypeInfo>;
        };
        export class Dx extends Dx_base {
        }
        const Mtz_base: {
            new (data: MtzFile, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: MtzFile;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<MtzFile, TypeInfo>;
        };
        export class Mtz extends Mtz_base {
        }
        export type BlobEntry = {
            id: string;
        } & ({
            kind: 'json';
            data: unknown;
        } | {
            kind: 'string';
            data: string;
        } | {
            kind: 'binary';
            data: Uint8Array<ArrayBuffer>;
        } | {
            kind: 'cif';
            data: CifFile;
        } | {
            kind: 'pdb';
            data: CifFile;
        } | {
            kind: 'gro';
            data: CifFile;
        } | {
            kind: 'dcd';
            data: DcdFile;
        } | {
            kind: 'ccp4';
            data: Ccp4File;
        } | {
            kind: 'dsn6';
            data: Dsn6File;
        } | {
            kind: 'dx';
            data: DxFile;
        } | {
            kind: 'ply';
            data: PlyFile;
        } | {
            kind: 'custom';
            data: unknown;
            tag: string;
        });
        export type BlobData = BlobEntry[];
        const Blob_base_1: {
            new (data: BlobData, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: BlobData;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<BlobData, TypeInfo>;
        };
        export class Blob extends Blob_base_1 {
        }
        export {};
    }
    export namespace Molecule {
        const Coordinates_base: {
            new (data: _Coordinates, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Coordinates;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Coordinates, TypeInfo>;
        };
        export class Coordinates extends Coordinates_base {
        }
        const Topology_base: {
            new (data: _Topology, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Topology;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Topology, TypeInfo>;
        };
        export class Topology extends Topology_base {
        }
        const Model_base: {
            new (data: _Model, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Model;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Model, TypeInfo>;
        };
        export class Model extends Model_base {
        }
        const Trajectory_base: {
            new (data: _Trajectory, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Trajectory;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Trajectory, TypeInfo>;
        };
        export class Trajectory extends Trajectory_base {
        }
        const Structure_base: {
            new (data: _Structure, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Structure;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Structure, TypeInfo>;
        };
        export class Structure extends Structure_base {
        }
        export namespace Structure {
            const Representation3D_base: {
                new (data: Representation3DData<StructureRepresentation<any>, _Structure>, props?: {
                    label: string;
                    description?: string;
                } | undefined): {
                    id: import("@molstar/core/util/uuid").UUID;
                    type: TypeInfo;
                    label: string;
                    description?: string;
                    data: Representation3DData<StructureRepresentation<any>, _Structure>;
                };
                type: TypeInfo;
                is(obj?: StateObject): obj is StateObject<Representation3DData<StructureRepresentation<any>, _Structure>, TypeInfo>;
            };
            export class Representation3D extends Representation3D_base {
            }
            export interface Representation3DStateData {
                repr: StructureRepresentation<any>;
                /** used to restore state when the obj is removed */
                initialState: Partial<StructureRepresentationState>;
                state: Partial<StructureRepresentationState>;
                info?: unknown;
            }
            const Representation3DState_base: {
                new (data: Representation3DStateData, props?: {
                    label: string;
                    description?: string;
                } | undefined): {
                    id: import("@molstar/core/util/uuid").UUID;
                    type: TypeInfo;
                    label: string;
                    description?: string;
                    data: Representation3DStateData;
                };
                type: TypeInfo;
                is(obj?: StateObject): obj is StateObject<Representation3DStateData, TypeInfo>;
            };
            export class Representation3DState extends Representation3DState_base {
            }
            export interface SelectionEntry {
                key: string;
                structureRef: string;
                groupId?: string;
                loci: StructureElement.Loci;
            }
            const Selections_base: {
                new (data: readonly SelectionEntry[], props?: {
                    label: string;
                    description?: string;
                } | undefined): {
                    id: import("@molstar/core/util/uuid").UUID;
                    type: TypeInfo;
                    label: string;
                    description?: string;
                    data: readonly SelectionEntry[];
                };
                type: TypeInfo;
                is(obj?: StateObject): obj is StateObject<readonly SelectionEntry[], TypeInfo>;
            };
            export class Selections extends Selections_base {
            }
            export {};
        }
        export {};
    }
    export namespace Volume {
        export interface LazyInfo {
            url: string | Asset.Url;
            isBinary: boolean;
            format: string;
            entryId?: string | string[];
            isovalues: {
                type: 'absolute' | 'relative';
                value: number;
                color: Color;
                alpha?: number;
                volumeIndex?: number;
            }[];
        }
        const Data_base: {
            new (data: _Volume, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: _Volume;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<_Volume, TypeInfo>;
        };
        export class Data extends Data_base {
        }
        const Lazy_base: {
            new (data: LazyInfo, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: LazyInfo;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<LazyInfo, TypeInfo>;
        };
        export class Lazy extends Lazy_base {
        }
        const Representation3D_base_1: {
            new (data: Representation3DData<VolumeRepresentation<any>, _Volume>, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Representation3DData<VolumeRepresentation<any>, _Volume>;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Representation3DData<VolumeRepresentation<any>, _Volume>, TypeInfo>;
        };
        export class Representation3D extends Representation3D_base_1 {
        }
        export {};
    }
    export namespace Shape {
        const Provider_base: {
            new (data: ShapeProvider<any, any, any>, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: ShapeProvider<any, any, any>;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<ShapeProvider<any, any, any>, TypeInfo>;
        };
        export class Provider extends Provider_base {
        }
        const Representation3D_base_2: {
            new (data: Representation3DData<ShapeRepresentation<any, any, any>, unknown>, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Representation3DData<ShapeRepresentation<any, any, any>, unknown>;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Representation3DData<ShapeRepresentation<any, any, any>, unknown>, TypeInfo>;
        };
        export class Representation3D extends Representation3D_base_2 {
        }
        export {};
    }
    export namespace Particle {
        const Trajectory_base_1: {
            new (data: ParticleTrajectory, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: ParticleTrajectory;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<ParticleTrajectory, TypeInfo>;
        };
        export class Trajectory extends Trajectory_base_1 {
        }
        const List_base: {
            new (data: ParticleList, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: ParticleList;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<ParticleList, TypeInfo>;
        };
        export class List extends List_base {
        }
        const Representation3D_base_3: {
            new (data: Representation3DData<ParticleRepresentation<any>, ParticleList>, props?: {
                label: string;
                description?: string;
            } | undefined): {
                id: import("@molstar/core/util/uuid").UUID;
                type: TypeInfo;
                label: string;
                description?: string;
                data: Representation3DData<ParticleRepresentation<any>, ParticleList>;
            };
            type: TypeInfo;
            is(obj?: StateObject): obj is StateObject<Representation3DData<ParticleRepresentation<any>, ParticleList>, TypeInfo>;
        };
        export class Representation3D extends Representation3D_base_3 {
        }
        export {};
    }
    export {};
}
export declare namespace PluginStateTransform {
    const CreateBuiltIn: <A extends StateObject, B extends StateObject, P extends {} = {}>(definition: StateTransformer.Definition<A, B, P>) => StateTransformer<any, any, any>;
    const BuiltIn: StateTransformer.Builder.Root;
}
//# sourceMappingURL=objects.d.ts.map