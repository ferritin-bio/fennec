/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { StructureRepresentationPresetProvider } from './types.js';
export declare const EmptyPreset: StructureRepresentationPresetProvider<unknown, {}, "preset-structure-representation-empty", "empty">;
/** The empty preset; it builds nothing. */
export declare const EmptyPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=empty.d.ts.map