/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { StructureRepresentationPresetProvider } from './types.js';
export declare const PolymerAndLigandPreset: StructureRepresentationPresetProvider<{
    ignoreHydrogens: boolean | undefined;
    ignoreHydrogensVariant: "all" | "non-polar" | undefined;
    ignoreLight: boolean | undefined;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
    theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        globalName: /*elided*/ any;
        globalColorParams: /*elided*/ any;
        carbonColor: /*elided*/ any;
        symmetryColor: /*elided*/ any;
        symmetryColorParams: /*elided*/ any;
        focus: /*elided*/ any;
    }> | undefined;
}, {
    components?: undefined;
    representations?: undefined;
} | {
    components: {
        polymer: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        ligand: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        nonStandard: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        branched: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        water: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        ion: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        lipid: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        coarse: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
    };
    representations: {
        polymer: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        ligand: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        nonStandard: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        branchedBallAndStick: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        branchedSnfg3d: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        water: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        ion: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        lipid: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        coarse: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    };
}, "preset-structure-representation-polymer-and-ligand", "polymer-and-ligand">;
/** The PolymerAndLigandPreset preset with the representations and themes it builds. */
export declare const PolymerAndLigandPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=polymer-and-ligand.d.ts.map