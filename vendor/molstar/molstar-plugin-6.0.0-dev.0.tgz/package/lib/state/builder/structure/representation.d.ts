/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { StateBuilder, StateObjectRef, StateObjectSelector, StateTransform } from '@molstar/core/state';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type StructureColorThemeRef, type StructureRepresentationProps, type StructureRepresentationRef, type StructureSizeThemeRef } from '../../helpers/structure-representation-params.js';
import type { PluginStateObject } from '../../objects.js';
import type { BuiltInStructureRepresentationPresetAlias, BuiltInStructureRepresentationPresetId, PresetStructureRepresentations } from './representation-presets/catalog.js';
import type { StructureRepresentationPresetProvider } from './representation-presets/types.js';
export type StructureRepresentationPresetProviderRef = BuiltInStructureRepresentationPresetId | BuiltInStructureRepresentationPresetAlias | StructureRepresentationPresetProvider | string;
type BuiltInPresetOf<P extends {
    id: string;
    alias?: string;
}, K extends string> = P extends P ? K extends P['id'] | NonNullable<P['alias']> ? P : never : never;
type BuiltInPreset<K extends string> = BuiltInPresetOf<PresetStructureRepresentations[keyof PresetStructureRepresentations], K>;
export declare class StructureRepresentationBuilder {
    plugin: PluginContext;
    private registry;
    private get dataState();
    resolveProvider(ref: StructureRepresentationPresetProviderRef): StructureRepresentationPresetProvider<any, StructureRepresentationPresetProvider.Result, string, string> | undefined;
    hasPreset(s: PluginStateObject.Molecule.Structure): boolean;
    get providers(): ReadonlyArray<StructureRepresentationPresetProvider>;
    getPresets(s?: PluginStateObject.Molecule.Structure): readonly StructureRepresentationPresetProvider<any, StructureRepresentationPresetProvider.Result, string, string>[];
    getPresetSelect(s?: PluginStateObject.Molecule.Structure): PD.Select<string>;
    getPresetsWithOptions(s: PluginStateObject.Molecule.Structure): PD.Mapped<PD.NamedParams<any, string>>;
    /** The message `registerPreset` would throw for this provider, or `undefined` if it would succeed. */
    findConflict(provider: StructureRepresentationPresetProvider): string | undefined;
    /** Whether a preset is registered under this id or alias. */
    has(idOrAlias: string): boolean;
    registerPreset(provider: StructureRepresentationPresetProvider): void;
    unregisterPreset(provider: StructureRepresentationPresetProvider | string): void;
    applyPreset<K extends BuiltInStructureRepresentationPresetId | BuiltInStructureRepresentationPresetAlias>(parent: StateObjectRef<PluginStateObject.Molecule.Structure>, preset: K, params?: StructureRepresentationPresetProvider.Params<BuiltInPreset<K>>): Promise<StructureRepresentationPresetProvider.State<BuiltInPreset<K>>> | undefined;
    applyPreset<P = any, S extends {} = {}>(parent: StateObjectRef<PluginStateObject.Molecule.Structure>, provider: StructureRepresentationPresetProvider<P, S>, params?: P): Promise<S> | undefined;
    applyPreset(parent: StateObjectRef<PluginStateObject.Molecule.Structure>, presetIdOrAlias: string, params?: any): Promise<any> | undefined;
    /** `type`, `color`, and `size` are each a provider or a name (see `StructureRepresentationProps`). */
    addRepresentation<R extends StructureRepresentationRef = StructureRepresentationRef, C extends StructureColorThemeRef = StructureColorThemeRef, S extends StructureSizeThemeRef = StructureSizeThemeRef>(structure: StateObjectRef<PluginStateObject.Molecule.Structure>, props: StructureRepresentationProps<R, C, S>, options?: Partial<StructureRepresentationBuilder.AddRepresentationOptions>): Promise<StateObjectSelector<PluginStateObject.Molecule.Structure.Representation3D>>;
    /** `type`, `color`, and `size` are each a provider or a name (see `StructureRepresentationProps`). */
    buildRepresentation<R extends StructureRepresentationRef = StructureRepresentationRef, C extends StructureColorThemeRef = StructureColorThemeRef, S extends StructureSizeThemeRef = StructureSizeThemeRef>(builder: StateBuilder.Root, structure: StateObjectRef<PluginStateObject.Molecule.Structure> | undefined, props: StructureRepresentationProps<R, C, S>, options?: Partial<StructureRepresentationBuilder.AddRepresentationOptions>): StateObjectSelector<PluginStateObject.Molecule.Structure.Representation3D>;
    constructor(plugin: PluginContext);
}
export declare namespace StructureRepresentationBuilder {
    interface AddRepresentationOptions {
        initialState?: Partial<StateTransform.State>;
        tag?: string;
    }
}
export {};
//# sourceMappingURL=representation.d.ts.map