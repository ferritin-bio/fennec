/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
import type { PluginStateObject } from '../../../objects.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { TrajectoryHierarchyPresetProvider } from './types.js';
export declare const DefaultHierarchyPreset: TrajectoryHierarchyPresetProvider<{
    modelProperties: PD.Normalize<PD.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    structureProperties: PD.Normalize<PD.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
    model: PD.Normalize<PD.Normalize<{
        modelIndex: /*elided*/ any;
    }>> | undefined;
    showUnitcell: boolean | undefined;
    structure: PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
    }>, "auto"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
    }>, "model"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        id: /*elided*/ any;
    }>, "assembly"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        radius: /*elided*/ any;
    }>, "symmetry-mates"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        ijkMin: /*elided*/ any;
        ijkMax: /*elided*/ any;
    }>, "symmetry"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        generators: /*elided*/ any;
    }>, "symmetry-assembly"> | undefined;
    representationPresetParams: PD.Normalize<{
        ignoreHydrogens: /*elided*/ any;
        ignoreHydrogensVariant: /*elided*/ any;
        ignoreLight: /*elided*/ any;
        quality: /*elided*/ any;
        theme: /*elided*/ any;
    }> | undefined;
}, {
    model: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    modelProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    unitcell: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
    structure: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    structureProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    representation: any;
}, "preset-trajectory-default", "default">;
/** The default hierarchy preset. The representation preset it applies comes from config, so the entry has none. */
export declare const DefaultHierarchyPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=default.d.ts.map