/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
export declare const PresetStructureRepresentations: {
    empty: import("./types.js").StructureRepresentationPresetProvider<unknown, {}, "preset-structure-representation-empty", "empty">;
    auto: import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            branched: undefined;
        };
        representations: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-auto", "auto">;
    'atomic-detail': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
        showCarbohydrateSymbol: boolean;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            branched: undefined;
        };
        representations: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-atomic-detail", "atomic-detail">;
    'polymer-cartoon': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-polymer-cartoon", "polymer-cartoon">;
    'polymer-and-ligand': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            ligand: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            nonStandard: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            branched: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            water: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            ion: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            lipid: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            coarse: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            ligand: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            nonStandard: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            branchedBallAndStick: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            branchedSnfg3d: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            water: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            ion: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            lipid: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            coarse: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-polymer-and-ligand", "polymer-and-ligand">;
    'protein-and-nucleic': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            protein: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            nucleic: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            protein: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            nucleic: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-protein-and-nucleic", "protein-and-nucleic">;
    'coarse-surface': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            lipid: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            polymer: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            lipid: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-coarse-surface", "coarse-surface">;
    illustrative: import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            branched: undefined;
        };
        representations: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-illustrative", "illustrative">;
    'molecular-surface': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
            branched: undefined;
        };
        representations: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-molecular-surface", "molecular-surface">;
    'auto-lod': import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            gaussianSurface: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            cartoon: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
            ballAndStick: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-auto-lod", "auto-lod">;
    mesoscale: import("./types.js").StructureRepresentationPresetProvider<{
        ignoreHydrogens: boolean | undefined;
        ignoreHydrogensVariant: "all" | "non-polar" | undefined;
        ignoreLight: boolean | undefined;
        quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
        theme: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            globalName: /*elided*/ any;
            globalColorParams: /*elided*/ any;
            carbonColor: /*elided*/ any;
            symmetryColor: /*elided*/ any;
            symmetryColorParams: /*elided*/ any;
            focus: /*elided*/ any;
        }> | undefined;
        graphics: "balanced" | "performance" | "quality" | "ultra";
    }, {
        components?: undefined;
        representations?: undefined;
    } | {
        components: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        };
        representations: {
            all: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        };
    }, "preset-structure-representation-mesoscale", "mesoscale">;
};
export type PresetStructureRepresentations = typeof PresetStructureRepresentations;
export type BuiltInStructureRepresentationPresetId = PresetStructureRepresentations[keyof PresetStructureRepresentations]['id'];
export type BuiltInStructureRepresentationPresetAlias = NonNullable<PresetStructureRepresentations[keyof PresetStructureRepresentations]['alias']>;
//# sourceMappingURL=catalog.d.ts.map