/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { type StateObjectRef, StateTransformer } from '@molstar/core/state';
import type { PluginStateObject } from '../../../objects.js';
import type { PluginContext } from '@molstar/plugin/context';
import type { Vec3 } from '@molstar/core/math/linear-algebra';
export declare const CrystalSymmetryParams: (a: PluginStateObject.Molecule.Trajectory | undefined, plugin: PluginContext) => {
    modelProperties: PD.Base<PD.Normalize<PD.Normalize<{
        autoAttach: string[];
        properties: PD.Normalize<{
            [x: string]: any;
        }>;
    }>> | undefined>;
    structureProperties: PD.Base<PD.Normalize<PD.Normalize<{
        autoAttach: string[];
        properties: PD.Normalize<{
            [x: string]: any;
        }>;
    }>> | undefined>;
    representationPreset: PD.Base<"preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined>;
    model: PD.Base<PD.Normalize<PD.Normalize<{
        modelIndex: number;
    }>> | undefined>;
};
export declare function applyCrystalSymmetry(props: {
    ijkMin: Vec3;
    ijkMax: Vec3;
    theme?: string;
}, trajectory: StateObjectRef<PluginStateObject.Molecule.Trajectory>, params: PD.ValuesFor<ReturnType<typeof CrystalSymmetryParams>>, plugin: PluginContext): Promise<{
    model: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    modelProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    unitcell: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
    structure: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    structureProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    representation: any;
}>;
//# sourceMappingURL=crystal-symmetry.d.ts.map