/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PresetProvider } from '../../preset-provider.js';
import type { PluginStateObject } from '../../../objects.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginContext } from '@molstar/plugin/context';
import type { BuiltInStructureRepresentationPresetAlias } from '../representation-presets/catalog.js';
export interface TrajectoryHierarchyPresetProvider<P = any, S = {}, Id extends string = string, Alias extends string = string> extends PresetProvider<PluginStateObject.Molecule.Trajectory, P, S, Id, Alias> {
}
export declare function TrajectoryHierarchyPresetProvider<P, S, const Id extends string, const Alias extends string = string>(preset: TrajectoryHierarchyPresetProvider<P, S, Id, Alias>): TrajectoryHierarchyPresetProvider<P, S, Id, Alias>;
export declare namespace TrajectoryHierarchyPresetProvider {
    type Params<P extends TrajectoryHierarchyPresetProvider> = P extends TrajectoryHierarchyPresetProvider<infer T> ? T : never;
    type State<P extends TrajectoryHierarchyPresetProvider> = P extends TrajectoryHierarchyPresetProvider<infer _, infer S> ? S : never;
    /** The representation preset to apply: the `representationPreset` param, else the configured default preset. */
    function getRepresentationPreset(plugin: PluginContext, params: {
        representationPreset?: string;
    }): string;
    const CommonParams: (a: PluginStateObject.Molecule.Trajectory | undefined, plugin: PluginContext) => {
        modelProperties: PD.Base<PD.Normalize<PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>> | undefined>;
        structureProperties: PD.Base<PD.Normalize<PD.Normalize<{
            autoAttach: string[];
            properties: PD.Normalize<{
                [x: string]: any;
            }>;
        }>> | undefined>;
        /** A representation preset id or alias. When absent, `PluginConfig.Structure.DefaultRepresentationPreset` is used. */
        representationPreset: PD.Base<"preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | BuiltInStructureRepresentationPresetAlias | undefined>;
    };
}
//# sourceMappingURL=types.d.ts.map