/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { PresetProvider } from '../../preset-provider.js';
import type { PluginStateObject } from '../../../objects.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { ColorTheme } from '@molstar/graphics/theme/color';
import type { Structure } from '@molstar/model/model/structure';
import type { PluginContext } from '@molstar/plugin/context';
import type { StateObjectRef, StateObjectSelector } from '@molstar/core/state';
import type { StaticStructureComponentType } from '../../../helpers/structure-component.js';
import type { StructureSelectionQuery } from '@molstar/plugin/state/queries/structure/query';
export interface StructureRepresentationPresetProvider<P = any, S extends _Result = _Result, Id extends string = string, Alias extends string = string> extends PresetProvider<PluginStateObject.Molecule.Structure, P, S, Id, Alias> {
}
export declare function StructureRepresentationPresetProvider<P, S extends _Result, const Id extends string, const Alias extends string = string>(repr: StructureRepresentationPresetProvider<P, S, Id, Alias>): StructureRepresentationPresetProvider<P, S, Id, Alias>;
export declare namespace StructureRepresentationPresetProvider {
    type Params<P extends StructureRepresentationPresetProvider> = P extends StructureRepresentationPresetProvider<infer T> ? T : never;
    type State<P extends StructureRepresentationPresetProvider> = P extends StructureRepresentationPresetProvider<infer _, infer S> ? S : never;
    type Result = {
        components?: {
            [name: string]: StateObjectSelector | undefined;
        };
        representations?: {
            [name: string]: StateObjectSelector | undefined;
        };
    };
    const CommonParams: {
        ignoreHydrogens: PD.Base<boolean | undefined>;
        ignoreHydrogensVariant: PD.Base<"all" | "non-polar" | undefined>;
        ignoreLight: PD.Base<boolean | undefined>;
        quality: PD.Base<"auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined>;
        theme: PD.Base<PD.Normalize<{
            globalName: "atom-id" | "carbohydrate-symbol" | "cartoon" | "chain-id" | "element-index" | "element-symbol" | "entity-id" | "entity-source" | "formal-charge" | "hydrophobicity" | "illustrative" | "model-index" | "molecule-type" | "occupancy" | "operator-hkl" | "operator-name" | "partial-charge" | "particle-attribute" | "particle-compartment" | "particle-entity" | "particle-hierarchy" | "particle-index" | "polymer-id" | "polymer-index" | "residue-charge" | "residue-name" | "secondary-structure" | "sequence-id" | "shape-group" | "structure-index" | "trajectory-index" | "uncertainty" | "uniform" | "unit-index" | "volume-instance" | "volume-segment" | "volume-value" | undefined;
            globalColorParams: any;
            carbonColor: "chain-id" | "element-symbol" | "operator-name" | undefined;
            symmetryColor: "atom-id" | "carbohydrate-symbol" | "cartoon" | "chain-id" | "element-index" | "element-symbol" | "entity-id" | "entity-source" | "formal-charge" | "hydrophobicity" | "illustrative" | "model-index" | "molecule-type" | "occupancy" | "operator-hkl" | "operator-name" | "partial-charge" | "particle-attribute" | "particle-compartment" | "particle-entity" | "particle-hierarchy" | "particle-index" | "polymer-id" | "polymer-index" | "residue-charge" | "residue-name" | "secondary-structure" | "sequence-id" | "shape-group" | "structure-index" | "trajectory-index" | "uncertainty" | "uniform" | "unit-index" | "volume-instance" | "volume-segment" | "volume-value" | undefined;
            symmetryColorParams: any;
            focus: PD.Normalize<{
                name: /*elided*/ any;
                params: /*elided*/ any;
            }> | undefined;
        }> | undefined>;
    };
    type CommonParams = PD.ValuesFor<typeof CommonParams>;
    function reprBuilder(plugin: PluginContext, params: CommonParams, structure?: Structure): {
        update: import("@molstar/core/state").StateBuilder.Root;
        builder: import("../representation.js").StructureRepresentationBuilder;
        color: "atom-id" | "carbohydrate-symbol" | "cartoon" | "chain-id" | "element-index" | "element-symbol" | "entity-id" | "entity-source" | "formal-charge" | "hydrophobicity" | "illustrative" | "model-index" | "molecule-type" | "occupancy" | "operator-hkl" | "operator-name" | "partial-charge" | "particle-attribute" | "particle-compartment" | "particle-entity" | "particle-hierarchy" | "particle-index" | "polymer-id" | "polymer-index" | "residue-charge" | "residue-name" | "secondary-structure" | "sequence-id" | "shape-group" | "structure-index" | "trajectory-index" | "uncertainty" | "uniform" | "unit-index" | "volume-instance" | "volume-segment" | "volume-value" | undefined;
        symmetryColor: "atom-id" | "carbohydrate-symbol" | "cartoon" | "chain-id" | "element-index" | "element-symbol" | "entity-id" | "entity-source" | "formal-charge" | "hydrophobicity" | "illustrative" | "model-index" | "molecule-type" | "occupancy" | "operator-hkl" | "operator-name" | "partial-charge" | "particle-attribute" | "particle-compartment" | "particle-entity" | "particle-hierarchy" | "particle-index" | "polymer-id" | "polymer-index" | "residue-charge" | "residue-name" | "secondary-structure" | "sequence-id" | "shape-group" | "structure-index" | "trajectory-index" | "uncertainty" | "uniform" | "unit-index" | "volume-instance" | "volume-segment" | "volume-value" | undefined;
        symmetryColorParams: any;
        globalColorParams: any;
        typeParams: {
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            ignoreHydrogens: boolean;
            ignoreHydrogensVariant: 'all' | 'non-polar';
            ignoreLight: boolean;
        };
        surfaceTypeParams: {
            quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
            ignoreHydrogens: boolean;
            ignoreHydrogensVariant: 'all' | 'non-polar';
            ignoreLight: boolean;
            solidInterior: boolean;
        };
        ballAndStickColor: Partial<PD.Values<{
            carbonColor: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "element-symbol"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                value: import("@molstar/core/util/color/color").Color;
                saturation: number;
                lightness: number;
            }>, "uniform"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
                asymId: "auth" | "label";
            }>, "chain-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
                overrideWater: boolean;
                waterColor: import("@molstar/core/util/color/color").Color;
            }>, "entity-id"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "entity-source"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "model-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "structure-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "trajectory-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "unit-index"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                palette: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    list: {
                        kind: 'interpolate' | 'set';
                        colors: import("@molstar/core/util/color/color").ColorListEntry[];
                    };
                }>, "colors"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                    hue: [number, number];
                    chroma: [number, number];
                    luminance: [number, number];
                    sort: "contrast" | "none";
                    clusteringStepCount: number;
                    minSampleCount: number;
                    sampleCountFactor: number;
                    maxCount: number;
                }>, "generate">;
            }>, "operator-name">>;
            saturation: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
            lightness: import("@molstar/core/util/param-definition").ParamDefinition.Numeric;
            colors: import("@molstar/core/util/param-definition").ParamDefinition.Mapped<import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<unknown>, "default"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
                H: import("@molstar/core/util/color/color").Color;
                D: import("@molstar/core/util/color/color").Color;
                T: import("@molstar/core/util/color/color").Color;
                HE: import("@molstar/core/util/color/color").Color;
                LI: import("@molstar/core/util/color/color").Color;
                BE: import("@molstar/core/util/color/color").Color;
                B: import("@molstar/core/util/color/color").Color;
                C: import("@molstar/core/util/color/color").Color;
                N: import("@molstar/core/util/color/color").Color;
                O: import("@molstar/core/util/color/color").Color;
                F: import("@molstar/core/util/color/color").Color;
                NE: import("@molstar/core/util/color/color").Color;
                NA: import("@molstar/core/util/color/color").Color;
                MG: import("@molstar/core/util/color/color").Color;
                AL: import("@molstar/core/util/color/color").Color;
                SI: import("@molstar/core/util/color/color").Color;
                P: import("@molstar/core/util/color/color").Color;
                S: import("@molstar/core/util/color/color").Color;
                CL: import("@molstar/core/util/color/color").Color;
                AR: import("@molstar/core/util/color/color").Color;
                K: import("@molstar/core/util/color/color").Color;
                CA: import("@molstar/core/util/color/color").Color;
                SC: import("@molstar/core/util/color/color").Color;
                TI: import("@molstar/core/util/color/color").Color;
                V: import("@molstar/core/util/color/color").Color;
                CR: import("@molstar/core/util/color/color").Color;
                MN: import("@molstar/core/util/color/color").Color;
                FE: import("@molstar/core/util/color/color").Color;
                CO: import("@molstar/core/util/color/color").Color;
                NI: import("@molstar/core/util/color/color").Color;
                CU: import("@molstar/core/util/color/color").Color;
                ZN: import("@molstar/core/util/color/color").Color;
                GA: import("@molstar/core/util/color/color").Color;
                GE: import("@molstar/core/util/color/color").Color;
                AS: import("@molstar/core/util/color/color").Color;
                SE: import("@molstar/core/util/color/color").Color;
                BR: import("@molstar/core/util/color/color").Color;
                KR: import("@molstar/core/util/color/color").Color;
                RB: import("@molstar/core/util/color/color").Color;
                SR: import("@molstar/core/util/color/color").Color;
                Y: import("@molstar/core/util/color/color").Color;
                ZR: import("@molstar/core/util/color/color").Color;
                NB: import("@molstar/core/util/color/color").Color;
                MO: import("@molstar/core/util/color/color").Color;
                TC: import("@molstar/core/util/color/color").Color;
                RU: import("@molstar/core/util/color/color").Color;
                RH: import("@molstar/core/util/color/color").Color;
                PD: import("@molstar/core/util/color/color").Color;
                AG: import("@molstar/core/util/color/color").Color;
                CD: import("@molstar/core/util/color/color").Color;
                IN: import("@molstar/core/util/color/color").Color;
                SN: import("@molstar/core/util/color/color").Color;
                SB: import("@molstar/core/util/color/color").Color;
                TE: import("@molstar/core/util/color/color").Color;
                I: import("@molstar/core/util/color/color").Color;
                XE: import("@molstar/core/util/color/color").Color;
                CS: import("@molstar/core/util/color/color").Color;
                BA: import("@molstar/core/util/color/color").Color;
                LA: import("@molstar/core/util/color/color").Color;
                CE: import("@molstar/core/util/color/color").Color;
                PR: import("@molstar/core/util/color/color").Color;
                ND: import("@molstar/core/util/color/color").Color;
                PM: import("@molstar/core/util/color/color").Color;
                SM: import("@molstar/core/util/color/color").Color;
                EU: import("@molstar/core/util/color/color").Color;
                GD: import("@molstar/core/util/color/color").Color;
                TB: import("@molstar/core/util/color/color").Color;
                DY: import("@molstar/core/util/color/color").Color;
                HO: import("@molstar/core/util/color/color").Color;
                ER: import("@molstar/core/util/color/color").Color;
                TM: import("@molstar/core/util/color/color").Color;
                YB: import("@molstar/core/util/color/color").Color;
                LU: import("@molstar/core/util/color/color").Color;
                HF: import("@molstar/core/util/color/color").Color;
                TA: import("@molstar/core/util/color/color").Color;
                W: import("@molstar/core/util/color/color").Color;
                RE: import("@molstar/core/util/color/color").Color;
                OS: import("@molstar/core/util/color/color").Color;
                IR: import("@molstar/core/util/color/color").Color;
                PT: import("@molstar/core/util/color/color").Color;
                AU: import("@molstar/core/util/color/color").Color;
                HG: import("@molstar/core/util/color/color").Color;
                TL: import("@molstar/core/util/color/color").Color;
                PB: import("@molstar/core/util/color/color").Color;
                BI: import("@molstar/core/util/color/color").Color;
                PO: import("@molstar/core/util/color/color").Color;
                AT: import("@molstar/core/util/color/color").Color;
                RN: import("@molstar/core/util/color/color").Color;
                FR: import("@molstar/core/util/color/color").Color;
                RA: import("@molstar/core/util/color/color").Color;
                AC: import("@molstar/core/util/color/color").Color;
                TH: import("@molstar/core/util/color/color").Color;
                PA: import("@molstar/core/util/color/color").Color;
                U: import("@molstar/core/util/color/color").Color;
                NP: import("@molstar/core/util/color/color").Color;
                PU: import("@molstar/core/util/color/color").Color;
                AM: import("@molstar/core/util/color/color").Color;
                CM: import("@molstar/core/util/color/color").Color;
                BK: import("@molstar/core/util/color/color").Color;
                CF: import("@molstar/core/util/color/color").Color;
                ES: import("@molstar/core/util/color/color").Color;
                FM: import("@molstar/core/util/color/color").Color;
                MD: import("@molstar/core/util/color/color").Color;
                NO: import("@molstar/core/util/color/color").Color;
                LR: import("@molstar/core/util/color/color").Color;
                RF: import("@molstar/core/util/color/color").Color;
                DB: import("@molstar/core/util/color/color").Color;
                SG: import("@molstar/core/util/color/color").Color;
                BH: import("@molstar/core/util/color/color").Color;
                HS: import("@molstar/core/util/color/color").Color;
                MT: import("@molstar/core/util/color/color").Color;
                DS: import("@molstar/core/util/color/color").Color;
                RG: import("@molstar/core/util/color/color").Color;
                CN: import("@molstar/core/util/color/color").Color;
                UUT: import("@molstar/core/util/color/color").Color;
                NH: import("@molstar/core/util/color/color").Color;
                FL: import("@molstar/core/util/color/color").Color;
                UUP: import("@molstar/core/util/color/color").Color;
                MC: import("@molstar/core/util/color/color").Color;
                LV: import("@molstar/core/util/color/color").Color;
                UUH: import("@molstar/core/util/color/color").Color;
                UUS: import("@molstar/core/util/color/color").Color;
                TS: import("@molstar/core/util/color/color").Color;
                UUO: import("@molstar/core/util/color/color").Color;
                OG: import("@molstar/core/util/color/color").Color;
            }>, "custom">>;
        }>>;
    };
    /**
     * Sets the color theme of the focus representation behavior's target and surroundings representations. Does nothing
     * when the behavior is absent, and skips a representation whose type or the requested theme is not registered. The
     * theme defaults to the default color theme of each representation type.
     */
    function updateFocusRepr<T extends ColorTheme.BuiltIn>(plugin: PluginContext, structure: Structure, themeName: T | undefined, themeParams: ColorTheme.BuiltInParams<T> | undefined): Promise<void> | undefined;
}
type _Result = StructureRepresentationPresetProvider.Result;
export declare const BuiltInPresetGroupName = "Basic";
export declare function presetStaticComponent(plugin: PluginContext, structure: StateObjectRef<PluginStateObject.Molecule.Structure>, type: StaticStructureComponentType, params?: {
    label?: string;
    tags?: string[];
}): Promise<StateObjectSelector<PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined>;
/**
 * Creates a component from a selection query. The component's key is `selection-<tag>`; import the query from its
 * module (for example `protein` from `@molstar/plugin/state/queries/structure/type`) instead of the query catalog.
 */
export declare function presetSelectionComponent(plugin: PluginContext, structure: StateObjectRef<PluginStateObject.Molecule.Structure>, query: StructureSelectionQuery, tag: string, params?: {
    label?: string;
    tags?: string[];
}): Promise<StateObjectSelector<PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined>;
export {};
//# sourceMappingURL=types.d.ts.map