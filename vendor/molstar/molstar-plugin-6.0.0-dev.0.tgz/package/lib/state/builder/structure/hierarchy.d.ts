/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { StateObjectRef } from '@molstar/core/state';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginStateObject } from '../../objects.js';
import type { BuiltInTrajectoryHierarchyPresetAlias, BuiltInTrajectoryHierarchyPresetId, PresetTrajectoryHierarchy } from './hierarchy-presets/catalog.js';
import type { TrajectoryHierarchyPresetProvider } from './hierarchy-presets/types.js';
export type TrajectoryHierarchyPresetProviderRef = BuiltInTrajectoryHierarchyPresetId | BuiltInTrajectoryHierarchyPresetAlias | TrajectoryHierarchyPresetProvider | string;
type BuiltInPresetOf<P extends {
    id: string;
    alias?: string;
}, K extends string> = P extends P ? K extends P['id'] | NonNullable<P['alias']> ? P : never : never;
type BuiltInPreset<K extends string> = BuiltInPresetOf<PresetTrajectoryHierarchy[keyof PresetTrajectoryHierarchy], K>;
export declare class TrajectoryHierarchyBuilder {
    plugin: PluginContext;
    private registry;
    resolveProvider(ref: TrajectoryHierarchyPresetProviderRef): TrajectoryHierarchyPresetProvider<any, {}, string, string> | undefined;
    hasPreset(t: PluginStateObject.Molecule.Trajectory): boolean;
    get providers(): ReadonlyArray<TrajectoryHierarchyPresetProvider>;
    getPresets(t?: PluginStateObject.Molecule.Trajectory): readonly TrajectoryHierarchyPresetProvider<any, {}, string, string>[];
    getPresetSelect(t?: PluginStateObject.Molecule.Trajectory): PD.Select<string>;
    getPresetsWithOptions(t: PluginStateObject.Molecule.Trajectory): PD.Mapped<PD.NamedParams<any, string>>;
    /** The message `registerPreset` would throw for this provider, or `undefined` if it would succeed. */
    findConflict(provider: TrajectoryHierarchyPresetProvider): string | undefined;
    /** Whether a preset is registered under this id or alias. */
    has(idOrAlias: string): boolean;
    registerPreset(provider: TrajectoryHierarchyPresetProvider): void;
    unregisterPreset(provider: TrajectoryHierarchyPresetProvider | string): void;
    applyPreset<K extends BuiltInTrajectoryHierarchyPresetId | BuiltInTrajectoryHierarchyPresetAlias>(parent: StateObjectRef<PluginStateObject.Molecule.Trajectory>, preset: K, params?: Partial<TrajectoryHierarchyPresetProvider.Params<BuiltInPreset<K>>>): Promise<TrajectoryHierarchyPresetProvider.State<BuiltInPreset<K>>> | undefined;
    applyPreset<P = any, S = {}>(parent: StateObjectRef<PluginStateObject.Molecule.Trajectory>, provider: TrajectoryHierarchyPresetProvider<P, S>, params?: P): Promise<S> | undefined;
    applyPreset(parent: StateObjectRef<PluginStateObject.Molecule.Trajectory>, presetIdOrAlias: string, params?: any): Promise<any> | undefined;
    constructor(plugin: PluginContext);
}
export {};
//# sourceMappingURL=hierarchy.d.ts.map