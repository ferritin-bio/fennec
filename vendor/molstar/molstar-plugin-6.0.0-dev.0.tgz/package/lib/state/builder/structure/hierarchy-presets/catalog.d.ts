/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export declare const PresetTrajectoryHierarchy: {
    default: import("./types.js").TrajectoryHierarchyPresetProvider<{
        modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
        model: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            modelIndex: /*elided*/ any;
        }>> | undefined;
        showUnitcell: boolean | undefined;
        structure: import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
        }>, "auto"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
        }>, "model"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
            id: /*elided*/ any;
        }>, "assembly"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
            radius: /*elided*/ any;
        }>, "symmetry-mates"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
            ijkMin: /*elided*/ any;
            ijkMax: /*elided*/ any;
        }>, "symmetry"> | import("@molstar/core/util/param-definition").ParamDefinition.NamedParams<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            dynamicBonds: /*elided*/ any;
            mergeBySymmetry: /*elided*/ any;
            generators: /*elided*/ any;
        }>, "symmetry-assembly"> | undefined;
        representationPresetParams: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            ignoreHydrogens: /*elided*/ any;
            ignoreHydrogensVariant: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            quality: /*elided*/ any;
            theme: /*elided*/ any;
        }> | undefined;
    }, {
        model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        representation: any;
    }, "preset-trajectory-default", "default">;
    'all-models': import("./types.js").TrajectoryHierarchyPresetProvider<{
        modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
        useDefaultIfSingleModel: boolean | undefined;
        representationPresetParams: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            ignoreHydrogens: /*elided*/ any;
            ignoreHydrogensVariant: /*elided*/ any;
            ignoreLight: /*elided*/ any;
            quality: /*elided*/ any;
            theme: /*elided*/ any;
        }> | undefined;
    }, {
        model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        representation: any;
    } | {
        models?: undefined;
        structures?: undefined;
    } | {
        models: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[];
        structures: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>[];
    }, "preset-trajectory-all-models", "all-models">;
    unitcell: import("./types.js").TrajectoryHierarchyPresetProvider<{
        modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
        model: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            modelIndex: /*elided*/ any;
        }>> | undefined;
    }, {
        model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        representation: any;
    }, "preset-trajectory-unitcell", "unitcell">;
    supercell: import("./types.js").TrajectoryHierarchyPresetProvider<{
        modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
        model: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            modelIndex: /*elided*/ any;
        }>> | undefined;
    }, {
        model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        representation: any;
    }, "preset-trajectory-supercell", "supercell">;
    crystalContacts: import("./types.js").TrajectoryHierarchyPresetProvider<{
        modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            autoAttach: /*elided*/ any;
            properties: /*elided*/ any;
        }>> | undefined;
        representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
        model: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            modelIndex: /*elided*/ any;
        }>> | undefined;
    }, {
        model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
        structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
        representation: any;
    }, "preset-trajectory-crystal-contacts", "crystalContacts">;
};
export type PresetTrajectoryHierarchy = typeof PresetTrajectoryHierarchy;
export type BuiltInTrajectoryHierarchyPresetId = PresetTrajectoryHierarchy[keyof PresetTrajectoryHierarchy]['id'];
export type BuiltInTrajectoryHierarchyPresetAlias = NonNullable<PresetTrajectoryHierarchy[keyof PresetTrajectoryHierarchy]['alias']>;
//# sourceMappingURL=catalog.d.ts.map