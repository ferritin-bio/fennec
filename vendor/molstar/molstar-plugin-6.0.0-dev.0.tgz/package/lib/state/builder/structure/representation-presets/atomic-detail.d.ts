/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { StructureRepresentationPresetProvider } from './types.js';
export declare const AtomicDetailPreset: StructureRepresentationPresetProvider<{
    ignoreHydrogens: boolean | undefined;
    ignoreHydrogensVariant: "all" | "non-polar" | undefined;
    ignoreLight: boolean | undefined;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium" | undefined;
    theme: PD.Normalize<{
        globalName: /*elided*/ any;
        globalColorParams: /*elided*/ any;
        carbonColor: /*elided*/ any;
        symmetryColor: /*elided*/ any;
        symmetryColorParams: /*elided*/ any;
        focus: /*elided*/ any;
    }> | undefined;
    showCarbohydrateSymbol: boolean;
}, {
    components?: undefined;
    representations?: undefined;
} | {
    components: {
        all: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
        branched: undefined;
    };
    representations: {
        all: import("@molstar/core/state").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    };
}, "preset-structure-representation-atomic-detail", "atomic-detail">;
/** The atomic detail preset with the representations it builds. */
export declare const AtomicDetailPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=atomic-detail.d.ts.map