/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { TrajectoryHierarchyPresetProvider } from './types.js';
export declare const UnitcellHierarchyPreset: TrajectoryHierarchyPresetProvider<{
    modelProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    structureProperties: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
    model: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        modelIndex: /*elided*/ any;
    }>> | undefined;
}, {
    model: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    modelProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Model, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    unitcell: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Shape.Representation3D, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>> | undefined;
    structure: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    structureProperties: import("@molstar/core/state/object").StateObjectSelector<import("../../../objects.js").PluginStateObject.Molecule.Structure, import("@molstar/core/state/transformer").StateTransformer<import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, import("@molstar/core/state/object").StateObject<any, import("@molstar/core/state/object").StateObject.Type<any>>, any>>;
    representation: any;
}, "preset-trajectory-unitcell", "unitcell">;
/** The unit cell hierarchy preset. */
export declare const UnitcellHierarchyPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=unitcell.d.ts.map