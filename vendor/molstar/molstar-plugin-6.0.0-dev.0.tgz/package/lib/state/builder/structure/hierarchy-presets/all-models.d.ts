/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { PluginStateObject } from '../../../objects.js';
import type { PluginRegistryEntry } from '@molstar/plugin/spec';
import { TrajectoryHierarchyPresetProvider } from './types.js';
export declare const AllModelsHierarchyPreset: TrajectoryHierarchyPresetProvider<{
    modelProperties: PD.Normalize<PD.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    structureProperties: PD.Normalize<PD.Normalize<{
        autoAttach: /*elided*/ any;
        properties: /*elided*/ any;
    }>> | undefined;
    representationPreset: "preset-structure-representation-atomic-detail" | "preset-structure-representation-auto" | "preset-structure-representation-auto-lod" | "preset-structure-representation-coarse-surface" | "preset-structure-representation-empty" | "preset-structure-representation-illustrative" | "preset-structure-representation-mesoscale" | "preset-structure-representation-molecular-surface" | "preset-structure-representation-polymer-and-ligand" | "preset-structure-representation-polymer-cartoon" | "preset-structure-representation-protein-and-nucleic" | import("../representation-presets/catalog.js").BuiltInStructureRepresentationPresetAlias | undefined;
    useDefaultIfSingleModel: boolean | undefined;
    representationPresetParams: PD.Normalize<{
        ignoreHydrogens: /*elided*/ any;
        ignoreHydrogensVariant: /*elided*/ any;
        ignoreLight: /*elided*/ any;
        quality: /*elided*/ any;
        theme: /*elided*/ any;
    }> | undefined;
}, {
    model: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    modelProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    unitcell: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Shape.Representation3D, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined;
    structure: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    structureProperties: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
    representation: any;
} | {
    models?: undefined;
    structures?: undefined;
} | {
    models: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Model, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[];
    structures: import("@molstar/core/state").StateObjectSelector<PluginStateObject.Molecule.Structure, import("@molstar/core/state").StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>[];
}, "preset-trajectory-all-models", "all-models">;
/** The all-models hierarchy preset with the default preset it delegates to and the `trajectory-index` color theme. */
export declare const AllModelsHierarchyPresetEntry: PluginRegistryEntry;
//# sourceMappingURL=all-models.d.ts.map