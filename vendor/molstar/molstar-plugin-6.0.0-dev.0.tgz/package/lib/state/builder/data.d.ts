/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StateTransformer, StateTransform } from '@molstar/core/state';
import type { PluginContext } from '@molstar/plugin/context';
import { Download, ReadFile, DownloadBlob, RawData } from '@molstar/plugin/state/transforms/data/fetch';
export declare class DataBuilder {
    plugin: PluginContext;
    private get dataState();
    rawData(params: StateTransformer.Params<RawData>, options?: Partial<StateTransform.Options>): Promise<import("@molstar/core/state").StateObjectSelector<import("../objects.js").PluginStateObject.Data.Binary | import("../objects.js").PluginStateObject.Data.String, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    download(params: StateTransformer.Params<Download>, options?: Partial<StateTransform.Options>): Promise<import("@molstar/core/state").StateObjectSelector<import("../objects.js").PluginStateObject.Data.Binary | import("../objects.js").PluginStateObject.Data.String, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    downloadBlob(params: StateTransformer.Params<DownloadBlob>, options?: Partial<StateTransform.Options>): Promise<import("@molstar/core/state").StateObjectSelector<import("../objects.js").PluginStateObject.Data.Blob, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    readFile(params: StateTransformer.Params<ReadFile>, options?: Partial<StateTransform.Options>): Promise<{
        data: import("@molstar/core/state").StateObjectSelector<import("../objects.js").PluginStateObject.Data.Binary | import("../objects.js").PluginStateObject.Data.String, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>;
        fileInfo: import("@molstar/core/util/file-info").FileNameInfo;
    }>;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=data.d.ts.map