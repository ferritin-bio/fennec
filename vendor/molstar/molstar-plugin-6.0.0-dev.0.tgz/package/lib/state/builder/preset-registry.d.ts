/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PresetProvider } from './preset-provider.js';
/**
 * Reference-counted registry of presets, keyed by `id` and (when present) `alias`.
 *
 * - Registering the same object again increments its count.
 * - Registering a different object under an existing key throws.
 * - Unregistering decrements the count and removes the preset at zero; an unknown preset is a no-op.
 */
export declare class PresetRegistry<P extends PresetProvider<any, any, any, any, any>> {
    private readonly name;
    private _providers;
    private keys;
    private counts;
    constructor(name: string);
    /** Providers in registration order. */
    get providers(): ReadonlyArray<P>;
    /** The message `register` would throw for this provider, or `undefined` if it would succeed. */
    findConflict(provider: P): string | undefined;
    register(provider: P): void;
    /** Accepts a provider or a provider id. */
    unregister(providerOrId: P | string): void;
    has(idOrAlias: string): boolean;
    /** Resolves by `id`, then by `alias`. */
    resolve(idOrAlias: string): P | undefined;
    private getById;
}
//# sourceMappingURL=preset-registry.d.ts.map