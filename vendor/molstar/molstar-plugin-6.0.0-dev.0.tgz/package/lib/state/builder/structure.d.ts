/**
 * Copyright (c) 2020 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { PluginContext } from '@molstar/plugin/context';
import { StateObjectRef, StateObjectSelector, StateTransformer, StateTransform, StateObjectCell } from '@molstar/core/state';
import { PluginStateObject as SO } from '../objects.js';
import type { ParseBlob } from '@molstar/plugin/state/formats/cif';
import { CustomModelProperties, CustomStructureProperties, ModelFromTrajectory } from '@molstar/plugin/state/transforms/structure/hierarchy';
import { ModelUnitcell3D } from '@molstar/plugin/state/transforms/structure/unitcell';
import type { RootStructureDefinition } from '../helpers/root-structure.js';
import type { StructureComponentParams, StaticStructureComponentType } from '../helpers/structure-component.js';
import type { BuiltInTrajectoryFormat } from '@molstar/plugin/state/formats/trajectory/catalog';
import type { TrajectoryFormatProvider } from '@molstar/plugin/state/formats/trajectory/provider';
import { StructureRepresentationBuilder } from './structure/representation.js';
import type { StructureSelectionQuery } from '@molstar/plugin/state/queries/structure/query';
import type { Expression } from '@molstar/query-language/language/expression';
import { TrajectoryHierarchyBuilder } from './structure/hierarchy.js';
export declare class StructureBuilder {
    plugin: PluginContext;
    private get dataState();
    private parseTrajectoryData;
    private parseTrajectoryBlob;
    readonly hierarchy: TrajectoryHierarchyBuilder;
    readonly representation: StructureRepresentationBuilder;
    parseTrajectory(data: StateObjectRef<SO.Data.Binary | SO.Data.String>, format: BuiltInTrajectoryFormat | TrajectoryFormatProvider): Promise<StateObjectSelector<SO.Molecule.Trajectory>>;
    parseTrajectory(blob: StateObjectRef<SO.Data.Blob>, params: StateTransformer.Params<typeof ParseBlob>): Promise<StateObjectSelector<SO.Molecule.Trajectory>>;
    createModel(trajectory: StateObjectRef<SO.Molecule.Trajectory>, params?: StateTransformer.Params<typeof ModelFromTrajectory>, initialState?: Partial<StateTransform.State>): Promise<StateObjectSelector<SO.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    insertModelProperties(model: StateObjectRef<SO.Molecule.Model>, params?: StateTransformer.Params<typeof CustomModelProperties>, initialState?: Partial<StateTransform.State>): Promise<StateObjectSelector<SO.Molecule.Model, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    tryCreateUnitcell(model: StateObjectRef<SO.Molecule.Model>, params?: StateTransformer.Params<typeof ModelUnitcell3D>, initialState?: Partial<StateTransform.State>): Promise<StateObjectSelector<SO.Shape.Representation3D, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>> | undefined;
    createStructure(modelRef: StateObjectRef<SO.Molecule.Model>, params?: RootStructureDefinition.Params, initialState?: Partial<StateTransform.State>, tags?: string | string[]): Promise<StateObjectSelector<SO.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    insertStructureProperties(structure: StateObjectRef<SO.Molecule.Structure>, params?: StateTransformer.Params<typeof CustomStructureProperties>): Promise<StateObjectSelector<SO.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>>>;
    isComponentTransform(cell: StateObjectCell): boolean;
    /** returns undefined if the component is empty/null */
    tryCreateComponent(structure: StateObjectRef<SO.Molecule.Structure>, params: StructureComponentParams, key: string, tags?: string[]): Promise<StateObjectSelector<SO.Molecule.Structure> | undefined>;
    tryCreateComponentFromExpression(structure: StateObjectRef<SO.Molecule.Structure>, expression: Expression, key: string, params?: {
        label?: string;
        tags?: string[];
    }): Promise<StateObjectSelector<SO.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined>;
    tryCreateComponentStatic(structure: StateObjectRef<SO.Molecule.Structure>, type: StaticStructureComponentType, params?: {
        label?: string;
        tags?: string[];
    }): Promise<StateObjectSelector<SO.Molecule.Structure, StateTransformer<import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, import("@molstar/core/state").StateObject<any, import("@molstar/core/state").StateObject.Type<any>>, any>> | undefined>;
    tryCreateComponentFromSelection(structure: StateObjectRef<SO.Molecule.Structure>, selection: StructureSelectionQuery, key: string, params?: {
        label?: string;
        tags?: string[];
    }): Promise<StateObjectSelector<SO.Molecule.Structure> | undefined>;
    constructor(plugin: PluginContext);
}
//# sourceMappingURL=structure.d.ts.map