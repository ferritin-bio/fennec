/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import type { RuntimeContext } from '@molstar/core/task';
import type { StateObject } from '@molstar/core/state';
import { type Coordinates } from '@molstar/model/model/structure';
export declare function getTrajectory(ctx: RuntimeContext, obj: StateObject, coordinates: Coordinates): Promise<import("@molstar/model/model/structure").Trajectory>;
//# sourceMappingURL=trajectory-helpers.d.ts.map