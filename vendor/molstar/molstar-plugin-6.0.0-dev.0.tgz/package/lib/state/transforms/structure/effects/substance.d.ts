/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StructureElement } from '@molstar/model/model/structure';
import { StateTransformer } from '@molstar/core/state';
export { SubstanceStructureRepresentation3DFromScript };
type SubstanceStructureRepresentation3DFromScript = typeof SubstanceStructureRepresentation3DFromScript;
declare const SubstanceStructureRepresentation3DFromScript: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        script: import("@molstar/core/util/script").Script;
        material: {
            metalness: number;
            roughness: number;
            bumpiness: number;
        };
        clear: boolean;
    }>[];
}>>;
export { SubstanceStructureRepresentation3DFromBundle };
type SubstanceStructureRepresentation3DFromBundle = typeof SubstanceStructureRepresentation3DFromBundle;
declare const SubstanceStructureRepresentation3DFromBundle: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        bundle: StructureElement.Bundle;
        material: {
            metalness: number;
            roughness: number;
            bumpiness: number;
        };
        clear: boolean;
    }>[];
}>>;
//# sourceMappingURL=substance.d.ts.map