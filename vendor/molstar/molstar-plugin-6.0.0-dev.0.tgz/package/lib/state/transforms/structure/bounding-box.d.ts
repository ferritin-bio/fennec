/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Color } from '@molstar/core/util/color';
import { StateTransformer } from '@molstar/core/state';
export { StructureBoundingBox3D };
type StructureBoundingBox3D = typeof StructureBoundingBox3D;
declare const StructureBoundingBox3D: StateTransformer<SO.Molecule.Structure, SO.Shape.Representation3D, PD.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: PD.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: PD.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: PD.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    ignoreLight: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: PD.Normalize<{
        color: Color;
        colorStrength: number;
        substance: PD.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: PD.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    radius: number;
    color: Color;
}>>;
//# sourceMappingURL=bounding-box.d.ts.map