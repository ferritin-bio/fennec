/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { ThemeStrengthRepresentation3D };
type ThemeStrengthRepresentation3D = typeof ThemeStrengthRepresentation3D;
declare const ThemeStrengthRepresentation3D: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    overpaintStrength: number;
    transparencyStrength: number;
    emissiveStrength: number;
    substanceStrength: number;
    wiggleStrength: number;
}>>;
//# sourceMappingURL=theme-strength.d.ts.map