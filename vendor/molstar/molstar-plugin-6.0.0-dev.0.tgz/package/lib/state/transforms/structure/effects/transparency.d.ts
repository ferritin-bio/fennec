/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StructureElement } from '@molstar/model/model/structure';
import { StateTransformer } from '@molstar/core/state';
export { TransparencyStructureRepresentation3DFromScript };
type TransparencyStructureRepresentation3DFromScript = typeof TransparencyStructureRepresentation3DFromScript;
declare const TransparencyStructureRepresentation3DFromScript: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        script: import("@molstar/core/util/script").Script;
        value: number;
    }>[];
}>>;
export { TransparencyStructureRepresentation3DFromBundle };
type TransparencyStructureRepresentation3DFromBundle = typeof TransparencyStructureRepresentation3DFromBundle;
declare const TransparencyStructureRepresentation3DFromBundle: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        bundle: StructureElement.Bundle;
        value: number;
    }>[];
}>>;
//# sourceMappingURL=transparency.d.ts.map