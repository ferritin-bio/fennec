/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Clipping } from '@molstar/graphics/theme/clipping';
import { StructureElement } from '@molstar/model/model/structure';
import { StateTransformer } from '@molstar/core/state';
export { ClippingStructureRepresentation3DFromScript };
type ClippingStructureRepresentation3DFromScript = typeof ClippingStructureRepresentation3DFromScript;
declare const ClippingStructureRepresentation3DFromScript: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        script: import("@molstar/core/util/script").Script;
        groups: Clipping.Groups.Flag;
    }>[];
}>>;
export { ClippingStructureRepresentation3DFromBundle };
type ClippingStructureRepresentation3DFromBundle = typeof ClippingStructureRepresentation3DFromBundle;
declare const ClippingStructureRepresentation3DFromBundle: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        bundle: StructureElement.Bundle;
        groups: Clipping.Groups.Flag;
    }>[];
}>>;
//# sourceMappingURL=clipping.d.ts.map