/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Expression } from '@molstar/query-language/language/expression';
import { StructureElement } from '@molstar/model/model/structure';
import { StateTransformer } from '@molstar/core/state';
export { StructureSelectionFromExpression };
type StructureSelectionFromExpression = typeof StructureSelectionFromExpression;
declare const StructureSelectionFromExpression: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    expression: Expression;
    label: string | undefined;
}>>;
export { MultiStructureSelectionFromExpression };
type MultiStructureSelectionFromExpression = typeof MultiStructureSelectionFromExpression;
declare const MultiStructureSelectionFromExpression: StateTransformer<SO.Root, SO.Molecule.Structure.Selections, PD.Normalize<{
    selections: PD.Normalize<{
        key: /*elided*/ any;
        ref: /*elided*/ any;
        groupId: /*elided*/ any;
        expression: /*elided*/ any;
    }>[];
    isTransitive: boolean | undefined;
    label: string | undefined;
}>>;
export { MultiStructureSelectionFromBundle };
type MultiStructureSelectionFromBundle = typeof MultiStructureSelectionFromBundle;
declare const MultiStructureSelectionFromBundle: StateTransformer<SO.Root, SO.Molecule.Structure.Selections, PD.Normalize<{
    selections: PD.Normalize<{
        key: /*elided*/ any;
        ref: /*elided*/ any;
        groupId: /*elided*/ any;
        bundle: /*elided*/ any;
    }>[];
    isTransitive: boolean | undefined;
    label: string | undefined;
}>>;
export { StructureSelectionFromScript };
type StructureSelectionFromScript = typeof StructureSelectionFromScript;
declare const StructureSelectionFromScript: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    script: import("@molstar/core/util/script").Script;
    label: string | undefined;
}>>;
export { StructureSelectionFromBundle };
type StructureSelectionFromBundle = typeof StructureSelectionFromBundle;
declare const StructureSelectionFromBundle: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    bundle: StructureElement.Bundle;
    label: string | undefined;
}>>;
export declare const StructureComplexElementTypes: {
    readonly polymer: 'polymer';
    readonly protein: 'protein';
    readonly nucleic: 'nucleic';
    readonly water: 'water';
    readonly branched: 'branched';
    readonly ligand: 'ligand';
    readonly 'non-standard': 'non-standard';
    readonly coarse: 'coarse';
    readonly 'atomic-sequence': 'atomic-sequence';
    readonly 'atomic-het': 'atomic-het';
    readonly spheres: 'spheres';
};
export type StructureComplexElementTypes = keyof typeof StructureComplexElementTypes;
export { StructureComplexElement };
type StructureComplexElement = typeof StructureComplexElement;
declare const StructureComplexElement: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    type: "atomic-het" | "atomic-sequence" | "branched" | "coarse" | "ligand" | "non-standard" | "nucleic" | "polymer" | "protein" | "spheres" | "water";
}>>;
export { StructureComponent };
type StructureComponent = typeof StructureComponent;
declare const StructureComponent: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    type: PD.NamedParams<StructureElement.Bundle, "bundle"> | PD.NamedParams<import("@molstar/core/util/script").Script, "script"> | PD.NamedParams<Expression, "expression"> | PD.NamedParams<"all" | "branched" | "coarse" | "ion" | "ligand" | "lipid" | "non-standard" | "nucleic" | "polymer" | "protein" | "water", "static">;
    nullIfEmpty: boolean | undefined;
    label: string;
}>>;
//# sourceMappingURL=selection.d.ts.map