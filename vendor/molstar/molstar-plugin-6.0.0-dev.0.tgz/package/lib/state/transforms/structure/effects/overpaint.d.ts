/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Color } from '@molstar/core/util/color';
import { StructureElement } from '@molstar/model/model/structure';
import { StateTransformer } from '@molstar/core/state';
export { OverpaintStructureRepresentation3DFromScript };
type OverpaintStructureRepresentation3DFromScript = typeof OverpaintStructureRepresentation3DFromScript;
declare const OverpaintStructureRepresentation3DFromScript: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        script: import("@molstar/core/util/script").Script;
        color: Color;
        clear: boolean;
    }>[];
}>>;
export { OverpaintStructureRepresentation3DFromBundle };
type OverpaintStructureRepresentation3DFromBundle = typeof OverpaintStructureRepresentation3DFromBundle;
declare const OverpaintStructureRepresentation3DFromBundle: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    layers: PD.Normalize<{
        bundle: StructureElement.Bundle;
        color: Color;
        clear: boolean;
    }>[];
}>>;
//# sourceMappingURL=overpaint.d.ts.map