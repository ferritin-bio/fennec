/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { StructureRepresentation3D };
type StructureRepresentation3D = typeof StructureRepresentation3D;
declare const StructureRepresentation3D: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure.Representation3D, PD.Normalize<{
    type: any;
    colorTheme: any;
    sizeTheme: any;
}>>;
//# sourceMappingURL=representation.d.ts.map