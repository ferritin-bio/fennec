/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { UnwindStructureAssemblyRepresentation3D };
type UnwindStructureAssemblyRepresentation3D = typeof UnwindStructureAssemblyRepresentation3D;
declare const UnwindStructureAssemblyRepresentation3D: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    t: number;
}>>;
export { ExplodeStructureRepresentation3D };
type ExplodeStructureRepresentation3D = typeof ExplodeStructureRepresentation3D;
declare const ExplodeStructureRepresentation3D: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    t: number;
}>>;
export { SpinStructureRepresentation3D };
type SpinStructureRepresentation3D = typeof SpinStructureRepresentation3D;
declare const SpinStructureRepresentation3D: StateTransformer<SO.Molecule.Structure.Representation3D, SO.Molecule.Structure.Representation3DState, PD.Normalize<{
    axis: PD.NamedParams<PD.Normalize<{
        principalAxis: /*elided*/ any;
    }>, "structure"> | PD.NamedParams<PD.Normalize<{
        vector: /*elided*/ any;
    }>, "custom">;
    origin: PD.NamedParams<PD.Normalize<unknown>, "structure"> | PD.NamedParams<PD.Normalize<{
        vector: /*elided*/ any;
    }>, "custom">;
    t: number;
}>>;
//# sourceMappingURL=animation.d.ts.map