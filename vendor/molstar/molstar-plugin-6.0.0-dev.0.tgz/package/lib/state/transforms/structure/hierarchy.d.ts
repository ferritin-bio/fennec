/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 * @author Ludovic Autin <ludovic.autin@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
import { type Frame } from '@molstar/model/model/structure';
export { TrajectoryFromModelAndCoordinates };
type TrajectoryFromModelAndCoordinates = typeof TrajectoryFromModelAndCoordinates;
declare const TrajectoryFromModelAndCoordinates: StateTransformer<SO.Root, SO.Molecule.Trajectory, PD.Normalize<{
    modelRef: string;
    coordinatesRef: string;
}>>;
export { ModelFromTrajectory };
type ModelFromTrajectory = typeof ModelFromTrajectory;
declare const ModelFromTrajectory: StateTransformer<SO.Molecule.Trajectory, SO.Molecule.Model, PD.Normalize<{
    modelIndex: number;
}>>;
export { StructureFromTrajectory };
type StructureFromTrajectory = typeof StructureFromTrajectory;
declare const StructureFromTrajectory: StateTransformer<SO.Molecule.Trajectory, SO.Molecule.Structure, PD.Normalize<{}>>;
export { StructureFromModel };
type StructureFromModel = typeof StructureFromModel;
declare const StructureFromModel: StateTransformer<SO.Molecule.Model, SO.Molecule.Structure, PD.Normalize<{
    type: PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
    }>, "auto"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
    }>, "model"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        id: /*elided*/ any;
    }>, "assembly"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        radius: /*elided*/ any;
    }>, "symmetry-mates"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        ijkMin: /*elided*/ any;
        ijkMax: /*elided*/ any;
    }>, "symmetry"> | PD.NamedParams<PD.Normalize<{
        dynamicBonds: /*elided*/ any;
        mergeBySymmetry: /*elided*/ any;
        generators: /*elided*/ any;
    }>, "symmetry-assembly">;
}>>;
export { TransformStructureConformation };
type TransformStructureConformation = typeof TransformStructureConformation;
declare const TransformStructureConformation: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    transform: PD.NamedParams<PD.Normalize<{
        data: /*elided*/ any;
        transpose: /*elided*/ any;
    }>, "matrix"> | PD.NamedParams<PD.Normalize<{
        translation: /*elided*/ any;
        axis: /*elided*/ any;
        angle: /*elided*/ any;
        rotationCenter: /*elided*/ any;
    }>, "components">;
}>>;
export { StructureInstances };
type StructureInstances = typeof StructureInstances;
declare const StructureInstances: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    transforms: PD.Normalize<{
        transform: /*elided*/ any;
    }>[];
}>>;
export { ModelWithCoordinates };
type ModelWithCoordinates = typeof ModelWithCoordinates;
declare const ModelWithCoordinates: StateTransformer<SO.Molecule.Model, SO.Molecule.Model, PD.Normalize<{
    frameIndex: number | undefined;
    frameCount: number | undefined;
    atomicCoordinateFrame: Frame | undefined;
}>>;
export { CustomModelProperties };
type CustomModelProperties = typeof CustomModelProperties;
declare const CustomModelProperties: StateTransformer<SO.Molecule.Model, SO.Molecule.Model, PD.Normalize<{
    autoAttach: string[];
    properties: PD.Normalize<{
        [x: string]: any;
    }>;
}>>;
export { CustomStructureProperties };
type CustomStructureProperties = typeof CustomStructureProperties;
declare const CustomStructureProperties: StateTransformer<SO.Molecule.Structure, SO.Molecule.Structure, PD.Normalize<{
    autoAttach: string[];
    properties: PD.Normalize<{
        [x: string]: any;
    }>;
}>>;
//# sourceMappingURL=hierarchy.d.ts.map