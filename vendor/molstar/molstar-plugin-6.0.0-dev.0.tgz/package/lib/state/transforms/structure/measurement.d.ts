/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO, type PluginStateObject } from '@molstar/plugin/state/objects';
import { type DistanceData } from '@molstar/graphics/repr/shape/loci/distance';
import { StateTransformer } from '@molstar/core/state';
import { type AngleData } from '@molstar/graphics/repr/shape/loci/angle';
import { type DihedralData } from '@molstar/graphics/repr/shape/loci/dihedral';
import { type LabelData } from '@molstar/graphics/repr/shape/loci/label';
import { type OrientationData } from '@molstar/graphics/repr/shape/loci/orientation';
import { type PlaneData } from '@molstar/graphics/repr/shape/loci/plane';
export { StructureSelectionsDistance3D };
type StructureSelectionsDistance3D = typeof StructureSelectionsDistance3D;
declare const StructureSelectionsDistance3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
    fontQuality: number;
    fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
    fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
    fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
    sizeFactor: number;
    borderColor: import("@molstar/core/util/color/color").Color;
    offsetX: number;
    offsetY: number;
    offsetZ: number;
    background: boolean;
    backgroundMargin: number;
    backgroundColor: import("@molstar/core/util/color/color").Color;
    backgroundOpacity: number;
    tether: boolean;
    tetherLength: number;
    tetherBaseWidth: number;
    attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    customText: string;
    textColor: import("@molstar/core/util/color/color").Color;
    textSize: number;
    borderWidth: number;
    unitLabel: string;
    lineSizeAttenuation: boolean;
    linesColor: import("@molstar/core/util/color/color").Color;
    linesSize: number;
    dashLength: number;
    visuals: ("lines" | "text")[];
}>>;
export { StructureSelectionsAngle3D };
type StructureSelectionsAngle3D = typeof StructureSelectionsAngle3D;
declare const StructureSelectionsAngle3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
    fontQuality: number;
    fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
    fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
    fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
    sizeFactor: number;
    borderColor: import("@molstar/core/util/color/color").Color;
    offsetX: number;
    offsetY: number;
    offsetZ: number;
    background: boolean;
    backgroundMargin: number;
    backgroundColor: import("@molstar/core/util/color/color").Color;
    backgroundOpacity: number;
    tether: boolean;
    tetherLength: number;
    tetherBaseWidth: number;
    attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
    customText: string;
    textColor: import("@molstar/core/util/color/color").Color;
    textSize: number;
    borderWidth: number;
    color: import("@molstar/core/util/color/color").Color;
    arcScale: number;
    lineSizeAttenuation: boolean;
    linesSize: number;
    dashLength: number;
    ignoreLight: boolean;
    sectorOpacity: number;
    visuals: ("arc" | "sector" | "text" | "vectors")[];
}>>;
export { StructureSelectionsDihedral3D };
type StructureSelectionsDihedral3D = typeof StructureSelectionsDihedral3D;
declare const StructureSelectionsDihedral3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
    fontQuality: number;
    fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
    fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
    fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
    sizeFactor: number;
    borderColor: import("@molstar/core/util/color/color").Color;
    offsetX: number;
    offsetY: number;
    offsetZ: number;
    background: boolean;
    backgroundMargin: number;
    backgroundColor: import("@molstar/core/util/color/color").Color;
    backgroundOpacity: number;
    tether: boolean;
    tetherLength: number;
    tetherBaseWidth: number;
    attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
    customText: string;
    textColor: import("@molstar/core/util/color/color").Color;
    textSize: number;
    borderWidth: number;
    color: import("@molstar/core/util/color/color").Color;
    arcScale: number;
    lineSizeAttenuation: boolean;
    linesSize: number;
    dashLength: number;
    ignoreLight: boolean;
    sectorOpacity: number;
    visuals: ("arc" | "arms" | "connector" | "extenders" | "sector" | "text" | "vectors")[];
}>>;
export { StructureSelectionsLabel3D };
type StructureSelectionsLabel3D = typeof StructureSelectionsLabel3D;
declare const StructureSelectionsLabel3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    fontFamily: import("@molstar/graphics/geo/geometry/text/font-atlas").FontFamily;
    fontQuality: number;
    fontStyle: import("@molstar/graphics/geo/geometry/text/font-atlas").FontStyle;
    fontVariant: import("@molstar/graphics/geo/geometry/text/font-atlas").FontVariant;
    fontWeight: import("@molstar/graphics/geo/geometry/text/font-atlas").FontWeight;
    sizeFactor: number;
    borderColor: import("@molstar/core/util/color/color").Color;
    offsetX: number;
    offsetY: number;
    offsetZ: number;
    background: boolean;
    backgroundMargin: number;
    backgroundColor: import("@molstar/core/util/color/color").Color;
    backgroundOpacity: number;
    tether: boolean;
    tetherLength: number;
    tetherBaseWidth: number;
    attachment: "bottom-center" | "bottom-left" | "bottom-right" | "middle-center" | "middle-left" | "middle-right" | "top-center" | "top-left" | "top-right";
    customText: string;
    textColor: import("@molstar/core/util/color/color").Color;
    textSize: number;
    borderWidth: number;
    scaleByRadius: boolean;
    visuals: "text"[];
    snapshotKey: string;
    tooltip: string;
}>>;
export { StructureSelectionsOrientation3D };
type StructureSelectionsOrientation3D = typeof StructureSelectionsOrientation3D;
declare const StructureSelectionsOrientation3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    ignoreLight: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    color: import("@molstar/core/util/color/color").Color;
    scaleFactor: number;
    radiusScale: number;
    visuals: ("axes" | "box" | "ellipsoid")[];
}>>;
export { StructureSelectionsPlane3D };
type StructureSelectionsPlane3D = typeof StructureSelectionsPlane3D;
declare const StructureSelectionsPlane3D: StateTransformer<SO.Molecule.Structure.Selections, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    ignoreLight: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    color: import("@molstar/core/util/color/color").Color;
    scaleFactor: number;
    variant: "circle" | "rectangle";
    radialSegments: number;
    visuals: "plane"[];
}>>;
export declare function getDistanceDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): DistanceData;
export declare function getAngleDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): AngleData;
export declare function getDihedralDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): DihedralData;
export declare function getLabelDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): LabelData;
export declare function getOrientationDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): OrientationData;
export declare function getPlaneDataFromStructureSelections(s: ReadonlyArray<PluginStateObject.Molecule.Structure.SelectionEntry>): PlaneData;
//# sourceMappingURL=measurement.d.ts.map