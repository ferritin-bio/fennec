/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Vec3, Mat4 } from '@molstar/core/math/linear-algebra';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export declare function transformParamsNeedCentroid(src: TransformParam): boolean;
export declare function getTransformFromParams(src: TransformParam, centroid: Vec3): Mat4;
export declare const TransformParam: PD.Mapped<PD.NamedParams<PD.Normalize<{
    data: Mat4;
    transpose: boolean;
}>, "matrix"> | PD.NamedParams<PD.Normalize<{
    translation: Vec3;
    axis: Vec3;
    angle: number;
    rotationCenter: PD.NamedParams<PD.Normalize<unknown>, "centroid"> | PD.NamedParams<PD.Normalize<{
        point: /*elided*/ any;
    }>, "point">;
}>, "components">>;
export type TransformParam = (typeof TransformParam)['defaultValue'];
//# sourceMappingURL=helpers.d.ts.map