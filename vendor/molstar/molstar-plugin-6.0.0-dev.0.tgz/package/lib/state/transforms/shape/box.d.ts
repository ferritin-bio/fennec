/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <autin@scripps.edu>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Vec3 } from '@molstar/core/math/linear-algebra';
import { Mesh } from '@molstar/graphics/geo/geometry/mesh/mesh';
import { Box3D } from '@molstar/core/math/geometry';
export { BoxShape3D };
type BoxShape3D = typeof BoxShape3D;
declare const BoxShape3D: import("@molstar/core/state/transformer").StateTransformer<SO.Root, SO.Shape.Provider, PD.Normalize<{
    bottomLeft: Vec3;
    topRight: Vec3;
    radius: number;
    color: import("@molstar/core/util/color/color").Color;
}>>;
export declare function getBoxMesh(box: Box3D, radius: number, oldMesh?: Mesh): Mesh;
//# sourceMappingURL=box.d.ts.map