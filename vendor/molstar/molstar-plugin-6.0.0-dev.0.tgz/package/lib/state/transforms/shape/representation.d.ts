/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { ShapeRepresentation3D };
type ShapeRepresentation3D = typeof ShapeRepresentation3D;
declare const ShapeRepresentation3D: StateTransformer<SO.Shape.Provider, SO.Shape.Representation3D, PD.Normalize<{}>>;
//# sourceMappingURL=representation.d.ts.map