/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { ImportJson };
type ImportJson = typeof ImportJson;
declare const ImportJson: StateTransformer<SO.Root, SO.Format.Json, PD.Normalize<{
    data: any;
    label: string | undefined;
}>>;
export { ParseJson };
type ParseJson = typeof ParseJson;
declare const ParseJson: StateTransformer<SO.Data.String, SO.Format.Json, PD.Normalize<{}>>;
//# sourceMappingURL=json.d.ts.map