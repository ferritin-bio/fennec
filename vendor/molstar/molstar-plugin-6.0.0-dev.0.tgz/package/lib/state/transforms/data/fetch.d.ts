/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Neli Fonseca <neli@ebi.ac.uk>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { Asset } from '@molstar/core/util/assets';
import { StateTransformer } from '@molstar/core/state';
export { Download };
type Download = typeof Download;
declare const Download: StateTransformer<SO.Root, SO.Data.Binary | SO.Data.String, PD.Normalize<{
    url: string | Asset.Url;
    label: string | undefined;
    isBinary: boolean | undefined;
}>>;
export { DownloadBlob };
type DownloadBlob = typeof DownloadBlob;
declare const DownloadBlob: StateTransformer<SO.Root, SO.Data.Blob, PD.Normalize<{
    sources: PD.Normalize<{
        id: /*elided*/ any;
        url: /*elided*/ any;
        isBinary: /*elided*/ any;
        canFail: /*elided*/ any;
    }>[];
    maxConcurrency: number | undefined;
}>>;
export { DeflateData };
type DeflateData = typeof DeflateData;
declare const DeflateData: StateTransformer<SO.Data.Binary, SO.Data.Binary | SO.Data.String, PD.Normalize<{
    method: string;
    isString: boolean;
    stringEncoding: string | undefined;
    label: string | undefined;
}>>;
export { RawData };
type RawData = typeof RawData;
declare const RawData: StateTransformer<SO.Root, SO.Data.Binary | SO.Data.String, PD.Normalize<{
    data: string | number[] | ArrayBuffer | Uint8Array<ArrayBuffer>;
    label: string | undefined;
}>>;
export { ReadFile };
type ReadFile = typeof ReadFile;
declare const ReadFile: StateTransformer<SO.Root, SO.Data.Binary | SO.Data.String, PD.Normalize<{
    file: Asset.File | null;
    label: string | undefined;
    isBinary: boolean | undefined;
}>>;
export { ImportString };
type ImportString = typeof ImportString;
declare const ImportString: StateTransformer<SO.Root, SO.Data.String, PD.Normalize<{
    data: string;
    label: string | undefined;
}>>;
export { LazyVolume };
type LazyVolume = typeof LazyVolume;
declare const LazyVolume: StateTransformer<SO.Root, SO.Volume.Lazy, PD.Normalize<{
    url: string | Asset.Url;
    isBinary: boolean;
    format: string;
    entryId: string | string[];
    isovalues: PD.Normalize<{
        type: /*elided*/ any;
        value: /*elided*/ any;
        color: /*elided*/ any;
        alpha: /*elided*/ any;
        volumeIndex: /*elided*/ any;
    }>[];
}>>;
//# sourceMappingURL=fetch.d.ts.map