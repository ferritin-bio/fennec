/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { CreateGroup };
type CreateGroup = typeof CreateGroup;
declare const CreateGroup: StateTransformer<never, SO.Group, PD.Normalize<{
    label: string;
    description: string | undefined;
}>>;
//# sourceMappingURL=group.d.ts.map