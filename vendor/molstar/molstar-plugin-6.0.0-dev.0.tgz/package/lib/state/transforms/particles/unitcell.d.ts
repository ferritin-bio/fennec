/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { StateTransformer } from '@molstar/core/state';
export { ParticleListUnitcell3D };
type ParticleListUnitcell3D = typeof ParticleListUnitcell3D;
declare const ParticleListUnitcell3D: StateTransformer<SO.Particle.List, SO.Shape.Representation3D, import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
    alpha: number;
    quality: "auto" | "custom" | "high" | "higher" | "highest" | "low" | "lower" | "lowest" | "medium";
    material: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        metalness: number;
        roughness: number;
        bumpiness: number;
    }>;
    clip: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        variant: import("@molstar/core/util/clip").Clip.Variant;
        objects: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: import("@molstar/core/math/linear-algebra").Vec3;
            rotation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<import("@molstar/core/util/clip").Clip.Rotation>;
            scale: import("@molstar/core/math/linear-algebra").Vec3;
            transform: import("@molstar/core/math/linear-algebra").Mat4;
        }>[];
    }>;
    emissive: number;
    density: number;
    instanceGranularity: import("@molstar/graphics/geo/geometry/base").InstanceGranularityValue;
    renderMerged: import("@molstar/graphics/geo/geometry/base").RenderMergedValue;
    lod: import("@molstar/core/math/linear-algebra").Vec3;
    cellSize: number;
    batchSize: number;
    doubleSided: boolean;
    flipSided: boolean;
    flatShaded: boolean;
    ignoreLight: boolean;
    celShaded: boolean;
    xrayShaded: "inverted" | boolean;
    transparentBackfaces: "off" | "on" | "opaque";
    solidInterior: boolean;
    bumpFrequency: number;
    bumpAmplitude: number;
    interior: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        color: import("@molstar/core/util/color/color").Color;
        colorStrength: number;
        substance: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
            metalness: number;
            roughness: number;
            bumpiness: number;
        }>;
        substanceStrength: number;
    }>;
    animation: import("@molstar/core/util/param-definition").ParamDefinition.Normalize<{
        wiggleMode: "group" | "position";
        wiggleSpeed: number;
        wiggleAmplitude: number;
        wiggleFrequency: number;
        tumbleSpeed: number;
        tumbleAmplitude: number;
        tumbleFrequency: number;
    }>;
    cellColor: import("@molstar/core/util/color/color").Color;
    cellScale: number;
    ref: "model" | "origin";
    attachment: "center" | "corner";
}>>;
//# sourceMappingURL=unitcell.d.ts.map