/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { ParticlesRepresentation3D };
type ParticlesRepresentation3D = typeof ParticlesRepresentation3D;
declare const ParticlesRepresentation3D: StateTransformer<SO.Particle.List, SO.Particle.Representation3D, PD.Normalize<{
    type: any;
    colorTheme: any;
    sizeTheme: any;
}>>;
//# sourceMappingURL=representation.d.ts.map