/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { Asset } from '@molstar/core/util/assets';
import { StateTransformer } from '@molstar/core/state';
export { ParticleListFromTrajectory };
type ParticleListFromTrajectory = typeof ParticleListFromTrajectory;
declare const ParticleListFromTrajectory: StateTransformer<SO.Particle.Trajectory, SO.Particle.List, PD.Normalize<{
    frameIndex: number;
}>>;
export { ParticleListWithTargets };
type ParticleListWithTargets = typeof ParticleListWithTargets;
declare const ParticleListWithTargets: StateTransformer<SO.Particle.List, SO.Particle.List, PD.Normalize<{
    files: Asset.File[] | null;
    targets: PD.Normalize<{
        targetId: /*elided*/ any;
        source: /*elided*/ any;
    }>[];
    includeParent: boolean;
}>>;
//# sourceMappingURL=ops.d.ts.map