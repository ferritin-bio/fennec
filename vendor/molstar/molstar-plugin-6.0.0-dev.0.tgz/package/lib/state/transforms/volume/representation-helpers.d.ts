/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PluginContext } from '@molstar/plugin/context';
import type { VolumeRepresentationRegistry } from '@molstar/graphics/repr/volume/registry';
import { Volume } from '@molstar/model/model/volume';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import type { RepresentationProvider } from '@molstar/graphics/repr/representation';
import type { ColorTheme } from '@molstar/graphics/theme/color';
import type { SizeTheme } from '@molstar/graphics/theme/size';
import type { StateTransformer } from '@molstar/core/state';
import type { VolumeRepresentation3D } from './representation.js';
export declare namespace VolumeRepresentation3DHelpers {
    function getDefaultParams(ctx: PluginContext, name: VolumeRepresentationRegistry.BuiltIn | RepresentationProvider<Volume>, volume: Volume, volumeParams?: Partial<PD.Values<PD.Params>>, colorName?: ColorTheme.BuiltIn | ColorTheme.Provider, colorParams?: Partial<ColorTheme.Props>, sizeName?: SizeTheme.BuiltIn | SizeTheme.Provider, sizeParams?: Partial<SizeTheme.Props>): StateTransformer.Params<VolumeRepresentation3D>;
    function getDefaultParamsStatic(ctx: PluginContext, name: VolumeRepresentationRegistry.BuiltIn | RepresentationProvider<Volume>, volumeParams?: Partial<PD.Values<PD.Params>>, colorName?: ColorTheme.BuiltIn | ColorTheme.Provider, colorParams?: Partial<ColorTheme.Props>, sizeName?: SizeTheme.BuiltIn | SizeTheme.Provider, sizeParams?: Partial<SizeTheme.Props>): StateTransformer.Params<VolumeRepresentation3D>;
    function getDescription(props: any): string | undefined;
}
//# sourceMappingURL=representation-helpers.d.ts.map