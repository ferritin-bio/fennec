/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Yakov Pechersky <ffxen158@gmail.com>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { AssignColorVolume };
type AssignColorVolume = typeof AssignColorVolume;
declare const AssignColorVolume: StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
    ref: string;
}>>;
export { VolumeTransform };
type VolumeTransform = typeof VolumeTransform;
declare const VolumeTransform: StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
    transform: PD.NamedParams<PD.Normalize<{
        data: /*elided*/ any;
        transpose: /*elided*/ any;
    }>, "matrix"> | PD.NamedParams<PD.Normalize<{
        translation: /*elided*/ any;
        axis: /*elided*/ any;
        angle: /*elided*/ any;
        rotationCenter: /*elided*/ any;
    }>, "components">;
}>>;
export { VolumeInstances };
type VolumeInstances = typeof VolumeInstances;
declare const VolumeInstances: StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
    mode: "periodicRange" | "transforms";
    transforms: PD.Normalize<{
        transform: /*elided*/ any;
    }>[];
    periodicRange: PD.Normalize<{
        min: /*elided*/ any;
        max: /*elided*/ any;
    }>;
}>>;
export { CustomVolumeProperties };
type CustomVolumeProperties = typeof CustomVolumeProperties;
declare const CustomVolumeProperties: StateTransformer<SO.Volume.Data, SO.Volume.Data, PD.Normalize<{
    autoAttach: string[];
    properties: PD.Normalize<{
        [x: string]: any;
    }>;
}>>;
//# sourceMappingURL=ops.d.ts.map