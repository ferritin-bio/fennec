/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { PluginStateObject as SO } from '@molstar/plugin/state/objects';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { StateTransformer } from '@molstar/core/state';
export { VolumeRepresentation3D };
type VolumeRepresentation3D = typeof VolumeRepresentation3D;
declare const VolumeRepresentation3D: StateTransformer<SO.Volume.Data, SO.Volume.Representation3D, PD.Normalize<{
    type: any;
    colorTheme: any;
    sizeTheme: any;
}>>;
//# sourceMappingURL=representation.d.ts.map