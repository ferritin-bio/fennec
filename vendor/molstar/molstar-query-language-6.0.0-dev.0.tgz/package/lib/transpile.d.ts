/**
 * Copyright (c) 2022-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Koya Sakuma <koya.sakuma.work@gmail.com>
 *
 * Adapted from MolQL src/transpile.ts
 */
import type { Transpiler } from './transpilers/transpiler.js';
import type { Expression } from './language/expression.js';
import type { Script } from '@molstar/core/util/script';
/** Enable a script language, called by the `transpilers/<lang>` modules on import */
export declare function registerTranspiler(lang: Script['language'], transpiler: Transpiler): void;
export declare function getRegisteredLanguages(): Script['language'][];
export declare function parse(lang: Script['language'], str: string): Expression;
//# sourceMappingURL=transpile.d.ts.map