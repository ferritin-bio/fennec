/**
 * Copyright (c) 2026 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Script as ScriptData } from '@molstar/core/util/script';
import type { Expression } from './language/expression.js';
export type Script = ScriptData;
export declare function Script(expression: string, language: Script['language']): Script;
/** Text-to-expression operations; molecular compilation and evaluation live in @molstar/model. */
export declare namespace Script {
    type Language = ScriptData['language'];
    const Info: Record<Language, string>;
    function is(x: any): x is Script;
    function areEqual(a: Script, b: Script): boolean;
    /** MolScript plus the languages enabled through explicit transpiler registration imports. */
    function getAvailableLanguages(): Language[];
    function toExpression(script: Script): Expression;
}
//# sourceMappingURL=script.d.ts.map