/**
 * Copyright (c) 2026 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Script } from '@molstar/core/util/script';
import type { Expression } from './language/expression.js';
/** Translate supported selection text to MolQL and validate its syntax and argument names.
 * MolScript input must contain exactly one expression; aliases and macros are validated before expansion.
 * Does not compile an executable query or evaluate against molecular data. All languages are available without
 * registration imports. Import individual transpiler parsers for single-language consumers. */
export declare function compileScript(language: Script['language'], source: string): Expression;
//# sourceMappingURL=compile.d.ts.map