/**
 * Copyright (c) 2017-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Koya Sakuma <koya.sakuma.work@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * Adapted from MolQL project
 */
import type { KeywordDict } from '../types.js';
export declare const keywords: KeywordDict;
//# sourceMappingURL=keywords.d.ts.map