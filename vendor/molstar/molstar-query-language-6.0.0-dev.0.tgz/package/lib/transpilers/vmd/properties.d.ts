/**
 * Copyright (c) 2017-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Panagiotis Tourlas <panagiot_tourlov@hotmail.com>
 *
 * Adapted from MolQL project
 */
import type { PropertyDict } from '../types.js';
export declare const sstrucDict: {
    [key: string]: string;
};
export declare function sstrucMap(x: string): import("../../language/expression.js").Expression;
export declare const properties: PropertyDict;
//# sourceMappingURL=properties.d.ts.map