/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 */
export {};
//# sourceMappingURL=jmol.d.ts.map