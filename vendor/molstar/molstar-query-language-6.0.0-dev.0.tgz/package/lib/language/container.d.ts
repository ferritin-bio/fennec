import type { Expression } from './expression.js';
export interface Container {
    source?: string;
    version: string;
    expression: Expression;
}
//# sourceMappingURL=container.d.ts.map