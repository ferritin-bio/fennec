type Expression = Expression.Literal | Expression.Symbol | Expression.Apply;
declare namespace Expression {
    /** A value of a list of literals: `null` is a missing value (it is what JSON makes of `undefined` in a list) */
    type ListValue = string | number | boolean | null;
    /** A literal: a value, `null` (a missing value), or a list of values, which the compiler passes through as it is (it does not compile every value of it).
     * A list of values is how a column of a table is given to a symbol which takes tables (`structure.generator.element-schema`) in any size. */
    type Literal = ListValue | ListValue[];
    type Symbol = {
        name: string;
    };
    type Arguments = Expression[] | {
        [name: string]: Expression;
    };
    interface Apply {
        readonly head: Expression;
        readonly args?: Arguments;
    }
    function Symbol(name: string): Expression.Symbol;
    function Apply(head: Expression, args?: Arguments): Apply;
    function isArgumentsArray(e?: Arguments): e is Expression[];
    function isArgumentsMap(e?: Arguments): e is {
        [name: string]: Expression;
    };
    function isLiteral(e: Expression): e is Expression.Literal;
    function isApply(e: Expression): e is Expression.Apply;
    function isSymbol(e: Expression): e is Expression.Symbol;
    /** Decide if a value has the recursive JSON shape of a MolScript expression. */
    function is(value: unknown): value is Expression;
}
export { Expression };
//# sourceMappingURL=expression.d.ts.map