/**
 * Copyright (c) 2026 Mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { MSymbol } from './symbol.js';
export interface ExpressionValidationOptions {
    /** Resolve symbol definitions, including any application-specific vocabulary. Defaults to the standard symbol table. */
    getSymbol?: (name: string) => MSymbol | undefined;
    /** Only check expression syntax, without resolving callable symbols or checking their argument names. */
    syntaxOnly?: boolean;
}
/** Validate expression syntax and argument names without compiling or evaluating a molecular query.
 * Does not check required arguments, argument types, or result types. */
export declare function expressionValidationIssues(expression: unknown, options?: ExpressionValidationOptions): string[] | undefined;
//# sourceMappingURL=validation.d.ts.map