/**
 * Copyright (c) 2018-26 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * adapted from https://github.com/d3/d3-ease
 */

import { ParamDefinition as PD } from '@molstar/core/util/param-definition';

const b1 = 4 / 11,
  b2 = 6 / 11,
  b3 = 8 / 11,
  b4 = 3 / 4,
  b5 = 9 / 11,
  b6 = 10 / 11,
  b7 = 15 / 16,
  b8 = 21 / 22,
  b9 = 63 / 64,
  b0 = 1 / b1 / b1;

export function bounceIn(t: number) {
  return 1 - bounceOut(1 - t);
}

export function bounceOut(t: number) {
  return (t = +t) < b1
    ? b0 * t * t
    : t < b3
      ? b0 * (t -= b2) * t + b4
      : t < b6
        ? b0 * (t -= b5) * t + b7
        : b0 * (t -= b8) * t + b9;
}

export function bounceInOut(t: number) {
  return ((t *= 2) <= 1 ? 1 - bounceOut(1 - t) : bounceOut(t - 1) + 1) / 2;
}

//

export function circleIn(t: number) {
  return 1 - Math.sqrt(1 - t * t);
}

export function circleOut(t: number) {
  return Math.sqrt(1 - --t * t);
}

export function circleInOut(t: number) {
  return ((t *= 2) <= 1 ? 1 - Math.sqrt(1 - t * t) : Math.sqrt(1 - (t -= 2) * t) + 1) / 2;
}

//

export function cubicIn(t: number) {
  return t * t * t;
}

export function cubicOut(t: number) {
  return --t * t * t + 1;
}

export function cubicInOut(t: number) {
  return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2;
}

//

export function expIn(t: number) {
  return Math.pow(2, 10 * t - 10);
}

export function expOut(t: number) {
  return 1 - Math.pow(2, -10 * t);
}

export function expInOut(t: number) {
  return ((t *= 2) <= 1 ? Math.pow(2, 10 * t - 10) : 2 - Math.pow(2, 10 - 10 * t)) / 2;
}

//

export function quadIn(t: number) {
  return t * t;
}

export function quadOut(t: number) {
  return t * (2 - t);
}

export function quadInOut(t: number) {
  return ((t *= 2) <= 1 ? t * t : --t * (2 - t) + 1) / 2;
}

//

const pi = Math.PI,
  halfPi = pi / 2;

export function sinIn(t: number) {
  return 1 - Math.cos(t * halfPi);
}

export function sinOut(t: number) {
  return Math.sin(t * halfPi);
}

export function sinInOut(t: number) {
  return (1 - Math.cos(pi * t)) / 2;
}

//

export const EasingFunctions = {
  linear: (t: number) => t,
  'bounce-in': bounceIn,
  'bounce-out': bounceOut,
  'bounce-in-out': bounceInOut,
  'circle-in': circleIn,
  'circle-out': circleOut,
  'circle-in-out': circleInOut,
  'cubic-in': cubicIn,
  'cubic-out': cubicOut,
  'cubic-in-out': cubicInOut,
  'exp-in': expIn,
  'exp-out': expOut,
  'exp-in-out': expInOut,
  'quad-in': quadIn,
  'quad-out': quadOut,
  'quad-in-out': quadInOut,
  'sin-in': sinIn,
  'sin-out': sinOut,
  'sin-in-out': sinInOut,
};

export type EasingKind = keyof typeof EasingFunctions;
export type EasingFunction = EasingKind | ((t: number) => number);

export function getEasingFn(easing: EasingFunction | undefined): (t: number) => number {
  if (!easing) return EasingFunctions.linear;
  return typeof easing === 'function' ? easing : (EasingFunctions[easing] ?? EasingFunctions.linear);
}

export function EasingParamDefinition(defaultValue: EasingKind): PD.Select<EasingKind> {
  return PD.Select(
    defaultValue,
    Object.keys(EasingFunctions).map((key) => [key as EasingKind, key]),
    {
      description:
        'Transition easing function. Adjusts transition speed near the beginning and end of the transition to create smoother camera motion.',
    },
  );
}
