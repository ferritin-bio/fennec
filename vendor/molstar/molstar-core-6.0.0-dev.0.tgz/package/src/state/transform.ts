/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */

import { StateTransformer } from './transformer.js';
import { UUID } from '@molstar/core/util';
import { hashMurmur128o } from '@molstar/core/data/util/hash-functions';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
import { arraySetAdd, arraySetRemove } from '@molstar/core/util/array';

export { Transform as StateTransform };

interface Transform<T extends StateTransformer = StateTransformer> {
  readonly parent: Transform.Ref;
  readonly transformer: T;
  readonly state: Transform.State;
  readonly tags?: string[];
  readonly ref: Transform.Ref;
  /**
   * Sibling-like dependency
   * Do NOT make a cell dependent on its ancestor.
   */
  readonly dependsOn?: Transform.Ref[];
  readonly params?: StateTransformer.Params<T>;
  readonly version: string;
}

namespace Transform {
  export type Ref = string;
  export type Transformer<T extends Transform> = T extends Transform<infer S> ? S : never;

  export const RootRef = '-=root=-' as Ref;

  export interface State {
    // is the cell shown in the UI
    isGhost?: boolean;
    // can the corresponding be deleted by the user.
    isLocked?: boolean;
    // is the representation associated with the cell hidden
    isHidden?: boolean;
    // is the tree node collapsed?
    isCollapsed?: boolean;
  }

  export function isStateChange(a: State, b?: Partial<State>) {
    if (!b) return false;
    if (typeof b.isCollapsed !== 'undefined' && a.isCollapsed !== b.isCollapsed) return true;
    if (typeof b.isHidden !== 'undefined' && a.isHidden !== b.isHidden) return true;
    if (typeof b.isGhost !== 'undefined' && a.isGhost !== b.isGhost) return true;
    if (typeof b.isLocked !== 'undefined' && a.isLocked !== b.isLocked) return true;
    return false;
  }

  export function assignState(a: State, b?: Partial<State>): boolean {
    if (!b) return false;

    let changed = false;
    for (const k of Object.keys(b)) {
      const s = (b as any)[k],
        t = (a as any)[k];
      if (!!s === !!t) continue;
      changed = true;
      (a as any)[k] = s;
    }
    return changed;
  }

  export function syncState(a: State, b?: Partial<State>): boolean {
    if (!b) return false;

    let changed = false;
    for (const k of Object.keys(b)) {
      const s = (b as any)[k],
        t = (a as any)[k];
      if (!!s === !!t) continue;
      changed = true;
      if (s !== void 0) {
        (a as any)[k] = s;
      } else {
        delete (a as any)[k];
      }
    }
    for (const k of Object.keys(a)) {
      const s = (b as any)[k],
        t = (a as any)[k];
      if (!!s === !!t) continue;
      changed = true;
      if (s !== void 0) {
        (a as any)[k] = s;
      } else {
        delete (a as any)[k];
      }
    }

    return changed;
  }

  export interface Options {
    ref?: string;
    tags?: string | string[];
    state?: State;
    dependsOn?: Ref[];
  }

  export function create<T extends StateTransformer>(
    parent: Ref,
    transformer: T,
    params?: StateTransformer.Params<T>,
    options?: Options,
  ): Transform<T> {
    const ref = options && options.ref ? options.ref : (UUID.create22() as string as Ref);
    let tags: string[] | undefined = void 0;
    if (options && options.tags) {
      tags = typeof options.tags === 'string' ? [options.tags] : options.tags;
      if (tags.length === 0) tags = void 0;
      else tags.sort();
    }
    return {
      parent,
      transformer,
      state: options?.state || {},
      tags,
      ref,
      dependsOn: options && options.dependsOn,
      params,
      version: UUID.create22(),
    };
  }

  export function withParams(t: Transform, params: any): Transform {
    return { ...t, params, version: UUID.create22() };
  }

  export function withState(t: Transform, state?: Partial<State>): Transform {
    if (!state) return t;
    return { ...t, state: { ...t.state, ...state } };
  }

  export function withTags(t: Transform, newTags?: string | string[]): Transform {
    let tags: string[] | undefined = void 0;
    if (newTags) {
      tags = typeof newTags === 'string' ? [newTags] : newTags;
      if (tags.length === 0) tags = void 0;
      else tags.sort();
    }
    return { ...t, tags, version: UUID.create22() };
  }

  export function withDependsOn(t: Transform, newDependsOn?: string | string[]): Transform {
    let dependsOn: string[] | undefined = void 0;
    if (newDependsOn) {
      dependsOn = typeof newDependsOn === 'string' ? [newDependsOn] : newDependsOn;
      if (dependsOn.length === 0) dependsOn = void 0;
      else dependsOn.sort();
    }
    return { ...t, dependsOn, version: UUID.create22() };
  }

  export function withParent(t: Transform, parent: Ref): Transform {
    return { ...t, parent, version: UUID.create22() };
  }

  export function createRoot(state?: State): Transform {
    return create(RootRef, StateTransformer.ROOT, {}, { ref: RootRef, state });
  }

  export function hasTag(t: Transform, tag: string) {
    if (!t.tags) return false;
    return t.tags.indexOf(tag) >= 0;
  }

  export function hasTags(t: Transform, tags: string | string[]) {
    if (!t.tags) return typeof tags !== 'string' && tags.length === 0;
    if (typeof tags === 'string') return hasTag(t, tags);
    for (const tag of tags) {
      if (t.tags.indexOf(tag) < 0) return false;
    }
    return true;
  }

  /**
   * Returns the default param schema for the transform's transformer, caching
   * the result on the transform instance. Returns `undefined` if the transformer
   * has no `params` definition or if calling it throws.
   */
  export function tryGetDefaultParamDefinition(t: Transform): PD.Params | undefined {
    const any = t as any;
    if (any._defaultSchemaSet) return any._defaultSchema;
    any._defaultSchemaSet = true;
    try {
      const def = t.transformer.definition;
      if (def.params) {
        any._defaultSchema = def.params(undefined as any, undefined) as PD.Params;
      }
    } catch {
      // Schema could not be obtained.
    }
    return any._defaultSchema;
  }

  /**
   * Compute the effective set of sibling-like dependencies for a transform.
   *
   * Combines (in order, de-duplicated):
   *   1. Explicit `t.dependsOn` (back-compat / non-param refs).
   *   2. Refs from `transformer.definition.getDependencies(params)` if defined.
   *   3. Refs collected from `PD.ValueRef` / `PD.DataRef` parameter values.
   *
   * Self-references and the root ref are filtered out. If the param schema
   * can't be obtained, auto-derivation falls back to a structural scan of
   * parameter values for `{ ref, getValue }` shaped objects.
   */
  export function getEffectiveDependsOn(t: Transform): Ref[] {
    const out: string[] = [];

    if (t.dependsOn) {
      for (const r of t.dependsOn) {
        arraySetAdd(out, r);
      }
    }

    const def = t.transformer.definition;
    const params = t.params as any;

    if (def.getDependencies && params) {
      try {
        const extra = def.getDependencies(params);
        if (extra) {
          for (const r of extra) {
            arraySetAdd(out, r);
          }
        }
      } catch {
        // Keep reconciliation robust if a user hook misbehaves.
      }
    }

    if (params) {
      const schema = tryGetDefaultParamDefinition(t);
      if (schema) {
        PD.collectRefs(schema, params, out);
      } else {
        collectStructuralRefs(params, out);
      }
    }

    // Filter out self-references and the root ref.
    arraySetRemove(out, t.ref);
    arraySetRemove(out, RootRef);
    return out;
  }

  function collectStructuralRefs(value: any, out: string[], depth = 0): string[] {
    if (!value || typeof value !== 'object' || depth > 6) return out;
    if (Array.isArray(value)) {
      for (const v of value) {
        collectStructuralRefs(v, out, depth + 1);
      }
      return out;
    }
    const ref = (value as any).ref;
    if (typeof ref === 'string' && typeof (value as any).getValue === 'function') {
      arraySetAdd(out, ref);
      return out;
    }
    for (const k of Object.keys(value)) {
      collectStructuralRefs(value[k], out, depth + 1);
    }
    return out;
  }

  const _emptyParams = {};
  /** Updates the version of the transform to be computed as hash of the parameters */
  export function setParamsHashVersion(t: Transform) {
    let version: string;
    try {
      version = hashMurmur128o(t.params ?? _emptyParams);
    } catch {
      const pToJson = t.transformer.definition.customSerialization
        ? t.transformer.definition.customSerialization.toJSON
        : _id;
      version = hashMurmur128o(pToJson(t.params ?? _emptyParams));
    }
    (t as { version: string }).version = version;
  }

  export interface Serialized {
    parent: string;
    transformer: string;
    params: any;
    state?: State;
    tags?: string[];
    isDecorator?: boolean;
    ref: string;
    dependsOn?: string[];
    version: string;
  }

  function _id(x: any) {
    return x;
  }
  export function toJSON(t: Transform): Serialized {
    const pToJson = t.transformer.definition.customSerialization
      ? t.transformer.definition.customSerialization.toJSON
      : _id;
    let state: any = void 0;
    for (const k of Object.keys(t.state)) {
      const s = (t.state as any)[k];
      if (!s) continue;
      if (!state) state = {};
      state[k] = true;
    }
    return {
      parent: t.parent,
      transformer: t.transformer.id,
      params: t.params ? pToJson(t.params) : void 0,
      state,
      tags: t.tags,
      ref: t.ref,
      dependsOn: t.dependsOn,
      version: t.version,
    };
  }

  export function fromJSON(t: Serialized): Transform {
    const transformer = StateTransformer.get(t.transformer);
    const pFromJson = transformer.definition.customSerialization
      ? transformer.definition.customSerialization.fromJSON
      : _id;
    return {
      parent: t.parent as Ref,
      transformer,
      params: t.params ? pFromJson(t.params) : void 0,
      state: t.state || {},
      tags: t.tags,
      ref: t.ref as Ref,
      dependsOn: t.dependsOn,
      version: t.version,
    };
  }
}
