/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author Russell Parker <russell@benchling.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * Implements some browser-only global variables for Node.js environment.
 * These workarounds will also work in browsers as usual.
 */

/** Determines whether the current code is running in Node.js */
export const RUNNING_IN_NODEJS =
  typeof process !== 'undefined' && process.versions != null && process.versions.node != null;

/**
 * Like `File` but works also in Node.js: the native `File` wherever there is one (browsers, Node.js 20 and later), so a
 * file a host or a test makes with `new File(...)` is the same class the asset manager checks for; a shim otherwise.
 */
export const File_ = getFile();

function getFile(): typeof File {
  if (typeof File === 'undefined') {
    class File_NodeJs implements File {
      private readonly blob: Blob;
      // Blob fields
      readonly size: number;
      readonly type: string;
      arrayBuffer() {
        return this.blob.arrayBuffer();
      }
      slice(start?: number, end?: number, contentType?: string) {
        return this.blob.slice(start, end, contentType);
      }
      stream() {
        return this.blob.stream();
      }
      text() {
        return this.blob.text();
      }
      bytes() {
        return this.blob.bytes();
      }
      // File fields
      name: string;
      lastModified: number;
      webkitRelativePath: string;

      constructor(fileBits: BlobPart[], fileName: string, options?: FilePropertyBag) {
        this.blob = new Blob(fileBits, options);
        // Blob fields
        this.size = this.blob.size;
        this.type = this.blob.type;
        // File fields
        this.name = fileName;
        this.lastModified = options?.lastModified ?? 0;
        this.webkitRelativePath = '';
      }
    }
    return File_NodeJs;
  } else {
    return File;
  }
}
