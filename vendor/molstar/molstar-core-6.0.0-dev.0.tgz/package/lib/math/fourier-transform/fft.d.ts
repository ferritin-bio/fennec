/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/** Float32Array or Float64Array for FFT data storage. */
export type FftArray = Float32Array | Float64Array;
/**
 * Returns the smallest integer >= n that is a power of 2.
 * Used to determine FFT-friendly grid dimensions.
 */
export declare function nextPow2(n: number): number;
/**
 * In-place radix-4 (radix-2²) Cooley-Tukey FFT (DIT), with a single radix-2
 * stage when log2(n) is odd. Reuses the radix-2 bit-reversal ordering.
 * Computes the forward DFT: X[k] = Σ_{n=0}^{N-1} x[n] * exp(-2πi*n*k/N)
 *
 * @param re - real parts (modified in-place), length must be a power of 2
 * @param im - imaginary parts (modified in-place), length must be a power of 2
 * @param offset - starting index within the arrays
 * @param n - transform length (must be a power of 2)
 * @param stride - element stride in the arrays
 */
export declare function fft1d<T extends FftArray>(re: T, im: T, offset: number, n: number, stride: number): void;
/**
 * In-place 3D forward FFT.
 * Computes the forward DFT along all three dimensions.
 * The data is stored in row-major order: data[h * N1 * N2 + k * N2 + l].
 *
 * The forward DFT directly gives the electron density when the input is
 * populated with structure factors: ρ[n1,n2,n3] = Σ_{h,k,l} F[h,k,l] * exp(-2πi*(h*n1/N0+k*n2/N1+l*n3/N2))
 *
 * @param re - real parts (in-place), length N0*N1*N2
 * @param im - imaginary parts (in-place), length N0*N1*N2
 * @param N0 - size along axis 0 (must be power of 2)
 * @param N1 - size along axis 1 (must be power of 2)
 * @param N2 - size along axis 2 (must be power of 2)
 */
export declare function fft3d<T extends FftArray>(re: T, im: T, N0: number, N1: number, N2: number): void;
/**
 * 3D forward FFT specialized for a Hermitian-symmetric input, producing a purely
 * real output. Roughly 2x faster than {@link fft3d} for this case and uses about
 * half the memory: only the non-redundant lower half-spectrum is stored.
 *
 * Exploits two facts that hold for crystallographic structure-factor synthesis:
 *  - the input grid F is Hermitian: F[-h,-k,-l] = conj(F[h,k,l]); hence
 *  - the forward DFT ρ[n] = Σ F·exp(-2πi·…) is real-valued.
 *
 * The input is the compact lower half-spectrum: planes l = 0..N2/2 only, in
 * row-major (N0, N1, P) layout with P = N2/2 + 1, i.e. index h*N1*P + k*P + l.
 * The caller fills these planes directly; the upper planes are implied by
 * Hermitian symmetry and never materialized.
 *
 * After transforming axes 0 and 1, every axis-2 line is conjugate-symmetric, so
 * the axis-2 pass uses a "two-for-one" real transform: two Hermitian lines are
 * packed into one complex length-N2 FFT whose real/imaginary outputs are the two
 * real result lines.
 *
 * The real result is written to `out`. The input arrays `re`/`im` are used as
 * scratch and their contents are destroyed.
 *
 * @param re - real parts of the half-spectrum (destroyed), length N0*N1*(N2/2+1)
 * @param im - imaginary parts of the half-spectrum (destroyed), length N0*N1*(N2/2+1)
 * @param N0 - size along axis 0 (must be power of 2)
 * @param N1 - size along axis 1 (must be power of 2)
 * @param N2 - size along axis 2 (must be power of 2)
 * @param out - real output (in-place), length N0*N1*N2, row-major
 */
export declare function fft3dHermitian<T extends FftArray>(re: T, im: T, N0: number, N1: number, N2: number, out: T): void;
//# sourceMappingURL=fft.d.ts.map