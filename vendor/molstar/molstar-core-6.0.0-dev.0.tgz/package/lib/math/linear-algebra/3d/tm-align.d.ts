/**
 * Copyright (c) 2025-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Diego del Alamo <diego.delalamo@gmail.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 *
 * TM-align: Structure-based protein alignment algorithm
 *
 * References:
 * Y Zhang, J Skolnick. Nucl Acids Res 33, 2302-9 (2005)
 * "TM-align: a protein structure alignment algorithm based on the TM-score"
 */
import { Mat4 } from './mat4.js';
import { MinimizeRmsd } from './minimize-rmsd.js';
import type { NumberArray } from '@molstar/core/util/type-helpers';
export { TMAlign };
declare namespace TMAlign {
    interface Result {
        /** Transformation matrix for structure B to superpose onto A */
        bTransform: Mat4;
        /** TM-score normalized by length of structure A */
        tmScoreA: number;
        /** TM-score normalized by length of structure B */
        tmScoreB: number;
        /** RMSD of aligned residues */
        rmsd: number;
        /** Number of aligned residue pairs */
        alignedLength: number;
        /** Sequence identity of aligned residues (if sequences provided) */
        sequenceIdentity: number;
        /** Alignment mapping: alignmentA[i] aligns with alignmentB[i] */
        alignmentA: NumberArray;
        alignmentB: NumberArray;
    }
    /** Reuse MinimizeRmsd.Positions type for consistency */
    type Positions = MinimizeRmsd.Positions;
    const Positions: typeof MinimizeRmsd.Positions;
    interface Input {
        /** Coordinates of structure A (reference) */
        a: Positions;
        /** Coordinates of structure B (mobile) */
        b: Positions;
        /** Optional: sequence of structure A for identity calculation */
        seqA?: string;
        /** Optional: sequence of structure B for identity calculation */
        seqB?: string;
    }
    /**
     * Compute TM-align between two structures
     */
    function compute(input: Input): Result;
    /**
     * Calculate the d0 normalization parameter
     * d0 = 1.24 * (L - 15)^(1/3) - 1.8 for L > 21
     * d0 = 0.5 for L <= 21
     */
    function calculateD0(length: number): number;
}
//# sourceMappingURL=tm-align.d.ts.map