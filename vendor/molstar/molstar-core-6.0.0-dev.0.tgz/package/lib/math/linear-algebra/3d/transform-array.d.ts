export declare function fillIdentityTransform(transform: Float32Array, count: number): Float32Array<ArrayBufferLike>;
//# sourceMappingURL=transform-array.d.ts.map