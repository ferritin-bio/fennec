/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { Mat4 } from './mat4.js';
import { Vec3 } from './vec3.js';
import { EVD } from '../matrix/evd.js';
export { MinimizeRmsd };
declare namespace MinimizeRmsd {
    interface Result {
        bTransform: Mat4;
        rmsd: number;
        nAlignedElements: number;
    }
    interface Positions {
        x: ArrayLike<number>;
        y: ArrayLike<number>;
        z: ArrayLike<number>;
    }
    namespace Positions {
        function empty(n: number): {
            x: Float64Array<ArrayBuffer>;
            y: Float64Array<ArrayBuffer>;
            z: Float64Array<ArrayBuffer>;
        };
    }
    interface Input {
        a: Positions;
        b: Positions;
        centerA?: Vec3;
        centerB?: Vec3;
        length?: number;
    }
    function compute(data: Input, result?: MinimizeRmsd.Result, state?: RmsdTransformState): Result;
}
export declare class RmsdTransformState {
    a: MinimizeRmsd.Positions;
    b: MinimizeRmsd.Positions;
    length: number;
    centerA: Vec3;
    centerB: Vec3;
    evdCache: EVD.Cache;
    translateB: Mat4;
    rotateB: Mat4;
    tempMatrix: Mat4;
    result: MinimizeRmsd.Result;
    constructor(data: MinimizeRmsd.Input, into: MinimizeRmsd.Result);
}
//# sourceMappingURL=minimize-rmsd.d.ts.map