/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
/**
 * Compute normal and binormal vectors along a curve using parallel transport
 */
export declare function computeFrenetFrames(curvePoints: Float32Array, normalVectors: Float32Array, binormalVectors: Float32Array, n: number): void;
//# sourceMappingURL=frenet-frames.d.ts.map