/**
 * Copyright (c) 2017-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat3 } from './mat3.js';
import { Vec3 } from './vec3.js';
import { type NumberArray } from '@molstar/core/util/type-helpers';
import type { Euler } from './euler.js';
import { Mat4 } from './mat4.js';
interface Quat extends Array<number> {
    [d: number]: number;
    '@type': 'quat';
    length: 4;
}
interface ReadonlyQuat extends Array<number> {
    readonly [d: number]: number;
    '@type': 'quat';
    length: 4;
}
declare function Quat(): Quat;
declare namespace Quat {
    function zero(): Quat;
    function identity(): Quat;
    function setIdentity(out: Quat): void;
    function hasNaN(q: Quat): boolean;
    function create(x: number, y: number, z: number, w: number): Quat;
    function is(a: any): a is Quat;
    function setAxisAngle(out: Quat, axis: Vec3, rad: number): Quat;
    /**
     * Gets the rotation axis and angle for a given
     *  quaternion. If a quaternion is created with
     *  setAxisAngle, this method will return the same
     *  values as providied in the original parameter list
     *  OR functionally equivalent values.
     * Example: The quaternion formed by axis [0, 0, 1] and
     *  angle -90 is the same as the quaternion formed by
     *  [0, 0, 1] and 270. This method favors the latter.
     */
    function getAxisAngle(out_axis: Vec3, q: Quat): number;
    function multiply(out: Quat, a: Quat, b: Quat): Quat;
    function rotateX(out: Quat, a: Quat, rad: number): Quat;
    function rotateY(out: Quat, a: Quat, rad: number): Quat;
    function rotateZ(out: Quat, a: Quat, rad: number): Quat;
    /**
     * Calculates the W component of a quat from the X, Y, and Z components.
     * Assumes that quaternion is 1 unit in length.
     * Any existing W component will be ignored.
     */
    function calculateW(out: Quat, a: Quat): Quat;
    /**
     * Performs a spherical linear interpolation between two quat
     */
    function slerp(out: Quat, a: Quat, b: Quat, t: number): Quat;
    function invert(out: Quat, a: Quat): Quat;
    /**
     * Calculates the conjugate of a quat
     * If the quaternion is normalized, this function is faster than quat.inverse and produces the same result.
     */
    function conjugate(out: Quat, a: Quat): Quat;
    function dot(a: Quat, b: Quat): number;
    /**
     * Creates a quaternion from the given 3x3 rotation matrix.
     *
     * NOTE: The resultant quaternion is not normalized, so you should be sure
     * to renormalize the quaternion yourself where necessary.
     */
    function fromMat3(out: Quat, m: Mat3): Quat;
    function fromMat4(out: Quat, m: Mat4): Quat;
    function fromEuler(out: Quat, euler: Euler, order: Euler.Order): Quat;
    /** Quaternion from two normalized unit vectors. */
    function fromUnitVec3(out: Quat, a: Vec3, b: Vec3): Quat;
    function fromBasis(out: Quat, x: Vec3, y: Vec3, z: Vec3): Quat;
    function clone(a: Quat): Quat;
    function fromObj(a: {
        x: number;
        y: number;
        z: number;
        w: number;
    }): Quat;
    function toObj(a: Quat): {
        x: number;
        y: number;
        z: number;
        w: number;
    };
    function toArray<T extends NumberArray>(a: Quat, out: T, offset: number): T;
    function fromArray(a: Quat, array: NumberArray, offset: number): Quat;
    function copy(out: Quat, a: Quat): Quat;
    function set(out: Quat, x: number, y: number, z: number, w: number): Quat;
    /**
     * Returns whether or not the quaternions have exactly the same elements in the same position (when compared with ===)
     */
    function exactEquals(a: Quat, b: Quat): boolean;
    /**
     * Returns whether or not the quaternions have approximately the same elements in the same position.
     */
    function equals(a: Quat, b: Quat): boolean;
    function add(out: Quat, a: Quat, b: Quat): Quat;
    function magnitude(a: Quat): number;
    function squaredMagnitude(a: Quat): number;
    function angle(a: Quat, b: Quat): number;
    function normalize(out: Quat, a: Quat): Quat;
    function rotationTo(out: Quat, a: Vec3, b: Vec3): Quat;
    function sqlerp(out: Quat, a: Quat, b: Quat, c: Quat, d: Quat, t: number): Quat;
    function setAxes(out: Quat, view: Vec3, right: Vec3, up: Vec3): Quat;
    function toString(a: Quat, precision?: number): string;
    const Identity: ReadonlyQuat;
}
export { Quat };
//# sourceMappingURL=quat.d.ts.map