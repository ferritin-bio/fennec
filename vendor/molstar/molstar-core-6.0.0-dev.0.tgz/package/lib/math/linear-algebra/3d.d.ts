/**
 * Copyright (c) 2017-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4 } from './3d/mat4.js';
import { Mat3 } from './3d/mat3.js';
import { Vec2 } from './3d/vec2.js';
import { Vec3 } from './3d/vec3.js';
import { Vec4 } from './3d/vec4.js';
import { Quat } from './3d/quat.js';
import { EPSILON } from './3d/common.js';
export { Mat4, Mat3, Vec2, Vec3, Vec4, Quat, EPSILON };
export type Vec<T> = T extends 4 ? Vec4 : T extends 3 ? Vec3 : T extends 2 ? Vec2 : number[];
//# sourceMappingURL=3d.d.ts.map