/**
 * Copyright (c) 2018-2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { NumberArray } from '@molstar/core/util/type-helpers';
import { Axes3D } from '../../geometry/primitives/axes3d.js';
export { PrincipalAxes };
interface PrincipalAxes {
    momentsAxes: Axes3D;
    boxAxes: Axes3D;
}
declare namespace PrincipalAxes {
    function ofPositions(positions: NumberArray): PrincipalAxes;
    function calculateMomentsAxes(positions: NumberArray): Axes3D;
    function calculateNormalizedAxes(momentsAxes: Axes3D): Axes3D;
    /**
     * Get the scale/length for each dimension for a box around the axes
     * to enclose the given positions
     */
    function calculateBoxAxes(positions: NumberArray, momentsAxes: Axes3D): Axes3D;
}
//# sourceMappingURL=principal-axes.d.ts.map