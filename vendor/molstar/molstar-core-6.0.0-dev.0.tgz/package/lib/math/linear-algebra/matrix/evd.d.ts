/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Paul Pillot <paul.pillot@tandemai.com>
 */
import { Matrix } from './matrix.js';
export declare namespace EVD {
    interface Cache {
        size: number;
        matrix: Matrix;
        eigenValues: number[];
        D: number[];
        E: number[];
    }
    function createCache(size: number): Cache;
    /**
     * Computes EVD and stores the result in the cache.
     */
    function compute(cache: Cache): void;
}
//# sourceMappingURL=evd.d.ts.map