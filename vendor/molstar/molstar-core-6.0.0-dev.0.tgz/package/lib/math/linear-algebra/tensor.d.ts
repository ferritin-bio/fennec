/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4 } from './3d/mat4.js';
import type { Vec3 } from './3d/vec3.js';
import type { Vec4 } from './3d/vec4.js';
import { Mat3 } from './3d/mat3.js';
export interface Tensor {
    data: Tensor.Data;
    space: Tensor.Space;
}
export declare namespace Tensor {
    type ArrayCtor = {
        new (size: number): ArrayLike<number>;
    };
    interface Data extends Array<number> {
        '@type': 'tensor';
    }
    interface Space {
        readonly rank: number;
        readonly dimensions: ReadonlyArray<number>;
        readonly axisOrderSlowToFast: ReadonlyArray<number>;
        create(array?: ArrayCtor): Tensor.Data;
        get(data: Tensor.Data, ...coords: number[]): number;
        set(data: Tensor.Data, ...coordsAndValue: number[]): number;
        add(data: Tensor.Data, ...coordsAndValue: number[]): number;
        dataOffset(...coords: number[]): number;
        getCoords(dataOffset: number, coords: {
            [i: number]: number;
        }): number[];
    }
    function create(space: Space, data: Data): Tensor;
    function Space(dimensions: number[], axisOrderSlowToFast: number[], ctor?: ArrayCtor): Space;
    /**
     * The strides of a space whose `get` and `dataOffset` are plain strided reads,
     * `dataOffset(c0, c1, …) === c0 * s[0] + c1 * s[1] + …` and `get(data, c0, c1, …) === data[dataOffset(c0, c1, …)]`,
     * for reading the data directly in hot loops; `undefined` for any other space, which must be read through its
     * accessors.
     *
     * Only a space made by `Space` has strides. They are keyed by the object, not a property, because spaces are copied
     * with their accessors overridden (`{ ...space, get }`: `createFloodfilled`, wrapped and periodic volumes), and a copied
     * property would make a direct read skip the override. A `get` or `dataOffset` replaced in place drops them too.
     */
    function strides(space: Space): ReadonlyArray<number> | undefined;
    function Data1(values: ArrayLike<number>): Data;
    function Vector(d: number, ctor?: ArrayCtor): Space;
    function ColumnMajorMatrix(rows: number, cols: number, ctor?: ArrayCtor): Space;
    function RowMajorMatrix(rows: number, cols: number, ctor?: ArrayCtor): Space;
    function toMat4(out: Mat4, space: Space, data: Tensor.Data): Mat4;
    function toMat3(out: Mat3, space: Space, data: Tensor.Data): Mat3;
    function toVec3(out: Vec3, space: Space, data: Tensor.Data): Vec3;
    function toVec4(out: Vec4, space: Space, data: Tensor.Data): Vec4;
    function areEqualExact(a: Tensor.Data, b: Tensor.Data): boolean;
    function invertAxisOrder(v: number[]): number[];
    function convertToCanonicalAxisIndicesFastToSlow(order: number[]): (xs: number[]) => number[];
    function convertToCanonicalAxisIndicesSlowToFast(order: number[]): (xs: number[]) => number[];
    /**
     * Floodfill from boundary voxels below the given threshold.
     * Only for rank-1, rank-2, and rank-3 tensors.
     */
    function floodfill(tensor: Tensor, threshold: number): Uint8Array;
    /**
     * Floodfill from boundary voxels below the given threshold.
     * Only for rank-1, rank-2, and rank-3 tensors.
     */
    function createFloodfilled(tensor: Tensor, threshold: number, mode: 'inside' | 'outside'): Tensor;
}
//# sourceMappingURL=tensor.d.ts.map