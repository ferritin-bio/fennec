/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export interface Histogram {
    min: number;
    max: number;
    binWidth: number;
    counts: Int32Array;
}
export interface HistogramRobustStats {
    /** Total voxel count contributing to the stats (after optional bin exclusion). */
    count: number;
    /** Minimum and maximum value over the contributing range. */
    min: number;
    max: number;
    /** Mean and population standard deviation, recomputed from bin centers. */
    mean: number;
    sigma: number;
    /** Approximate percentiles (linear interpolation across bin counts). */
    p1: number;
    p50: number;
    p95: number;
    p99: number;
}
export declare function calculateHistogram(data: ArrayLike<number>, binCount: number, options?: {
    min: number;
    max: number;
}): Histogram;
/**
 * Approximate `p`-th percentile (p in [0, 1]) of a histogram via linear
 * interpolation across the cumulative bin counts. Bin centers are used as
 * value samples. If `excludeBin` is provided, that bin is treated as having
 * zero counts (useful to ignore an explicit "background" bin, e.g. the bin
 * containing exact zeros for masked density maps).
 */
export declare function histogramPercentile(h: Histogram, p: number, excludeBin?: number): number;
/**
 * Compute robust summary statistics directly from a `Histogram`.
 * Mean and sigma are recomputed from bin centers so they stay consistent
 * with the percentiles when `ignoreZero` excludes the bin containing 0.
 *
 * Note: "robust" here means robust against a dominant zero/background bin,
 * not against outliers. The histogram is still binned across the full
 * `[min, max]` range, so a single extreme value coarsens every bin.
 */
export declare function histogramRobustStats(h: Histogram, opts?: {
    ignoreZero?: boolean;
}): HistogramRobustStats;
/**
 * Regroup a fine-grained histogram into a coarser one with `binCount` bins
 * over the same `[min, max]` range. Counts are preserved (each source bin is
 * mapped to a target bin by index), letting callers reuse an existing
 * histogram for display instead of re-scanning the source data. When
 * `binCount >= h.counts.length` the original histogram is returned unchanged.
 */
export declare function downsampleHistogram(h: Histogram, binCount: number): Histogram;
//# sourceMappingURL=histogram.d.ts.map