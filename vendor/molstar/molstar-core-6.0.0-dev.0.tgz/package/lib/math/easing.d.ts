/**
 * Copyright (c) 2018-26 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * adapted from https://github.com/d3/d3-ease
 */
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export declare function bounceIn(t: number): number;
export declare function bounceOut(t: number): number;
export declare function bounceInOut(t: number): number;
export declare function circleIn(t: number): number;
export declare function circleOut(t: number): number;
export declare function circleInOut(t: number): number;
export declare function cubicIn(t: number): number;
export declare function cubicOut(t: number): number;
export declare function cubicInOut(t: number): number;
export declare function expIn(t: number): number;
export declare function expOut(t: number): number;
export declare function expInOut(t: number): number;
export declare function quadIn(t: number): number;
export declare function quadOut(t: number): number;
export declare function quadInOut(t: number): number;
export declare function sinIn(t: number): number;
export declare function sinOut(t: number): number;
export declare function sinInOut(t: number): number;
export declare const EasingFunctions: {
    linear: (t: number) => number;
    'bounce-in': typeof bounceIn;
    'bounce-out': typeof bounceOut;
    'bounce-in-out': typeof bounceInOut;
    'circle-in': typeof circleIn;
    'circle-out': typeof circleOut;
    'circle-in-out': typeof circleInOut;
    'cubic-in': typeof cubicIn;
    'cubic-out': typeof cubicOut;
    'cubic-in-out': typeof cubicInOut;
    'exp-in': typeof expIn;
    'exp-out': typeof expOut;
    'exp-in-out': typeof expInOut;
    'quad-in': typeof quadIn;
    'quad-out': typeof quadOut;
    'quad-in-out': typeof quadInOut;
    'sin-in': typeof sinIn;
    'sin-out': typeof sinOut;
    'sin-in-out': typeof sinInOut;
};
export type EasingKind = keyof typeof EasingFunctions;
export type EasingFunction = EasingKind | ((t: number) => number);
export declare function getEasingFn(easing: EasingFunction | undefined): (t: number) => number;
export declare function EasingParamDefinition(defaultValue: EasingKind): PD.Select<EasingKind>;
//# sourceMappingURL=easing.d.ts.map