/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3 } from '../linear-algebra/3d/vec3.js';
interface ConvexHullResult {
    /** Triangle indices into the original positions array (length = numTriangles * 3) */
    indices: number[];
}
/**
 * Compute 3D convex hull of a set of points.
 * @param positions Array of Vec3 positions
 * @returns Triangle indices with outward-facing normals, or empty if degenerate
 */
export declare function convexHull(positions: ArrayLike<Vec3>): ConvexHullResult;
export {};
//# sourceMappingURL=convex-hull.d.ts.map