/**
 * Copyright (c) 2023 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { NumberArray } from '@molstar/core/util/type-helpers';
import type { Vec2 } from '../linear-algebra.js';
/** raycast along x-axis and apply even-odd rule */
export declare function pointInPolygon(point: Vec2, polygon: NumberArray, count: number): boolean;
/** raycast along x-axis and apply even-odd rule; accepts an array of [x, y] tuples */
export declare function pointInPolygon2D(px: number, py: number, polygon: readonly [number, number][]): boolean;
//# sourceMappingURL=polygon.d.ts.map