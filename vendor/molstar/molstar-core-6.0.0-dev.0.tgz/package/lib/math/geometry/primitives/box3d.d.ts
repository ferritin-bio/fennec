/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { PositionData } from '../common.js';
import { Sphere3D } from './sphere3d.js';
import { Vec3 } from '../../linear-algebra/3d/vec3.js';
import type { Mat4 } from '../../linear-algebra/3d/mat4.js';
interface Box3D {
    min: Vec3;
    max: Vec3;
}
declare function Box3D(): Box3D;
declare namespace Box3D {
    function create(min: Vec3, max: Vec3): Box3D;
    function zero(): Box3D;
    function copy(out: Box3D, a: Box3D): Box3D;
    function set(out: Box3D, min: Vec3, max: Vec3): Box3D;
    function setZero(out: Box3D): Box3D;
    function clone(a: Box3D): Box3D;
    /** Get box from sphere, uses extrema if available */
    function fromSphere3D(out: Box3D, sphere: Sphere3D): Box3D;
    function addVec3Array(out: Box3D, array: Vec3[]): Box3D;
    function fromVec3Array(out: Box3D, array: Vec3[]): Box3D;
    function addSphere3D(out: Box3D, sphere: Sphere3D): Box3D;
    function addBox3D(out: Box3D, box: Box3D): Box3D;
    function intersectsSphere3D(box: Box3D, sphere: Sphere3D): boolean;
    function computeBounding(data: PositionData): Box3D;
    /** Bounding box of the first `count` points of the interleaved xyz `array`; empty (`setEmpty`) if `count` is 0 */
    function fromPositionArray(out: Box3D, array: ArrayLike<number>, count: number): Box3D;
    /** Intersection of `a` and `b`, empty (`isEmpty`) if they do not overlap */
    function intersect(out: Box3D, a: Box3D, b: Box3D): Box3D;
    /** Whether the box holds no point: min > max (or NaN) on some axis, e.g. after `setEmpty` */
    function isEmpty(box: Box3D): boolean;
    /** Get size/extent of the box */
    function size(size: Vec3, box: Box3D): Vec3;
    /** Get volume of the box */
    function volume(box: Box3D): number;
    /** Sets min to Number.MAX_VALUE and max to -Number.MAX_VALUE */
    function setEmpty(box: Box3D): Box3D;
    /** Add point to box */
    function add(box: Box3D, point: Vec3): Box3D;
    /** Expand box by delta */
    function expand(out: Box3D, box: Box3D, delta: Vec3): Box3D;
    function expandUniformly(out: Box3D, box: Box3D, delta: number): Box3D;
    function scale(out: Box3D, box: Box3D, scale: number): Box3D;
    /** Transform box with a Mat4 */
    function transform(out: Box3D, box: Box3D, m: Mat4): Box3D;
    function containsVec3(box: Box3D, v: Vec3): boolean;
    function overlaps(a: Box3D, b: Box3D): boolean;
    function containsSphere3D(box: Box3D, s: Sphere3D): boolean;
    function center(out: Vec3, box: Box3D): Vec3;
    function exactEquals(a: Box3D, b: Box3D): boolean;
    function equals(a: Box3D, b: Box3D): boolean;
}
export { Box3D };
//# sourceMappingURL=box3d.d.ts.map