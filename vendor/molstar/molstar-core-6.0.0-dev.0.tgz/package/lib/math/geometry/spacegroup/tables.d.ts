/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4 } from '../../linear-algebra.js';
/**
 * The full spacegroup reference table: one entry per `syminfo.lib` setting
 * (540 total - all CCP4-numbered settings AND non-numbered axis/cell/origin
 * alternatives), built from `./syminfo`'s code-generated (compact tuple)
 * `RawSpacegroupData` (see `src/cli/syminfo` for how that's produced from
 * `data/sym/syminfo.lib`).
 */
export interface SpacegroupEntry {
    /** International Tables for Crystallography (ITA) spacegroup number (1-230), always present. */
    readonly itaNumber: number;
    /**
     * CCP4-style spacegroup number (mol*'s historical numbering, e.g. 1146,
     * 1003) - `0` for settings CCP4 doesn't assign a distinct number to
     * (most of `syminfo.lib`'s non-default axis/cell/origin descriptions).
     */
    readonly ccp4Number: number;
    /** Accepted Hermann-Mauguin name(s); index 0 is the canonical name. */
    readonly names: readonly string[];
    /**
     * Hall symbol for this exact setting. For entries with a non-zero
     * `ccp4Number` this is an independently-crafted symbol with no
     * change-of-basis suffix (so `operatorsFromHall` can parse it directly,
     * byte-identical to the pre-`syminfo.lib` table); for the rest it is
     * `syminfo.lib`'s own `symbol Hall` value verbatim, which may carry a
     * `(...)` comma-form change-of-basis suffix that `operatorsFromHall`
     * cannot parse - see `operatorsForEntry`, which handles both cases
     * transparently.
     */
    readonly hall: string;
    /**
     * ITA change-of-basis coordinate expression (`syminfo.lib`'s `basisop`)
     * relative to this ITA number's canonical (identity `'x,y,z'`) setting,
     * e.g. `'z,x,y'`, `'x-1/4,y-1/4,z-1/4'`, `'-y+z,x+z,-x+y+z'`.
     */
    readonly basisop: string;
}
export declare const SpacegroupData: readonly SpacegroupEntry[];
/** Maps a Hermann-Mauguin name (canonical or alias) to its `SpacegroupEntry`. */
export declare const SpacegroupEntryByName: ReadonlyMap<string, SpacegroupEntry>;
/** Maps a CCP4-style spacegroup number to its `SpacegroupEntry` (only the ~268 numbered settings). */
export declare const SpacegroupEntryByNumber: ReadonlyMap<number, SpacegroupEntry>;
/** Resolves a Hermann-Mauguin name or CCP4-style number to its `SpacegroupEntry`, or `undefined` if unknown. */
export declare function findSpacegroupEntry(nameOrNumber: number | string): SpacegroupEntry | undefined;
/** Maps a Hermann-Mauguin name (canonical or alias) to its spacegroup number. */
export declare const SpacegroupNameToNumberMap: {
    [name: string]: number;
};
/** Maps a CCP4-style spacegroup number to its canonical Hermann-Mauguin name. */
export declare const SpacegroupName: {
    [num: number]: string;
};
/**
 * Returns the spacegroup number for a name or number - `-1` if unknown.
 * Numeric input is only resolved against the ~268 CCP4-style numbers (exact
 * match, same as before this table gained the extra `syminfo.lib` settings).
 * A NAME may resolve to a setting without its own CCP4-style number, in
 * which case its ITA number is returned instead (not unique across the
 * several such alternate settings that can share one ITA number, but a
 * strictly more useful result than "unknown").
 */
export declare function getSpacegroupNumber(nameOrNumber: number | string): number;
/**
 * Returns the Hall symbol for a CCP4-style spacegroup number (e.g. 1146), or
 * `undefined` if the number is unknown. Together with `operatorsFromHall`
 * this generates the full operator set from the symbol alone - but only for
 * the ~268 CCP4-numbered settings; use `operatorsForEntry` for any
 * `SpacegroupEntry`, numbered or not.
 */
export declare function getHallSymbol(spacegroupNumber: number): string | undefined;
/**
 * Order of the point group (crystal class) an ITA spacegroup number belongs
 * to, i.e. the number of distinct rotation parts among its operators.
 */
export declare function pointGroupOrder(itaNumber: number): number;
/**
 * Number of symmetry operators of an entry (the multiplicity of the general
 * position) - its point group order times its lattice centering count. Both
 * are table lookups, so unlike `operatorsForEntry(entry).length` this builds
 * no matrices.
 */
export declare function orderForEntry(entry: SpacegroupEntry): number;
/**
 * Resolves the full operator set for any `SpacegroupEntry`, numbered or not.
 * For entries with a directly-parseable Hall symbol (true for all
 * CCP4-numbered entries, since their Hall symbols are independently crafted
 * to avoid a change-of-basis suffix) this is just `operatorsFromHall(entry.hall)`.
 * Otherwise (most non-numbered `syminfo.lib` settings), operators are derived
 * by finding a sibling setting (same `itaNumber`) with a resolvable Hall
 * symbol, "undoing" that sibling's own `basisop` to get back to the common
 * canonical frame, then re-applying this entry's own `basisop`. Memoized per
 * entry (entries are stable singleton objects from `SpacegroupData`).
 */
export declare function operatorsForEntry(entry: SpacegroupEntry): ReadonlyArray<Mat4>;
//# sourceMappingURL=tables.d.ts.map