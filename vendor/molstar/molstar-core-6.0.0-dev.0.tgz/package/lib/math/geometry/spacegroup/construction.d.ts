/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3, Mat4 } from '../../linear-algebra.js';
import { SymmetryOperator } from '../symmetry-operator.js';
import { Cell } from './cell.js';
interface SpacegroupCell extends Cell {
    /** Hermann-Mauguin spacegroup name (uniquely identifies the spacegroup) */
    readonly name: string;
}
interface Spacegroup {
    /** Hermann-Mauguin spacegroup name */
    readonly name: string;
    /**
     * Spacegroup number - the CCP4-style number (e.g. 1146) when the
     * resolved setting has one, else its plain ITA number as a fallback
     * (not unique across the several non-CCP4-numbered settings that can
     * share one ITA number - see `SpacegroupEntry` in `./tables`).
     */
    readonly num: number;
    readonly cell: SpacegroupCell;
    /**
     * ITA change-of-basis coordinate expression relative to the canonical
     * (identity `'x,y,z'`) description, in the same xyz-style `basisop`
     * notation as `SpacegroupEntry.basisop` (e.g. `'x,y,z'`, `'z,x,y'`,
     * `'x-1/4,y-1/4,z-1/4'`, `'y,x,-z'`, `'x+y,-x+y,z'` - see
     * `./common`/`./notation`). Used by `createWithSetting` callers such as
     * MOL2 CRYSIN as well as by `Spacegroup.create`.
     */
    readonly basisop: string;
    readonly operators: ReadonlyArray<Mat4>;
}
declare namespace SpacegroupCell {
    /** Create a 'P 1' with cellsize [1, 1, 1] */
    const Zero: SpacegroupCell;
    /** True if the cell is a `SpacegroupCell` */
    function is(cell: Cell): cell is SpacegroupCell;
    /** True if 'P 1' with cellsize [1, 1, 1] */
    function isZero(cell?: SpacegroupCell): boolean;
    /** Returns Zero cell if the spacegroup does not exist */
    function create(nameOrNumber: number | string, size: Vec3, anglesInRadians: Vec3): SpacegroupCell;
    function getLabel(cell: SpacegroupCell): string;
}
declare namespace Spacegroup {
    /** P1 with [1, 1, 1] cell */
    const ZeroP1: Spacegroup;
    function create(cell: SpacegroupCell): Spacegroup;
    /**
     * Assembles a `Spacegroup` from an already-computed operator list for a
     * non-default axis setting/description, given its xyz-style `basisop`
     * change-of-basis coordinate expression (e.g. `'y,x,-z'` or
     * `'x+y,-x+y,z'` - see the `Spacegroup.basisop` field). `num` is derived
     * from `cell.name` exactly as in `create`. This is intentionally
     * agnostic of any particular file format's own setting-numbering scheme
     * - callers that need to resolve such a scheme (e.g. MOL2 CRYSIN) into
     * `name` + `basisop` + `operators` should do so themselves and pass the
     * result here.
     */
    function createWithSetting(cell: SpacegroupCell, name: string, basisop: string, operators: ReadonlyArray<Mat4>): Spacegroup;
    function setOperatorMatrix(spacegroup: Spacegroup, index: number, i: number, j: number, k: number, target: Mat4): Mat4;
    function getSymmetryOperator(spacegroup: Spacegroup, spgrOp: number, i: number, j: number, k: number): SymmetryOperator;
    /**
     * Get Symmetry operator for transformation around the given
     * reference point `ref` in fractional coordinates
     */
    function getSymmetryOperatorRef(spacegroup: Spacegroup, spgrOp: number, i: number, j: number, k: number, ref: Vec3): SymmetryOperator;
    function getOperatorXyz(op: Mat4): string;
}
export { Spacegroup, SpacegroupCell };
//# sourceMappingURL=construction.d.ts.map