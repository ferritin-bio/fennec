/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4, Vec3 } from '../../linear-algebra.js';
export { Cell };
interface Cell {
    readonly size: Vec3;
    readonly anglesInRadians: Vec3;
    readonly volume: number;
    /** Number of symmetry operators of the spacegroup the cell belongs to, 1 for a plain box */
    readonly order: number;
    /** Transfrom cartesian -> fractional coordinates within the cell */
    readonly toFractional: Mat4;
    /** Transfrom fractional coordinates within the cell -> cartesian */
    readonly fromFractional: Mat4;
}
declare function Cell(): Cell;
declare namespace Cell {
    function create(size: Vec3, anglesInRadians: Vec3, order?: number): Cell;
    function empty(): Cell;
    function fromBasis(x: Vec3, y: Vec3, z: Vec3): Cell;
    /** Human readable dimensions and angles, prefixed by `title` */
    function getLabel(cell: Cell, title?: string): string;
}
//# sourceMappingURL=cell.d.ts.map