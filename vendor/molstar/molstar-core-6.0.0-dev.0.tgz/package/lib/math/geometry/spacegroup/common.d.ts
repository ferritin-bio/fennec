/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Mat4 } from '../../linear-algebra.js';
/**
 * Wraps a fractional coordinate into the `[0, 1)` interval, snapping to the
 * nearest 1/12th to avoid floating-point drift accumulating (crystallographic
 * translations are always simple fractions like 1/2, 1/3, 1/4, 1/6).
 */
export declare function wrap01(x: number): number;
/**
 * Applies a change-of-basis (conjugation `P⁻¹ · W · P`) to a set of
 * symmetry operators, re-expressing them in the new basis described by `P`
 * (whose columns are the new basis vectors expressed in the old basis).
 * Works for any invertible `P`, including non-unimodular ones (e.g. the
 * tetragonal centering transform, determinant 2).
 */
export declare function transformOperators(operators: ReadonlyArray<Mat4>, P: Mat4): Mat4[];
/**
 * Builds a fractional-space Seitz operator (`Mat4`) from a 3x3 rotation given
 * as rows together with a translation vector.
 */
export declare function seitz(rot: ReadonlyArray<ReadonlyArray<number>>, tran: ReadonlyArray<number>): Mat4;
/**
 * Parses a CCP4/ITA `basisop`-style affine coordinate triplet (e.g.
 * `'x,y,z'`, `'-x+1/2,y,-z+1/2'`, `'z,x,y'`) into a fractional-space `Mat4`.
 * Coefficients of `x`/`y`/`z` are always ±1 in this notation.
 */
export declare function coordinateExpressionToOperator(triplet: string): Mat4;
/**
 * Closes a set of generator operators into the full group by repeated
 * multiplication (orbit of the identity), wrapping translations into `[0, 1)`
 * at 1/24 resolution. Throws if the group exceeds `maxOrder` (which indicates
 * bad or inconsistent generators).
 */
export declare function closeGroup(generators: ReadonlyArray<Mat4>, maxOrder?: number): Mat4[];
/**
 * A standard ITA axis-permutation change-of-basis: `basisop` is the
 * xyz-style affine coordinate expression (same notation as
 * `SpacegroupEntry.basisop` in `./tables`, e.g. `'y,x,-z'`) and `matrix` is
 * the corresponding change-of-basis `Mat4` (derived from `basisop` via
 * `coordinateExpressionToOperator`).
 */
export interface AxisPermutation {
    readonly basisop: string;
    readonly matrix: Mat4;
}
/**
 * The six standard axis settings of the monoclinic and orthorhombic space
 * groups (ITfC Vol. A Table 1.5.4.4), expressed as xyz-style `basisop`
 * coordinate expressions rather than the classic basis-vector notation
 * (`'abc'`, `'ba-c'`, ...) - e.g. `'y,x,-z'` is the `'ba-c'` setting. A
 * non-default axis setting's symmetry operators are obtained by conjugating
 * the canonical (setting `'x,y,z'`) operators with the matching `matrix`
 * (see `createWithSetting` + `transformOperators`) - this is standard ITA
 * data, independent of any particular file format's setting-numbering
 * convention.
 */
export declare const AxisPermutations: readonly AxisPermutation[];
/**
 * Standard ITA change-of-basis `basisop` for the doubled-cell "C"/"F"
 * description of a primitive tetragonal lattice (det = 2): `'x+y,-x+y,z'`
 * (a general linear combination, not a pure axis permutation - so it isn't
 * one of the six `AxisPermutations` entries).
 */
export declare const TetragonalCenteringBasisop = "x+y,-x+y,z";
/** Doubled-cell "C"/"F"-centered description of a primitive tetragonal group (setting 2 only). */
export declare function transformTetragonalCentering(baseOperators: ReadonlyArray<Mat4>): Mat4[];
//# sourceMappingURL=common.d.ts.map