/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { type ReadonlyMat4 } from '../../linear-algebra/3d/mat4.js';
import { Vec3 } from '../../linear-algebra/3d/vec3.js';
/** Lattice-centering translation vectors for a lattice letter (P/A/B/C/I/R/F). */
export declare function centringVectors(letter: string): Vec3[];
/**
 * Generates the full set of symmetry operators (as fractional `Mat4`) for a
 * Hall space-group symbol, e.g. `"-P 2ac 2ab"` or `"P 31 2 (0 0 4)"`. The
 * operators are derived purely from the symbol - no per-space-group operator
 * table is consulted. Results are memoized per symbol; callers must treat the
 * returned array (and its matrices) as read-only.
 */
export declare function operatorsFromHall(hall: string): ReadonlyArray<ReadonlyMat4>;
/**
 * `true` if a `symbol Hall` string carries a long-form (comma-separated)
 * change-of-basis suffix, e.g. `'P 2y (z,x,y)'` - which `operatorsFromHall`
 * cannot parse (only the short numeric-shift form, e.g.
 * `'P 31 2 (0 0 4)'`, is supported).
 */
export declare function hasLongFormChangeOfBasis(hall: string): boolean;
//# sourceMappingURL=notation.d.ts.map