/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { Vec3 } from '../linear-algebra/3d/vec3.js';
import { CentroidHelper } from './centroid-helper.js';
import { Sphere3D } from './primitives/sphere3d.js';
import { Box3D } from './primitives/box3d.js';
export declare class BoundaryHelper {
    private readonly dir;
    private readonly dirLength;
    private minDist;
    private maxDist;
    private extrema;
    centroidHelper: CentroidHelper;
    private computeExtrema;
    private computeSphereExtrema;
    includeSphere(s: Sphere3D): void;
    includePosition(p: Vec3): void;
    includePositionRadius(center: Vec3, radius: number): void;
    finishedIncludeStep(): void;
    private refineExtrema;
    radiusSphere(s: Sphere3D): void;
    radiusPosition(p: Vec3): void;
    radiusPositionRadius(center: Vec3, radius: number): void;
    getSphere(sphere?: Sphere3D): Sphere3D;
    getBox(box?: Box3D): Box3D;
    reset(): void;
    constructor(quality: EposQuality);
}
type EposQuality = '6' | '14' | '26' | '98';
export {};
//# sourceMappingURL=boundary-helper.d.ts.map