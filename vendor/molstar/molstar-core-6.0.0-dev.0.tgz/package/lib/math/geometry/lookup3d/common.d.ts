/**
 * Copyright (c) 2018-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Box3D } from '../primitives/box3d.js';
import type { Sphere3D } from '../primitives/sphere3d.js';
export interface Result<T> {
    count: number;
    indices: T[];
    squaredDistances: number[];
}
export declare namespace Result {
    function add<T>(result: Result<T>, index: T, distSq: number): void;
    function reset(result: Result<any>): void;
    function create<T = number>(): Result<T>;
    function copy<T = number>(out: Result<T>, result: Result<T>): Result<T>;
}
export interface Lookup3D<T = number> {
    find(x: number, y: number, z: number, radius: number, result?: Result<T>): Result<T>;
    nearest(x: number, y: number, z: number, k: number, stopIf?: Function, result?: Result<T>): Result<T>;
    check(x: number, y: number, z: number, radius: number): boolean;
    approxNearest(x: number, y: number, z: number, radius: number, result?: Result<T>): Result<T>;
    readonly boundary: {
        readonly box: Box3D;
        readonly sphere: Sphere3D;
    };
    /** transient result */
    readonly result: Result<T>;
}
//# sourceMappingURL=common.d.ts.map