/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import type { RuntimeContext } from '@molstar/core/task';
import { type PositionData, type DensityData } from './common.js';
import { type Boundary } from './boundary.js';
export declare const DefaultBlobSurfaceProps: {
    blobSize: number;
    method: 'grid' | 'clustering';
    clusterIterations: number;
    shape: 'ellipsoid' | 'sh';
    shDegree: number;
    shRegularization: number;
    resolution: number;
    radiusOffset: number;
    smoothness: number;
};
export type BlobSurfaceProps = typeof DefaultBlobSurfaceProps;
export type BlobSurfaceData = {
    radiusFactor: number;
} & DensityData;
/**
 * Estimates the density of the atom point cloud with a small number of ellipsoid "blobs"
 * (`fitBlobs`), then accumulates their union directly into a dense grid. The grid box is the
 * TIGHT union of each individual blob's own padded extent (`center ± pad`, not the atoms'
 * bounding box expanded uniformly by the single largest blob) - this avoids one big/outlier blob
 * forcing wasted padding across the entire box, which matters most for sparse/spread-out
 * structures (elongated chains, multi-domain assemblies) where most of the atoms' own bounding
 * box is otherwise empty space between blobs. `resolution` (grid cell size) is left entirely to
 * the caller - unlike `blobSize`, it's not auto-derived here, so callers that want a smooth
 * high-resolution mesh over big blobs can still ask for one; keeping the box tight is what keeps
 * that affordable instead of also depending on a coarse resolution to avoid blowing up cell count.
 */
export declare function computeBlobSurface(ctx: RuntimeContext, position: PositionData, boundary: Boundary, radius: (index: number) => number, props: BlobSurfaceProps): Promise<BlobSurfaceData>;
//# sourceMappingURL=blob-surface.d.ts.map