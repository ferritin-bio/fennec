/**
 * Copyright (c) 2018-2022 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Box3D, DensityData } from '../geometry.js';
import type { PositionData } from './common.js';
import { Task } from '@molstar/core/task/task';
export declare const DefaultGaussianDensityProps: {
    resolution: number;
    radiusOffset: number;
    smoothness: number;
};
export type GaussianDensityProps = typeof DefaultGaussianDensityProps;
export type GaussianDensityData = {
    radiusFactor: number;
} & DensityData;
export declare function computeGaussianDensity(position: PositionData, box: Box3D, radius: (index: number) => number, props: GaussianDensityProps): Task<GaussianDensityData>;
//# sourceMappingURL=gaussian-density.d.ts.map