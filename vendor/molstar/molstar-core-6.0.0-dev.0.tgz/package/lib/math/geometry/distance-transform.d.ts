/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Tadej Satler <tadej.satler@gmail.com>
 */
import type { NumberArray } from '@molstar/core/util/type-helpers';
/**
 * 2D Euclidean distance transform by Felzenszwalb & Huttenlocher https://cs.brown.edu/~pff/papers/dt-final.pdf
 */
export declare function edt(data: NumberArray, width: number, height: number, f: NumberArray, d: NumberArray, v: NumberArray, z: NumberArray): void;
/**
 * Squared 3D Euclidean distance from every cell to the nearest cell with `inside[i] !== 0`,
 * in grid units (Felzenszwalb & Huttenlocher, one separable pass per axis). `inside` is in
 * x-fastest order (`x + y * nx + z * nx * ny`). Cells inside get 0; if nothing is inside,
 * all values are `>= 1e20`.
 */
export declare function squaredDistanceTransform3D(inside: ArrayLike<number>, nx: number, ny: number, nz: number, out?: Float32Array): Float32Array;
//# sourceMappingURL=distance-transform.d.ts.map