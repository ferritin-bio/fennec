/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Ludovic Autin <autin@scripps.edu>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * Self-contained real spherical-harmonics utilities: associated Legendre
 * polynomials, the real SH basis Y_l^m, least-squares fitting of a radial
 * function r(theta, phi) and reconstruction from the fitted coefficients.
 *
 * The math is implemented from scratch; only Mol*'s generic dense `svd`
 * (mol-math/linear-algebra/matrix) is reused for the least-squares solve.
 *
 * Coefficient/basis ordering is flat by (l, m): index(l, m) = l*l + l + m,
 * so an expansion up to degree L has (L + 1)^2 terms.
 */
/** Number of (l, m) terms for an expansion up to (and including) degree L. */
export declare function shTermCount(L: number): number;
/** Flat index of the (l, m) term, m in [-l, l]. */
export declare function shIndex(l: number, m: number): number;
/**
 * Associated Legendre polynomials P_l^m(x), m >= 0, computed with the standard
 * stable recurrences. Results are written into `out` indexed by `legendreIndex`.
 * `x` is expected in [-1, 1] (typically cos(theta)).
 */
export declare function assocLegendre(L: number, x: number, out?: Float64Array): Float64Array;
export declare function getNormFactors(L: number): Float64Array;
/**
 * Evaluate the real SH basis Y_l^m(theta, phi) for all 0 <= l <= L, -l <= m <= l.
 * `cosTheta` is the cosine of the polar angle, in [-1, 1]; phi the azimuth [-pi, pi].
 * The polar angle is taken as its cosine rather than the angle itself because that is the only
 * form the associated Legendre recurrences need - callers invariably have it directly (`z / r`
 * for a direction, or a uniform table axis), so going through `acos` here and `cos` back again
 * would cost two transcendentals per call to recover a value that was already exact.
 * Results are written into `out` (length shTermCount(L)).
 *
 * Real form:
 *   m > 0:  sqrt(2) K_l^m cos(m phi) P_l^m(cos theta)
 *   m = 0:  K_l^0 P_l^0(cos theta)
 *   m < 0:  sqrt(2) K_l^|m| sin(|m| phi) P_l^|m|(cos theta)
 */
export declare function realSph(L: number, cosTheta: number, phi: number, out: Float64Array, legendreScratch: Float64Array, norm: Float64Array): Float64Array;
/**
 * Spherical coordinates of a point relative to a center. The polar angle is kept as its cosine
 * (`z / r`, clamped) rather than the angle: that is the form `realSph` consumes, and it is exact
 * and free here, whereas the angle would cost an `acos` only for the callee to undo it.
 */
export interface SphericalCoord {
    r: number;
    cosTheta: number;
    phi: number;
}
export declare function toSpherical(x: number, y: number, z: number, out?: SphericalCoord): SphericalCoord;
export interface SphericalHarmonicFit {
    /** Fitted coefficients, length shTermCount(L). */
    coeffs: Float64Array;
    L: number;
    /** Largest observed sample radius about the center; used to clamp reconstruction overshoot. */
    rMax: number;
}
/**
 * Least-squares fit of the radial function r(theta, phi) of `points` (flat xyz
 * array) about `center` to a real spherical-harmonic expansion up to degree L.
 *
 * Builds the symmetric normal-equations system A = B^T B (size K x K,
 * K = (L+1)^2) and rhs = B^T r without materializing the full design matrix,
 * then solves via a truncated SVD pseudo-inverse for stability.
 *
 * `maxPoints` caps the number of samples used for fitting (stride subsampling)
 * to keep high-L fits affordable; reconstruction quality is unaffected.
 *
 * `regularization` adds a scale-invariant Tikhonov term to the normal-equations
 * diagonal with per-band `l(l+1)` damping (a smoothness prior). It is the main
 * defense against the ill-conditioned, exploding fits that arise from sparse or
 * clustered samples (e.g. trace-only or low-resolution clouds): high-degree bands
 * are penalized so an under-determined system relaxes toward the mean-radius
 * sphere instead of diverging. 0 disables it.
 */
export declare function fitSphericalHarmonics(points: ArrayLike<number>, center: ArrayLike<number>, L: number, maxPoints?: number, regularization?: number): SphericalHarmonicFit;
/** Reconstruct the radius from fitted coefficients at the given direction. `norm` can be a
 * precomputed `getNormFactors(L)` result, saving a lookup when called repeatedly for the same
 * `L` (e.g. once per grid voxel while reconstructing a blob's surface). */
export declare function reconstructRadius(coeffs: ArrayLike<number>, L: number, cosTheta: number, phi: number, basisScratch: Float64Array, legendreScratch: Float64Array, norm: Float64Array): number;
/** One star-shaped lobe: a radial SH expansion about its own center. */
export interface SphericalHarmonicLobe {
    center: number[];
    coeffs: Float64Array;
    rMax: number;
}
export interface SphericalHarmonicLobesFit {
    lobes: SphericalHarmonicLobe[];
    L: number;
}
/**
 * A bilinear-interpolatable lookup table of `R(theta, phi)` over a uniform `(nTheta+1) x nPhi`
 * grid spanning `theta` in `[0, pi]` (both poles included) and `phi` in `[-pi, pi)` (wrapping).
 *
 * Rows are uniform in `theta`, NOT in `cos(theta)`, even though that would let callers (which hold
 * a direction, i.e. `z / r`) skip an `acos`: every `m != 0` band carries `sin^|m|(theta) =
 * (1 - cos^2 theta)^(|m|/2)`, which has a square-root branch point at the poles, so `R` is analytic
 * in `theta` but not smooth in `cos(theta)`. Interpolating in `cos(theta)` costs ~20x the error
 * within `|cos theta| > 0.8` at equal table size, and converges too slowly in `nTheta` to buy back.
 */
export interface RadiusLUT {
    nTheta: number;
    nPhi: number;
    values: Float64Array;
}
/**
 * Precomputes a `RadiusLUT` for the fitted radial boundary `R(theta, phi) = sum coeffs[k] *
 * Y_k(theta, phi)`.
 *
 * ALGORITHMIC MOTIVATION: evaluating `R` directly (`reconstructRadius`) costs O(L^2) per call (a
 * fresh associated-Legendre table plus O(L) trig recurrence, since both depend on the specific
 * direction). Caching a scalar or a few intermediate values does not help when `R` must be
 * evaluated at a very large number of DIFFERENT directions - which is exactly what
 * `computeBlobSurface`'s marching-cubes splat loop does, calling it once per grid voxel within a
 * blob's padded box (easily thousands to millions of directions for one blob). Building this
 * table ONCE per blob - a fixed O(tableSize * L^2) cost, independent of how many voxels will
 * query it - and then looking values up via `sampleRadiusLUT` (O(1): 4 array reads + a bilinear
 * blend, no trigonometry or Legendre recursion at all) changes the TOTAL complexity of
 * reconstructing one blob's surface from O(voxels * L^2) to O(tableSize * L^2 + voxels), which is
 * a genuine asymptotic win whenever (as is typical) voxels >> tableSize.
 *
 * `minR`/`maxR` clamp each table entry once at build time (rather than after every lookup).
 * `out`, if given and the right size, has its `values` array reused instead of reallocating -
 * useful when rebuilding the table once per blob but the table dimensions (which only depend on
 * the shared `shDegree` prop, not on any individual blob) stay constant across all of them.
 */
export declare function buildRadiusLUT(coeffs: ArrayLike<number>, L: number, nTheta: number, nPhi: number, minR?: number, maxR?: number, out?: RadiusLUT): RadiusLUT;
/**
 * Bilinearly samples a `RadiusLUT` (built by `buildRadiusLUT`) at the given direction - O(1): 4
 * array reads plus a bilinear blend, no trigonometry or Legendre recursion.
 */
export declare function sampleRadiusLUT(lut: RadiusLUT, theta: number, phi: number): number;
//# sourceMappingURL=spherical-harmonics.d.ts.map