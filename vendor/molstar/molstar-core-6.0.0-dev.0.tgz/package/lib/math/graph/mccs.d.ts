/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */
import { IntAdjacencyGraph } from './int-adjacency-graph.js';
export { Mccs };
/**
 * Maximum common connected subgraph (MCCS) matching between two graphs.
 *
 * Builds the modular-product (compatibility) graph and enumerates its connected cliques (Koch's
 * connected-clique variant of Bron-Kerbosch): product vertices are compatible vertex pairs
 * (`a` in graph A, `b` in graph B); two product vertices are joined by a "c-edge" when the
 * underlying vertices are adjacent in both graphs with compatible edges, or by a "d-edge" when they
 * are non-adjacent in both with similar topological distance. A clique connected via c-edges is a
 * common *connected* subgraph, and the maximum such clique is the MCCS. The vertex/edge
 * compatibility predicates are supplied by the caller, so the routine is domain-agnostic.
 */
declare namespace Mccs {
    interface Options {
        /** Whether vertex `a` of graph A may be paired with vertex `b` of graph B. */
        vertexTest: (a: number, b: number) => boolean;
        /** Whether edge `edgeA` of A may be paired with edge `edgeB` of B (indices into the graphs' edge arrays). */
        edgeTest: (edgeA: number, edgeB: number) => boolean;
        /**
         * Topological-distance tolerance for "d-edges" (vertex pairs non-adjacent in both graphs).
         * These are required for the clique formulation to represent non-complete subgraphs (e.g.
         * rings), so the default is 1: two non-adjacent pairs may be matched iff their shortest-path
         * distances differ by at most this much. Higher values allow more topological stretch; 0
         * disables d-edges (only complete-subgraph matches survive, rarely useful).
         */
        pathCutoff: number;
        /** Wall-clock budget; the search returns the best cliques found so far once exceeded. */
        maxTimeMs: number;
        /** Hard backstop on recursion steps. */
        maxIterations: number;
        /** Discard cliques smaller than this. */
        minMatchedVertices: number;
        /** Number of equally-sized maximum cliques to retain. */
        maxCliques: number;
    }
    const DefaultOptions: Options;
    /** Optional out-parameter reporting whether the search hit its time/iteration budget. */
    interface Status {
        truncated: boolean;
    }
    /**
     * Enumerate the maximum-size common-connected-subgraph correspondences between `a` and `b`.
     * Several equally sized candidates may be returned when the maximum is symmetry-degenerate; each
     * is a list of `[vertexA, vertexB]` pairs sorted by `vertexA`. Empty if nothing meets
     * `minMatchedVertices`.
     *
     * Best-effort: the search stops at `maxTimeMs`/`maxIterations` and returns the best cliques found
     * so far. Pass `status` to learn whether that budget was hit (`status.truncated`).
     */
    function find(a: IntAdjacencyGraph<any, any>, b: IntAdjacencyGraph<any, any>, options?: Partial<Options>, status?: Status): Array<Array<[number, number]>>;
}
//# sourceMappingURL=mccs.d.ts.map