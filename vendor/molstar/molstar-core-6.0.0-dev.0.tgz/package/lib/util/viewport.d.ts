/**
 * Copyright (c) 2018-2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Vec4 } from '@molstar/core/math/linear-algebra/3d/vec4';
export { Viewport };
/** A rectangle in window pixels with a top-left origin (y down), as in the browser (CSS, pointer events, `ImageData`) */
type Viewport = {
    x: number;
    y: number;
    width: number;
    height: number;
};
declare function Viewport(): Viewport;
declare namespace Viewport {
    function zero(): Viewport;
    function create(x: number, y: number, width: number, height: number): Viewport;
    function clone(viewport: Viewport): Viewport;
    function copy(target: Viewport, source: Viewport): Viewport;
    function set(viewport: Viewport, x: number, y: number, width: number, height: number): Viewport;
    function toVec4(v4: Vec4, viewport: Viewport): Vec4;
    function equals(a: Viewport, b: Viewport): boolean;
}
//# sourceMappingURL=viewport.d.ts.map