/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
/** Scratch buffers which grew beyond this many entries (1 MB of 32-bit integers) are dropped after use, so that one huge call does not pin memory forever. */
export declare const MaxRetainedBufferCapacity: number;
/** The scratch memory which code keeps between calls to avoid allocating (module level buffers): it is small after each call, and
 * `ScratchMemory.release(...contexts)` frees what the contexts kept (e.g. after loading a large file, when it is not needed for a while).
 * A context is the name of what uses the memory, e.g. `'schema-selection'`, the resolution of the rows of `StructureElement.Schema`. */
export declare const ScratchMemory: {
    /** Register a function which frees some scratch memory of a context (called by `release`). Return a function which unregisters it. */
    register(context: string, release: () => void): () => void;
    /** Free the scratch memory of the contexts, or of every context if there are none. It is allocated again when it is needed. */
    release(...contexts: string[]): void;
};
/** Growable buffer of 32-bit integers with an explicit element count, for reuse across calls.
 *
 * (Reusing `array.length = 0` does not work for this: V8 releases the backing store when an array is truncated, so
 * every refill allocates again. A buffer which only resets its counter keeps its capacity.) */
export declare class IntBuffer {
    data: Int32Array;
    n: number;
    constructor(capacity?: number);
    clear(): void;
    /** Make sure `capacity` values fit without growing (keeps the current contents). */
    ensureCapacity(capacity: number): void;
    push(value: number): void;
    /** The filled part as a typed array view (shares memory with the buffer, valid until the buffer is modified). */
    view(): Int32Array;
    /** Free the memory if the capacity grew above `limit` (so one huge call does not pin memory forever). */
    trim(limit: number): void;
}
//# sourceMappingURL=int-buffer.d.ts.map