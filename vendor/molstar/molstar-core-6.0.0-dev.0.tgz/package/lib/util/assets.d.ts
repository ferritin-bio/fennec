/**
 * Copyright (c) 2020-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { UUID } from './uuid.js';
import { type DataType, type DataResponse } from './data-source.js';
import { Task } from '@molstar/core/task';
export { AssetManager, Asset };
type _File = File;
type Asset = Asset.Url | Asset.File;
declare namespace Asset {
    type Url = {
        kind: 'url';
        id: UUID;
        url: string;
        title?: string;
        body?: string;
        headers?: Record<string, string>;
    };
    type File = {
        kind: 'file';
        id: UUID;
        name: string;
        file?: _File;
    };
    function Url(url: string, options?: {
        body?: string;
        title?: string;
        headers?: Record<string, string>;
    }): Url;
    function File(file: _File): File;
    function isUrl(x?: Asset): x is Url;
    function isFile(x?: Asset): x is File;
    interface Wrapper<T extends DataType = DataType> {
        readonly data: DataResponse<T>;
        dispose: () => void;
    }
    function Wrapper<T extends DataType = DataType>(data: DataResponse<T>, asset: Asset, manager: AssetManager): {
        data: DataResponse<T>;
        dispose: () => void;
    };
    function getUrl(url: string | Url): string;
    function getUrlAsset(manager: AssetManager, url: string | Url, body?: string, headers?: Record<string, string>): Url;
}
/**
 * Holds assets (URL downloads and files) and their bytes, ref-counted: `resolve` takes a reference and
 * `Asset.Wrapper.dispose` (`release`) gives it back.
 *
 * URL assets read through a URL-keyed, ref-counted byte cache (`urlCacheKey`): the first `resolve` of a URL downloads,
 * later ones (another `Asset.Url` of the same URL and headers, or the same one) are served from the held bytes, and
 * concurrent ones share the download in flight, so a URL is fetched once whoever asks first. The bytes live while any
 * asset that resolved to them is held and are dropped with the last one.
 *
 * - A failed download is not cached, the next `resolve` fetches again. The waiters of that download get its error.
 * - An aborted download (its requester was aborted) does not fail the waiters: they that are still interested retry,
 *   one of them becoming the downloader. A waiter itself notices its own abort when its task next updates.
 * - `resolve(asset, type, false)` (`store` off) and requests with a body bypass the cache.
 */
declare class AssetManager {
    private _assets;
    private _urlCache;
    get assets(): {
        asset: Asset;
        file: File;
        refCount: number;
        isStatic?: boolean;
        tag?: string;
        cacheKey?: string;
    }[];
    /** The number of URLs the byte cache holds or is downloading. */
    get urlCacheSize(): number;
    tryFindUrl(url: string, body?: string, headers?: Record<string, string>): Asset.Url | undefined;
    tryFindFilename(name: string): Asset | undefined;
    set(asset: Asset, file: File, options?: {
        isStatic?: boolean;
        tag?: string;
    }): void;
    get(asset: Asset): {
        asset: Asset;
        file: File;
        refCount: number;
        isStatic?: boolean;
        tag?: string;
        cacheKey?: string;
    } | undefined;
    delete(asset: Asset): boolean;
    has(asset: Asset): boolean;
    resolve<T extends DataType>(asset: Asset, type: T, store?: boolean): Task<Asset.Wrapper<T>>;
    release(asset: Asset): void;
    clearTag(tag: string): void;
    clear(): void;
    dispose(): void;
    /** Deletes an asset entry and gives back its hold of the byte cache. */
    private _remove;
    private _releaseUrl;
    /** A hit, the download in flight, or a new download; returns an entry with `file` and one hold taken for the caller. */
    private _acquireUrl;
    private _download;
    private _isAborted;
}
//# sourceMappingURL=assets.d.ts.map