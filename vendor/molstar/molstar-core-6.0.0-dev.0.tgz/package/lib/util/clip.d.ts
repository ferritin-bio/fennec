/**
 * Copyright (c) 2021-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Gianluca Tomasello <giagitom@gmail.com>
 */
import { Mat4 } from '@molstar/core/math/linear-algebra/3d/mat4';
import { Vec3 } from '@molstar/core/math/linear-algebra/3d/vec3';
import { Plane3D } from '@molstar/core/math/geometry/primitives/plane3d';
import { Sphere3D } from '@molstar/core/math/geometry/primitives/sphere3d';
import { ParamDefinition as PD } from './param-definition.js';
export interface Clip {
    variant: Clip.Variant;
    objects: Clip.Objects;
}
export declare function Clip(): void;
export declare namespace Clip {
    /** Clip object types */
    const Type: {
        none: number;
        plane: number;
        sphere: number;
        cube: number;
        cylinder: number;
        infiniteCone: number;
    };
    type Variant = 'instance' | 'pixel';
    /** additional objects are ignored */
    const MaxObjectCount = 16;
    type Objects = {
        count: number;
        type: number[];
        invert: boolean[];
        position: number[];
        rotation: number[];
        scale: number[];
        /** Transform point by this before testing */
        transform: number[];
    };
    type Rotation = {
        axis: Vec3;
        angle: number;
    };
    const Params: {
        variant: PD.Select<Variant>;
        objects: PD.ObjectList<PD.Normalize<{
            type: "cube" | "cylinder" | "infiniteCone" | "none" | "plane" | "sphere";
            invert: boolean;
            position: Vec3;
            rotation: PD.Normalize<Rotation>;
            scale: Vec3;
            transform: Mat4;
        }>>;
    };
    type Params = typeof Params;
    type Props = PD.Values<Params>;
    function getClip(props: Props, clip?: Clip): Clip;
    /**
     * Plane of the clip object at `index`, in the space of the points
     * given to the clip test (i.e. with `transform` undone) and with
     * the clipped half-space on its positive side
     */
    function getPlane(out: Plane3D, objects: Objects, index: number): Plane3D;
    /**
     * Test if the surface of the clip object at `index` can intersect `sphere`,
     * exact for planes, conservative for spheres, cubes and cylinders
     */
    function canIntersectSphere(objects: Objects, index: number, sphere: Sphere3D): boolean;
    function areEqual(cA: Clip, cB: Clip): boolean;
}
//# sourceMappingURL=clip.d.ts.map