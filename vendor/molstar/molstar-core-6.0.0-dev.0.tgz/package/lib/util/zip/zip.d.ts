/**
 * Copyright (c) 2020-2024 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 *
 * ported from https://github.com/photopea/UZIP.js/blob/master/UZIP.js
 * MIT License, Copyright (c) 2018 Photopea
 *
 * - added `ungzip`
 */
import { type RuntimeContext, Task } from '@molstar/core/task';
export declare function Unzip(buf: ArrayBuffer, onlyNames?: boolean): Task<{
    [k: string]: Uint8Array<ArrayBuffer> | {
        size: number;
        csize: number;
    };
}>;
/**
 * What an archive may hold, checked from its central directory before anything is inflated: at most `maxEntries`
 * entries, their declared sizes summing to at most `maxBytes`, each local entry listed once.
 */
export interface UnzipLimits {
    readonly maxEntries: number;
    readonly maxBytes: number;
}
export declare function unzip(runtime: RuntimeContext, buf: ArrayBuffer, onlyNames?: boolean, limits?: UnzipLimits): Promise<{
    [k: string]: Uint8Array<ArrayBuffer> | {
        size: number;
        csize: number;
    };
}>;
export declare function inflateRaw(runtime: RuntimeContext, file: Uint8Array<ArrayBuffer>, buf?: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>>;
export declare function inflate(runtime: RuntimeContext, file: Uint8Array<ArrayBuffer>, buf?: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>>;
export declare function ungzip(runtime: RuntimeContext, file: Uint8Array<ArrayBuffer>, buf?: Uint8Array<ArrayBuffer>): Promise<Uint8Array<ArrayBuffer>>;
export declare function deflate(runtime: RuntimeContext, data: Uint8Array<ArrayBuffer>, opts?: {
    level: number;
}): Promise<Uint8Array<ArrayBuffer>>;
export declare function Zip(obj: {
    [k: string]: Uint8Array<ArrayBuffer>;
}, noCmpr?: boolean): Task<ArrayBuffer>;
export declare function zip(runtime: RuntimeContext, obj: {
    [k: string]: Uint8Array<ArrayBuffer>;
}, noCmpr?: boolean): Promise<ArrayBuffer>;
//# sourceMappingURL=zip.d.ts.map