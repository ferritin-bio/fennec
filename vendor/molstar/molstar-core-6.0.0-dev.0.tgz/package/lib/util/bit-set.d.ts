/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Sebastian Bittrich <sebastian.m.bittrich@gmail.com>
 */
/**
 * A dense, fixed-size bit set backed by a Uint32Array. Bits are addressed 0..nbits-1.
 *
 * Intentionally minimal — extend as needed. The in-place set operations (and/andNot/or) assume the
 * operand has the same capacity.
 */
export declare class BitSet {
    readonly nbits: number;
    readonly words: Uint32Array;
    constructor(nbits: number);
    /** A set with every bit in [0, nbits) set. */
    static full(nbits: number): BitSet;
    clone(): BitSet;
    /** Clear all bits. */
    zero(): void;
    set(i: number): void;
    clear(i: number): void;
    get(i: number): boolean;
    /** In-place intersection with `o` (same capacity). */
    and(o: BitSet): void;
    /** In-place set difference with `o` (same capacity). */
    andNot(o: BitSet): void;
    /** In-place union with `o` (same capacity). */
    or(o: BitSet): void;
    isEmpty(): boolean;
    /** Number of set bits. */
    cardinality(): number;
    /** Index of the first set bit at or after `from`, or -1 if there is none. */
    nextSetBit(from: number): number;
}
//# sourceMappingURL=bit-set.d.ts.map