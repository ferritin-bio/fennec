/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export type MarkdownInline = {
    readonly kind: 'text';
    readonly text: string;
} | {
    readonly kind: 'strong' | 'em';
    readonly children: readonly MarkdownInline[];
} | {
    readonly kind: 'code';
    readonly text: string;
} | {
    readonly kind: 'link';
    readonly href: string;
    readonly children: readonly MarkdownInline[];
} | {
    readonly kind: 'break';
};
export type MarkdownBlock = {
    readonly kind: 'heading';
    readonly level: number;
    readonly children: readonly MarkdownInline[];
} | {
    readonly kind: 'paragraph';
    readonly children: readonly MarkdownInline[];
} | {
    readonly kind: 'list';
    readonly ordered: boolean;
    readonly start: number;
    readonly items: readonly (readonly MarkdownBlock[])[];
} | {
    readonly kind: 'code';
    readonly lang: string;
    readonly text: string;
} | {
    readonly kind: 'rule';
};
/**
 * Whether a link's target is one a renderer may follow: http(s), mailto, or relative (no scheme). The scheme is read as
 * a browser's URL parser reads it: leading and trailing C0 controls and spaces stripped, tabs and newlines removed
 * anywhere (`\x01javascript:` and `java\tscript:` are `javascript:`).
 */
export declare function isSafeMarkdownHref(href: string): boolean;
/** The blocks of a Markdown text. */
export declare function parseMarkdown(source: string): MarkdownBlock[];
/** The inline marks of a run of text (a paragraph, a heading, an item). */
export declare function parseMarkdownInline(text: string): MarkdownInline[];
/** The text of inline marks (no emphasis): for labels that show plain text, and for search. */
export declare function markdownInlineText(nodes: readonly MarkdownInline[]): string;
//# sourceMappingURL=markdown.d.ts.map