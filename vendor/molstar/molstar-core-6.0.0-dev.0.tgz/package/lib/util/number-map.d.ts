/**
 * Copyright (c) 2023-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Mapping } from './multi-map.js';
/** Implementation of `Map` where keys are integers and the values are non-negative integers (so they can be kept in a typed array)
 * and most keys are expected to be from interval `[offset, offset + limit)`.
 * For the keys within this interval, performance is better than `Map` (implemented by array, 4 bytes per key).
 * For the keys out of this interval, performance is slightly worse than `Map`.
 * Keys are numbers: a key of another type has no value (it would otherwise be converted to a number by the array). */
export declare class NumberMap<K extends number, V extends number> implements Mapping<K, V> {
    readonly limit: number;
    readonly offset: number;
    private array;
    private map;
    constructor(limit: number, offset?: number);
    get(key: K): V | undefined;
    set(key: K, value: V): void;
    /** The number of keys which are not in the interval of the array */
    get overflowSize(): number;
}
//# sourceMappingURL=number-map.d.ts.map