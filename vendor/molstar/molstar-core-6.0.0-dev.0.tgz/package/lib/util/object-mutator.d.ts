/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
/**
 * Repeated immutable updates of the same paths of a plain JSON-like object, e.g. the frames of an animation
 * (MVS: `packages/mvs/runtime/_spec/animation.md §2`).
 *
 * The paths are declared once, in an `ObjectMutator.Plan` (a trie of keys, its leaves are "slots"); then each update
 * (a frame) only sets values of slots and commits. A commit copies the objects on the paths whose values changed since
 * the previous commit and keeps the identity of everything else, the previous commit's included: a commit with no
 * change returns the previous root itself, and unchanged subtrees are the same objects frame after frame.
 *
 * ```
 * const plan = ObjectMutator.plan(source);
 * plan.pushPrefix('children', 0, 'params');
 * const opacity = plan.slot('opacity');
 * plan.popPrefix();
 * const mutator = ObjectMutator.create(plan);
 * mutator.set(opacity, 0.5);
 * const next = mutator.commit(); // a copy of source with children[0].params.opacity = 0.5
 * ```
 *
 * A slot not set before a commit has the source's value at that path (the key is removed if the source has none). A
 * slot is "dead" when an object on its path is missing in the source: setting it does nothing. When a slot lies inside
 * another slot's value (the plan is not disjoint), the sets of a frame are applied in order, each copying from the
 * source, and the frame is compared with the previous commit as a whole (`deepEqual`).
 */
export interface ObjectMutator<T> {
    readonly plan: ObjectMutatorPlan<T>;
    /** The value of `slot` in the frame being built: the last value set since the previous commit, else the source's. */
    get(slot: number): unknown;
    set(slot: number, value: unknown): void;
    /** The object with this frame's values; the previous commit's root (or the source) when nothing differs from it. */
    commit(): T;
}
type Key = string | number;
export declare class ObjectMutatorPlan<T> {
    readonly source: T;
    /** Trie nodes: 0 is the root; `keys[i]` is the key of node `i` in the object of its parent. */
    readonly keys: Key[];
    readonly parents: number[];
    readonly children: number[][];
    readonly childByKey: Map<string, number>[];
    /** Slot of a trie node, -1 for inner nodes. */
    readonly slotOfNode: number[];
    /** Trie node of a slot. */
    readonly slotNodes: number[];
    /** Keys from the root to the slot. */
    readonly slotPaths: Key[][];
    private prefix;
    private prefixLengths;
    constructor(source: T);
    pushPrefix(...keys: Key[]): void;
    popPrefix(): void;
    /** The slot at the current prefix followed by `path`; the same path gives the same slot. */
    slot(path: Key | Key[]): number;
    /** No slot lies inside another slot's value. */
    get isDisjoint(): boolean;
}
export declare const ObjectMutator: {
    plan<T>(source: T): ObjectMutator.Plan<T>;
    /** `equals` compares a slot's value with the previous one (`deepEqual` by default); the plan not disjoint, whole trees */
    create<T>(plan: ObjectMutator.Plan<T>, options?: {
        equals?: (a: unknown, b: unknown) => boolean;
    }): ObjectMutator<T>;
};
export declare namespace ObjectMutator {
    type Plan<T> = ObjectMutatorPlan<T>;
}
export {};
//# sourceMappingURL=object-mutator.d.ts.map