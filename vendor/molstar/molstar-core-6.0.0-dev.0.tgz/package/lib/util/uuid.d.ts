/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
/** A UUID, either standard 36 characters or 22 characters base64 encoded. */
type UUID = string & {
    '@type': 'uuid';
};
declare namespace UUID {
    /**
     * Creates a 22 characters id in the URL-safe base64 alphabet: a random prefix (per process, renewed every 2^48 ids)
     * and a counter. Unique within the process by the counter and across processes by the prefix; not an RFC 4122 UUID,
     * not random per call, not a secret. Creating one is a string concatenation (ids are made for every state transform
     * and its version, many per frame of an animation).
     */
    function create22(): UUID;
    function createv4(): UUID;
    function is(x: any): x is UUID;
}
export { UUID };
//# sourceMappingURL=uuid.d.ts.map