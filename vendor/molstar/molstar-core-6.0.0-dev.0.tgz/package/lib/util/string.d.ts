/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export declare function indentString(str: string, count: number, indent: string): string;
/** Add space between camelCase text. */
export declare function splitCamelCase(str: string, separator?: string): string;
/** Split camelCase text and capitalize. */
export declare function camelCaseToWords(str: string): string;
export declare const lowerCase: (str: string) => string;
export declare const upperCase: (str: string) => string;
/** Return upper case if string, otherwise return empty string */
export declare function upperCaseAny(value: any): string;
/** Uppercase the first character of each word. */
export declare function capitalize(str: string): string;
export declare function splitSnakeCase(str: string): string;
export declare function snakeCaseToWords(str: string): string;
export declare function splitKebabCase(str: string): string;
export declare function kebabCaseToWords(str: string): string;
export declare function stringToWords(str: string): string;
export declare function substringStartsWith(str: string, start: number, end: number, target: string): boolean;
export declare function interpolate(str: string, params: {
    [k: string]: any;
}): string;
/** Validate that a path template only uses supported `${id…}` expressions. */
export declare function validateIdPathTemplate(template: string): void;
export declare function interpolateIdPath(template: string, id: string): string;
export declare function trimChar(str: string, char: string): string;
export declare function trimCharStart(str: string, char: string): string;
export declare function trimCharEnd(str: string, char: string): string;
/** Simple function to strip tags from a string */
export declare function stripTags(str: string): string;
/**
 * Escape string for use in Javascript regex
 *
 * From https://stackoverflow.com/questions/3446170/escape-string-for-use-in-javascript-regex/6969486#6969486
 */
export declare function escapeRegExp(str: string): string;
//# sourceMappingURL=string.d.ts.map