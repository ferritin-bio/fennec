/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Vec2 } from '@molstar/core/math/linear-algebra/3d/vec2';
export declare function eventOffset(out: Vec2, ev: MouseEvent | Touch, target: Element): Vec2;
//# sourceMappingURL=event-offset.d.ts.map