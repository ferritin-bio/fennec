/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Color } from './color/index.js';
import type { ColorListEntry } from './color/color.js';
export type Legend = TableLegend | ScaleLegend;
export interface TableLegend {
    kind: 'table-legend';
    table: [string, Color][];
}
export declare function TableLegend(table: [string, Color][]): TableLegend;
export interface ScaleLegend {
    kind: 'scale-legend';
    minLabel: string;
    maxLabel: string;
    colors: ColorListEntry[];
}
export declare function ScaleLegend(minLabel: string, maxLabel: string, colors: ColorListEntry[]): ScaleLegend;
//# sourceMappingURL=legend.d.ts.map