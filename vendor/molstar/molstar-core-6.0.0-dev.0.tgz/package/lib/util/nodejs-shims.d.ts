/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Adam Midlik <midlik@gmail.com>
 * @author Russell Parker <russell@benchling.com>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * Implements some browser-only global variables for Node.js environment.
 * These workarounds will also work in browsers as usual.
 */
/** Determines whether the current code is running in Node.js */
export declare const RUNNING_IN_NODEJS: boolean;
/**
 * Like `File` but works also in Node.js: the native `File` wherever there is one (browsers, Node.js 20 and later), so a
 * file a host or a test makes with `new File(...)` is the same class the asset manager checks for; a shim otherwise.
 */
export declare const File_: {
    new (fileBits: BlobPart[], fileName: string, options?: FilePropertyBag): File;
    prototype: File;
};
//# sourceMappingURL=nodejs-shims.d.ts.map