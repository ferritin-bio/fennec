/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
export declare function makeDir(path: string, root?: string): boolean;
//# sourceMappingURL=make-dir.d.ts.map