/**
 * Copyright (c) 2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { ColorSwatch } from './color.js';
export declare const DefaultColorSwatch: ColorSwatch;
//# sourceMappingURL=swatches.d.ts.map