/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Zach Charlop-Powers <zach.charlop.powers@gmail.com>
 */
import { Color, type ColorListEntry } from './color.js';
export declare function decodeColor(colorString: string | undefined | null): Color | undefined;
export declare function getColorGradientBanded(colors: ColorListEntry[]): string;
export declare function getColorGradient(colors: ColorListEntry[]): string;
export declare function parseColorList(input: string, separator?: RegExp): ColorListEntry[];
//# sourceMappingURL=utils.d.ts.map