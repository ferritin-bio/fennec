/**
 * Copyright (c) 2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author ReliaSolve <russ@reliasolve.com>
 *
 * Adapted from kin-parser.ts file from the NGL project:
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * Adapted from hsl.ts in this same directory:
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Color } from '../color.js';
import { Rgb } from './rgb.js';
export { Hsv };
/** Hsv tuple: [h, s, v]
 *  - h in [0,360] degrees
 *  - s in [0,100] percent
 *  - v in [0,100] percent
 */
interface Hsv extends Array<number> {
    [d: number]: number;
    '@type': 'hsv';
    length: 3;
}
declare function Hsv(): Hsv;
declare namespace Hsv {
    function zero(): Hsv;
    /** Copy values from an array-like 3-tuple into `out`. */
    function fromArray(arr: ArrayLike<number>): Hsv;
    function toColor(hsv: Hsv): Color;
    function toRgb(out: Rgb, hsv: Hsv): Rgb;
}
//# sourceMappingURL=hsv.d.ts.map