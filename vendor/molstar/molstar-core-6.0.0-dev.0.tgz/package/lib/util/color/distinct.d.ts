/**
 * Copyright (c) 2019-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 *
 * adapted from https://github.com/internalfx/distinct-colors (ISC License Copyright (c) 2015, InternalFX Inc.)
 * which is heavily inspired by http://tools.medialab.sciences-po.fr/iwanthue/
 */
import { ParamDefinition as PD } from '../param-definition.js';
import { Color } from './color.js';
export declare const DistinctColorsParams: {
    hue: PD.Interval;
    chroma: PD.Interval;
    luminance: PD.Interval;
    sort: PD.Select<"contrast" | "none">;
    clusteringStepCount: PD.Numeric;
    minSampleCount: PD.Numeric;
    sampleCountFactor: PD.Numeric;
};
export type DistinctColorsParams = typeof DistinctColorsParams;
export type DistinctColorsProps = PD.Values<typeof DistinctColorsParams>;
/**
 * Create a list of visually distinct colors
 */
export declare function distinctColors(count: number, props?: Partial<DistinctColorsProps>): Color[];
/**
 * Create a list of distinct colors within a hue range around the given base color.
 * Use to color the members of a group that has `color` assigned to it.
 */
export declare function getDistinctGroupColors(count: number, color: Color, variability: number, shift: number, props?: Partial<DistinctColorsProps>): Color[];
/**
 * Create a list of distinct colors spanning the full hue range.
 * Use to color groups, e.g. as base colors for `getDistinctGroupColors`.
 */
export declare function getDistinctBaseColors(count: number, shift: number, props?: Partial<DistinctColorsProps>): Color[];
//# sourceMappingURL=distinct.d.ts.map