/**
 * Copyright (c) 2019-2021 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { Color } from './index.js';
import { type ScaleLegend, TableLegend } from '../legend.js';
import { ParamDefinition as PD } from '../param-definition.js';
import { type ColorListName } from './lists.js';
type PaletteType = 'generate' | 'colors';
declare const DefaultGetPaletteProps: {
    type: PaletteType;
    colorList: ColorListName;
};
type GetPaletteProps = typeof DefaultGetPaletteProps;
export declare function getPaletteParams(props?: Partial<GetPaletteProps>): {
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("./color.js").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
};
declare const DefaultPaletteProps: PD.Values<{
    palette: PD.Mapped<PD.NamedParams<PD.Normalize<{
        list: {
            kind: 'interpolate' | 'set';
            colors: import("./color.js").ColorListEntry[];
        };
    }>, "colors"> | PD.NamedParams<PD.Normalize<{
        hue: [number, number];
        chroma: [number, number];
        luminance: [number, number];
        sort: "contrast" | "none";
        clusteringStepCount: number;
        minSampleCount: number;
        sampleCountFactor: number;
        maxCount: number;
    }>, "generate">>;
}>;
type PaletteProps = typeof DefaultPaletteProps;
declare const DefaultLabelOptions: {
    valueLabel: (i: number) => string;
    minLabel: string;
    maxLabel: string;
};
type LabelOptions = typeof DefaultLabelOptions;
export interface Palette {
    color: (i: number) => Color;
    legend?: TableLegend | ScaleLegend;
}
export declare function getPalette(count: number, props: PaletteProps, labelOptions?: Partial<LabelOptions>): {
    color: (i: number) => Color;
    legend: ScaleLegend | TableLegend;
};
export {};
//# sourceMappingURL=palette.d.ts.map