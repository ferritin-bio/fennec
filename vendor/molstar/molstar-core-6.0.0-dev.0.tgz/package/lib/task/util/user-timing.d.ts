/**
 * Copyright (c) 2018-2019 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import type { Task } from '../task.js';
export declare namespace UserTiming {
    function markStart(task: Task<any>): void;
    function markEnd(task: Task<any>): void;
    function measure(task: Task<any>): void;
}
//# sourceMappingURL=user-timing.d.ts.map