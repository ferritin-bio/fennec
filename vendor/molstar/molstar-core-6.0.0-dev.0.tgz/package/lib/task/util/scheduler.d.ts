/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
declare const Scheduler: {
    setImmediate: ((callback: (...args: any[]) => void, ...args: any[]) => number) | typeof setImmediate;
    clearImmediate: ((handle: number) => void) | typeof clearImmediate;
    immediatePromise(): Promise<void>;
    delay<T>(timeout: number, value?: T | undefined): Promise<T>;
};
export { Scheduler };
//# sourceMappingURL=scheduler.d.ts.map