/**
 * Copyright (c) 2017 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { Column } from './column.js';
export declare function getArrayBounds(rowCount: number, params?: Column.ToArrayParams<any>): {
    start: number;
    end: number;
};
export declare function createArray(rowCount: number, params?: Column.ToArrayParams<any>): {
    array: any[];
    start: number;
    end: number;
};
export declare function fillArrayValues(value: (row: number) => any, target: any[], start: number): any[];
export declare function createAndFillArray(rowCount: number, value: (row: number) => any, params?: Column.ToArrayParams<any>): any[];
export declare function isTypedArray(data: any): boolean;
export declare function typedArrayWindow(data: any, params?: Column.ToArrayParams<any>): ReadonlyArray<number>;
/**
 * Like `typedArrayWindow` but honors a BinaryCIF mask, returning `defaultValue` for
 * masked (i.e. missing) values instead of whatever happens to be in the data array.
 */
export declare function typedArrayWindowMasked(data: any, mask: ArrayLike<number>, defaultValue: number, params?: Column.ToArrayParams<any>): ReadonlyArray<number>;
//# sourceMappingURL=column-helpers.d.ts.map