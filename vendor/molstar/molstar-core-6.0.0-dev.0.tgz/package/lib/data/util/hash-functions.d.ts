/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 * @author Adam Midlik <midlik@gmail.com>
 */
export declare function hash1(i: number): number;
export declare function hash2(i: number, j: number): number;
export declare function hash3(i: number, j: number, k: number): number;
export declare function hash4(i: number, j: number, k: number, l: number): number;
export declare function hashString(s: string): number;
/**
 * A unique number for each pair of integers
 * Biggest representable pair is (67108863, 67108863) (limit imposed by Number.MAX_SAFE_INTEGER)
 */
export declare function cantorPairing(a: number, b: number): number;
/**
 * A unique number for each sorted pair of integers
 * Biggest representable pair is (67108863, 67108863) (limit imposed by Number.MAX_SAFE_INTEGER)
 */
export declare function sortedCantorPairing(a: number, b: number): number;
export declare function invertCantorPairing(out: [number, number], z: number): [number, number];
/**
 * 32 bit FNV-1a hash, see http://isthe.com/chongo/tech/comp/fnv/
 */
export declare function hashFnv32a(array: ArrayLike<number>): number;
/**
 * 256 bit FNV-1a hash, returns 8 32-bit words
 * Based on the FNV-1a algorithm extended to 256 bits
 */
export declare function hashFnv256a(array: ArrayLike<number>, out: Uint32Array): Uint32Array<ArrayBufferLike>;
/**
 * 256-bit object hash function using FNV-1a
 */
export declare function hashFnv256o(obj: any): string;
/**
 * 32-bit Murmur hash of `JSON.stringify(obj)` (its UTF-8 bytes)
 */
export declare function hashMurmur32o(obj: any, seed?: number): number;
/**
 * 128-bit Murmur hash of `JSON.stringify(obj)` (its UTF-8 bytes)
 */
export declare function hashMurmur128o(obj: any, seed?: number): string;
/**
 * MurmurHash3_x86_32 of the UTF-8 bytes of a string
 * @param key - The input string to hash
 * @param seed - The seed value
 * @returns The 32-bit hash as a number
 */
export declare function murmurHash3_32(key: string, seed: number): number;
/**
 * MurmurHash3_x86_32 of bytes
 * @param key - The input data to hash
 * @param seed - The seed value
 * @returns The 32-bit hash as a number
 */
export declare function murmurHash3_32_fromBytes(key: Uint8Array, seed: number): number;
/**
 * MurmurHash3_x86_128 of bytes
 * @param key - The input data to hash
 * @param seed - The seed value
 * @returns The 128-bit hash as a hexadecimal string (h1 to h4, each as 8 hex digits)
 */
export declare function murmurHash3_128_fromBytes(key: Uint8Array, seed: number): string;
/**
 * MurmurHash3_x86_128 of the UTF-8 bytes of a string
 * @param key - The input string to hash
 * @param seed - The seed value
 * @returns The 128-bit hash as a hexadecimal string (h1 to h4, each as 8 hex digits)
 */
export declare function murmurHash3_128(key: string, seed: number): string;
/**
 * PCG pseudo-random number generator
 * See https://www.pcg-random.org/ and https://jcgt.org/published/0009/03/02/
 */
export declare class PCG {
    private state;
    constructor(seed?: number);
    /**
     * 32-bit unsigned integer
     */
    int(): number;
    /**
     * Float in [0, 1)
     */
    float(): number;
}
export declare function mortonOrder3d(x: number, y: number, z: number): number;
export declare function invertMortonOrder3d(code: number): [number, number, number];
//# sourceMappingURL=hash-functions.d.ts.map