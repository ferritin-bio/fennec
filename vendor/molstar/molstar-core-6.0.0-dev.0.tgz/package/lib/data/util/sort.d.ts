/**
 * Copyright (c) 2017-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
export type Comparer<T = any> = (data: T, i: number, j: number) => number;
export type Swapper<T = any> = (data: T, i: number, j: number) => void;
export declare function arrayLess(arr: ArrayLike<number>, i: number, j: number): number;
export declare function arraySwap(arr: ArrayLike<any>, i: number, j: number): void;
export declare function sortArray(data: ArrayLike<number>, cmp?: Comparer<ArrayLike<number>>): ArrayLike<number>;
export declare function sortArrayRange(data: ArrayLike<number>, start: number, end: number, cmp?: Comparer<ArrayLike<number>>): ArrayLike<number>;
export declare function sort<T>(data: T, start: number, end: number, cmp: Comparer<T>, swap: Swapper<T>): T;
/**
 * In-place LSD radix sort (8-bit digits) for non-negative integers, ascending.
 * `maxValue` is an inclusive upper bound of the values and determines the number
 * of passes; it is computed from the data when omitted.
 *
 * Typically outperforms comparison sorts, at the cost of a scratch
 * array allocation of the same size as the input.
 */
export declare function radixSort<T extends Int32Array | Uint32Array>(data: T, maxValue?: number): T;
//# sourceMappingURL=sort.d.ts.map