/**
 * Copyright (c) 2018 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import type { StateAction } from '../action.js';
import type { StateObjectCell } from '../object.js';
import { StateTransformer } from '../transformer.js';
import { UUID } from '@molstar/core/util';
export { StateActionManager };
declare class StateActionManager {
    private ev;
    /** Registered actions with the number of registrations, keyed by action id. */
    private actions;
    private fromTypeIndex;
    readonly events: {
        added: import("rxjs").Subject<undefined>;
        removed: import("rxjs").Subject<undefined>;
    };
    /** Registering the same action again increments its count; `added` fires only when the action first appears. */
    add(actionOrTransformer: StateAction | StateTransformer): this;
    /**
     * Decrements the count of the action; it is removed (and `removed` fires) when the count reaches zero.
     * Removing an unknown action is a no-op.
     */
    remove(actionOrTransformer: StateAction | StateTransformer | UUID): this;
    /** Registering an action never conflicts: the same action is counted, distinct actions have distinct ids. */
    findConflict(_actionOrTransformer: StateAction | StateTransformer): string | undefined;
    fromCell(cell: StateObjectCell, ctx: unknown): ReadonlyArray<StateAction>;
    dispose(): void;
}
//# sourceMappingURL=manager.d.ts.map