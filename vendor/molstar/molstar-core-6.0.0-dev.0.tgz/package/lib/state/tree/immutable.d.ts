/**
 * Copyright (c) 2018-2025 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 */
import { OrderedSet } from 'immutable';
import { StateTransform } from '../transform.js';
import { TransientTree } from './transient.js';
export { StateTree };
/**
 * An immutable tree where each node requires a unique reference.
 * Represented as an immutable map.
 */
interface StateTree {
    readonly root: StateTransform;
    readonly transforms: StateTree.Transforms;
    readonly children: StateTree.Children;
    /** Refs to all nodes that depend on the given key */
    readonly dependencies: StateTree.Dependencies;
    asTransient(): TransientTree;
}
declare namespace StateTree {
    type Ref = StateTransform.Ref;
    export interface ChildSet {
        readonly size: number;
        readonly values: OrderedSet<Ref>['values'];
        has(ref: Ref): boolean;
        readonly forEach: OrderedSet<Ref>['forEach'];
        readonly map: OrderedSet<Ref>['map'];
        toArray(): Ref[];
        first(defaultValue?: Ref): Ref | undefined;
        asMutable(): MutableChildSet;
    }
    export interface MutableChildSet extends ChildSet {
        add(ref: Ref): MutableChildSet;
        remove(ref: Ref): MutableChildSet;
        asImmutable(): ChildSet;
    }
    interface _Map<T> {
        readonly size: number;
        has(ref: Ref): boolean;
        get(ref: Ref): T;
        asImmutable(): _Map<T>;
        asMutable(): MutableMap<T>;
    }
    export interface MutableMap<T> extends _Map<T> {
        set(ref: Ref, value: T): MutableMap<T>;
        delete(ref: Ref): MutableMap<T>;
    }
    export interface Transforms extends _Map<StateTransform> {
    }
    export interface Children extends _Map<ChildSet> {
    }
    export interface Dependencies extends _Map<ChildSet> {
    }
    export interface MutableTransforms extends MutableMap<StateTransform> {
    }
    export interface MutableChildren extends MutableMap<MutableChildSet> {
    }
    export interface MutableDependencies extends MutableMap<MutableChildSet> {
    }
    /**
     * Create an instance of an immutable tree.
     */
    export function createEmpty(customRoot?: StateTransform): StateTree;
    export function create(nodes: Transforms, children: Children, dependencies: Dependencies): StateTree;
    /**
     * Visit all nodes in a subtree in "post order", meaning leafs get visited first.
     */
    export function doPostOrder<S>(tree: StateTree, root: StateTransform, state: S, f: (node: StateTransform, tree: StateTree, state: S) => boolean | undefined | void): S;
    /**
     * Visit all nodes in a subtree in "pre order", meaning leafs get visited last.
     * If the visitor function returns false, the visiting for that branch is interrupted.
     */
    export function doPreOrder<S>(tree: StateTree, root: StateTransform, state: S, f: (node: StateTransform, tree: StateTree, state: S) => boolean | undefined | void): S;
    /**
     * Get all nodes in a subtree, leafs come first.
     */
    export function subtreePostOrder(tree: StateTree, root: StateTransform): StateTransform<import("../transformer.js").StateTransformer<import("../object.js").StateObject<any, import("../object.js").StateObject.Type<any>>, import("../object.js").StateObject<any, import("../object.js").StateObject.Type<any>>, any>>[];
    export interface Serialized {
        /** Transforms serialized in pre-order */
        transforms: StateTransform.Serialized[];
    }
    export function toJSON(tree: StateTree): Serialized;
    export function fromJSON(data: Serialized): StateTree;
    export function dump(tree: StateTree): void;
    /** Check if the subtree with the given root has the provided ref */
    export function subtreeHasRef(tree: StateTree, root: StateTransform.Ref, ref: StateTransform.Ref): boolean;
    export function getDecoratorRoot(tree: StateTree, ref: StateTransform.Ref): StateTransform.Ref;
    export function setParamHashVersion(tree: StateTree, refs: StateTransform.Ref[]): void;
    /** Re-use parameters of transforms with the same ref, transformer, and version */
    export function reuseTransformParams(destination: StateTree.Serialized, source: StateTree.Serialized): void;
    export {};
}
//# sourceMappingURL=immutable.d.ts.map