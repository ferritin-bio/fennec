/**
 * Copyright (c) 2018-2026 mol* contributors, licensed under MIT, See LICENSE file for more info.
 *
 * @author David Sehnal <david.sehnal@gmail.com>
 * @author Alexander Rose <alexander.rose@weirdbyte.de>
 */
import { StateTransformer } from './transformer.js';
import { ParamDefinition as PD } from '@molstar/core/util/param-definition';
export { Transform as StateTransform };
interface Transform<T extends StateTransformer = StateTransformer> {
    readonly parent: Transform.Ref;
    readonly transformer: T;
    readonly state: Transform.State;
    readonly tags?: string[];
    readonly ref: Transform.Ref;
    /**
     * Sibling-like dependency
     * Do NOT make a cell dependent on its ancestor.
     */
    readonly dependsOn?: Transform.Ref[];
    readonly params?: StateTransformer.Params<T>;
    readonly version: string;
}
declare namespace Transform {
    type Ref = string;
    type Transformer<T extends Transform> = T extends Transform<infer S> ? S : never;
    const RootRef: Ref;
    interface State {
        isGhost?: boolean;
        isLocked?: boolean;
        isHidden?: boolean;
        isCollapsed?: boolean;
    }
    function isStateChange(a: State, b?: Partial<State>): boolean;
    function assignState(a: State, b?: Partial<State>): boolean;
    function syncState(a: State, b?: Partial<State>): boolean;
    interface Options {
        ref?: string;
        tags?: string | string[];
        state?: State;
        dependsOn?: Ref[];
    }
    function create<T extends StateTransformer>(parent: Ref, transformer: T, params?: StateTransformer.Params<T>, options?: Options): Transform<T>;
    function withParams(t: Transform, params: any): Transform;
    function withState(t: Transform, state?: Partial<State>): Transform;
    function withTags(t: Transform, newTags?: string | string[]): Transform;
    function withDependsOn(t: Transform, newDependsOn?: string | string[]): Transform;
    function withParent(t: Transform, parent: Ref): Transform;
    function createRoot(state?: State): Transform;
    function hasTag(t: Transform, tag: string): boolean;
    function hasTags(t: Transform, tags: string | string[]): boolean;
    /**
     * Returns the default param schema for the transform's transformer, caching
     * the result on the transform instance. Returns `undefined` if the transformer
     * has no `params` definition or if calling it throws.
     */
    function tryGetDefaultParamDefinition(t: Transform): PD.Params | undefined;
    /**
     * Compute the effective set of sibling-like dependencies for a transform.
     *
     * Combines (in order, de-duplicated):
     *   1. Explicit `t.dependsOn` (back-compat / non-param refs).
     *   2. Refs from `transformer.definition.getDependencies(params)` if defined.
     *   3. Refs collected from `PD.ValueRef` / `PD.DataRef` parameter values.
     *
     * Self-references and the root ref are filtered out. If the param schema
     * can't be obtained, auto-derivation falls back to a structural scan of
     * parameter values for `{ ref, getValue }` shaped objects.
     */
    function getEffectiveDependsOn(t: Transform): Ref[];
    /** Updates the version of the transform to be computed as hash of the parameters */
    function setParamsHashVersion(t: Transform): void;
    interface Serialized {
        parent: string;
        transformer: string;
        params: any;
        state?: State;
        tags?: string[];
        isDecorator?: boolean;
        ref: string;
        dependsOn?: string[];
        version: string;
    }
    function toJSON(t: Transform): Serialized;
    function fromJSON(t: Serialized): Transform;
}
//# sourceMappingURL=transform.d.ts.map